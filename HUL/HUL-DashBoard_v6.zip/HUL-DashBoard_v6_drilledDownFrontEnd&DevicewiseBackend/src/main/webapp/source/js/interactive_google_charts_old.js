myApp.controller('charts', ['$scope', '$http', 'HUL_CONST', '$timeout', '$location', '$rootScope', '$routeParams', function ($scope, $http, HUL_CONST, $timeout, $location, $rootScope, $routeParams) {

        $scope.removeSelected = function (obj, filterscopetype, selectedscope) {
            $rootScope.removeFromArray(obj, $scope.configParam[selectedscope]);
            $scope.filterLocationData($scope.allDropdowndata, filterscopetype, selectedscope, false);
            if ($scope.checkDefaultData()) {
                $scope.drawChart(true);
            } else {
                $scope.redrawChart();
            }
            if ($scope.configParam.selectedRegion.length == 0) {
                $scope.isDisabled = true;
                $scope.setSelectedToDefault();
            }

        }
        $scope.checkDefaultData = function () {
            var def = true;
            for (var j = 0; j < $scope.initscope.length; j++) {
                if ($scope.configParam[$scope.initscope[j].selectedscope].length > 0) {
                    def = false;
                    break;
                }
            }
            return def;
        }
        $scope.changeTrend = function (trendType) {
            $scope.trendType = trendType;
            $location.path("/index/" + trendType);
        };
        $scope.drawColdChain = function (actdata) {
            var temparr = $scope.filterbyDataSelected(actdata, $scope.configParam.selectedColdChain);
            var data2 = google.visualization.arrayToDataTable(temparr);
            var groupedColumnColdChain = new google.visualization.ColumnChart(document.getElementById('groupedColumnColdChain'));
            $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
            var getDataByColdChain = function () {
                var selectedItem = groupedColumnColdChain.getSelection()[0];
                if ($scope.configParam.selectedColdChain.length > 0 && selectedItem) {
                    var topping = data2.getValue(selectedItem.row, 0);
                    if ($scope.configParam.selectedColdChain.indexOf(topping) > -1) {
                        $scope.removeFromArray(topping, $scope.configParam.selectedColdChain);
                        $scope.redrawChart();
                    }
                } else {
                    $scope.configParam.selectedColdChain = [];
                    if (selectedItem) {
                        var topping = data2.getValue(selectedItem.row, 0);
                        $scope.configParam.selectedColdChain.push(topping);
                        $scope.redrawChart();
                    }
                }
                $scope.$apply();
            };
            google.visualization.events.addListener(groupedColumnColdChain, 'select', getDataByColdChain);
            google.visualization.events.addListener(groupedColumnColdChain, 'ready', function () {
                var content = '<img alt="By Cold Chain" src="' + groupedColumnColdChain.getImageURI() + '">';
                $('#graph-images').append(content);
            });
            groupedColumnColdChain.draw(data2, $scope.googlecharts);
        }
        $scope.indiaComplianceMonitoring = function () {
            $scope.openModal();
            $timeout(function () {
                var options = $scope.getDountConfig();
                var total = 0;
                var act = 0;
                $.each($scope.othergraphall, function (key, value) {//othergraphall means it contains all data with locsubtype 2
                    value = $scope.reformateGraphData(true, value);// we are removing locsubtype 2;
                    for (var j = 0; j < $scope.temperatureRange.length; j++) {
                        var tr = $scope.temperatureRange[j].type;
                        total += value[tr].length;
                        if (tr == "-20 & below")
                            act += value[tr].length;
                    }
                });
                var per = $scope.getPercentage(act, total);
                var col = $scope.getComplianceColor(per);
                options.slices = {0: {color: col}};
                var data = google.visualization.arrayToDataTable([
                    ['India', '%Compliance'],
                    ['Compliance', per]
                ]);
                var chart = new google.visualization.PieChart(document.getElementById('indiaComplianceMonitoring'));
                chart.draw(data, options);
                $scope.closeModal();
//                $("#indiaComplianceMonitoringoverlay").html("");
//                $("#indiaComplianceMonitoringoverlay").html('<a class="popover_href_style" href="javascript:void(0)" title="% Compliance" data-toggle="popover" data-trigger="hover" data-placement="top"  data-content="'+per+'(100%)"><b>'+per+'%</b></a>');
//                $('[data-toggle="popover"]').popover();
            }, 2000);
        }
        $scope.getDountConfig = function () {
            return  {
                pieHole: 0.6,
                legend: 'none',
                pieSliceText: 'value',
                pieSliceTextStyle: {
                    color: 'black',
                    fontSize: 20
                }
            };
        }
        $scope.panIndiaComplianceMonitoring = function () {
            $scope.openModal();
            $timeout(function () {
                $.each($scope.othergraphall, function (key, value) {
                    var total = 0;
                    var act = 0;
                    var graphid = "panindiaComplianceMonitoring_" + key.toLowerCase();
                    if (key == 'FACTORY' || key == 'RS Cold Room' || key == 'DEPOT') {
                        value = $scope.reformateGraphData(true, value);
                    }
                    if (key == 'RS Cold Room') {
                        graphid = "panindiaComplianceMonitoring_rsc";
                    }
                    for (var j = 0; j < $scope.temperatureRange.length; j++) {
                        var tr = $scope.temperatureRange[j].type;
                        total += value[tr].length;
                        if (tr == "-20 & below")
                            act = value[tr].length;
                    }
                    var per = $scope.getPercentage(act, total);
                    var col = $scope.getComplianceColor(per);
                    var options = $scope.getDountConfig();
                    options.slices = {0: {color: col}};
                    var data = google.visualization.arrayToDataTable([
                        ['Cold Chain', '%Compliance'],
                        [key, per]
                    ]);
                    if (Number(per) == 0) {
                        $("#" + graphid).html("");
                        $("#" + graphid).html("<div style='height:200px;padding-top:100px;padding-left:80px';>Data is not available related  to  selected filter for " + key + "</div>");
                    } else {
                        var chart = new google.visualization.PieChart(document.getElementById(graphid));
                        chart.draw(data, options);
                    }
                });
                $scope.closeModal();
            }, 2000);
        }
        $scope.reformateGraphData = function (condition, objvalue) {// we need reformate data based on if weneed locsubtype = 2 or not & get return back to the user
// if condition== false means we need all data if true  we need only location subtype!=2  data;
//param = factory parameter 
            if (!condition) {
                return objvalue;
            }
            var tempobj = [];
            for (var j = 0; j < $scope.temperatureRange.length; j++) {
                var tr = $scope.temperatureRange[j].type;
                if (objvalue[tr].length > 0) {
                    var temp = [];
                    for (var i = 0; i < objvalue[tr].length; i++) {
                        if (objvalue[tr][i].locSubType != "2") {
                            temp.push(objvalue[tr][i]);
                        }
                    }
                    tempobj[tr] = temp;
                } else {
                    tempobj[tr] = [];
                }
            }
            return tempobj;
        }
        $scope.getPercentage = function (val, total) {
            var num = (val / total) * 100;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.getComplianceColor = function (per) {
            for (var i = 0; i < $scope.indiaCompliance.length; i++) {
                if (per >= Number($scope.indiaCompliance[i].min) && per <= Number($scope.indiaCompliance[i].max)) {
                    return $scope.indiaCompliance[i].color;
                }
            }
        }
        $scope.getAnteRoomPer = function (coldchain) {
            if ($scope.othergraphall != undefined) {
                var ccdata = $scope.othergraphall[coldchain];
                var total = 0;
                var act = 0;
                for (var j = 0; j < $scope.temperatureRange.length; j++) {
                    var tr = $scope.temperatureRange[j].type;
                    if (ccdata[tr].length > 0 && tr == "-20 & below") {
                        total += ccdata[tr].length;
                        var temp = [];
                        for (var i = 0; i < ccdata[tr].length; i++) {
                            if (ccdata[tr][i].locSubType == "2" && Number(ccdata[tr][i].paramValue) <= -5) {
                                temp.push(ccdata[tr][i]);
                            }
                        }
                        act = temp.length;
                    }
                }
                var num = (act / total) * 100;
                if (isNaN(num)) {
                    return 0;
                } else {
                    if (Number(num) == 0) {
                        return 0;
                    }
                    return num.toFixed(2);
                }
            }
        }
        $scope.drawRegionChart = function (actdata) {
            $("#secondgraph").css("display", "block");
            $("#thirdgraph").css("display", "none");
            var temparr = $scope.filterbyDataSelected(actdata, $scope.configParam.selectedRegion);
            $scope.googlecharts.bar.groupWidth = 74;
            var data = google.visualization.arrayToDataTable(temparr);
            var groupedColumnRegion = new google.visualization.ColumnChart(document.getElementById('groupedColumnRegion'));
            var getDataByColumnRegion = function () {
                var selectedItem = groupedColumnRegion.getSelection()[0];
                if ($scope.configParam.selectedRegion.length > 0 && selectedItem) {
                    var topping = data.getValue(selectedItem.row, 0);
                    if ($scope.configParam.selectedRegion.indexOf(topping) > -1) {
                        $scope.removeFromArray(topping, $scope.configParam.selectedRegion);
                        $scope.redrawChart();
                    }
                } else {
                    $scope.configParam.selectedRegion = [];
                    if (selectedItem) {
                        var topping = data.getValue(selectedItem.row, 0);
                        $scope.configParam.selectedRegion.push(topping);
                        $scope.redrawChart();
                    }
                }
                $scope.$apply();
            };
            google.visualization.events.addListener(groupedColumnRegion, 'select', getDataByColumnRegion);
            google.visualization.events.addListener(groupedColumnRegion, 'ready', function () {
                var content = '<img alt="By Region" src="' + groupedColumnRegion.getImageURI() + '">';
                $('#graph-images').append(content);
            });
            groupedColumnRegion.draw(data, $scope.googlecharts);
        }
        $scope.drawChart = function (byDefault) {
            $scope.openModal();
            if (byDefault) {
                var requestName = "fetchDefaultValues";
                $scope.selectedFilter = $scope.temperatureRange;
            } else {
                var requestName = "fetchChartValues";
            }
            //console.log(requestName);
         //   $http.get(tempContextPath + "/data/fetchdata.json").success(function (data) {
            //console.log(JSON.stringify($scope.selectedFilter));
            $http.post(tempContextPath + "/" + requestName, $scope.selectedFilter).success(function (data) {
                 $scope.region = data.region;
                 $scope.othergraph=data.coldChain;
                 $scope.othergraphall=data.coldChain;
                 $scope.othergraphavg=data.coldChainavg;
                 $scope.redrawChart();

            });
        };
        $scope.filterbyDataSelected = function (actdata, selarr) {
            var temparr = [];
            for (var i = 0; i < actdata.length; i++) {
                var inner_x_axis_val = actdata[i][0];
                if (inner_x_axis_val == '' || selarr.length == 0 || selarr.indexOf(inner_x_axis_val) > -1) {
                    temparr.push(actdata[i]);
                }
            }
            return temparr;
        }

        $scope.checkFilterDatalength = function (data, coldchain) {
            var filterd = [];
            for (var i = 0; i < data.length; i++) {
                var value = data[i];
                if (value.branchType == coldchain) {
                    filterd.push(value);
                }
            }
            if (filterd.length == 0) {
                return true;
            } else {
                return false;
            }
        };

        $scope.drawSelectdDropdownChart = function (data, type) {// type = RSV PT,ETC
//            $scope.openModal();
            $timeout(function () {
                var locCode = data.locCode;
                if ($scope.configParam.selectedDeviceID.indexOf(locCode) == -1) {
                    $scope.configParam.selectedDeviceID.push(locCode);
                    $scope.selectedindex.push(type);
                } else {
                    $scope.selectedindex.splice($scope.configParam.selectedDeviceID.indexOf(locCode), 1);
                    $scope.removeFromArray(locCode, $scope.configParam.selectedDeviceID);
                }
                if ($scope.configParam.selectedDeviceID.length >= 7) {
                    alert("You can select up to 7 Device only.");
//                    $scope.closeModal();
                    return;
                } else if ($scope.configParam.selectedDeviceID.length == 0) {
                    $("#secondgraph").css("display", "block");
                    $("#thirdgraph").css("display", "none");
//                    $scope.closeModal();
                    return;
                }
                $("#secondgraph").css("display", "none");
                $("#thirdgraph").css("display", "block");
                if ($scope.configParam.selectedDeviceID.length > 0) {
                    $scope.temp = {};
                    for (var i = 0; i < $scope.configParam.selectedDeviceID.length; i++) {
                        var rg = $scope.configParam.selectedDeviceID[i];
                        $scope.temp[rg] = {};
                        for (var j = 0; j < $scope.temperatureRange.length; j++) {
                            var tr = $scope.temperatureRange[j].type;
                            $scope.temp[rg][tr] = [];
                        }
                    }
                    for (var i = 0; i < $scope.configParam.selectedDeviceID.length; i++) {
                        var selecteddropdownval = $scope.configParam.selectedDeviceID[i];
                        var acttype = $scope.selectedindex[i];
                        for (var j = 0; j < $scope.temperatureRange.length; j++) {
                            var tr = $scope.temperatureRange[j].type;
                            $scope.temp[selecteddropdownval][tr] = $scope.formateDataBasedOnSelectedParam(selecteddropdownval, $scope.othergraph[acttype][tr], 'locCode');
                        }
                    }
                    console.log($scope.temp);
                    var temparr = $scope.setGraphData($scope.temp);
                    var data2 = google.visualization.arrayToDataTable(temparr);
                    var selectedDropdownGraph = new google.visualization.ColumnChart(document.getElementById('selectedDropdownGraph'));
                    $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
                    google.visualization.events.addListener(selectedDropdownGraph, 'ready', function () {
                        var content = '<img alt="By Cold Chain" src="' + selectedDropdownGraph.getImageURI() + '">';
                        $('#graph-images').append(content);
                    });
                    selectedDropdownGraph.draw(data2, $scope.googlecharts);
                }
//                $scope.closeModal();
            }, 0);
        };
        $scope.formateDataBasedOnSelectedParam = function (selecteddropdownval, data, type) {//type = key type need to be matched in data array with the selected dropdown
            if (data.length > 0) {
                var temp = [];
                for (var i = 0; i < data.length; i++) {
                    if (data[i][type] == selecteddropdownval) {
                        temp.push(data[i]);
                    }
                }
                return temp;
            } else {
                return data;
            }
        };

        $scope.redrawChart = function () {
            $scope.openModal();
            $timeout(function () {
                if ($scope.trendType == 'regional' || $scope.trendType == 'temperature') {
                    $scope.drawRegionChart($scope.setGraphData($scope.region));
                    var ogdata = $scope.setGraphData($scope.othergraph);//this scope data will be used for filter table
                    $scope.drawColdChain(ogdata);
                    ogdata.splice(0, 1);
                    $scope.alldata = ogdata;
                } else if ($scope.trendType == 'monitor') {
                    $scope.indiaComplianceMonitoring();
                } else if ($scope.trendType == 'compliance') {
                    $scope.panIndiaComplianceMonitoring();
                }
                if ($scope.trendType == 'temperature') {
                    $scope.temperatureTrend();
                }
                $scope.closeModal();
            }, 500);
        }
        $scope.setGraphData = function (data) {
            var actualarr = [];
            var i = 1;
            actualarr[0] = $scope.temperature;
            $.each(data, function (key, value) {
                var temparr = [key];// set 0 value to the EAST west  or REV cold chian
                for (var j = 0; j < $scope.temperatureRange.length; j++) {
                    var tr = value[$scope.temperatureRange[j].type];
                    //temparr.push(tr);
                    temparr[$scope.temperatureRange[j].id]=tr;
                }
                temparr.push('');
                actualarr[i] = temparr;
                i++;
            });
            return actualarr;
        };
        $scope.getDefaultScope = function (data, param, innerparam) {//create dynamic scope for graph , param =dynamic scope,innerparam will inside key
            $scope[param] = {};
            for (var i = 0; i < data.length; i++) {
                var rg = data[i][innerparam];
                $scope[param][rg] = {};
                for (var j = 0; j < $scope.temperatureRange.length; j++) {
                    var tr = $scope.temperatureRange[j].type;
                    $scope[param][rg][tr] = [];
                }
            }
        };
        $scope.temperatureTrend = function () {
            var data = google.visualization.arrayToDataTable([
                ['Year', 'Temperature'],
                ['17-12-2015', 24.90],
                ['17-12-2015', 26.70],
                ['17-12-2015', 21.80],
                ['17-12-2015', 24.80],
                ['17-12-2015', 0.00],
                ['17-12-2015', 25.30],
                ['17-12-2015', 0.00],
                ['17-12-2015', 15.70],
                ['17-12-2015', 23.70],
                ['17-12-2015', 12.30],
                ['17-12-2015', 10.76],
                ['17-12-2015', 8.07],
                ['17-12-2015', 7.56],
                ['17-12-2015', 11.66],
                ['17-12-2015', 20.88],
                ['17-12-2015', 16.50],
                ['17-12-2015', 18.76]
            ]);
            var options = {
                "pointSize": 5,
                "width": 1200,
                "height": 250,
                "legend": {
                    "position": "none"
                },
                "hAxis": {
                    "slantedText": true,
                    "textStyle": {
                        "fontSize": 10,
                        "color": "black",
                    },
                    "gridlines": {
                        "count": -1,
                        "color": "white"
                    }
                },
                "vAxis":
                        {
                            "title": " % Temperature",
                            "titleTextStyle": {
                                "color": "black",
                                "bold": true,
                                "italic": false,
                                "fontSize": 12
                            },
                            "gridlines": {
                                "count": 2,
                                "color": "black"
                            },
                            "ticks": [0.00, 150.00]
                        }

            };
            var chart = new google.visualization.AreaChart(document.getElementById('areaCharts'));
            chart.draw(data, options);
        }
        $scope.getChartConfig = function () {
            $http.get(tempContextPath + "/data/googlecharts.json").success(function (data) {
                $scope.googlecharts = data;
                $scope.googlecharts.colors = $scope.colors;
                $scope.drawChart(true);
            });
        };
        $scope.setChartConfigParam = function () {
            // in this project we have 2 scope for for each dropdown type ,once for alldata & other scope is only for selected data.
            $scope.configParam = {
                "allRegion": [],
                "selectedRegion": [],
                "allColdChain": [],
                "selectedColdChain": [],
                "allUILevel": [],
                "selectedUILevel": [],
                "allCity": [],
                "selectedCity": [],
                "allBranchName": [],
                "selectedBranchName": [],
                "allVendor": [],
                "selectedVendor": [],
                "allColdRoom": [],
                "selectedColdRoom": [],
                "allDeviceIDs": [],
                "selectedDeviceID": [],
                "fromdate": new Date(),
                "todate": new Date()
            };
            $scope.fetchDropdownValues();
        };
        $scope.fetchDropdownValues = function () {
            $scope.openModal();
            $http.get(tempContextPath + "/data/roleBasedDropdown.json").success(function (data) {
//            $http.post(tempContextPath + "/roleBasedDropDownData").success(function (data) {
                $scope.configParam.allUILevel = data.uLLevelList;//countryName
                $scope.configParam.allRegion = data.regionsList;//countryName
                $scope.configParam.allColdChain = data.coldChainList;//countryName
                $scope.allRegion = data.regionsList;//countryName
                $scope.allColdChain = data.coldChainList;//countryName
                $scope.allDropdowndata = data.tablesJoinList;
                $scope.displayIndiaComplianceMonitoring();
                $scope.filterLocationData($scope.allDropdowndata, false, false, true);//second param  true means condition is not set... 3rd param is true means we need dedault data without filter
                $scope.getChartConfig();
            });
        }
        $scope.displayIndiaComplianceMonitoring = function () {
            var temp = 0;
            for (var j = 0; j < $scope.allRegion.length; j++) {
                if ($scope.allRegion[j].regionName == 'EAST' || $scope.allRegion[j].regionName == 'WEST' || $scope.allRegion[j].regionName == 'NORTH' || $scope.allRegion[j].regionName == 'SOUTH') {
                    temp++;
                }
            }
            if (temp == 4) {
                $("#indiatrendlist").css("display", "block");
            } else {
                $("#indiatrendlist").css("display", "none");
            }
        }
        $scope.filterLocationData = function (locationList, filterscopetype, selectedscope, bydefault) {
            var tempcity = [];
            var tempbranch = [];
            var tempvendor = [];
            var temploc = [];
            var temploccode = [];
            var tempreg = [];
            var tempcc = [];
            for (var j = 0; j < $scope.initscope.length; j++) {//set other scope to blank expect the selected one.
                if ($scope.initscope[j].scopename != filterscopetype) {
                    $scope.configParam[$scope.initscope[j].scopename] = [];
                }
            }
            for (var i = 0; i < locationList.length; i++) {
                if (bydefault || (!bydefault && $scope.checkCondition(filterscopetype, selectedscope, locationList[i]))) {
                    var locSubtype = $.trim(locationList[i]['locSubtype']);
                    var locType = $.trim(locationList[i]['locType']);
                    var locCode = $.trim(locationList[i]['locCode']);
                    var regionName = $.trim(locationList[i]['regionName']);
                    var coldChain = $.trim(locationList[i]['branchType']);
                    if (filterscopetype != 'allColdChain' && coldChain != null && tempcc.indexOf(coldChain) == -1) {
                        $scope.configParam.allColdChain.push({branchType: coldChain});
                        tempcc.push(coldChain);
                    }
                    if (filterscopetype != 'allRegion' && regionName != null && tempreg.indexOf(regionName) == -1) {
                        $scope.configParam.allRegion.push({regionCode: regionName, regionName: regionName});
                        tempreg.push(regionName);
                    }
                    if (filterscopetype != 'allVendor' && locSubtype != null && tempvendor.indexOf(locSubtype) == -1) {
                        $scope.configParam.allVendor.push({locSubtype: locSubtype});
                        tempvendor.push(locSubtype);
                    }
                    if (filterscopetype != 'allColdRoom' && locType != null && temploc.indexOf(locType) == -1) {
                        $scope.configParam.allColdRoom.push({locType: locType});
                        temploc.push(locType);
                    }
                    if (filterscopetype != 'allDeviceIDs' && locCode != null && temploccode.indexOf(locCode) == -1) {
                        $scope.configParam.allDeviceIDs.push({locCode: locCode, branchType: coldChain});
                        temploccode.push(locCode);
                    }
                    if (filterscopetype != 'allCity' && locationList[i]['districtName'] != null && tempcity.indexOf(locationList[i]['districtName']) == -1) {
                        $scope.configParam.allCity.push({districtName: locationList[i]['districtName'], districtCode: locationList[i]['districtCode']});
                        tempcity.push(locationList[i]['districtName']);
                    }
                    if (filterscopetype != 'allBranchName' && locationList[i]['branchName'] != null && tempbranch.indexOf(locationList[i]['branchName']) == -1) {
                        $scope.configParam.allBranchName.push({branchName: locationList[i]['branchName'], branchCode: locationList[i]['branchCode']});
                        tempbranch.push(locationList[i]['branchName']);
                    }
                }
            }
        };
        $scope.checkCondition = function (filterscopetype, selectedscope, data) {
            if ($scope.configParam[selectedscope].length == 0 || ($scope.configParam[selectedscope].indexOf(data.regionName) > -1 || $scope.configParam[selectedscope].indexOf(data.locCode) > -1 || $scope.configParam[selectedscope].indexOf(data.locType) > -1 || $scope.configParam[selectedscope].indexOf(data.locSubtype) > -1 || $scope.configParam[selectedscope].indexOf(data.branchName) > -1 || $scope.configParam[selectedscope].indexOf(data.districtName) > -1 || $scope.configParam[selectedscope].indexOf(data.branchType) > -1)) {
//            if ($scope.configParam[selectedscope].length == 0  || ($scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && ($scope.configParam[selectedscope].indexOf(data.locCode) > -1 || $scope.configParam[selectedscope].indexOf(data.locType) > -1 || $scope.configParam[selectedscope].indexOf(data.locSubtype) > -1 || $scope.configParam[selectedscope].indexOf(data.branchName) > -1 || $scope.configParam[selectedscope].indexOf(data.districtName) > -1 || $scope.configParam[selectedscope].indexOf(data.branchType) > -1))) {
                return true;
            } else {
                return false;
            }
        };
        $scope.applyFilter = function () {
            $scope.selectedFilter = {
                "selectedUILevel": ($scope.configParam.selectedUILevel.length ? "'" + $scope.configParam.selectedUILevel.join("','") + "'" : ""),
                "selectedRegion": ($scope.configParam.selectedRegion.length ? "'" + $scope.configParam.selectedRegion.join("','") + "'" : ""),
                "selectedColdChain": ($scope.configParam.selectedColdChain.length ? "'" + $scope.configParam.selectedColdChain.join("','") + "'" : ""),
                "selectedCity": ($scope.configParam.selectedCity.length ? "'" + $scope.configParam.selectedCity.join("','") + "'" : ""),
                "selectedBranchName": ($scope.configParam.selectedBranchName.length ? "'" + $scope.configParam.selectedBranchName.join("','") + "'" : ""),
                "selectedVendor": ($scope.configParam.selectedVendor.length ? "'" + $scope.configParam.selectedVendor.join("','") + "'" : ""),
                "selectedColdRoom": ($scope.configParam.selectedColdRoom.length ? "'" + $scope.configParam.selectedColdRoom.join("','") + "'" : ""),
                "selectedDeviceID": ($scope.configParam.selectedDeviceID.length ? "'" + $scope.configParam.selectedDeviceID.join("','") + "'" : ""),
                "selectedFromDate": $scope.configParam.fromdate,
                "selectedToDate": $scope.configParam.todate,
                "temperatureRange":$scope.temperatureRange
            };
            var fromdate = $scope.getActDate($scope.configParam.fromdate);
            var todate = $scope.getActDate($scope.configParam.todate);
            // var timeDiff = Math.abs(todate.getTime() - fromdate.getTime());
            // var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
            if (fromdate > todate) {
                alert("From date must be less then to date");
                return;
            }
//            else if (diffDays > 4) {
//                alert("You can not select date range more then 4 days");
//                return;
//            }
            if ($scope.checkDefaultData()) {
                $scope.drawChart(true);
            } else {
                $scope.drawChart(false);
            }
        }
        $scope.ByColdChain = function (data) {
            if ($.inArray(data[0], $scope.configParam.selectedColdChain) >= 0 || $scope.configParam.selectedColdChain.length == 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.ByRegion = function (data, temptype) {//temptype=tempraturetype
            var temp = 0;
            var total = 0
            for (var i = 1; i < data.length; i++) {
                total += data[i];
                if (temptype == i) {
                    temp = Number(data[i]);
                }
            }
            var num = (temp * 100) / total;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        };
        $scope.ByRegionAvg = function (type, temptype) {//type will name of cold chain & temptype will be temprature range
            var num = $scope.othergraphavg[type][temptype];
//            var total = 0;
//            for (var i = 0; i < ccdata.length; i++) {
//                total += Number(ccdata[i].paramValue);
//            }
//            var num = total / ccdata.length;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }

        $scope.setInitialTemperatureConfig = function () {
            $scope.temperatureRange = HUL_CONST.temperatureRange;
            $scope.totalcompcolor = HUL_CONST.totalcompcolor;
            $scope.indiaCompliance = HUL_CONST.indiaCompliance;
            $scope.trendType = $routeParams.trendType;
            $scope.colors = [];
            $scope.temperature = [''];
            for (var i = 0; i < $scope.temperatureRange.length; i++) {
                $scope.colors.push($scope.temperatureRange[i].color);
                $scope.temperature.push($scope.temperatureRange[i].type);
            }
            $scope.temperature.push({role: 'style'});
        };
        $scope.init = function () {
            $scope.initscope =
                    [
                        {
                            "level": 1,
                            "scopename": "allRegion",
                            "selectedscope": "selectedRegion"
                        },
                        {
                            "level": 2,
                            "scopename": "allColdChain",
                            "selectedscope": "selectedColdChain"
                        },
                        {
                            "level": 3,
                            "scopename": "allCity",
                            "selectedscope": "selectedCity"
                        },
                        {
                            "level": 4,
                            "scopename": "allBranchName",
                            "selectedscope": "selectedBranchName"
                        },
                        {
                            "level": 5,
                            "scopename": "allVendor",
                            "selectedscope": "selectedVendor"
                        },
                        {
                            "level": 6,
                            "scopename": "allColdRoom",
                            "selectedscope": "selectedColdRoom"
                        },
                        {
                            "level": 7,
                            "scopename": "allDeviceIDs",
                            "selectedscope": "selectedDeviceID"
                        }
                    ];
            $scope.setInitialTemperatureConfig();
            $scope.setChartConfigParam();
            $scope.graphdata = [];
            $scope.alldata = [];
            $scope.filtereddata = [];
            $scope.isDisabled = true;
            $scope.isexpanded = true;
            $scope.isselected = false;
            $scope.selectedindex = [];

        };
        $scope.getSheetName = function () {
            var fromdate = $scope.getActDate($scope.configParam.fromdate);
            var todate = $scope.getActDate($scope.configParam.todate);
            var opt;
            if (fromdate.toDateString() == todate.toDateString()) {
                var data = fromdate.toDateString().split(" ");
                opt = data[2] + '' + data[1];
            } else {
                var fromdata = fromdate.toDateString().split(" ");
                var todata = todate.toDateString().split(" ");
                opt = fromdata[2] + '' + fromdata[1] + "-" + todata[2] + '' + todata[1];
            }
            return "RegionalTrend-DataExtract-" + opt;
        }
        $scope.exportData = function () {
            var xlname = $scope.getSheetName();
            var xlheader = {
                sheetid: xlname,
                headers: true,
                column: {
                    style: 'background:#FFFF33'
                },
                columns: [
                    {columnid: 'region_code', width: 150},
                    {columnid: 'branch_type', width: 150},
                    {columnid: 'device_id', width: 150},
                    {columnid: 'branch_name', width: 150},
                    {columnid: 'txn_time', width: 150},
                    {columnid: 'param_value', width: 150}
                ]
            };
            var data = [];
            for (var i = 0; i < $scope.filtereddata.length; i++) {
                var obj = {
                    "region_code": $scope.filtereddata[i].regionCode,
                    "branch_type": $scope.filtereddata[i].branchType,
                    "device_id": $scope.filtereddata[i].deviceId,
                    "branch_name": $scope.filtereddata[i].branchName,
                    "txn_time": $scope.filtereddata[i].txnTime,
                    "param_value": Number($scope.filtereddata[i].paramValue)
                };
                data.push(obj);
            }
            alasql("SELECT * INTO XLS('" + xlname + ".xls',?) FROM ? ", [xlheader, data]);
//            alasql("SELECT * INTO xlsx('DEPOT-West-Andheri-23Dec.xlsx',?) FROM ? ", [xlheader, data]);
        }
        $scope.generatePDF = function () {
            var doc = new jsPDF('p', 'pt', 'a4', false); /* Creates a new Document*/
            doc.setFontSize(18); /* Define font size for the document */
            //doc.setTextColor(255, 0, 0);
            var yAxis = 30;
            var imageTags = $('#graph-images img');
            for (var i = 0; i < imageTags.length; i++) {
                if (i % 2 == 0 && i != 0) { /* I want only two images in a page */
                    doc.addPage();  /* Adds a new page*/
                    yAxis = 30; /* Re-initializes the value of yAxis for newly added page*/
                }
                var someText = imageTags[i].alt;
                doc.text(60, yAxis, someText); /* Add some text in the PDF */
                yAxis = yAxis + 20; /* Update yAxis */
                doc.addImage(imageTags[i], 'png', 40, yAxis, 530, 350, undefined, 'none');
                yAxis = yAxis + 380; /* Update yAxis default 360*/
            }
            doc.save('hul_report' + '.pdf');
        };
        // Left Panel Dropdown enable Disable Logic..
        $scope.$watch('configParam.selectedRegion', function () {
            if ($scope.configParam.selectedRegion.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allRegion', 'selectedRegion', false);
                $scope.isDisabled = false;
            } else {
                if ($scope.allDropdowndata != undefined) {
                    $scope.filterLocationData($scope.allDropdowndata, false, false, true);
                    $scope.setSelectedToDefault('selectedRegion');
                }
                $scope.isDisabled = true;
            }

        });
        $scope.$watch('configParam.selectedDeviceID', function () {
            if ($scope.configParam.selectedDeviceID.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allDeviceIDs', 'selectedDeviceID', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedColdRoom', function () {
            if ($scope.configParam.selectedColdRoom.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allColdRoom', 'selectedColdRoom', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedVendor', function () {
            if ($scope.configParam.selectedVendor.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allVendor', 'selectedVendor', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedBranchName', function () {
            if ($scope.configParam.selectedBranchName.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allBranchName', 'selectedBranchName', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedCity', function () {
            if ($scope.configParam.selectedCity.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allCity', 'selectedCity', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedColdChain', function () {
            if ($scope.configParam.selectedColdChain.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allColdChain', 'selectedColdChain', false);
            } else {
                $scope.setDefaultFilter();
            }
        });
        $scope.setDefaultFilter = function () {
            if ($scope.allDropdowndata != undefined) {
                $scope.filterLocationData($scope.allDropdowndata, 'allRegion', 'selectedRegion', false);
            }
        };
        $scope.getTrendname = function (type) {
            if (type != 'monitor' && type != 'compliance') {
                return $scope.capitalizeFirstLetter(type) + " Trend";
            } else if (type == 'monitor') {
                return "India Compliance Monitoring";
            } else if (type = 'compliance') {
                return "Pan India Compliance Monitoring";
            }

        }
        $scope.setSelectedToDefault = function (filterscopetype) {
            for (var j = 0; j < $scope.initscope.length; j++) {//set other scope to blank expect the selected one.
                if ($scope.initscope[j].selectedscope != filterscopetype) {
                    $scope.configParam[$scope.initscope[j].selectedscope] = [];
                }
            }
        }
        $scope.init();
    }]);