myApp.controller('charts', ['$scope', '$http', 'HUL_CONST', '$timeout', '$location', '$rootScope', '$routeParams', '$q', '$log', function ($scope, $http, HUL_CONST, $timeout, $location, $rootScope, $routeParams, $q, $log) {

        $scope.removeSelected = function (obj, filterscopetype, selectedscope, level) {
            $rootScope.removeFromArray(obj, $scope.configParam[selectedscope]);
            //console.log($scope.allDropdowndata)
            $scope.filterLocationData($scope.allDropdowndata, filterscopetype, selectedscope, false, level);
            $scope.checkDefaultData();
            if ($scope.configParam[selectedscope].length == 0) {
                $scope.setDefaultDisabledByLevel(level);
            }
            if (level == 6) {//drill down level
                $scope.level = 2;// Fornt-end scope level
            } if (level == 2) {//drill down level
                $scope.level = 1;// Fornt-end scope level
            } else {
                $scope.level = 1;
            }
            $scope.applyFilter();
        }


        $scope.checkDefaultData = function () {
            var def = true;
            for (var j = 0; j < $scope.initscope.length; j++) {
                if ($scope.configParam[$scope.initscope[j].selectedscope].length > 0) {
                    def = false;
                    break;
                }
            }
            $scope.addToSessionStorage('filter', $scope.configParam);
            return def;
        }
        $scope.changeTrend = function (trendType) {
            $scope.trendType = trendType;
            $scope.addToSessionStorage('filter', $scope.configParam);
            $location.path("/index/" + trendType);
        };
        $scope.drawColdChain = function (actdata) {
            var temparr = $scope.filterbyDataSelected(actdata, $scope.configParam.selectedColdChain);
            var data2 = google.visualization.arrayToDataTable(temparr);
            var groupedColumnColdChain = new google.visualization.ColumnChart(document.getElementById('groupedColumnColdChain'));
            $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
            var getDataByColdChain = function () {
                var selectedItem = groupedColumnColdChain.getSelection()[0];
                if ($scope.configParam.selectedColdChain.length > 0 && selectedItem) {
                    var topping = data2.getValue(selectedItem.row, 0);
                    if ($scope.configParam.selectedColdChain.indexOf(topping) > -1) {
                        $scope.removeFromArray(topping, $scope.configParam.selectedColdChain);
                        if ($scope.configParam.selectedColdChain.length == 0) {
                            $scope.setDefaultDisabledByLevel(1);
                        }
                        $scope.applyFilter();
                    }
                } else {
                    $scope.configParam.selectedColdChain = [];
                    if (selectedItem) {
                        var topping = data2.getValue(selectedItem.row, 0);
                        $scope.configParam.selectedColdChain.push(topping);
                        //$scope.applyFilter();
                        $scope.getSecondLevelData();
                    }
                }
                $scope.$apply();
            };
            google.visualization.events.addListener(groupedColumnColdChain, 'select', getDataByColdChain);
            google.visualization.events.addListener(groupedColumnColdChain, 'ready', function () {
                var content = '<img alt="By Cold Chain" src="' + groupedColumnColdChain.getImageURI() + '">';
                $('#graph-images').append(content);
            });
            groupedColumnColdChain.draw(data2, $scope.googlecharts);
        };
        $scope.levelManagment = function () {// Level Managment : need to show or Hide Block Based On Level
            // currently we have three level for First :  region & cold Chain graph will be show
            // for Secon : region & city Graph Will be show
            //for Third Region & Device Id Grap Will be shown
            if ($scope.level == 1) {
                //$("#firstgraph").css("display", "block");
                $("#thirdgraph").css("display", "none");
                $("#secondgraph").css("display", "none");
                $("#firstgraph").fadeIn(2000);
                $("#initialgraph").fadeIn(2000);
            } else if ($scope.level == 2) {
                $("#firstgraph").css("display", "none");
                $("#thirdgraph").css("display", "none");
                $("#secondgraph").fadeIn(2000);
                //$("#secondgraph").css("display", "block");
            } else if ($scope.level == 3) {
                $("#firstgraph").css("display", "none");
                // $("#thirdgraph").css("display", "block");
                $("#secondgraph").css("display", "none");
                $("#thirdgraph").fadeIn(2000);
            }
        }
        $scope.getSecondLevelData = function () {
            $scope.openModal();
            $scope.level = 2;//second level means need to fetch city as well as divce related data
            $scope.levelManagment();
            $scope.setSelectedFilter();
            //$http.get(tempContextPath + "/data/city-diviceid-map.json").success(function (data) {
            $http.post(tempContextPath + "/fetchDrilledValues", $scope.selectedFilter).success(function (data) {
                $scope.citydata = data.city;
                $scope.allNextLevelData = data;
                $scope.allcitydata = $scope.setGraphData($scope.citydata);
                var data2 = google.visualization.arrayToDataTable($scope.allcitydata);
                var secondLevelGraph = new google.visualization.ColumnChart(document.getElementById('secondLevelGraph'));
                $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
                var getDataByCity = function () {
                    var selectedItem = secondLevelGraph.getSelection()[0];
                    if ($scope.configParam.selectedCity.length > 0 && selectedItem) {
                        var topping = data2.getValue(selectedItem.row, 0);
                        if ($scope.configParam.selectedCity.indexOf(topping) > -1) {
                            $scope.removeFromArray(topping, $scope.configParam.selectedCity);
                            $scope.getSecondLevelData();
                        }
                    } else {
                        $scope.configParam.selectedCity = [];
                        if (selectedItem) {
                            var topping = data2.getValue(selectedItem.row, 0);
                            $scope.configParam.selectedCity.push(topping);
                            $scope.getThirdLevelData();
                        }
                    }
                    $scope.$apply();
                };
                google.visualization.events.addListener(secondLevelGraph, 'select', getDataByCity);
                google.visualization.events.addListener(secondLevelGraph, 'ready', function () {
                    var content = '<img alt="By Cold Chain" src="' + secondLevelGraph.getImageURI() + '">';
                    $('#graph-images').append(content);
                });
                secondLevelGraph.draw(data2, $scope.googlecharts);
                $scope.closeModal();
            });
        };
        $scope.getThirdLevelData = function () {
            $scope.openModal();
            $scope.level = 3;//third level means need to display device related data
            $scope.levelManagment();
            $scope.setSelectedFilter();
            //$http.get(tempContextPath + "/data/city-diviceid-map.json").success(function (data) {
            $http.post(tempContextPath + "/fetchDrilledValues", $scope.selectedFilter).success(function (data) {
                $scope.citydata = data.city;
                $scope.allNextLevelData = data;
                var cityDevices = $scope.allNextLevelData[$scope.configParam.selectedCity[0]].deviceID;
                var data2 = google.visualization.arrayToDataTable($scope.setGraphData(cityDevices));
                var thirdLevelGraph = new google.visualization.ColumnChart(document.getElementById('thirdLevelGraph'));
                $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
                var getDataByDevice = function () {
                    var selectedItem = thirdLevelGraph.getSelection()[0];
                    if ($scope.configParam.selectedDeviceID.length > 0 && selectedItem) {
                        var topping = data2.getValue(selectedItem.row, 0);
                        if ($scope.configParam.selectedDeviceID.indexOf(topping) > -1) {
                            $scope.removeFromArray(topping, $scope.configParam.selectedDeviceID);
                            $scope.getSecondLevelData();
                        }
                    } else {
                        $scope.configParam.selectedDeviceID = [];
                        if (selectedItem) {
                            var topping = data2.getValue(selectedItem.row, 0);
                            $scope.deviceID = topping;
                            $scope.configParam.selectedDeviceID.push(topping);
                            $scope.getThirdLevelData();
                        }
                    }
                    $scope.$apply();
                };
                google.visualization.events.addListener(thirdLevelGraph, 'select', getDataByDevice);
                google.visualization.events.addListener(thirdLevelGraph, 'ready', function () {
                    var content = '<img alt="By Cold Chain" src="' + thirdLevelGraph.getImageURI() + '">';
                    $('#graph-images').append(content);
                });
                thirdLevelGraph.draw(data2, $scope.googlecharts);
                $scope.closeModal();
            });
        };
        $scope.indiaComplianceMonitoring = function () {
            $scope.openModal();
            $timeout(function () {
                var options = $scope.getDountConfig();
                var per = $scope.indiaComplianceMonitoringData.percentage;
                var col = $scope.getComplianceColor(per);
                options.slices = {0: {color: col}};
                var data = google.visualization.arrayToDataTable([
                    ['India', '%Compliance'],
                    ['Compliance', per]
                ]);
                var chart = new google.visualization.PieChart(document.getElementById('indiaComplianceMonitoring'));
                chart.draw(data, options);
                $scope.closeModal();
            }, 2000);
        }
        $scope.getDountConfig = function () {
            return  {
                pieHole: 0.6,
                legend: 'none',
                pieSliceText: 'value',
                pieSliceTextStyle: {
                    color: 'black',
                    fontSize: 20
                }
            };
        }
        $scope.panIndiaComplianceMonitoring = function () {
            $scope.openModal();
            /* $scope.panComplianceMonitoringData = {
             "FACTORY": 12,
             "RS Cold Room": 57,
             "DEPOT": 29,
             "PT": 49.58,
             "ST": 23,
             "RSV": 89,
             "FACTORYANT": 5,
             "DEPOTANT": 72
             }*/
            $timeout(function () {
                $.each($scope.panComplianceMonitoringData, function (key, percentage) {
                    if (key != "FACTORYANT" && key != "DEPOTANT") {
                        var graphid = "panindiaComplianceMonitoring_" + key.toLowerCase();
                        if (key == 'RS Cold Room') {
                            graphid = "panindiaComplianceMonitoring_rsc";
                        }
                        var per = $scope.getActPercentage(percentage);
                        var col = $scope.getPanComplianceColor(per, key);
                        var options = $scope.getDountConfig();
                        options.slices = {0: {color: col}};
                        var data = google.visualization.arrayToDataTable([
                            ['Cold Chain', '%Compliance'],
                            [key, per]
                        ]);
                        if (Number(per) == 0) {
                            $("#" + graphid).html("");
                            $("#" + graphid).html("<div style='height:200px;padding-top:100px;padding-left:80px';>Data is not available related  to  selected filter for " + key + "</div>");
                        } else {
                            var chart = new google.visualization.PieChart(document.getElementById(graphid));
                            chart.draw(data, options);
                        }
                    }
                });

                $scope.closeModal();
            }, 2000);
        };
        $scope.getPanComplianceColor = function (per, key) {
            if (key == 'FACTORY') {
                if (per < 70) {
                    return "#FF0000";
                } else if (per >= 70 && per <= 94) {
                    return "#FFC200";
                } else {
                    return "#66CC00";
                }
            } else {
                if (per < 50) {
                    return "#FF0000";
                } else if (per >= 50 && per <= 70) {
                    return "#FFC200";
                } else {
                    return "#66CC00";
                }
            }
        };
        $scope.reformateGraphData = function (condition, objvalue) {// we need reformate data based on if weneed locsubtype = 2 or not & get return back to the user
// if condition== false means we need all data if true  we need only location subtype!=2  data;
//param = factory parameter 
            if (!condition) {
                return objvalue;
            }
            var tempobj = [];
            for (var j = 0; j < $scope.colors.length; j++) {
                var tr = $scope.colors[j];
                if (objvalue[tr].length > 0) {
                    var temp = [];
                    for (var i = 0; i < objvalue[tr].length; i++) {
                        if (objvalue[tr][i].locSubType != "2") {
                            temp.push(objvalue[tr][i]);
                        }
                    }
                    tempobj[tr] = temp;
                } else {
                    tempobj[tr] = [];
                }
            }
            return tempobj;
        }
        $scope.getPercentage = function (val, total) {
            var num = (val / total) * 100;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.getActPercentage = function (num) {
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.getComplianceColor = function (per) {
            for (var i = 0; i < $scope.indiaCompliance.length; i++) {
                if (per >= Number($scope.indiaCompliance[i].min) && per <= Number($scope.indiaCompliance[i].max)) {
                    return $scope.indiaCompliance[i].color;
                }
            }
        }
        $scope.getAnteRoomPer = function (coldchain) {
            if ($scope.othergraphall != undefined) {
                var ccdata = $scope.othergraphall[coldchain];
                var total = 0;
                var act = 0;
                for (var j = 0; j < $scope.colors.length; j++) {
                    var tr = $scope.colors[j];
                    if (ccdata[tr].length > 0 && tr == "Green") {
                        total += ccdata[tr].length;
                        var temp = [];
                        for (var i = 0; i < ccdata[tr].length; i++) {
                            if (ccdata[tr][i].locSubType == "2" && Number(ccdata[tr][i].paramValue) <= -5) {
                                temp.push(ccdata[tr][i]);
                            }
                        }
                        act = temp.length;
                    }
                }
                var num = (act / total) * 100;
                if (isNaN(num)) {
                    return 0;
                } else {
                    if (Number(num) == 0) {
                        return 0;
                    }
                    return num.toFixed(2);
                }
            }
        }
        $scope.drawRegionChart = function (actdata) {
            var temparr = $scope.filterbyDataSelected(actdata, $scope.configParam.selectedRegion);
            $scope.googlecharts.bar.groupWidth = 74;
            var data = google.visualization.arrayToDataTable(temparr);
            var groupedColumnRegion = new google.visualization.ColumnChart(document.getElementById('groupedColumnRegion'));
            var getDataByColumnRegion = function () {
                var selectedItem = groupedColumnRegion.getSelection()[0];
                if ($scope.configParam.selectedRegion.length > 0 && selectedItem) {
                    var topping = data.getValue(selectedItem.row, 0);
                    if ($scope.configParam.selectedRegion.indexOf(topping) > -1) {
                        $scope.removeFromArray(topping, $scope.configParam.selectedRegion);
                        if ($scope.configParam.selectedRegion.length == 0) {
                            $scope.setDefaultDisabledByLevel(0);
                        }
                        $scope.applyFilter();
                    }
                } else {
                    $scope.configParam.selectedRegion = [];
                    if (selectedItem) {
                        var topping = data.getValue(selectedItem.row, 0);
                        $scope.configParam.selectedRegion.push(topping);
                        $scope.applyFilter();
                    }
                }
                $scope.level = 1;
                $scope.levelManagment();
                $scope.$apply();
            };
            google.visualization.events.addListener(groupedColumnRegion, 'select', getDataByColumnRegion);
            google.visualization.events.addListener(groupedColumnRegion, 'ready', function () {
                var content = '<img alt="By Region" src="' + groupedColumnRegion.getImageURI() + '">';
                $('#graph-images').append(content);
            });
            groupedColumnRegion.draw(data, $scope.googlecharts);
        }
        $scope.drawChart = function (byDefault) {
            $scope.openModal();
            if (byDefault) {
                $scope.selectedFilter = {};
                var requestName = "fetchDefaultValues";
                $scope.selectedFilter.type = $scope.trendType;
                $scope.selectedFilter.temperature = $scope.temperatureRange;
            } else {
                var requestName = "fetchChartValues";
            }
            if ($scope.trendType == 'compliance') {
                $scope.selectedFilter.coldchain = {
                    "FACTORY": -20,
                    "PT": -20,
                    "DEPOT": -20,
                    "ST": -20,
                    "RS Cold Room": -18,
                    "RSV": -18,
                    "FACTORYANT": {
                        "locSubType": 2,
                        "paramValue": -5
                    },
                    "DEPOTANT": {
                        "locSubType": 2,
                        "paramValue": -5
                    }
                }
            }
            //  console.log(JSON.stringify($scope.selectedFilter));
//            $http.get(tempContextPath + "/data/finaloutpt.json").success(function (data) {
//                $http.get(tempContextPath + "/data/dummyuploadhul.json").success(function (data) {
            $http.post(tempContextPath + "/" + requestName, $scope.selectedFilter).success(function (data) {
                if ($scope.trendType == 'regional' || $scope.trendType == 'temperature') {
                    var lg = Object.keys(data.region).length;
                    if (lg === 0) {//temp fix
                        $http.get(tempContextPath + "/data/defaultoutput.json").success(function (defaultdata) {
                            $scope.region = defaultdata.region;
                            $scope.othergraph = defaultdata.coldChain;
                            $scope.othergraphall = defaultdata.coldChain;
                            $scope.othergraphavg = defaultdata.coldChainavg;
                        });
                    } else {
                        $scope.region = data.region;
                        $scope.othergraph = data.coldChain;
                        $scope.othergraphall = data.coldChain;
                        $scope.othergraphavg = data.coldChainavg;
                    }
                    if ($scope.trendType == 'temperature') {
                        $scope.temperatureData = data.temperature;
                    }
                    $scope.othergraph = data.coldChain;
                    $scope.othergraphall = data.coldChain;
                    $scope.othergraphavg = data.coldChainavg;
                } else if ($scope.trendType == 'monitor') {//India Compliance Monitoring
                    $scope.indiaComplianceMonitoringData = {};
                    $scope.indiaComplianceMonitoringData = data;
                } else if ($scope.trendType == 'compliance') {//Pan India Compliance
                    $scope.panComplianceMonitoringData = data.compliance;
                }
                $scope.redrawChart();
            });
        };
        $scope.filterbyDataSelected = function (actdata, selarr) {
            var temparr = [];
            for (var i = 0; i < actdata.length; i++) {
                var inner_x_axis_val = actdata[i][0];
                if (inner_x_axis_val == '' || selarr.length == 0 || selarr.indexOf(inner_x_axis_val) > -1) {
                    temparr.push(actdata[i]);
                }
            }
            return temparr;
        }

        $scope.checkFilterDatalength = function (data, coldchain) {
            var filterd = [];
            for (var i = 0; i < data.length; i++) {
                var value = data[i];
                if (value.branchType == coldchain) {
                    filterd.push(value);
                }
            }
            if (filterd.length == 0) {
                return true;
            } else {
                return false;
            }
        };
        $scope.checkDeviceDatalength = function (data) {
            var deviceIdCount = 0;
            deviceIdCount = Object.keys(data).length;
            if (deviceIdCount == 0) {
                return true;
            } else {
                return false;
            }
        }

        $scope.drawSelectdDropdownChartByCity = function (data) {// type = RSV PT,ETC,
            $timeout(function () {
                var districtName = data.districtName;
                if ($scope.configParam.selectedCity.indexOf(districtName) == -1) {
                    $scope.configParam.selectedCity.push(districtName);
                } else {
                    $scope.removeFromArray(districtName, $scope.configParam.selectedCity);
                }
                if ($scope.configParam.selectedCity.length >= 7) {
                    alert("You can select up to 7 City only.");
                    return;
                } else if ($scope.configParam.selectedCity.length == 0) {
                    $("#firstgraph").css("display", "block");
                    $("#secondgraph").css("display", "none");
                    $("#thirdgraph").css("display", "none");
                    return;
                }
                $scope.openModal();
                $("#firstgraph").css("display", "none");
                $("#secondgraph").css("display", "block");
                $("#thirdgraph").css("display", "none");
                if ($scope.configParam.selectedCity.length > 0) {
                    $scope.setSelectedFilter();
                    //$http.get(tempContextPath + "/data/city-diviceid-map.json").success(function (data) {
                    $http.post(tempContextPath + "/fetchDrilledValues", $scope.selectedFilter).success(function (data) {
                        $scope.citydata = data.city;
                        $scope.temp = {};
                        for (var i = 0; i < $scope.configParam.selectedCity.length; i++) {
                            var rg = $scope.configParam.selectedCity[i];
                            if ($scope.citydata[rg] == undefined) {
                                $scope.temp[rg] = {
                                    "Yellow": 0,
                                    "Red": 0,
                                    "Amber": 0,
                                    "Green": 0
                                }
                            } else {
                                $scope.temp[rg] = $scope.citydata[rg];
                            }
                        }
                        var temparr = $scope.setGraphData($scope.temp);
                        var data2 = google.visualization.arrayToDataTable(temparr);
                        var secondLevelGraph = new google.visualization.ColumnChart(document.getElementById('secondLevelGraph'));
                        var getDataByCity = function () {
                            var selectedItem = secondLevelGraph.getSelection()[0];
                            if ($scope.configParam.selectedCity.length > 0 && selectedItem) {
                                $scope.getThirdLevelData();
                            }
                            $scope.$apply();
                        };
                        google.visualization.events.addListener(secondLevelGraph, 'select', getDataByCity);
                        $scope.googlecharts.bar.groupWidth = 37;//will change the logic for it soon
                        google.visualization.events.addListener(secondLevelGraph, 'ready', function () {
                            var content = '<img alt="By Cold Chain" src="' + secondLevelGraph.getImageURI() + '">';
                            $('#graph-images').append(content);
                        });
                        secondLevelGraph.draw(data2, $scope.googlecharts);
                        $scope.closeModal();
                    });
                }
            }, 0);
        };
        $scope.drawSelectdDropdownChartByDevice = function (slectedcity, DeviceID) {
            $timeout(function () {
                if ($scope.configParam.selectedDeviceID.indexOf(DeviceID) == -1) {
                    $scope.configParam.selectedDeviceID.push(DeviceID);
                } else {
                    $scope.removeFromArray(DeviceID, $scope.configParam.selectedDeviceID);
                }
                if ($scope.configParam.selectedDeviceID.length >= 7) {
                    alert("You can select up to 7 Device only.");
//                    $scope.closeModal();
                    return;
                } else if ($scope.configParam.selectedDeviceID.length == 0) {
                    $("#firstgraph").css("display", "none");
                    $("#secondgraph").css("display", "block");
                    $("#thirdgraph").css("display", "none");
//                    $scope.closeModal();
                    return;
                }
                $scope.openModal();
                $("#firstgraph").css("display", "none");
                $("#secondgraph").css("display", "none");
                $("#thirdgraph").css("display", "block");
                if ($scope.configParam.selectedDeviceID.length > 0) {
                    $scope.setSelectedFilter();
                    //$http.get(tempContextPath + "/data/city-diviceid-map.json").success(function (data) {
                    $http.post(tempContextPath + "/fetchDrilledValues", $scope.selectedFilter).success(function (data) {
                        $scope.allNextLevelData = data;
                        $scope.temp = {};
                        for (var i = 0; i < $scope.configParam.selectedDeviceID.length; i++) {
                            var rg = $scope.configParam.selectedDeviceID[i];
                            if ($scope.allNextLevelData[slectedcity].deviceID == undefined) {
                                $scope.temp[rg] = {
                                    "Yellow": 0,
                                    "Red": 0,
                                    "Amber": 0,
                                    "Green": 0
                                }
                            } else {
                                var deviceIDs = $scope.allNextLevelData[slectedcity].deviceID;
                                $scope.temp[rg] = deviceIDs[rg];
                            }
                        }
                        var temparr = $scope.setGraphData($scope.temp);
                        var data2 = google.visualization.arrayToDataTable(temparr);
                        var thirdLevelGraph = new google.visualization.ColumnChart(document.getElementById('thirdLevelGraph'));
                        $scope.googlecharts.bar.groupWidth = 37;
                        google.visualization.events.addListener(secondLevelGraph, 'ready', function () {
                            var content = '<img alt="By Cold Chain" src="' + thirdLevelGraph.getImageURI() + '">';
                            $('#graph-images').append(content);
                        });
                        thirdLevelGraph.draw(data2, $scope.googlecharts);
                        $scope.closeModal();
                    });
                }

            }, 0);
        };
        $scope.formateDataBasedOnSelectedParam = function (selecteddropdownval, data, type) {//type = key type need to be matched in data array with the selected dropdown
            if (data.length > 0) {
                var temp = [];
                for (var i = 0; i < data.length; i++) {
                    if (data[i][type] == selecteddropdownval) {
                        temp.push(data[i]);
                    }
                }
                return temp;
            } else {
                return data;
            }
        };

        $scope.redrawChart = function () {
            $scope.openModal();
            $timeout(function () {
                if ($scope.trendType == 'regional' || $scope.trendType == 'temperature') {
                    $scope.drawRegionChart($scope.setGraphData($scope.region));
                    $scope.closeModal();
                    var ogdata = $scope.setGraphData($scope.othergraph);//this scope data will be used for filter table
                    $scope.drawColdChain(ogdata);
                    ogdata.splice(0, 1);
                    $scope.alldata = ogdata;
                } else if ($scope.trendType == 'monitor') {
                    $scope.indiaComplianceMonitoring();
                } else if ($scope.trendType == 'compliance') {
                    $scope.panIndiaComplianceMonitoring();
                }
                if ($scope.trendType == 'temperature') {
                    $scope.temperatureTrend();
                }
                $scope.closeModal();
            }, 500);
        }
        $scope.setGraphData = function (data) {
            var actualarr = [];
            var i = 1;
            actualarr[0] = $scope.temperature;
            $.each(data, function (key, value) {
                var temparr = [key];// set 0 value to the EAST west  or REV cold chian
                for (var j = 0; j < $scope.colors.length; j++) {
                    var tr = $scope.colors[j];
                    temparr[j + 1] = value[tr];
                }
                temparr.push('');
                actualarr[i] = temparr;
                i++;
            });
            return actualarr;
        };
        $scope.getDefaultScope = function (data, param, innerparam) {//create dynamic scope for graph , param =dynamic scope,innerparam will inside key
            $scope[param] = {};
            for (var i = 0; i < data.length; i++) {
                var rg = data[i][innerparam];
                $scope[param][rg] = {};
                var temperatureRange = $scope.temperatureRange['FACTORY'];
                for (var j = 0; j < temperatureRange.length; j++) {
                    var tr = temperatureRange[j].colorname;
                    $scope[param][rg][tr] = [];
                }
            }
        };
        $scope.temperatureTrend = function () {
            var finaldata = [];
            var hd = ['Year', 'Temperature'];
            $.each($scope.temperatureData, function (key, num) {
                var tp = [];
                tp[0] = key;
                if (isNaN(num)) {
                    var avgtemp = 0;
                } else {
                    var avgtemp = Math.abs(num.toFixed(2));
                }
                tp[1] = avgtemp;
                finaldata.push(tp);
            });
            var sortedarr = finaldata.sort(function (a, b) {
                return new Date(a[0]) - new Date(b[0]);

            });
            sortedarr.splice(0, 0, hd);

            var data = google.visualization.arrayToDataTable(finaldata);
            var options = {
                "pointSize": 5,
                "width": 1200,
                "height": 250,
                "legend": {
                    "position": "none"
                },
                "curveType": 'function',
                "hAxis": {
                    "slantedText": true,
                    "textStyle": {
                        "fontSize": 10,
                        "color": "black",
                    },
                    "gridlines": {
                        "count": -1,
                        "color": "white"
                    }
                },
                "vAxis":
                        {
                            "title": " % Temperature in minus (-)",
                            "titleTextStyle": {
                                "color": "black",
                                "bold": true,
                                "italic": false,
                                "fontSize": 12
                            },
                            "gridlines": {
                                "count": 2,
                                "color": "black"
                            },
                            "ticks": [0.00, 50.00]
                        }

            };
            var chart = new google.visualization.AreaChart(document.getElementById('areaCharts'));
            chart.draw(data, options);
        }
        $scope.getChartConfig = function () {
            $http.get(tempContextPath + "/data/googlecharts.json").success(function (data) {
                $scope.googlecharts = data;
                $scope.googlecharts.colors = $scope.colorsarr;
                var sessiondata = $scope.getDataFromSessionStorage('filter');
                if (sessiondata != null && sessiondata != undefined) {
                    //console.log('from session')
                    $scope.configParam = sessiondata;
                    $scope.applyFilter();
                } else {
                    $scope.drawChart(true);
                }

            });
        };
        $scope.setChartConfigParam = function () {
            // in this project we have 2 scope for for each dropdown type ,once for alldata & other scope is only for selected data.
            $scope.configParam = {
                "allRegion": [],
                "selectedRegion": [],
                "allColdChain": [],
                "selectedColdChain": [],
                "allUILevel": [],
                "selectedUILevel": [],
                "allCity": [],
                "selectedCity": [],
                "allBranchName": [],
                "selectedBranchName": [],
                "allVendor": [],
                "selectedVendor": [],
                "allColdRoom": [],
                "selectedColdRoom": [],
                "allDeviceIDs": [],
                "selectedDeviceID": [],
                "fromdate": new Date(),
                "todate": new Date()
            };
            $scope.fetchDropdownValues();
        };
        $scope.fetchDropdownValues = function () {
            $scope.openModal();
//            $http.get(tempContextPath + "/data/roleBasedDropdown.json").success(function (data) {
            $http.post(tempContextPath + "/roleBasedDropDownData").success(function (data) {
                // $scope.configParam.allUILevel = data.uLLevelList;//countryName
                $scope.configParam.allRegion = data.regionsList;//countryName
                $scope.configParam.allColdChain = data.coldChainList;//countryName
                $scope.allRegion = data.regionsList;//countryName
                $scope.allColdChain = data.coldChainList;//countryName
                $scope.allDropdowndata = data.tablesJoinList;
                $scope.displayIndiaComplianceMonitoring();
                $scope.filterLocationData($scope.allDropdowndata, false, false, true, 0);
                $scope.getChartConfig();
            });
        }
        $scope.displayIndiaComplianceMonitoring = function () {
            var temp = 0;
            for (var j = 0; j < $scope.allRegion.length; j++) {
                if ($scope.allRegion[j].regionName == 'EAST' || $scope.allRegion[j].regionName == 'WEST' || $scope.allRegion[j].regionName == 'NORTH' || $scope.allRegion[j].regionName == 'SOUTH') {
                    temp++;
                }
            }
            if (temp == 4) {
                $("#indiatrendlist").css("display", "block");
            } else {
                $("#indiatrendlist").css("display", "none");
            }
        }
        $scope.filterLocationData = function (locationList, filterscopetype, selectedscope, bydefault, level) {
            //console.log(level)
            var tempcity = [];
            var tempbranch = [];
            var tempvendor = [];
            var temploc = [];
            var temploccode = [];
            for (var j = 0; j < $scope.initscope.length; j++) {//set other scope to blank expect the selected one.
                if ($scope.initscope[j].level > level && $scope.initscope[j].scopename != 'allRegion' && $scope.initscope[j].scopename != 'allColdChain') {
                    $scope.configParam[$scope.initscope[j].scopename] = [];
                }
            }
            $scope.allCityColdChainMap=[];
            // note at same level filter will not update existignvalue
            // for ex: if we are select city Which level is 2 so ..all greater level then this filete will appply not for lower or intial level
            // in simple it will apply only from top to bottom
            for (var i = 0; i < locationList.length; i++) {
                if (bydefault || (!bydefault && $scope.checkCondition(locationList[i], level))) {
                    var locSubtype = $.trim(locationList[i]['locSubtype']);
                    var locType = $.trim(locationList[i]['locType']);
                    var locCode = $.trim(locationList[i]['locCode']);
                    var coldChain = $.trim(locationList[i]['branchType']);
                    if (2 > level && locationList[i]['districtName'] != null && tempcity.indexOf(locationList[i]['districtName']) == -1) {//2= level of city
                        $scope.configParam.allCity.push({districtName: locationList[i]['districtName'], districtCode: locationList[i]['districtCode'], branchType: coldChain});
                        tempcity.push(locationList[i]['districtName']);
                    }
                    //below if only used for city filtering  With unique cold chain
                    if (2 > level && locationList[i]['districtName'] != null && $scope.checkCityColdChainMap(locationList[i]['districtName'], coldChain)) {//2= level of city
                        $scope.allCityColdChainMap.push({districtName: locationList[i]['districtName'], districtCode: locationList[i]['districtCode'], branchType: coldChain});
                    }
                    if (3 > level && locationList[i]['branchName'] != null && tempbranch.indexOf(locationList[i]['branchName']) == -1) {//3= level of branch
                        $scope.configParam.allBranchName.push({branchName: locationList[i]['branchName'], branchCode: locationList[i]['branchCode']});
                        tempbranch.push(locationList[i]['branchName']);
                    }
                    if (4 > level && locSubtype != null && tempvendor.indexOf(locSubtype) == -1) {//4= level of vendor
                        $scope.configParam.allVendor.push({locSubtype: locSubtype});
                        tempvendor.push(locSubtype);
                    }
                    if (5 > level && locType != null && temploc.indexOf(locType) == -1) {//5= level of cold room
                        $scope.configParam.allColdRoom.push({locType: locType});
                        temploc.push(locType);
                    }
                    if (6 > level && locCode != null && temploccode.indexOf(locCode) == -1) {//6= level of device
                        $scope.configParam.allDeviceIDs.push({locCode: locCode, branchType: coldChain});
                        temploccode.push(locCode);
                    }

                }
            }
        };
//        $scope.checkCondition = function (data, level) {//level filtering
//            if (level == 0) {
//                return true;
//            }
//            if ((level == 1 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.indexOf(data.branchType) > -1) || (level == 1 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.length == 0)) {
//                return true;
//            }
//            if (level == 2 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.indexOf(data.branchType) > -1 && $scope.configParam.selectedCity.indexOf(data.districtName) > -1) {
//                return true;
//            }
//            if (level == 3 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.indexOf(data.branchType) > -1 && $scope.configParam.selectedCity.indexOf(data.districtName) > -1 && $scope.configParam.selectedBranchName.indexOf(data.branchName) > -1) {
//                return true;
//            }
//            if (level == 4 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.indexOf(data.branchType) > -1 && $scope.configParam.selectedCity.indexOf(data.districtName) > -1 && $scope.configParam.selectedBranchName.indexOf(data.branchName) > -1 && $scope.configParam.selectedVendor.indexOf(data.locSubtype) > -1) {
//                return true;
//            }
//            if (level == 5 && $scope.configParam.selectedRegion.indexOf(data.regionName) > -1 && $scope.configParam.selectedColdChain.indexOf(data.branchType) > -1 && $scope.configParam.selectedCity.indexOf(data.districtName) > -1 && $scope.configParam.selectedBranchName.indexOf(data.branchName) > -1 && $scope.configParam.selectedVendor.indexOf(data.locSubtype) > -1 && $scope.configParam.selectedColdRoom.indexOf(data.locType) > -1) {
//                return true;
//            }
//            return false;
//        };
        $scope.checkCityColdChainMap = function (districtName, branchType) {
            var def = true;
            for (var i = 0; i < $scope.allCityColdChainMap.length; i++) {
                if ($scope.allCityColdChainMap[i].districtName == districtName && $scope.allCityColdChainMap[i].branchType == branchType) {
                    def = false;
                }
            }
            return def;
        }

        $scope.checkCondition = function (data, level) {//level filtering
            if (level == 0 && $scope.conditionalIf('selectedRegion', data.regionName)) {
                return true;
            }
            if (level == 1 && $scope.conditionalIf('selectedRegion', data.regionName) && $scope.conditionalIf('selectedColdChain', data.branchType)) {
                return true;
            }
            if (level == 2 && $scope.conditionalIf('selectedRegion', data.regionName) && $scope.conditionalIf('selectedColdChain', data.branchType) && $scope.conditionalIf('selectedCity', data.districtName)) {
                return true;
            }
            if (level == 3 && $scope.conditionalIf('selectedRegion', data.regionName) && $scope.conditionalIf('selectedColdChain', data.branchType) && $scope.conditionalIf('selectedCity', data.districtName) && $scope.conditionalIf('selectedBranchName', data.branchName)) {
                return true;
            }
            if (level == 4 && $scope.conditionalIf('selectedRegion', data.regionName) && $scope.conditionalIf('selectedColdChain', data.branchType) && $scope.conditionalIf('selectedCity', data.districtName) && $scope.conditionalIf('selectedBranchName', data.branchName) && $scope.conditionalIf('selectedVendor', data.locSubtype)) {
                return true;
            }
            if (level == 5 && $scope.conditionalIf('selectedRegion', data.regionName) && $scope.conditionalIf('selectedColdChain', data.branchType) && $scope.conditionalIf('selectedCity', data.districtName) && $scope.conditionalIf('selectedBranchName', data.branchName) && $scope.conditionalIf('selectedVendor', data.locSubtype) && $scope.conditionalIf('selectedColdRoom', data.locType)) {
                return true;
            }
            return false;
        };
        $scope.conditionalIf = function (type, value) {
            if ($scope.configParam[type].length == 0) {
                return true;
            } else if ($scope.configParam[type].length > 0 && $scope.configParam[type].indexOf(value) > -1) {
                return true;
            } else {
                return false;
            }
        }
        $scope.setSelectedFilter = function () {
            $scope.selectedFilter = {
                "selectedUILevel": ($scope.configParam.selectedUILevel.length ? "'" + $scope.configParam.selectedUILevel.join("','") + "'" : ""),
                "selectedRegion": ($scope.configParam.selectedRegion.length ? "'" + $scope.configParam.selectedRegion.join("','") + "'" : ""),
                "selectedColdChain": ($scope.configParam.selectedColdChain.length ? "'" + $scope.configParam.selectedColdChain.join("','") + "'" : ""),
                "selectedCity": ($scope.configParam.selectedCity.length ? "'" + $scope.configParam.selectedCity.join("','") + "'" : ""),
                "selectedBranchName": ($scope.configParam.selectedBranchName.length ? "'" + $scope.configParam.selectedBranchName.join("','") + "'" : ""),
                "selectedVendor": ($scope.configParam.selectedVendor.length ? "'" + $scope.configParam.selectedVendor.join("','") + "'" : ""),
                "selectedColdRoom": ($scope.configParam.selectedColdRoom.length ? "'" + $scope.configParam.selectedColdRoom.join("','") + "'" : ""),
                "selectedDeviceID": ($scope.configParam.selectedDeviceID.length ? "'" + $scope.configParam.selectedDeviceID.join("','") + "'" : ""),
                "selectedFromDate": $scope.configParam.fromdate,
                "selectedToDate": $scope.configParam.todate,
                "type": $scope.trendType,
                "temperature": $scope.temperatureRange
            };
        }
        $scope.applyFilter = function () {
            $scope.levelManagment();
            $scope.setSelectedFilter();
            var fromdate = $scope.getActDate($scope.configParam.fromdate);
            var todate = $scope.getActDate($scope.configParam.todate);
            // var timeDiff = Math.abs(todate.getTime() - fromdate.getTime());
            // var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
            if (fromdate > todate) {
                alert("From date must be less then to date");
                return;
            }
//            else if (diffDays > 4) {
//                alert("You can not select date range more then 4 days");
//                return;
//            }
//            if ($scope.checkDefaultData()) {
//                $scope.drawChart(true);
//            } else {
            $scope.drawChart(false);
//            }
        }
        $scope.ByColdChain = function (data) {
            if ($.inArray(data[0], $scope.configParam.selectedColdChain) >= 0 || $scope.configParam.selectedColdChain.length == 0) {
                return true;
            } else {
                return false;
            }
        }
        $scope.ByCity = function (data) {
            if (data[0] == "") {
                return false;
            }
            if ($.inArray(data[0], $scope.configParam.selectedCity) >= 0 || $scope.configParam.selectedCity.length == 0) {
                return true;
            } else {
                return false;
            }
        }

        $scope.ByRegion = function (data, color) {//temptype=tempraturetype
            var temp = 0;
            var total = 0
            if (color == 'Amber') {
                temp = Number(data[1]);
            } else if (color == 'Green') {
                temp = Number(data[2]);
            } else if (color == 'Red') {
                temp = Number(data[3]);
            } else if (color == 'Yellow') {
                temp = Number(data[4]);
            }
            for (var i = 1; i < data.length; i++) {
                total += data[i];
            }
            var num = (temp * 100) / total;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        };

        $scope.ByDeviceData = function (key, value, colorname) {
            var total = 0;
            var temp = value[colorname];
            angular.forEach(value, function (val, key) {
                total += val;
            });
            var num = (temp * 100) / total;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.ByDeviceDataAvg = function (key, colorname) {
            var alldata = $scope.allNextLevelData[$scope.configParam.selectedCity[0]].deviceIDavg;
            var avgdata = alldata[key];
            var num = avgdata[colorname];
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.ByRegionAvg = function (type, temptype) {//type will name of cold chain & temptype will be temprature range
            var num = $scope.othergraphavg[type][temptype];
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }
        $scope.ByCityAvg = function (type, temptype) {
            var citydata = $scope.allNextLevelData[type];
            var temp = 0;
            var totaldivice = Object.keys(citydata.deviceIDavg).length;
            angular.forEach(citydata.deviceIDavg, function (value) {
                temp += value[temptype];
            });
            var num = (temp) / totaldivice;
            if (isNaN(num)) {
                return 0;
            } else {
                return num.toFixed(2);
            }
        }

        $scope.setInitialTemperatureConfig = function () {
            $scope.totalcompcolor = HUL_CONST.totalcompcolor;

            $scope.trendType = $routeParams.trendType;
            $scope.colors = HUL_CONST.colors;
            $scope.colorsarr = HUL_CONST.colorsarr;
            $scope.temperature = [''];//header of graph
            for (var i = 0; i < $scope.colors.length; i++) {
                $scope.temperature.push($scope.colors[i]);
            }
            $scope.temperature.push({role: 'style'});
        };
        $scope.init = function () {
            $scope.level = 1;
            $scope.initscope =
                    [
                        {
                            "level": 0,
                            "scopename": "allRegion",
                            "selectedscope": "selectedRegion",
                            "isDisabled": false
                        },
                        {
                            "level": 1,
                            "scopename": "allColdChain",
                            "selectedscope": "selectedColdChain",
                            "isDisabled": true
                        },
                        {
                            "level": 2,
                            "scopename": "allCity",
                            "selectedscope": "selectedCity",
                            "isDisabled": true
                        },
                        {
                            "level": 3,
                            "scopename": "allBranchName",
                            "selectedscope": "selectedBranchName",
                            "isDisabled": true
                        },
                        {
                            "level": 4,
                            "scopename": "allVendor",
                            "selectedscope": "selectedVendor",
                            "isDisabled": true
                        },
                        {
                            "level": 5,
                            "scopename": "allColdRoom",
                            "selectedscope": "selectedColdRoom",
                            "isDisabled": true
                        },
                        {
                            "level": 6,
                            "scopename": "allDeviceIDs",
                            "selectedscope": "selectedDeviceID",
                            "isDisabled": true
                        }
                    ];

            $scope.setInitialTemperatureConfig();
            $scope.getTemperatureJson();
            $scope.setChartConfigParam();
            $scope.graphdata = [];
            $scope.alldata = [];
            $scope.allCityColdChainMap = [];
            $scope.filtereddata = [];
            $scope.isDisabled = true;
            $scope.isexpanded = true;
            $scope.isselected = false;
            $scope.selectedindex = [];
            $scope.levelManagment();

        };
        $scope.getTemperatureJson = function () {
            var deferred = $q.defer();
            var promise = deferred.promise;
            $http.get(tempContextPath + "/data/temperature.json").success(function (data) {
                deferred.resolve(data);
            }).error(function (msg, code) {
                deferred.reject(msg);
                $log.error(msg, code);
            });
            promise.then(function (data) {
                if ($scope.trendType == 'regional' || $scope.trendType == 'temperature') {
                    $scope.temperatureRange = data['regional'];
                } else {
                    $scope.temperatureRange = data[$scope.trendType];
                }
                if ($scope.trendType == 'compliance') {//temp fix need specified in database
                    $scope.indiaCompliance = data['monitor'];
                }
                $scope.formateTempratureBasedonTrendtype();

            }, function () {
                //console.log('if failer);
            });
        };
        $scope.formateTempratureBasedonTrendtype = function () {
            if ($scope.trendType == 'regional' || $scope.trendType == 'temperature') {
                var temp = [];
                var k = 0;
                for (var i = 1; i <= 4; i++) {
                    var temparr = [];
                    $.each($scope.temperatureRange, function (key, value) {
                        for (var j = 0; j < value.length; j++) {
                            if (value[j].id == i) {
                                value[j]['branchType'] = key;
                                temparr.push(value[j]);
                                break;
                            }
                        }
                    });
                    temp[k] = temparr;
                    k++;
                }
                $scope.regionaltemperature = temp;
            } else if ($scope.trendType == 'monitor') {
                $scope.indiaCompliance = $scope.temperatureRange;
                $scope.indianCompilanceData = [];
            }
        };
        $scope.getSheetName = function () {
            var fromdate = $scope.getActDate($scope.configParam.fromdate);
            var todate = $scope.getActDate($scope.configParam.todate);
            var opt;
            if (fromdate.toDateString() == todate.toDateString()) {
                var data = fromdate.toDateString().split(" ");
                opt = data[2] + '' + data[1];
            } else {
                var fromdata = fromdate.toDateString().split(" ");
                var todata = todate.toDateString().split(" ");
                opt = fromdata[2] + '' + fromdata[1] + "-" + todata[2] + '' + todata[1];
            }
            return "RegionalTrend-DataExtract-" + opt;
        };
        $scope.exportData = function () {
            $scope.setSelectedFilter();
            $scope.selectedFilter.isdefault="false";
            if ($scope.trendType == 'compliance') {
                $scope.selectedFilter.coldchain = {
                    "FACTORY": -20,
                    "PT": -20,
                    "DEPOT": -20,
                    "ST": -20,
                    "RS Cold Room": -18,
                    "RSV": -18,
                    "FACTORYANT": {
                        "locSubType": 2,
                        "paramValue": -5
                    },
                    "DEPOTANT": {
                        "locSubType": 2,
                        "paramValue": -5
                    }
                };
            }
            $http.post(tempContextPath + "/exportToExcel", $scope.selectedFilter).success(function (data) {
                window.location.href = data.filepath;
            });

            /* var xlname = $scope.getSheetName();
             var xlheader = {
             sheetid: xlname,
             headers: true,
             column: {
             style: 'background:#FFFF33'
             },
             columns: [
             {columnid: 'region_code', width: 150},
             {columnid: 'branch_type', width: 150},
             {columnid: 'device_id', width: 150},
             {columnid: 'branch_name', width: 150},
             {columnid: 'txn_time', width: 150},
             {columnid: 'param_value', width: 150}
             ]
             };
             var data = [];
             for (var i = 0; i < $scope.filtereddata.length; i++) {
             var obj = {
             "region_code": $scope.filtereddata[i].regionCode,
             "branch_type": $scope.filtereddata[i].branchType,
             "device_id": $scope.filtereddata[i].deviceId,
             "branch_name": $scope.filtereddata[i].branchName,
             "txn_time": $scope.filtereddata[i].txnTime,
             "param_value": Number($scope.filtereddata[i].paramValue)
             };
             data.push(obj);
             }
             alasql("SELECT * INTO XLS('" + xlname + ".xls',?) FROM ? ", [xlheader, data]);*/
//            alasql("SELECT * INTO xlsx('DEPOT-West-Andheri-23Dec.xlsx',?) FROM ? ", [xlheader, data]);
        }
        $scope.generatePDF = function () {
            var doc = new jsPDF('p', 'pt', 'a4', false); /* Creates a new Document*/
            doc.setFontSize(18); /* Define font size for the document */
            //doc.setTextColor(255, 0, 0);
            var yAxis = 30;
            var imageTags = $('#graph-images img');
            for (var i = 0; i < imageTags.length; i++) {
                if (i % 2 == 0 && i != 0) { /* I want only two images in a page */
                    doc.addPage();  /* Adds a new page*/
                    yAxis = 30; /* Re-initializes the value of yAxis for newly added page*/
                }
                var someText = imageTags[i].alt;
                doc.text(60, yAxis, someText); /* Add some text in the PDF */
                yAxis = yAxis + 20; /* Update yAxis */
                doc.addImage(imageTags[i], 'png', 40, yAxis, 530, 350, undefined, 'none');
                yAxis = yAxis + 380; /* Update yAxis default 360*/
            }
            doc.save('hul_report' + '.pdf');
        };
        // Left Panel Dropdown enable Disable Logic..
        $scope.$watch('configParam.selectedRegion', function () {
            if ($scope.configParam.selectedRegion.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allRegion', 'selectedRegion', false, 0);
                $scope.checkDisabledCondition(0);
            } else {
                if ($scope.allDropdowndata != undefined) {
                    $scope.setDefaultDisabledByLevel(0);
                    $scope.setSelectedToDefault('selectedRegion');
                }
            }

        });
        $scope.$watch('configParam.selectedColdChain', function () {
            if ($scope.configParam.selectedColdChain.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allColdChain', 'selectedColdChain', false, 1);
                $scope.checkDisabledCondition(1);
            } else {
                $scope.setDefaultDisabledByLevel(1);
                //$scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedCity', function () {
            if ($scope.configParam.selectedCity.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allCity', 'selectedCity', false, 2);
                $scope.checkDisabledCondition(2);
            } else {
                $scope.setDefaultDisabledByLevel(2);
                //$scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedBranchName', function () {
            if ($scope.configParam.selectedBranchName.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allBranchName', 'selectedBranchName', false, 3);
                $scope.checkDisabledCondition(3);
            } else {
                $scope.setDefaultDisabledByLevel(3);
                //$scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedVendor', function () {
            if ($scope.configParam.selectedVendor.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allVendor', 'selectedVendor', false, 4);
                $scope.checkDisabledCondition(4);
            } else {
                $scope.setDefaultDisabledByLevel(4);
                //$scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedColdRoom', function () {
            if ($scope.configParam.selectedColdRoom.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allColdRoom', 'selectedColdRoom', false, 5);
                $scope.checkDisabledCondition(5);
            } else {
                $scope.setDefaultDisabledByLevel(5);
                //$scope.setDefaultFilter();
            }
        });
        $scope.$watch('configParam.selectedDeviceID', function () {
            if ($scope.configParam.selectedDeviceID.length > 0) {
                $scope.filterLocationData($scope.allDropdowndata, 'allDeviceIDs', 'selectedDeviceID', false, 6);
            }
        });
        $scope.setDefaultFilter = function () {// no need to do edition as it's below level we are alread disabled in setDefaultDisabledByLevel function
            // if ($scope.allDropdowndata != undefined) {
            //$scope.filterLocationData($scope.allDropdowndata, 'allRegion', 'selectedRegion', false);
            //}
        };
        $scope.checkDisabledCondition = function (level) {
            $scope.setDefaultDisabledByLevel(level);
            for (var j = 0; j < $scope.initscope.length; j++) {
                if ($scope.initscope[j].level == level && $scope.initscope[j].isDisabled == false) {
                    $scope.initscope[j + 1].isDisabled = false;
                    break;
                }
            }
        }
        $scope.setDefaultDisabledByLevel = function (level) {
            for (var j = 0; j < $scope.initscope.length; j++) {
                if ($scope.initscope[j].level > level) {
                    $scope.initscope[j].isDisabled = true;
                    $scope.configParam[$scope.initscope[j].selectedscope] = [];
                }
            }
        }
        $scope.getTrendname = function (type) {
            if (type != 'monitor' && type != 'compliance') {
                return $scope.capitalizeFirstLetter(type) + " Trend";
            } else if (type == 'monitor') {
                return "India Compliance Monitoring";
            } else if (type = 'compliance') {
                return "Pan India Compliance Monitoring";
            }

        }
        $scope.setSelectedToDefault = function (filterscopetype) {
            for (var j = 0; j < $scope.initscope.length; j++) {//set other scope to blank expect the selected one.
                if ($scope.initscope[j].selectedscope != filterscopetype) {
                    $scope.configParam[$scope.initscope[j].selectedscope] = [];
                }
            }
        }
        $scope.init();
    }]);