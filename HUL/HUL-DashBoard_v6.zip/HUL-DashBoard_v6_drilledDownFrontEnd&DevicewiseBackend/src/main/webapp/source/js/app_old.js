'use strict';

/* Controllers */
google.charts.load('current', {packages: ['corechart']});
google.charts.setOnLoadCallback(function () {
angular.bootstrap(document.body, ['hul']);
});

// declare modules
angular.module('Authentication', []);

var myApp = angular.module('hul', ['am.multiselect', 'ngRoute', 'Authentication', 'ngCookies', 'myApp.directives','myApp.filters']).config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
        $routeProvider.
                when('/login', {templateUrl: tempContextPath + '/jsp/login.jsp'}).
                when('/index/:trendType', {templateUrl: tempContextPath + '/jsp/index.jsp', controller: "charts"}).
                otherwise({redirectTo: '/login'});
    }]);

myApp.constant('HUL_CONST', {//#FF0000,#FFFF33,#FFC200,#66CC00. Note Don't chnage the Id , it;s unique which used in graph ordering
    path: '/index',
    totalcompcolor: "#66CC00",
    temperatureRange: [{
            "id": 1,
            "type": "above -12",
            "min": -12,
            "max": 100,
            "color": "#FF0000",
            "fontcolor": "white",
            "colorname": "Red"
        }, {
            "id": 2,
            "type": "-12.1 to -15.9",
            "min": -15.9,
            "max": -12.1,
            "color": "#FFFF33",
            "fontcolor": "black",
            "colorname": "Yellow"
        }, {
            "id": 3,
            "type": "-16 to -21.9",
            "min": -21.9,
            "max": -16,
            "color": "#FFC200",
            "fontcolor": "white",
            "colorname": "Amber"
        }, {
            "id": 4,
            "type": "-22 & below",
            "min": -50,
            "max": -22,
            "color": "#66CC00",
            "fontcolor": "white",
            "colorname": "Green"
        }], //#990000
    indiaCompliance: [{
            "id": 5,
            "type": "above -10",
            "min": 0,
            "max": 50,
            "color": "#FF0000",
            "fontcolor": "white",
            "colorname": "Red",
            "group": "compliance",
            "inper": "< 50 %"
        }, {
            "id": 6,
            "type": "-14 to -19.9",
            "min": 50,
            "max": 70,
            "color": "#FFC200",
            "fontcolor": "white",
            "colorname": "Amber",
            "group": "compliance",
            "inper": "50% - 70%"
        }, {
            "id": 7,
            "type": "-20 & below",
            "min": 70,
            "max": 100,
            "color": "#66CC00",
            "fontcolor": "white",
            "colorname": "Green",
            "group": "compliance",
            "inper": "> 70%"
        }]
});


myApp.run(['$rootScope', '$location', '$cookieStore', '$http',
    function ($rootScope, $location, $cookieStore, $http) {
        $rootScope.isUserLoggedIn = false;
		// keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};

        if ($rootScope.globals.currentUser) {
			$rootScope.isUserLoggedIn = true;
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }
 
        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in
            if ($location.path() !== '/login' && !$rootScope.globals.currentUser) {
                $location.path('/login');
            }
        });
		
		 $rootScope.appendToArray = function (obj, arr) {
        if (arr.indexOf(obj) == -1) {
            arr.push(obj);
        }
    }
    $rootScope.prependToArray = function (obj, arr) {
        if (arr.indexOf(obj) == -1) {
            arr.unshift(obj);
        }
    }
    $rootScope.removeFromArray = function (obj, arr) {
        arr.splice(arr.indexOf(obj), 1);
    }
    $rootScope.openModal = function () {
        document.getElementById('modal').style.display = 'block';
        document.getElementById('fade').style.display = 'block';
		$('html, body').css({//html, body
			'overflow': 'hidden',
			'height': '100%'
		});
    }
    $rootScope.closeModal = function () {
        document.getElementById('modal').style.display = 'none';
        document.getElementById('fade').style.display = 'none';
		$('html, body').css({//html, body
			'overflow': 'auto',
			'height': 'auto'
		});
		$('html, body').css({//html, body
			'overflow-x': 'hidden'
		});
    }
	$rootScope.capitalizeFirstLetter = function (string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}
	
	$rootScope.getFormatedDate = function (seldate) {
		if (seldate == undefined) {
			seldate = new Date();
		}
		var dd = seldate.getDate();
		var mm = seldate.getMonth() + 1; //January is 0!

            var yyyy = seldate.getFullYear();
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            var actdate = dd + '-' + mm + '-' + yyyy;
            return actdate;
        };
        $rootScope.getActDate = function (date) {
            var data = date.split("-");
            var dd = data[0];
            var mm = data[1] - 1;
            var yyyy = data[2];
            var actdate = new Date(yyyy, mm, dd, 0, 0, 0);
            return actdate;
        };
    }]);

