'use strict';

/* Filters */

var AppFilters = angular.module('myApp.filters', []);


AppFilters.filter('ByDeviceColdChain', function () {
    return function (data, coldchain) {
        var filterd = [];
        for (var i = 0; i < data.length; i++) {
            var value = data[i];
            if (value.branchType == coldchain) {
                filterd.push(value);
            }
        }
        return filterd;
    }
});
AppFilters.filter('custom', function () {// used in level 2 for keyh based filter 
    return function (input, search) {
        if (!input)
            return input;
        if (!search)
            return input;
        console.log(search)
        var expected = search.toLowerCase();
        var result = {};
        angular.forEach(input, function (value, key) {
            var actual =  key.toLowerCase();
            if (actual.indexOf(expected) !== -1) {
                result[key] = value;
            }
        });
        return result;
    }
});