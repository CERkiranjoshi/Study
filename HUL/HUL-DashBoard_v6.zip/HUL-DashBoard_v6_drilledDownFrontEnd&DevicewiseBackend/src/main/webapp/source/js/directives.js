'use strict';

/* Directives */

var AppDirectives = angular.module('myApp.directives', []);
AppDirectives.directive('datetimez', function () {// used in RCA datetime both
    return {
        restrict: 'A', // A match with only matches attribute name , E Element Name, C Class name
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {//Directives that want to modify the DOM #Link do the Job
//            scope.$watch(attrs.datetimez, function ngWatchAction(value) {
            var options = {format: 'dd-mm-yyyy'};
            if (element.hasClass('no-previous')) {
                options.beforeShowDay = function (date) {
                    var d = new Date();
                    var n = d.getTime();
                    var yp = n - 1000 * 60 * 60 * 24;   // current date's milliseconds - 1,000 ms * 60 s * 60 mins * 24 hrs * (# of days beyond one to go back)
                    var curDate = new Date(yp);
                    curDate.setHours(0, 0, 0, 0);
                    return (date <= curDate);
                }
            }
            var value = attrs.datetimez;
            element.datepicker(options);
            element.datepicker().on('changeDate', function (e) {
//                $(this).datepicker('hide');
                element.datepicker('hide');
                ngModelCtrl.$setViewValue(e.date);
                scope.$apply();
            });
            var date;
            if (value == 'today') {
                var d = new Date();
                var n = d.getTime();
                var yp = n - 1000 * 60 * 60 * 24;   // current date's milliseconds - 1,000 ms * 60 s * 60 mins * 24 hrs * (# of days beyond one to go back)
                date = new Date(yp);
            } else {
                var d = new Date();
                var n = d.getTime();
                var yp = n - 1000 * 60 * 60 * 24 * 3;   // current date's milliseconds - 1,000 ms * 60 s * 60 mins * 24 hrs * (# of days beyond one to go back)
                date = new Date(yp);
            }
            element.datepicker('update', date);
        }

    };
});
AppDirectives.directive('slideable', function () {
    return {
        restrict: 'C',
        compile: function (element, attr) {
            // wrap tag
            var contents = element.html();
            element.html('<div class="slideable_content" style="margin:0 !important; padding:0 !important" >' + contents + '</div>');
            return function postLink(scope, element, attrs) {
                // default properties
                attrs.duration = (!attrs.duration) ? '1s' : attrs.duration;
                attrs.easing = (!attrs.easing) ? 'ease-in-out' : attrs.easing;
                element.css({
                    'overflow': 'hidden',
                    'height': '0px',
                    'transitionProperty': 'height',
                    'transitionDuration': attrs.duration,
                    'transitionTimingFunction': attrs.easing
                });
            };
        }
    };
})
AppDirectives.directive('slideToggle', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var target = document.querySelector(attrs.slideToggle);
            attrs.expanded = false;
            element.bind('click', function () {
                target = document.querySelector(attrs.slideToggle);
                var content = target.querySelector('.slideable_content');
                if (!attrs.expanded) {
                    content.style.border = '1px solid rgba(0,0,0,0)';
                    var y = content.clientHeight;
                    content.style.border = 0;
                    target.style.height = y + 'px';
                } else {
                    target.style.height = '0px';
                }
                attrs.expanded = !attrs.expanded;
            });
        }
    }
});
