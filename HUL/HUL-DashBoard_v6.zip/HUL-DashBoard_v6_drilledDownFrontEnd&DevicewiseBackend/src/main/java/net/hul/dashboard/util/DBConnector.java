/**
 * 
 */
package net.hul.dashboard.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import net.hul.dashboard.dto.Branch;
import net.hul.dashboard.dto.Country;
import net.hul.dashboard.dto.FilterData;
import net.hul.dashboard.dto.MonthlyTrendData;
import net.hul.dashboard.dto.Region;
import net.hul.dashboard.dto.TablesJoin;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;

/**
 * @author a561065
 *
 */
@Controller
public class DBConnector extends BaseController{

	private static final Log LOGGER = LogFactory.getLog(DBConnector.class);

	/*
	 INSERT INTO iot_tx_raw_data (id,appliance_id,created_by,created_date,device_id,modified_by,modified_date,raw_data,rd_addl_info,rd_cat,rd_sub_cat,rd_sub_type,rd_type,service_name,tenant_name,tx_lat,tx_location,tx_long,status_code,status_subcode,txn_time)
		     			  SELECT  id,appliance_id,created_by,created_date,device_id,modified_by,modified_date,raw_data,rd_addl_info,rd_cat,rd_sub_cat,rd_sub_type,rd_type,service_name,tenant_name,tx_lat,tx_location,tx_long,status_code,status_subcode,txn_time FROM hul_nov_dec

	 INSERT INTO IOT_TX_DATA (id ,alert_flag ,associated_id ,associated_sub_id ,created_by ,created_date ,modified_by ,modified_date ,param_name ,param_type ,param_value ,tx_addl_info ,tx_cat ,tx_id ,  tx_sub_cat ,tx_sub_type ,tx_timestamp ,tx_type ,status_code ,status_subcode )
		  SELECT id ,alert_flag ,associated_id ,associated_sub_id ,created_by ,created_date ,modified_by ,modified_date ,param_name ,param_type ,param_value ,tx_addl_info ,tx_cat ,tx_id ,  tx_sub_cat ,tx_sub_type ,tx_timestamp ,tx_type ,status_code ,status_subcode FROM hul_nov_dec_tx 

	 */

	/**
	 * This method fetches distinct country_name from country table whose tenant_id = 'HIN'
	 * @return list of distinct country_name
	 */
	public List<Country> getULLevels() {
		List<Country> countryList = new ArrayList<Country>();
		ResultSet rs = null;
		Country record = null;		
		Connection conn = null;
		PreparedStatement preparedStatementForQuery2 = null;
		String queryStrFieldSet2 = "select country_name, country_code,tenant_id from country where tenant_id='HIN'";
		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery2 = conn.prepareStatement(queryStrFieldSet2);
			rs = preparedStatementForQuery2.executeQuery();
			while (rs.next()) {
				record = new Country();
				record.setCountryName(rs.getString(1));
				record.setCountryCode(rs.getString(2));
				record.setTenantId(rs.getString(3));
				countryList.add(record);
			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery2 != null )
					preparedStatementForQuery2.close();
			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}
		return countryList;
	}

	/**
	 * This method fetches distinct region_name from region table whose tenant_id = 'HIN' and the access zones to which the user has access/permission
	 * @param hashMapSessionValues
	 * @return list of distinct region_name
	 */
	public List<Region> getRegions(HashMap<String,String> hashMapSessionValues) {
		List<Region> regionList = new ArrayList<Region>();
		ResultSet rs = null;
		Region record = null;	
		Connection conn = null;
		PreparedStatement preparedStatementForQuery1 = null;
		String queryStrFieldSet1 = "select region_name , region_code, country_code from region where (tenant_id='HIN' and region_name IN ("+fetchZones(hashMapSessionValues.get(HULConstant.ACCESS_ZONE))+"))";

		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery1 = conn.prepareStatement(queryStrFieldSet1);
			rs = preparedStatementForQuery1.executeQuery();
			while (rs.next()) {
				record = new Region();
				record.setRegionName(rs.getString(1));
				record.setRegionCode(rs.getString(2));
				record.setCountryCode(rs.getString(3));
				regionList.add(record);
			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery1 != null )
					preparedStatementForQuery1.close();
			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}
		return regionList;
	}

	/**
	 * This method fetches distinct cold-chain values to user the user has access/permission
	 * @param hashMapSessionValues
	 * @return list of distinct cold-chain
	 */
	public List<Branch> getColdChainList(HashMap<String,String> hashMapSessionValues) {
		List<Branch> coldChainList = new ArrayList<Branch>();
		Branch record = null;
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_FACTORY), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("FACTORY");
			coldChainList.add(record);
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_PV), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("PT");
			coldChainList.add(record);
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_DEPOT), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("DEPOT");
			coldChainList.add(record);
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_SV), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("ST");
			coldChainList.add(record);
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_RS_COLDROOM), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("RS Cold Room");
			coldChainList.add(record);
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_RSV), HULConstant.TRUE)){
			record = new Branch();
			record.setBranchType("RSV");
			coldChainList.add(record);
		}
		return coldChainList;
	}

	/**
	 * This method appends the cold-chain(branchType) values in a string so that it can directly be used in "IN(condition)" for executing query
	 * @param hashMapSessionValues
	 * @return list of distinct cold-chain
	 */
	public String fetchBranchTypeValuesFromHashMap(HashMap<String, String> hashMapSessionValues) {
		StringBuffer sbBranchType = new StringBuffer();
		String branchType = null;

		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_FACTORY), HULConstant.TRUE)){
			sbBranchType.append("'"+"FACTORY"+"',");
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_PV), HULConstant.TRUE)){
			sbBranchType.append("'"+"PT"+"',");
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_DEPOT), HULConstant.TRUE)){
			sbBranchType.append("'"+"DEPOT"+"',");
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_SV), HULConstant.TRUE)){
			sbBranchType.append("'"+"ST"+"',");
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_RS_COLDROOM), HULConstant.TRUE)){
			sbBranchType.append("'"+"RS Cold Room"+"',");
		}
		if(StringUtils.equals(hashMapSessionValues.get(HULConstant.ACCESS_RSV), HULConstant.TRUE)){
			sbBranchType.append("'"+"RSV"+"',");
		}

		branchType = sbBranchType.toString();
		if (branchType.endsWith(",")) {
			branchType = branchType.substring(0, branchType.length() - 1);
		}

		return branchType;
	}

	/**
	 * This method fetches access_zone, access_factory, access_pv, access_depot,access_sv,access_rs_cold_room,access_rsv values for user from employee_role table
	 * @param emailId
	 * @param password
	 * @return failure when user not found in employee_role ELSE if found ,it returns success and the access_zone, access_factory, access_pv, access_depot,access_sv,access_rs_cold_room,access_rsv values for user from employee_role table
	 */
	public HashMap<String,String> getRoleAndStatus(String emailId ,String password) {
		HashMap<String,String> hashMap = new HashMap<String, String>();
		String status = HULConstant.FAILURE;
		PreparedStatement preparedStatementForQuery11 = null;
		String queryStrFieldSet11 = "select access_zone, access_factory, access_pv, access_depot,access_sv,access_rs_cold_room,access_rsv from employee_role where ((lower(mail_id) like '"+StringUtils.lowerCase(emailId)+"@%'))";
		System.out.println("Login Query:"+queryStrFieldSet11);
		String accessZone = null;
		Boolean accessFactory = null;
		Boolean accessPV = null;
		Boolean accessDepot = null;
		Boolean accessSV = null;
		Boolean accessRSColdRoom = null;
		Boolean accessRSV = null;
		ResultSet rs = null;
		Connection conn = null;
		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery11 = conn.prepareStatement(queryStrFieldSet11);
			//preparedStatementForQuery11.setString(1,StringUtils.lowerCase(emailId));
			//preparedStatementForQuery11.setString(2, password);
			rs = preparedStatementForQuery11.executeQuery();
			while (rs.next()) {
				accessZone = rs.getString(1);
				accessFactory = rs.getBoolean(2);
				accessPV = rs.getBoolean(3);
				accessDepot = rs.getBoolean(4);
				accessSV = rs.getBoolean(5);
				accessRSColdRoom = rs.getBoolean(6);
				accessRSV = rs.getBoolean(7);	
				System.out.println("accessZone:"+accessZone + " accessFactory:"+accessFactory +" accessPV:"+accessPV+" accessDepot:"+accessDepot+" accessSV:"+accessSV+" accessRSColdRoom:"+accessRSColdRoom +" accessRSV:"+accessRSV);
				status = HULConstant.SUCCESS;
				hashMap.put("accessZone", accessZone);
				hashMap.put("accessFactory", accessFactory.toString());
				hashMap.put("accessPV", accessPV.toString());
				hashMap.put("accessDepot", accessDepot.toString());
				hashMap.put("accessSV", accessSV.toString());
				hashMap.put("accessRSColdRoom", accessRSColdRoom.toString());
				hashMap.put("accessRSV", accessRSV.toString());
			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery11 != null )
					preparedStatementForQuery11.close();
			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}

		hashMap.put(HULConstant.STATUS, status);
		return hashMap;
	}

	/**
	 * This method fetches region.region_code, branch.branch_type, device_assigned.loc_code, device_assigned.device_id, iot_tx_data.param_value, branch.branch_name, location.loc_type, location.loc_subtype, district.district_name, iot_tx_raw_data.txn_time
	 * This method filters data based on Region and cold-chain type according to user access/permission
	 * @param filteredHashMap
	 * @param type
	 * @return list of FilterData Objects which contains regionCode,branchType,locCode,deviceId,paramValue,branchName,locType,locSubType,districtName,txnTime values
	 */
	public List<FilterData> getFilteredData(HashMap<String, String> filteredHashMap,String type) {
		List<FilterData> list = new ArrayList<FilterData>();
		ResultSet rs = null;
		FilterData record = null;
		PreparedStatement preparedStatementForQuery13 = null;
		String toDate = null;
		String fromDate = null;
		String[] datesToBeConsidered = null;
		String query = null;
		Connection conn = null;
		try {
			String datesVal = compareDates(filteredHashMap.get(HULConstant.SELECTED_FROM_DATE),filteredHashMap.get(HULConstant.SELECTED_TO_DATE));
			datesToBeConsidered = datesVal.split(","); 
			toDate = datesToBeConsidered[1];
			fromDate = datesToBeConsidered[0];
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		if(StringUtils.equals(type, HULConstant.DEFAULT)){
			//fromDate="20-01-2016";
			//toDate="28-01-2016";
			query = generateQuery(filteredHashMap,fromDate,toDate, HULConstant.DEFAULT);
		}else{
			query = generateQuery(filteredHashMap,fromDate,toDate, HULConstant.FILTER);
		}


		System.out.println("query:"+query);
		LOGGER.info("DBConnector: getFilteredData() : Query execution started : "+new Date());
		LOGGER.info("DBConnector: getFilteredData() : query : "+query);
		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery13 = conn.prepareStatement(query);
			rs = preparedStatementForQuery13.executeQuery();
			while (rs.next()) {
				record = new FilterData();
				record.setRegionCode(rs.getString(1));	
				record.setBranchType(rs.getString(2));
				record.setLocCode(rs.getString(3));
				record.setDeviceId(rs.getString(4));
				//record.setParamName(rs.getString(5));
				record.setParamValue(rs.getString(6));
				//record.setTxId(rs.getLong(7));
				//record.setId(rs.getLong(8));
				record.setBranchName(rs.getString(11));
				record.setLocType(rs.getString(12));
				record.setLocSubType(rs.getString(13));
				record.setDistrictName(rs.getString(14));
				record.setTxnTime(rs.getString(15));
				record.setAddress1(rs.getString(16));
				record.setBranchCodeCust(rs.getString(17));
				record.setApplianceId(rs.getString(18));
				list.add(record);
			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery13 != null)
					preparedStatementForQuery13.close();

			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}
		return list;
	}


	/**
	 * This method generates query dynamically based on DEFAULT/FILTER condition applied to fetch regionCode,branchType,locCode,deviceId,paramValue,branchName,locType,locSubType,districtName,txnTime values
	 * 
	 * @param filteredHashMap
	 * @param fromDate
	 * @param toDate
	 * @param filterType
	 * @return generated dynamic query 
	 */
	private String generateQuery(HashMap<String, String> filteredHashMap,String fromDate, String toDate ,String filterType) {
		StringBuilder sb_query = new StringBuilder();
		if(StringUtils.equals(filterType, HULConstant.FILTER)){
			//sb_query.append("select region.region_code, branch.branch_type, device_assigned.loc_code, device_assigned.device_id, iot_tx_data.param_name, iot_tx_data.param_value, iot_tx_data.tx_id, iot_tx_raw_data.id, iot_tx_raw_data.created_date, iot_tx_data.created_date, branch.branch_name, location.loc_type, location.loc_subtype, district.district_name, to_char(iot_tx_raw_data.txn_time, 'YYYY-MM-DD HH24:MI:SS') from location, device_assigned, region, state, district, branch, iot_tx_raw_data, iot_tx_data where iot_tx_raw_data.tenant_name = 'HIN' and iot_tx_data.param_name = 'TEMP' and iot_tx_data.status_subcode = '0' and iot_tx_raw_data.created_date > to_date('"+fromDate+"', 'DD-MM-YYYY') and iot_tx_raw_data.created_date <= to_date('"+toDate+"', 'DD-MM-YYYY') and iot_tx_raw_data.status_subcode = '0' and iot_tx_data.created_date > to_date('"+fromDate+"', 'DD-MM-YYYY') and iot_tx_data.created_date <= to_date('"+toDate+"', 'DD-MM-YYYY') and iot_tx_data.tx_id = iot_tx_raw_data.id ");
			sb_query.append("select region.region_code, branch.branch_type, device_assigned.loc_code, device_assigned.device_id, iot_tx_data.param_name, iot_tx_data.param_value, iot_tx_data.tx_id, iot_tx_raw_data.id, iot_tx_raw_data.created_date, iot_tx_data.created_date, branch.branch_name, location.loc_type, location.loc_subtype, district.district_name, to_char(iot_tx_data.tx_timestamp, 'YYYY-MM-DD HH24:MI:SS'), branch.address1, branch.branch_code_cust, device_assigned.appliance_id from location, device_assigned, region, state, district, branch, iot_tx_raw_data, iot_tx_data where iot_tx_raw_data.tenant_name = 'HIN' and iot_tx_data.param_name = 'TEMP' and device_assigned.tenant_id = 'HIN' and device_assigned.active = '1' and iot_tx_data.tx_timestamp >= to_date('"+fromDate+"', 'DD-MM-YYYY') and iot_tx_data.tx_timestamp <= (to_date('"+toDate+"', 'DD-MM-YYYY')+1) and iot_tx_data.tx_id = iot_tx_raw_data.id and iot_tx_data.status_code = '0' and iot_tx_data.status_subcode = '0' and iot_tx_raw_data.status_code = '0' and iot_tx_raw_data.status_subcode = '0' and CAST(iot_tx_data.param_value AS decimal(10,2)) < 0.0");
			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_REGION))){
				sb_query.append("and region.region_code in ("+filteredHashMap.get(HULConstant.SELECTED_REGION)+") ");
			}
			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_CITY))){
				sb_query.append("and district.district_name in ("+filteredHashMap.get(HULConstant.SELECTED_CITY)+") ");
			}

			sb_query.append("and state.region_code = region.region_code and district.state_code = state.state_code and branch.district_code = district.district_code  ");

			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_COLD_CHAIN))){
				sb_query.append("and branch.branch_type IN ("+filteredHashMap.get(HULConstant.SELECTED_COLD_CHAIN)+") ");
			}
			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_BRANCH_NAME))){
				sb_query.append("and branch.branch_name IN ("+filteredHashMap.get(HULConstant.SELECTED_BRANCH_NAME)+") ");
			}

			sb_query.append("and location.branch_code = branch.branch_code and location.loc_code = device_assigned.loc_code ");

			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_VENDOR))){
				sb_query.append("and location.loc_subtype IN("+filteredHashMap.get(HULConstant.SELECTED_VENDOR)+") ");
			}
			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_COLD_ROOM))){
				sb_query.append("and location.loc_type IN("+filteredHashMap.get(HULConstant.SELECTED_COLD_ROOM)+") ");
			}
			
			if(StringUtils.isNotBlank(filteredHashMap.get(HULConstant.SELECTED_DEVICE_ID))){
				sb_query.append("and device_assigned.device_id IN ("+filteredHashMap.get(HULConstant.SELECTED_DEVICE_ID)+") ");
			}

			sb_query.append("and iot_tx_raw_data.device_id = device_assigned.device_id");

		}else{
			//sb_query.append("select region.region_code, branch.branch_type, device_assigned.loc_code, device_assigned.device_id, iot_tx_data.param_name, iot_tx_data.param_value, iot_tx_data.tx_id, iot_tx_raw_data.id, iot_tx_raw_data.created_date, iot_tx_data.created_date, branch.branch_name, location.loc_type, location.loc_subtype, district.district_name, to_char(iot_tx_raw_data.txn_time, 'YYYY-MM-DD HH24:MI:SS') from location, device_assigned, region, state, district, branch, iot_tx_raw_data, iot_tx_data where iot_tx_raw_data.tenant_name = 'HIN' and iot_tx_data.param_name = 'TEMP' and iot_tx_data.status_subcode = '0' and iot_tx_raw_data.created_date > to_date('"+fromDate+"', 'DD-MM-YYYY') and iot_tx_raw_data.created_date <= to_date('"+toDate+"', 'DD-MM-YYYY') and iot_tx_raw_data.status_subcode = '0' and iot_tx_data.created_date > to_date('"+fromDate+"', 'DD-MM-YYYY') and iot_tx_data.created_date <= to_date('"+toDate+"', 'DD-MM-YYYY') and iot_tx_data.tx_id = iot_tx_raw_data.id and region.region_code in ("+fetchZones(filteredHashMap.get(HULConstant.ACCESS_ZONE))+") and branch.branch_type IN ("+fetchBranchTypeValuesFromHashMap(filteredHashMap)+") and state.region_code = region.region_code and district.state_code = state.state_code and branch.district_code = district.district_code and location.branch_code = branch.branch_code and location.loc_code = device_assigned.loc_code and iot_tx_raw_data.device_id = device_assigned.device_id");
			sb_query.append("select region.region_code, branch.branch_type, device_assigned.loc_code, device_assigned.device_id, iot_tx_data.param_name, iot_tx_data.param_value, iot_tx_data.tx_id, iot_tx_raw_data.id, iot_tx_raw_data.created_date, iot_tx_data.created_date, branch.branch_name, location.loc_type, location.loc_subtype, district.district_name, to_char(iot_tx_data.tx_timestamp, 'YYYY-MM-DD HH24:MI:SS'), branch.address1, branch.branch_code_cust, device_assigned.appliance_id from location, device_assigned, region, state, district, branch, iot_tx_raw_data, iot_tx_data where iot_tx_raw_data.tenant_name = 'HIN' and iot_tx_data.param_name = 'TEMP' and device_assigned.tenant_id = 'HIN' and device_assigned.active = '1' and iot_tx_data.tx_timestamp >= to_date('"+fromDate+"','DD-MM-YYYY') and iot_tx_data.tx_timestamp <= (to_date('"+toDate+"','DD-MM-YYYY')+1) and iot_tx_data.tx_id = iot_tx_raw_data.id and iot_tx_data.status_code = '0' and iot_tx_data.status_subcode = '0' and iot_tx_raw_data.status_code = '0' and iot_tx_raw_data.status_subcode = '0' and region.region_code in ("+fetchZones(filteredHashMap.get(HULConstant.ACCESS_ZONE))+") and branch.branch_type IN ("+fetchBranchTypeValuesFromHashMap(filteredHashMap)+") and state.region_code = region.region_code and district.state_code = state.state_code and branch.district_code = district.district_code and location.branch_code = branch.branch_code and location.loc_code = device_assigned.loc_code and iot_tx_raw_data.device_id = device_assigned.device_id and CAST(iot_tx_data.param_value AS decimal(10,2)) < 0.0");
		}

		return sb_query.toString();

	}

	/**
	 * This method provides zone values in a string so that it can directly be used in "IN(condition)" for executing query
	 * @param zone
	 * @return zones to which user has access/permission
	 */
	private String fetchZones(String zone) {
		String accessZone = null;
		if(StringUtils.equalsIgnoreCase(zone, HULConstant.PAN_INDIA)){
			accessZone = "'EAST','WEST','NORTH','SOUTH'";		
		}else{
			accessZone = StringUtils.upperCase("'"+zone+"'");
		}
		return accessZone;
	}


	/**
	 * This method manipulates fromDate and toDate so that they can be directly used in conditional query
	 * @param _fromDate
	 * @param _toDate
	 * @return fromDate and toDate in string format
	 * @throws ParseException
	 */
	private String compareDates(String _fromDate,String _toDate) throws ParseException {
		String fromDate = "";
		String toDate = "";
		//Date currentDate = new Date();
		DateFormat df= new SimpleDateFormat("dd-MM-yyyy");
		String appendDate = null;  
		if(StringUtils.isBlank(_fromDate) || StringUtils.isBlank( _toDate)){
			Calendar calToDate = Calendar.getInstance();
			calToDate.add(Calendar.DATE, -1);
			toDate = df.format(calToDate.getTime());
			Calendar calFromDate = Calendar.getInstance();
			calFromDate.add(Calendar.DATE, -3);
			fromDate = df.format(calFromDate.getTime());
			appendDate = fromDate+","+toDate;
			System.out.println("Default date : ");
			System.out.println("appendDate : "+appendDate);
		}else{
			appendDate = _fromDate+","+_toDate;
			System.out.println("Filter Date");
			System.out.println("appendDate : "+appendDate);
		}
		return appendDate;

	}

	/**
	 * This method fetches r.region_code,r.region_name,b.branch_type,b.branch_name,l.branch_code,c.district_name,c.district_code,c.state_code,l.loc_type,l.loc_subtype,l.loc_code based on user access to cold-chain and region
	 * @param hashMapSessionValues
	 * @return list of TablesJoin Objects which contains r.region_code,r.region_name,b.branch_type,b.branch_name,l.branch_code,c.district_name,c.district_code,c.state_code,l.loc_type,l.loc_subtype,l.loc_code
	 */
	public List<TablesJoin> getTablesJoin(HashMap<String,String> hashMapSessionValues) {
		List<TablesJoin> list = new ArrayList<TablesJoin>();
		ResultSet rs = null;
		TablesJoin record = null;
		Connection conn = null;
		PreparedStatement preparedStatementForQuery14 = null;
		String branchType = fetchBranchTypeValuesFromHashMap(hashMapSessionValues);
		String accessZone = fetchZones(hashMapSessionValues.get(HULConstant.ACCESS_ZONE));

		//String queryStrFieldSet14 = "select r.region_code,r.region_name,b.branch_type,b.branch_name,l.branch_code,c.district_name,c.district_code,c.state_code,l.loc_type,l.loc_subtype,l.loc_code from location l join branch b ON(l.branch_code = b.branch_code) join district c ON(b.district_code = c.district_code) join state s ON(s.state_code = c.state_code) join region r ON(s.region_code = r.region_code)";
		String queryStrFieldSet14 = "select r.region_code,r.region_name,b.branch_type,b.branch_name,l.branch_code,c.district_name,c.district_code,c.state_code,l.loc_type,l.loc_subtype,l.loc_code from location l join branch b ON((l.branch_code = b.branch_code) and (b.branch_type IN ("+branchType+"))) join district c ON(b.district_code = c.district_code) join state s ON(s.state_code = c.state_code) join region r ON((s.region_code = r.region_code) and (r.region_code in ("+accessZone+")))";	

		System.out.println("query:"+queryStrFieldSet14);
		LOGGER.info("DBConnector: getTablesJoin() : Query execution started : "+new Date());
		LOGGER.info("DBConnector: getTablesJoin() : query : "+queryStrFieldSet14);
		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery14 = conn.prepareStatement(queryStrFieldSet14);
			rs = preparedStatementForQuery14.executeQuery();

			while (rs.next()) {
				record = new TablesJoin();
				record.setRegionCode(rs.getString(1));	
				record.setRegionName(rs.getString(2));
				record.setBranchType(rs.getString(3));
				record.setBranchName(rs.getString(4));
				record.setBranchCode(rs.getString(5));
				record.setDistrictName(rs.getString(6));
				record.setDistrictCode(rs.getString(7));
				record.setStateCode(rs.getString(8));
				record.setLocType(rs.getString(9));
				record.setLocSubtype(StringUtils.trim(rs.getString(10)));
				record.setLocCode(rs.getString(11));
				list.add(record);
			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery14 != null)
					preparedStatementForQuery14.close();

			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}

		return list;
	}

	public List<MonthlyTrendData> getMonthlyTrendData(String month) {

		ResultSet rs = null;
		Connection conn = null;
		PreparedStatement preparedStatementForQuery = null;
		List<MonthlyTrendData> monthlyTrend=null;
		MonthlyTrendData data=null;
		final  String MONTHLY_TREND_DATA_SQL="select id ,compliance_year  ,compliance_month  ,region_code  ,branch_type , param_name ,compliance_green_count , compliance_yellow_count  , compliance_amber_count  ,compliance_red_count ,compliance_green_sum ,compliance_yellow_sum  ,compliance_amber_sum , compliance_red_sum , branch_name ,loc_type , district_name from monthly_compliance_data where compliance_year = '2016' and compliance_month = '"+month+"'";

		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			preparedStatementForQuery = conn.prepareStatement(MONTHLY_TREND_DATA_SQL);
			rs = preparedStatementForQuery.executeQuery();
			monthlyTrend=new ArrayList<MonthlyTrendData>();

			while (rs.next()) {
				data=new MonthlyTrendData();
				data.setId(rs.getInt(1));
				data.setComplianceYear(rs.getString(2));
				data.setComplianceMonth(rs.getString(3));

				data.setRegionCode(rs.getString(4));
				data.setBranchType(rs.getString(5));
				data.setParamName(rs.getString(6));

				data.setComplianceGreenCount(rs.getString(7));
				data.setComplianceYellowCount(rs.getString(8));
				data.setComplianceAmberCount(rs.getString(9));
				data.setComplianceRedCount(rs.getString(10));

				data.setComplianceGreenSum(rs.getString(11));
				data.setComplianceYellowSum(rs.getString(12));
				data.setComplianceAmberSum(rs.getString(13));
				data.setComplianceRedSum(rs.getString(14));

				data.setBranchName(rs.getString(15));
				data.setLocType(rs.getString(16));
				data.setDistrictName(rs.getString(17));

				monthlyTrend.add(data);

			}

		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 3", se);
			}

			try {
				if (preparedStatementForQuery != null )
					preparedStatementForQuery.close();
			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}

		return monthlyTrend;

	}

	/**
	 * This method is used to insert data for monthlyTrend into the monthly_compliance_data.
	 * This is invoked by scheduler responsible for monthly data update.
	 * 
	 * @author a603292 (Nirvantosh Mishra)
	 * @param region 
	 * @param branchType
	 * @param year the year of data to be inserted
	 * @param month the month of data to be inserted
	 * @param greenCount 
	 * @param yellowCount
	 * @param amberCount
	 * @param redCount
	 * @param greenSum
	 * @param yellowSum
	 * @param amberSum
	 * @param redSum
	 * @return int number of rows updated/inserted
	 */
	public int updateMonthlyTrendData(String region, String branchType, String year, String month,
			double greenCount, double yellowCount, double amberCount, double redCount, double greenSum, 
			double yellowSum, double amberSum, double redSum ) {

		LOGGER.info("inside updateMonthlyTrendData");
		int rowCount = 0;
		Connection conn = null;
		PreparedStatement preparedStatementForQuery = null;
		final  String MONTHLY_TREND_DATA_UPDATE_SQL="INSERT INTO monthly_compliance_data(compliance_year  ,compliance_month  ,region_code  ,branch_type , param_name ,compliance_green_count ,compliance_yellow_count  ,compliance_amber_count  ,compliance_red_count ,compliance_green_sum ,compliance_yellow_sum  ,compliance_amber_sum  ,compliance_red_sum) values ('"+year+"', '"+month+"', '"+region+"' ,'"+branchType+"' , 'TEMP' ,'"+greenCount+"','"+yellowCount+"','"+amberCount+"','"+redCount+"','"+greenSum+"','"+yellowSum+"','"+amberSum+"','"+redSum+"')";

		LOGGER.info("prepared query is "+MONTHLY_TREND_DATA_UPDATE_SQL);
		try {
			Class.forName(getDriverClassName());
			conn = DriverManager.getConnection(getDatabaseurl(), getUsername(), getPassword());
			LOGGER.info("connection prepared with DB");
			preparedStatementForQuery = conn.prepareStatement(MONTHLY_TREND_DATA_UPDATE_SQL);
			LOGGER.info("GOing to execute query");
			rowCount = preparedStatementForQuery.executeUpdate();
			LOGGER.info("Query executed");
			//conn.commit();
			
		} catch (SQLException se) {
			LOGGER.error("SQLException 1", se);
		} catch (Exception e) {
			LOGGER.error("Exception 2", e);
		} finally {

			try {
				if (preparedStatementForQuery != null )
					preparedStatementForQuery.close();
			} catch (SQLException se2) {
				LOGGER.error("SQLException 4", se2);
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				LOGGER.error("SQLException 5", se);
			}

		}
		LOGGER.info("No of rows effected by query are "+rowCount);
		return rowCount;

	}


}
