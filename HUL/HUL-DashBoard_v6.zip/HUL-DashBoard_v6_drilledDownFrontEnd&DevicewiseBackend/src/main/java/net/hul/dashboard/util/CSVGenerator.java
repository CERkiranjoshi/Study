package net.hul.dashboard.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import net.hul.dashboard.dto.FilterData;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class CSVGenerator {

	//Delimiter used in CSV file
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\n";
	
	//CSV file header
	private static final String FILE_HEADER = "Sr No.,Region,Cold Chain,City,Vendor,Vehicle No.,Device ID,Bar Code,Time,Temperature";
	private static final Logger LOGGER=Logger.getLogger(CSVGenerator.class);
	
	//filename constant
	private String fileName = "complianceReport";
	
	public String generateCSV(String uploadDir, List<FilterData> filterData) {

		File myOutputDir = new File(uploadDir);
		if (!myOutputDir.exists()) {
			myOutputDir.mkdir();
		}

		DateFormat df = new SimpleDateFormat("dd-MM-yyyy_HH:mm:ss");
        Date timestamp = Calendar.getInstance().getTime();        

        String reportDate = df.format(timestamp);
        LOGGER.info(reportDate);
		String generatedFileName = fileName + "_" + reportDate + ".csv";
		String generatedFilePath = uploadDir + generatedFileName;
		LOGGER.info(generatedFilePath+" file created for CSV Report");

		FileWriter fileWriter = null;

		try {

			fileWriter = new FileWriter(generatedFilePath);

			fileWriter.append(FILE_HEADER.toString());

			//Add a new line separator after the header
			fileWriter.append(NEW_LINE_SEPARATOR);

			LOGGER.info("Generating CSV file...... ");

			Integer srNo=0;
			for(FilterData data :filterData) {
				srNo++;
				fileWriter.append(String.valueOf(srNo));
				fileWriter.append(COMMA_DELIMITER);

				if (data.getRegionCode() != null) {
					fileWriter.append(data.getRegionCode());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getBranchType() != null) {
					fileWriter.append(data.getBranchType());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getBranchName() != null) {
					fileWriter.append(data.getBranchName());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getAddress1() != null) {
					fileWriter.append(data.getAddress1());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getBranchCodeCust() != null) {
					fileWriter.append(data.getBranchCodeCust());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getDeviceId() != null) {
					fileWriter.append(data.getDeviceId());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getApplianceId() != null) {
					fileWriter.append(data.getApplianceId());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getTxnTime()!= null) {
					fileWriter.append(data.getTxnTime());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(COMMA_DELIMITER);
				if (data.getParamValue() != null) {
					fileWriter.append(data.getParamValue());
				} else {
					fileWriter.append("");
				}
				fileWriter.append(NEW_LINE_SEPARATOR);
			}

		} catch (Exception e) {

			LOGGER.error("Exception while writing CSV........"+e.getMessage());

		}finally {
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				LOGGER.error("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}

		}

		return generatedFileName;
	}

}
