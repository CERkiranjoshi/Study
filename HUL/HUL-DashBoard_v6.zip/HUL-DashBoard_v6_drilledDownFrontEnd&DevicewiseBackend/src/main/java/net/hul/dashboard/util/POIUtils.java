package net.hul.dashboard.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import net.hul.dashboard.dto.FilterData;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;


@Service
public class POIUtils {

	private static final Log LOGGER = LogFactory.getLog(POIUtils.class);

	private String fileName = "complianceReport";

	/**
	 * generate report in csv format of HUL Compliance
	 * 
	 * @param uploadDir
	 * @param filterDataList
	 * @return String
	 */
	public String createComplianceCSV(String uploadDir, List<FilterData> filterDataList) {
		LOGGER.info("Inside POIUtils:createComplianceCSV:Start");
		File myOutputDir = new File(uploadDir);
		if (!myOutputDir.exists()) {
			myOutputDir.mkdir();
		}

		DateFormat df = new SimpleDateFormat("dd-MM-yyyy_HH:mm:ss");
        Date timestamp = Calendar.getInstance().getTime();        

        String reportDate = df.format(timestamp);
		String generatedFileName = fileName + "_" + reportDate + ".xls";
		String generatedFilePath = uploadDir + generatedFileName;
		LOGGER.info(generatedFilePath+" file created for Excel Report");
		
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(generatedFilePath);
			LOGGER.info("created output stream to excel");
			
			// create workbook
			Workbook wb = new HSSFWorkbook();

			// create sheet
			Sheet sheet = wb.createSheet("Results");

			// create header row
			HSSFRow rowhead = (HSSFRow) sheet.createRow(0);
			rowhead.createCell(0).setCellValue("Sr No.");
			rowhead.createCell(1).setCellValue("Region");
			rowhead.createCell(2).setCellValue("Cold Chain");
			rowhead.createCell(3).setCellValue("City");
			rowhead.createCell(4).setCellValue("Vendor");
			rowhead.createCell(5).setCellValue("Vehicle No.");
			rowhead.createCell(6).setCellValue("Device ID");
			rowhead.createCell(7).setCellValue("Bar Code");
			rowhead.createCell(8).setCellValue("Time");
			rowhead.createCell(9).setCellValue("Temperature");
			
			for (int i = 0; i < filterDataList.size(); i++) {

				HSSFRow row = (HSSFRow) sheet.createRow(i + 1);
				FilterData filterData = filterDataList.get(i);
				row.createCell(0).setCellValue(i + 1);
				if (filterData.getRegionCode() != null) {
					row.createCell(1).setCellValue(filterData.getRegionCode());
				} else {
					row.createCell(1).setCellValue("");
				}
				if (filterData.getBranchType() != null) {
					row.createCell(2).setCellValue(filterData.getBranchType());
				} else {
					row.createCell(2).setCellValue("");
				}
				if (filterData.getBranchName() != null) {
					row.createCell(3).setCellValue(filterData.getBranchName());
				} else {
					row.createCell(3).setCellValue("");
				}
				if (filterData.getAddress1() != null) {
					row.createCell(4).setCellValue(filterData.getAddress1());
				} else {
					row.createCell(4).setCellValue("");
				}
				if (filterData.getBranchCodeCust() != null) {
					row.createCell(5).setCellValue(filterData.getBranchCodeCust());
				} else {
					row.createCell(5).setCellValue("");
				}
				if (filterData.getDeviceId() != null) {
					row.createCell(6).setCellValue(filterData.getDeviceId());
				} else {
					row.createCell(6).setCellValue("");
				}
				if (filterData.getApplianceId() != null) {
					row.createCell(7).setCellValue(filterData.getApplianceId());
				} else {
					row.createCell(7).setCellValue("");
				}
				if (filterData.getTxnTime()!= null) {
					row.createCell(8).setCellValue(filterData.getTxnTime());
				} else {
					row.createCell(8).setCellValue("");
				}
				if (filterData.getParamValue() != null) {
					row.createCell(9).setCellValue(filterData.getParamValue());
				} else {
					row.createCell(9).setCellValue("");
				}
				
			}
			LOGGER.info("done with cell creation and allocation");
			wb.write(fileOut);
			LOGGER.info("Report generated successfully");
		} catch (Exception e) {
			LOGGER.error("exception while writing data to excel " + e);
		}
		return generatedFileName;
	}

}
