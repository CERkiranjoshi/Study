/*
 * MonthlyTrendDataScheduler
 *
 * Version 1.0  23-Mar-2016
 *
 * Copyright (c) 2015-2016 Atos India. All Rights Reserved. This software
 * is the confidential and proprietary information of Atos India.
 * ("Confidential Information"). You shall not disclose such
 * Confidential Information and  shall use it only  in accordance
 * with the terms of the license agreement you entered into with Atos India.
 */

package net.hul.dashboard.scheduler;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.hul.dashboard.dto.FilterData;
import net.hul.dashboard.util.DBConnector;
import net.hul.dashboard.util.HULConstant;
import net.hul.dashboard.util.HulUseCaseHandler;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;

/**
 * This class is responsible for updating regional and branch-type based
 * color counts and sum values in the monthly_compliance_data table every month.
 * 
 * @version 1.0 23-Mar-2016 
 * @author a603292
 * 
 */
@Controller
public class MonthlyTrendDataScheduler {

	/**
	 * Object of DBConnector class
	 */
	@Autowired
	private DBConnector dbConnector;

	/**
	 * static object of Logger class
	 */
	private static Logger LOGGER= Logger.getLogger(MonthlyTrendDataScheduler.class);

	/**
	 * This method is scheduled to run 1st day of every month updating the monthly_compliance_data
	 * table with last month entries.
	 */
	//@Scheduled(cron = "${monthly.trend.data.update.scheduler}")
	@SuppressWarnings("unchecked")
	public void MonthlyTrendDataUpdateScheduler() {

		LOGGER.info("Scheduler starts here");
		//fetching criteria JSON for colors
		org.json.simple.JSONObject inputJSON=null; 
		JSONParser parser = new JSONParser();
		String JSONpath = null;

		try {
			//setting path for criteria JSON file in project data folder
			ClassLoader loader = MonthlyTrendDataScheduler.class.getClassLoader();
			String primaryPath = loader.getResource("").toString().substring(loader.getResource("").toString().indexOf("/")+1);
			String[] splitResult = primaryPath.split("huldashboard");
			JSONpath = splitResult[0] + "huldashboard/data/temperature.json";
			LOGGER.info("JSON path finally: "+JSONpath);

			//creating local JSON from criteria JSON file
			org.json.simple.JSONObject inputTempJSON = (org.json.simple.JSONObject) parser.parse(new FileReader(JSONpath));
			inputJSON = (org.json.simple.JSONObject) inputTempJSON.get("regional");
			LOGGER.info("Criteria JSON as fetched from the data folder: "+inputJSON);

		} catch (ParseException e) {
			LOGGER.error("Parsing exception while reading criteria JSON."+e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error("File not found while reading criteria JSON. "+e.getMessage());
		} catch (IOException e) {
			LOGGER.error("IO exception while reading criteria JSON. "+e.getMessage());
		}

		//creating map for input to get payload for the required month
		HashMap<String,String> hashMap = new HashMap<String,String>();
		hashMap.put(HULConstant.ACCESS_ZONE, "Pan India");
		hashMap.put(HULConstant.ACCESS_FACTORY, "TRUE");
		hashMap.put(HULConstant.ACCESS_PV,"TRUE");
		hashMap.put(HULConstant.ACCESS_DEPOT,"TRUE");
		hashMap.put(HULConstant.ACCESS_SV,"TRUE");
		hashMap.put(HULConstant.ACCESS_RS_COLDROOM, "TRUE");
		hashMap.put(HULConstant.ACCESS_RSV, "TRUE");

		//setting 1st and last date of last month
		Calendar tempCal = Calendar.getInstance();
		Calendar calFromDate = Calendar.getInstance();
		Calendar calToDate = Calendar.getInstance();
		tempCal.add(Calendar.MONTH, -1);
		tempCal.set(Calendar.DAY_OF_MONTH, tempCal.getActualMinimum(Calendar.DAY_OF_MONTH));
		calFromDate.setTime(tempCal.getTime());
		tempCal.set(Calendar.DAY_OF_MONTH, tempCal.getActualMaximum(Calendar.DAY_OF_MONTH));
		calToDate.setTime(tempCal.getTime());
		//formatting date to string
		DateFormat df= new SimpleDateFormat("dd-MM-yyyy");
		String fromDate = df.format(calFromDate.getTime());
		String toDate = df.format(calToDate.getTime());
		hashMap.put(HULConstant.SELECTED_FROM_DATE, fromDate);
		hashMap.put(HULConstant.SELECTED_TO_DATE, toDate);
		//LOGGER.info("hashmap is set for passing to filterdata: "+hashMap);
		
		//fetching payload for full month required
		List<FilterData> filterData = new ArrayList<FilterData>();
		filterData = dbConnector.getFilteredData(hashMap, HULConstant.DEFAULT);

		//-------------------------------------filterData DB fetching emulation using a file having JSON- only for testing---------------------------
		/*try {
			ObjectMapper objectMapper=new ObjectMapper();
			JSONArray jsonArray = (JSONArray) parser.parse(new FileReader("C:\\Users\\A603292\\Documents\\projects\\IOT\\HULDashBoardEnv\\dummyJSON.json"));
			for (Object object : jsonArray) {
				org.json.simple.JSONObject data =  (org.json.simple.JSONObject) object;
				FilterData filter=objectMapper.convertValue(data, FilterData.class);
				filterData.add(filter);
			}

		} catch (ParseException e) {
			LOGGER.error("ParseException in reading JSON file"+e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException in reading JSON file"+e.getMessage());
		} catch (IOException e) {
			LOGGER.error("IOException in reading JSON file"+e.getMessage());
		}*/
		//--------------------------------------------------------------------------------------------------------------------------------------------
		//LOGGER.info("Got filterData"+filterData);

		//key set to iterate over input JSON for getting colour criteria
		Set<String> inputJSONKeySet=inputJSON.keySet();

		//map to contain data for every branchType
		Map<String,MultiMap> branchRegionPayload = new HashMap<String,MultiMap>();
		//reference for region-payload multimap
		MultiMap regionPayloadMap = null;

		//iterating over input JSON for getting colour criteria
		for(String branch: inputJSONKeySet){
			//map for region data
			regionPayloadMap=new MultiValueMap();
			//creating map of region-payloads
			for(FilterData data: filterData){
				if(branch.equalsIgnoreCase(data.getBranchType())){
					if(data.getRegionCode().equalsIgnoreCase("EAST")){
						regionPayloadMap.put("EAST", data);
					}else if(data.getRegionCode().equalsIgnoreCase("WEST")){
						regionPayloadMap.put("WEST", data);
					}else if(data.getRegionCode().equalsIgnoreCase("NORTH")){
						regionPayloadMap.put("NORTH", data);
					}else if(data.getRegionCode().equalsIgnoreCase("SOUTH")){
						regionPayloadMap.put("SOUTH", data);
					} 
				}
			}
			//updating branch wise map for current branchType
			branchRegionPayload.put(branch, regionPayloadMap);
		}
		//LOGGER.info("Map intialised for required data:"+branchRegionPayload);
		
		//now updating the data in the table
		//FilterData list reference to hold payload list for every branch type and region pair 
		List<FilterData> filterDataList = null;
		//instance of HULUseCaseHandler for getting count data
		HulUseCaseHandler handler = new HulUseCaseHandler();
		//map to store data fetched by getRegionalTrend method of HulUseCaseHandler
		Map<String, Map<String, Map<String, Object>>> returnMap = null;
		//creating org.json.JSONObject type instance of input JSON for getRegionalTrend method
		JSONObject inputJsonObj = new JSONObject(inputJSON.toJSONString());

		//iterating over new map created (keyset is similar for both)
		for(String branch: inputJSONKeySet){
			//LOGGER.info("inside loop for branch "+branch);
			regionPayloadMap = branchRegionPayload.get(branch);
			//fetching keyset of multimap
			Set<String> regionSet= regionPayloadMap.keySet();
			//iterating over regions for selected branch type
			for(String region:regionSet) {
				//LOGGER.info("inside inner loop for region "+region);
				float redCount = 0f, greenCount = 0f, yellowCount = 0f, amberCount = 0f;
				float redAvg = 0f, greenAvg = 0f, yellowAvg = 0f, amberAvg = 0f;
				float redSum = 0f, greenSum = 0f, yellowSum = 0f, amberSum = 0f;
				
				//LOGGER.info("Going to get data for region: "+region+" and BT: "+branch);
				filterDataList = (List<FilterData>) regionPayloadMap.get(region);
				returnMap = handler.getRegionalTrend(filterDataList, inputJsonObj);
				//LOGGER.info("Fetched data from getRegionalTrend method as : "+returnMap);
				//getting color counts for selected branch type and region pair
				if (returnMap.get("region").get(region) != null){
					if(returnMap.get("region").get(region).get("Red") !=null)
						redCount =  (Float) returnMap.get("region").get(region).get("Red");
					if(returnMap.get("region").get(region).get("Green") != null)
						greenCount =  (Float) returnMap.get("region").get(region).get("Green");
					if(returnMap.get("region").get(region).get("Yellow") != null)
						yellowCount =  (Float) returnMap.get("region").get(region).get("Yellow");
					if(returnMap.get("region").get(region).get("Amber") != null)
						amberCount =  (Float) returnMap.get("region").get(region).get("Amber");
				}
				
				//getting color averages for selected branch type and region pair
				if(returnMap.get("coldChainavg").get(branch).get("Red") != null)
					redAvg =  (Float) returnMap.get("coldChainavg").get(branch).get("Red");
				if(returnMap.get("coldChainavg").get(branch).get("Green") != null)
					greenAvg =  (Float) returnMap.get("coldChainavg").get(branch).get("Green");
				if(returnMap.get("coldChainavg").get(branch).get("Yellow") != null)
					yellowAvg = (Float) returnMap.get("coldChainavg").get(branch).get("Yellow");
				if(returnMap.get("coldChainavg").get(branch).get("Amber") != null)
					amberAvg =  (Float) returnMap.get("coldChainavg").get(branch).get("Amber");

				//calculating color sums for selected branch type and region pair
				redSum = redAvg * redCount;
				greenSum = greenAvg * greenCount;
				yellowSum = yellowAvg * yellowCount;
				amberSum = amberAvg * amberCount;

				//LOGGER.info("Values as fetched are: redCount="+redCount+", greenCount="+greenCount+", "
				//		+ "amberCount="+amberCount+", yellowCount="+yellowCount);
				//LOGGER.info("Values as fetched are: redSum="+redSum+", greenSum="+greenSum+", "
				//		+ "amberSum="+amberSum+", yellowSum="+yellowSum);
				//getting year and month to be passed for updation of table
				String year = Integer.toString(calFromDate.get(Calendar.YEAR)); 
				String	month = new SimpleDateFormat("MMM").format(calFromDate.getTime());
				//LOGGER.info("year is "+year+" and month is "+month);

				//updating the monthly_compliance_table here
				try{
					//LOGGER.info("Going to call method of dbConnector for table insert");
					//LOGGER.info("dbconnector object : "+dbConnector);
					int result = dbConnector.updateMonthlyTrendData(region, branch, year, month, greenCount, yellowCount, amberCount, 
							redCount, greenSum, yellowSum, amberSum, redSum);
					//LOGGER.info("result of insert query : "+result);
					if(result  <= 0){
						LOGGER.error("SOme error occurred in insert query for region "+region+" and branch type "+branch+ " for "+month+", " +year);
						throw new Exception("SOme error occurred in insert query for region "+region+" and branch type "+branch+ " for "+month+", " +year);
					}
				}catch (Exception e){
					LOGGER.error("Unknown error occured while inserting data "+e.getMessage() +"; "+ e.toString());
				}

				LOGGER.info("All done....adios!!");
			}
		}
	}
}

