/**
 * 
 */
package net.hul.dashboard.controller;

import java.util.HashMap;

import net.hul.dashboard.cloudprovisioning.CloudProvisioningClient;
import net.hul.dashboard.cloudprovisioning.CloudProvisioningConstants;
import net.hul.dashboard.cloudprovisioning.UserRequest;
import net.hul.dashboard.cloudprovisioning.UserResponse;
import net.hul.dashboard.util.DBConnector;
import net.hul.dashboard.util.HULConstant;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author a561065
 *
 */
@Controller
public class LoginController {

	@Autowired
	private CloudProvisioningClient cloudProvisioningClient;
	
	@Autowired
	private DBConnector dbConnector;
	
	@Value("${cloud.provisioning.tenantName}")
	private String tenant;

	@Value("${cloud.provisioning.serviceCode}")
	private String serviceCode;
	
	/**
	 * This method performs two task,one is login authentication and second is login-authorization.
	 * Login authentication is done using cloud-provisioning. Login authorization is done using employee-role table in local database
	 * @param hashMap
	 * @return success/failure 
	 */
	public HashMap<String,String> performLoginValidation(HashMap<String,String> hashMap) {
		HashMap<String,String> userAuthorizationStatus = new HashMap<String, String>();
		String emailId= hashMap.get("emailId");
		String password= hashMap.get("password");
		String message = null;
		HashMap<String,String> cloudProvisioningAuthenticationStatus = performCloudProvisioningAuthentication(emailId,password);
		message = cloudProvisioningAuthenticationStatus.get(HULConstant.MESSAGE);
		if(StringUtils.equalsIgnoreCase(cloudProvisioningAuthenticationStatus.get(HULConstant.STATUS), HULConstant.SUCCESS)){
			userAuthorizationStatus = performUserAuthorization(emailId,password);	
			if(StringUtils.equalsIgnoreCase(userAuthorizationStatus.get(HULConstant.STATUS), HULConstant.FAILURE)){
				message = message +", Local DB- UserName and Password Not Matched";	
			}
		}else{
	//	if(StringUtils.equals(cloudProvisioningAuthenticationStatus, HULConstant.FAILURE)){
			userAuthorizationStatus.put(HULConstant.STATUS, HULConstant.FAILURE);
		}
		
		userAuthorizationStatus.put(HULConstant.MESSAGE, message);
		return userAuthorizationStatus;
	}

	/**
	 * This method performs login-authentication using cloud-provisioning.
	 * @param emailId
	 * @param password
	 * @return success/failure along with message
	 */
	private HashMap<String,String> performCloudProvisioningAuthentication(String emailId,String password) {
		HashMap<String,String> cloudProvisioningResponse = new HashMap<String, String>();
		UserRequest userRequest = new UserRequest();
		UserResponse userResponse = new UserResponse();
		String status = HULConstant.FAILURE;
		String message = null;
		userRequest.setUsername(emailId);
		userRequest.setPassword(password);
		userRequest.setTenant(tenant);
		userRequest.setService(serviceCode);
		userRequest.setRememberMeToken(true);
		userResponse = cloudProvisioningClient.authenticateUser(userRequest);
		System.out.println("UserName:"+userResponse.getUsername()+" SessionId:"+userResponse.getSessionId()+" HttpStatus:"+userResponse.getHttpStatus()+" SpringSecurityCookie:"+userResponse.getSpringSecurityCookie()+" CpResposeCode:"+userResponse.getCpResposeCode());
		
		if(userResponse!=null && StringUtils.isNotBlank(userResponse.getSpringSecurityCookie()) && userResponse.getRoles().size() != 0){
			
			for(String a:userResponse.getRoles()){
				System.out.println("Roles:"+a);
				if(StringUtils.equalsIgnoreCase(a, "OEM Administrator")){
					status = HULConstant.SUCCESS;
					message = "User Authenticated Successfully";
				}
			
			}
		
		}
		if(StringUtils.equalsIgnoreCase(userResponse.getCpResposeCode().toString(), "USER_LOCKED")){
			message = "User Is Locked";
		}
		if(StringUtils.equalsIgnoreCase(userResponse.getCpResposeCode().toString(), "SUCCESSFUL")){
			message = "CP-EmailId and Password doesnot match";
		}
		System.out.println("performCloudProvisioningAuthentication : status :"+status);
		cloudProvisioningResponse.put(HULConstant.STATUS, status);
		cloudProvisioningResponse.put(HULConstant.MESSAGE, message);
		return cloudProvisioningResponse;
	}
	
	/**
	 * This method performs login-authorization using employee-role table in local database.
	 * This method fetches access_zone, access_factory, access_pv, access_depot,access_sv,access_rs_cold_room,access_rsv values for user if present in database
	 * @param emailId
	 * @param password
	 * @return failure when user not found in employee_role ELSE if found ,it returns success and the access_zone, access_factory, access_pv, access_depot,access_sv,access_rs_cold_room,access_rsv values for user from employee_role table
	 */
	private HashMap<String,String> performUserAuthorization(String emailId, String password) {
		HashMap<String,String> hashMapResponse = new HashMap<String, String>();
		hashMapResponse = dbConnector.getRoleAndStatus(emailId,password);
		return hashMapResponse;
	}
	
}
