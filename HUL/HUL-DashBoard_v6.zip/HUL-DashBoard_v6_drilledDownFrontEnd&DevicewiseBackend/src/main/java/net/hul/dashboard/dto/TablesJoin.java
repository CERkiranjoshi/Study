/**
 * 
 */
package net.hul.dashboard.dto;

/**
 * @author a561065
 *
 */
public class TablesJoin {
	
	private String regionCode;
	private String regionName;
	private String branchType;
	private String branchName;
	private String branchCode;
	private String districtCode;
	private String districtName;
	private String stateCode;
	private String locType;
	private String locSubtype;
	private String locCode;
	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	/**
	 * @return the branchType
	 */
	public String getBranchType() {
		return branchType;
	}
	/**
	 * @param branchType the branchType to set
	 */
	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}
	/**
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}
	/**
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}
	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	/**
	 * @return the districtCode
	 */
	public String getDistrictCode() {
		return districtCode;
	}
	/**
	 * @param districtCode the districtCode to set
	 */
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	/**
	 * @return the districtName
	 */
	public String getDistrictName() {
		return districtName;
	}
	/**
	 * @param districtName the districtName to set
	 */
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the locType
	 */
	public String getLocType() {
		return locType;
	}
	/**
	 * @param locType the locType to set
	 */
	public void setLocType(String locType) {
		this.locType = locType;
	}
	/**
	 * @return the locSubtype
	 */
	public String getLocSubtype() {
		return locSubtype;
	}
	/**
	 * @param locSubtype the locSubtype to set
	 */
	public void setLocSubtype(String locSubtype) {
		this.locSubtype = locSubtype;
	}
	/**
	 * @return the locCode
	 */
	public String getLocCode() {
		return locCode;
	}
	/**
	 * @param locCode the locCode to set
	 */
	public void setLocCode(String locCode) {
		this.locCode = locCode;
	}

	
}
