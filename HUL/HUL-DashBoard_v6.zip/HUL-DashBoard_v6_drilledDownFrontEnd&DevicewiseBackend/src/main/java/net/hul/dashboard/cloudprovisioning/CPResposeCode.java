package net.hul.dashboard.cloudprovisioning;

public enum CPResposeCode {

    SUCCESSFUL, FAILED, FIRST_LOGIN, SERVICE_CODE_INVALID, USER_LOCKED, USER_DISABLED;
}
