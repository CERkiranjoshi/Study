/**
 * 
 */
package net.hul.dashboard.dto;

import java.util.Date;
import java.util.List;

/**
 * @author a561065
 *
 */
public class FilterData {
	
	private String regionCode;
	private String branchType;
	private String locCode;
	private String deviceId;
	//private String paramName;
	private String paramValue;
	//private Long txId;
	//private Long id;
	private String branchName;
	private String locType;
	private String locSubType;
	private String districtName;//City
	private String txnTime;
	private String address1;
	private String branchCodeCust;
	private String applianceId;
	
	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	/**
	 * @return the branchType
	 */
	public String getBranchType() {
		return branchType;
	}
	/**
	 * @param branchType the branchType to set
	 */
	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}
	/**
	 * @return the locCode
	 */
	public String getLocCode() {
		return locCode;
	}
	/**
	 * @param locCode the locCode to set
	 */
	public void setLocCode(String locCode) {
		this.locCode = locCode;
	}
	/**
	 * @return the deviceId
	 */
	public String getDeviceId() {
		return deviceId;
	}
	/**
	 * @param deviceId the deviceId to set
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	/**
	 * @return the paramValue
	 */
	public String getParamValue() {
		return paramValue;
	}
	/**
	 * @param paramValue the paramValue to set
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	/**
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}
	/**
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	/**
	 * @return the locType
	 */
	public String getLocType() {
		return locType;
	}
	/**
	 * @param locType the locType to set
	 */
	public void setLocType(String locType) {
		this.locType = locType;
	}
	/**
	 * @return the locSubType
	 */
	public String getLocSubType() {
		return locSubType;
	}
	/**
	 * @param locSubType the locSubType to set
	 */
	public void setLocSubType(String locSubType) {
		this.locSubType = locSubType;
	}
	/**
	 * @return the districtName
	 */
	public String getDistrictName() {
		return districtName;
	}
	/**
	 * @param districtName the districtName to set
	 */
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	/**
	 * @return the txnTime
	 */
	public String getTxnTime() {
		return txnTime;
	}
	/**
	 * @param txnTime the txnTime to set
	 */
	public void setTxnTime(String txnTime) {
		this.txnTime = txnTime;
	}
	/**
	 * @return address1
	 */
	public String getAddress1() {
		return address1;
	}
	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	/**
	 * @return branchCodeCust
	 */
	public String getBranchCodeCust() {
		return branchCodeCust;
	}
	/**
	 * @param branchCodeCust the branchCodeCust to set
	 */
	public void setBranchCodeCust(String branchCodeCust) {
		this.branchCodeCust = branchCodeCust;
	}

	/**
	 * @return applianceID
	 */
	public String getApplianceId() {
		return applianceId;
	}
	
	/**
	 * @param applianceId the appliance ID to set
	 */
	public void setApplianceId(String applianceId) {
		this.applianceId = applianceId;
	}
}
