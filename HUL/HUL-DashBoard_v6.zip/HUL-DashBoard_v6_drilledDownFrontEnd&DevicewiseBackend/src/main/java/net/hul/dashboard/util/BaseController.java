/**
 * 
 */
package net.hul.dashboard.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

/**
 * @author a561065
 *
 */
@Controller
public class BaseController {

	@Value("${jdbc.driverClassName}")
	private String driverClassName;

	@Value("${jdbc.databaseurl}")
	private String databaseurl;

	@Value("${jdbc.username}")
	private String username;

	@Value("${jdbc.password}")
	private String password;

	/**
	 * @return the driverClassName
	 */
	public String getDriverClassName() {
		return driverClassName;
	}

	/**
	 * @param driverClassName the driverClassName to set
	 */
	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	/**
	 * @return the databaseurl
	 */
	public String getDatabaseurl() {
		return databaseurl;
	}

	/**
	 * @param databaseurl the databaseurl to set
	 */
	public void setDatabaseurl(String databaseurl) {
		this.databaseurl = databaseurl;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
