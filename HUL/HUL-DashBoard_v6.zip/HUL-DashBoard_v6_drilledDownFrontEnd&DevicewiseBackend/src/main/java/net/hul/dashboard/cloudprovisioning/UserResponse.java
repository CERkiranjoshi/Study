package net.hul.dashboard.cloudprovisioning;

import java.io.Serializable;
import java.util.List;

/**
 * @author A561065
 *
 */
public class UserResponse implements Serializable {

    private static final long serialVersionUID = -8303380336095801845L;
    
    private CPResposeCode cpResposeCode;
    private String sessionId;
    private String username;
    private String springSecurityCookie;
    private List<String> roles;
    private int httpStatus;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public CPResposeCode getCpResposeCode() {
        return cpResposeCode;
    }

    public void setCpResposeCode(CPResposeCode cpResposeCode) {
        this.cpResposeCode = cpResposeCode;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSpringSecurityCookie() {
        return springSecurityCookie;
    }

    public void setSpringSecurityCookie(String springSecurityCookie) {
        this.springSecurityCookie = springSecurityCookie;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    public int getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(int httpStatus) {
        this.httpStatus = httpStatus;
    }

    @Override
    public String toString() {
        return "UserResponse [cpResposeCode=" + cpResposeCode + ", sessionId=" + sessionId + ", username=" + username
                + ", springSecurityCookie=" + springSecurityCookie + ", roles=" + roles + ", httpStatus=" + httpStatus
                + "]";
    }

}
