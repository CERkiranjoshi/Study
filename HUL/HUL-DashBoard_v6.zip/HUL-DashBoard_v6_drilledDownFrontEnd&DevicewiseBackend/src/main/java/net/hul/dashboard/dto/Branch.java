/**
 * 
 */
package net.hul.dashboard.dto;

import java.util.Date;

/**
 * @author a561065
 *
 */
public class Branch {

	  //public Long id;
	  //public String branchCode;
	  //public String branchCodeCust;
	  public String branchName;
	  public String branchType;
	  //public String branchSubtype;
	  //public String address1;
	  //public String address2;
	  //public String address3;
	  public String districtCode;
	  //public String active;
	  //public String createdBy;
	  //public Date createdDate;
	  //public String modifiedBy;
	  //public Date modifiedDate;
	  //public Double longitude;
	  //public Double latitude;
	

	/**
	 * @return the branchName
	 */
	public String getBranchName() {
		return branchName;
	}
	/**
	 * @param branchName the branchName to set
	 */
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	/**
	 * @return the branchType
	 */
	public String getBranchType() {
		return branchType;
	}
	/**
	 * @param branchType the branchType to set
	 */
	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}

	/**
	 * @return the districtCode
	 */
	public String getDistrictCode() {
		return districtCode;
	}
	/**
	 * @param districtCode the districtCode to set
	 */
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	
	  
	  

}
