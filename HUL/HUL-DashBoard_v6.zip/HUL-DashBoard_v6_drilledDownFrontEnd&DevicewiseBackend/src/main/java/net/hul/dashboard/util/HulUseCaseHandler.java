/*
 * HulUseCaseHandler
 *
 * Version 1.0  21-Apr-2016
 *
 * Copyright (c) 2015-2016 Atos India. All Rights Reserved. This software
 * is the confidential and proprietary information of Atos India.
 * ("Confidential Information"). You shall not disclose such
 * Confidential Information and  shall use it only  in accordance
 * with the terms of the license agreement you entered into with Atos India.
 */

package net.hul.dashboard.util;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import net.hul.dashboard.dto.FilterData;
import net.hul.dashboard.dto.MonthlyTrendData;
import net.sf.ehcache.search.aggregator.Average;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

/**
 * This class contains methods for processing of data and generating results for different use cases as required
 * by web-services for HUL Dashboard.
 * 
 * @version 1.0 21-Apr-2016
 * @author a603292 (Nirvantosh Mishra)
 *
 */
@Component
public class HulUseCaseHandler {

	/**
	 * Object of DBConnector class
	 */
	@Autowired
	private DBConnector dbConnector;

	/**
	 * Object of Logger class
	 */
	private static Logger LOGGER= Logger.getLogger(HulUseCaseHandler.class);

	/**
	 * Object of ObjectMapper class
	 */
	private ObjectMapper objectMapper=new ObjectMapper();

	/**
	 * This method is called when fetchDefaultValue or fetchChartValue webservices are called for getting regional Trend.
	 * The method iterates over the input data of devices (payloads as recieved in selected range while calling webservice)
	 * and calculates counts and averages for the four ranges of temperatures (categorised as red, green, amber and yellow)
	 * for each device and subsequently, for each branch and region. The data is returned in the form of nested map.
	 * 
	 * @param filterData - List of filterData objects (payloads of devices)
	 * @param inputJSON - JSON having branch type wise filter criteria for color coding 
	 * @return Map<String, Map<String, Map<String, Object>>> - region, coldchain count and coldchain average mapped in a nested map
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Map<String, Map<String, Object>>> getRegionalTrend(List<FilterData> filterData,org.json.JSONObject inputJSON) {

		LOGGER.info("getRegionalTrend started");

		//region set to be provided for regional count method
		Set<String> regionSet=new HashSet<String>();
		//map for branch iteration
		MultiMap branchDeviceMap=new MultiValueMap();
		//Map for device iteration
		MultiMap devicePayloadMap=new MultiValueMap();

		//creating maps of branch-devices and device-payloads
		for(FilterData data: filterData){
			if(!branchDeviceMap.isEmpty() && branchDeviceMap !=null){
				if(!branchDeviceMap.containsValue(data.getDeviceId())){
					branchDeviceMap.put(data.getBranchType(), data.getDeviceId());
				}
			}
			else if(branchDeviceMap.isEmpty()){
				branchDeviceMap.put(data.getBranchType(), data.getDeviceId());
			}
			devicePayloadMap.put(data.getDeviceId(),data);
			regionSet.add(data.getRegionCode());
		}

		//LOGGER.info("branchDeviceMap: "+branchDeviceMap+" \ndevicePayloadMap: "+devicePayloadMap+" \nregionSet: "+regionSet);
		//key set to iterate over input JSON for getting colour criteria
		Set<String> inputJSONKeySet=inputJSON.keySet();
		//key set for iterating over cities
		Set<String> branches= branchDeviceMap.keySet();

		//initialising final result map
		Map<String, Map<String, Map<String, Object>>> resultantMap=new HashMap<String, Map<String,Map<String,Object>>>();

		//Initialising maps for final data 
		Map<String, Map<String, Object>> branchWiseCount=new HashMap<String, Map<String,Object>>();
		Map<String, Map<String, Object>> branchWiseAvg=new HashMap<String, Map<String,Object>>();
		Map<String, Map<String, Object>> regionWiseCount=null; 

		//other maps/lists/references to be used in the process
		Map<String,Map<String,Object>> deviceCountMap = null;
		Map<String,Map<String,Object>> deviceAvgMap = null;
		Map<String,Object> colorCountMap = null;
		Map<String,Object> colorAvgMap = null;
		List<FilterData> devicePayloads = null;
		org.json.JSONArray branchWiseJsonArray = null;
		org.json.JSONObject branchObject = null;


		//here starts the loop for creating branch-wise devise-wise count and averages
		//iterating over branches
		for(String branch: branches){
			//LOGGER.info("ENtered in loop for branchtype "+branch);
			deviceCountMap = new HashMap<String, Map<String,Object>>();
			deviceAvgMap = new HashMap<String, Map<String,Object>>();
			List<String> branchDevices = (List<String>) branchDeviceMap.get(branch);
			//LOGGER.info("List of devices for branch "+branch+" is "+branchDevices);

			//iterating over devices for selected city
			for(String branchDevice: branchDevices){
				//LOGGER.info("inside loop for device "+branchDevice);
				colorCountMap = new HashMap<String, Object>();
				colorAvgMap = new HashMap<String, Object>();
				float redCount=0f, yellowCount=0f, greenCount=0f, amberCount=0f;
				float redSum=0f, yellowSum=0f, greenSum=0f, amberSum=0f;
				devicePayloads = (List<FilterData>) devicePayloadMap.get(branchDevice);

				//iterating over payloads for selected device
				for(FilterData data: devicePayloads){
					//LOGGER.info("payload of device "+branchDevice+" is data "+data);
					branchWiseJsonArray = inputJSON.getJSONArray(branch);
					for(int objectIndex=0;objectIndex<branchWiseJsonArray.length();objectIndex++){
						branchObject = branchWiseJsonArray.getJSONObject(objectIndex);
						double min=branchObject.getDouble("min");
						double max=branchObject.getDouble("max");
						String colorName=branchObject.getString("colorname");
						//LOGGER.info("JSON inside JSONarray :"+branchObject);
						Double temp=Double.parseDouble(data.getParamValue());
						//LOGGER.info("paramValue: "+temp);

						if(colorName.equalsIgnoreCase("Red")){
							//LOGGER.info("inside red");
							if(data.getBranchType().equalsIgnoreCase("RSV")) {
								if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {  
									redCount++;
									redSum+=temp;
									//LOGGER.info("RSV: redcount: "+redCount+" redsum: "+redSum);
								} 
							} else {
								if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2")) {  
									redCount++;
									redSum+=temp;
									//LOGGER.info("redcount: "+redCount+" redsum: "+redSum);
								}
							}
						}else if(colorName.equalsIgnoreCase("Yellow")){
							//LOGGER.info("inside yelloW");
							if(data.getBranchType().equalsIgnoreCase("RSV")) {
								if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
									yellowCount++;
									yellowSum+=temp;
									//LOGGER.info("RSV: yellowcount: "+yellowCount+" yellowsum: "+yellowSum);
								}
							}else {
								if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
									yellowCount++;
									yellowSum+=temp;
									//LOGGER.info("yellowcount: "+yellowCount+" yellowsum: "+yellowSum);
								}
							}
						}else if(colorName.equalsIgnoreCase("Amber")){
							//LOGGER.info("inside amber");
							if(data.getBranchType().equalsIgnoreCase("RSV")) {
								if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
									amberCount++;
									amberSum+=temp;
									//LOGGER.info("RSV: ambercount: "+amberCount+" ambersum: "+amberSum);
								}
							}else {
								if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
									amberCount++;
									amberSum+=temp;
									//LOGGER.info("ambercount: "+amberCount+" ambersum: "+amberSum);
								}
							}
						}else if(colorName.equalsIgnoreCase("Green")){
							//LOGGER.info("inside green");
							if(data.getBranchType().equalsIgnoreCase("RSV")) {
								if ( temp <= max && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {
									greenCount++;
									greenSum+=temp;
									//LOGGER.info("RSV: greencount: "+greenCount+" greensum: "+greenSum);
								}
							}else{
								if( temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) {
									greenCount++;
									greenSum+=temp;
									//LOGGER.info("RSV: greencount: "+greenCount+" greensum: "+greenSum);
								}	
							}
						}
					}
				}

				//updating color count map for selected device
				colorCountMap.put("Red",redCount);
				colorCountMap.put("Yellow",yellowCount);
				colorCountMap.put("Amber",amberCount);
				colorCountMap.put("Green",greenCount);

				//updating color average map for selected device
				if(redCount>0){
					colorAvgMap.put("Red", (redSum/redCount));
				}else{
					colorAvgMap.put("Red", 0f);
				}
				if(yellowCount>0){
					colorAvgMap.put("Yellow", (yellowSum/yellowCount));
				}else{
					colorAvgMap.put("Yellow", 0f);
				}
				if(amberCount>0){
					colorAvgMap.put("Amber", (amberSum/amberCount));
				}else{
					colorAvgMap.put("Amber", 0f);
				}
				if(greenCount>0){
					colorAvgMap.put("Green", (greenSum/greenCount));
				}else{
					colorAvgMap.put("Green", 0f);
				}

				//updating device maps for color count and avg
				deviceCountMap.put(branchDevice, colorCountMap);
				deviceAvgMap.put(branchDevice, colorAvgMap);

				//LOGGER.info("DeviceCountMap: "+deviceCountMap+"\ndeviceAvgMAp: "+deviceAvgMap);
				//LOGGER.info("device "+branchDevice+" loop ends");
			}

			//LOGGER.info("outside device loop of branch "+branch);
			//variables/maps used for final counts and average calculations
			float finalRedCount = 0f, finalGreenCount = 0f, finalAmberCount = 0f, finalYellowCount = 0f; 
			float finalRedAvg = 0f, finalGreenAvg = 0f, finalAmberAvg = 0f, finalYellowAvg = 0f;
			float redDeviceCount = 0f, greenDeviceCount = 0f, amberDeviceCount = 0f, yellowDeviceCount = 0f;
			Map<String,Object> preFinalCountMap = new HashMap<String, Object>();
			Map<String,Object> preFinalAvgMap = new HashMap<String, Object>();

			//iterating over devices again to get branch-wise maps
			for(String branchDevice: branchDevices){
				//LOGGER.info("inside second loop of device "+branchDevice);
				if(((Float)deviceCountMap.get(branchDevice).get("Red")).floatValue() != 0){
					finalRedCount += ((Float)deviceCountMap.get(branchDevice).get("Red")).floatValue();
					redDeviceCount++;
				}
				if(((Float)deviceCountMap.get(branchDevice).get("Amber")).floatValue() != 0){
					finalAmberCount += ((Float)deviceCountMap.get(branchDevice).get("Amber")).floatValue();
					amberDeviceCount++;
				}
				if(((Float)deviceCountMap.get(branchDevice).get("Yellow")).floatValue() != 0){
					finalYellowCount += ((Float)deviceCountMap.get(branchDevice).get("Yellow")).floatValue();
					yellowDeviceCount++;
				}
				if(((Float)deviceCountMap.get(branchDevice).get("Green")).floatValue() != 0){
					finalGreenCount += ((Float)deviceCountMap.get(branchDevice).get("Green")).floatValue();
					greenDeviceCount++;
				}

				finalRedAvg += ((Float)deviceAvgMap.get(branchDevice).get("Red")).floatValue();
				finalAmberAvg += ((Float)deviceAvgMap.get(branchDevice).get("Amber")).floatValue();
				finalYellowAvg += ((Float)deviceAvgMap.get(branchDevice).get("Yellow")).floatValue();
				finalGreenAvg += ((Float)deviceAvgMap.get(branchDevice).get("Green")).floatValue();

				//LOGGER.info("finalRedC:"+finalRedCount+", finalAmberC:"+finalAmberCount+", finalGreenC:"+finalGreenCount+", finalYellowC:"+finalYellowCount);
				//LOGGER.info("finalRedA:"+finalRedAvg+", finalAmberA:"+finalAmberAvg+", finalGreenA:"+finalGreenAvg+", finalYellowA:"+finalYellowAvg);
				//LOGGER.info("redDeviceCount:"+redDeviceCount+", greenDevC:"+greenDeviceCount+", amberDC:"+amberDeviceCount+", yelloDC:"+yellowDeviceCount);
			}

			//LOGGER.info("Outside second iteration of devices for branch "+branch);
			preFinalCountMap.put("Red",finalRedCount);
			preFinalCountMap.put("Amber",finalAmberCount);
			preFinalCountMap.put("Yellow",finalYellowCount);
			preFinalCountMap.put("Green",finalGreenCount);

			if(redDeviceCount>0){
				preFinalAvgMap.put("Red",(finalRedAvg/redDeviceCount));
			}else{
				preFinalAvgMap.put("Red",0f);
			}
			if(amberDeviceCount>0){
				preFinalAvgMap.put("Amber",(finalAmberAvg/amberDeviceCount));
			}else{
				preFinalAvgMap.put("Amber",0f);
			}
			if(yellowDeviceCount>0){
				preFinalAvgMap.put("Yellow",(finalYellowAvg/yellowDeviceCount));
			}else{
				preFinalAvgMap.put("Yellow",0f);
			}
			if(greenDeviceCount>0){
				preFinalAvgMap.put("Green",(finalGreenAvg/greenDeviceCount));
			}else{
				preFinalAvgMap.put("Green",0f);
			}

			//LOGGER.info("prefinal count map:"+preFinalCountMap+"\n prefinal avg map:"+preFinalAvgMap);
			//updating branch-wise maps with final values
			branchWiseCount.put(branch, preFinalCountMap);
			branchWiseAvg.put(branch, preFinalAvgMap);

			//LOGGER.info("branchwise count: "+branchWiseCount+" \n branch wise avg:"+ branchWiseAvg);
		}
		resultantMap.put("coldChain", branchWiseCount);
		resultantMap.put("coldChainavg", branchWiseAvg);

		regionWiseCount=getRegionCount(filterData, inputJSON, regionSet, inputJSONKeySet);

		resultantMap.put("region", regionWiseCount);
		LOGGER.info("getRegionalTrend ends");
		return resultantMap;

	}

	/**
	 * This method is used by getRegionalTrend() method for calculating region wise count of packets in each color range (temperature value range).
	 * 
	 * @author a602834 (Krishna Arigela)
	 * 
	 * @param filterData - List of payloads of devices as FilterData objects
	 * @param inputJSON - JSON having branch type wise filter criteria for color coding
	 * @param regionSet - set containing all regions present in current list of payloads
	 * @param inputJSONKeySet - set of keys of inputJSON
	 * @return Map<String, Map<String, Object>> - Map having region mapped with map having color and counts for that region
	 */
	private  Map<String, Map<String, Object>> getRegionCount(List<FilterData> filterData ,org.json.JSONObject inputJSON,Set<String> regionSet,Set<String> inputJSONKeySet) {

		LOGGER.debug("Enter getRegionCount(-,-,-,-)");

		org.json.JSONObject branchObject=null;
		org.json.JSONArray branchWiseJsonArray = null;
		Map<String, Object> rangeColorCountMap=null;
		Map<String, Map<String, Object>> regionWiseCodeColorCount=new HashMap<String, Map<String,Object>>(); 
		for(String region:regionSet) {
			rangeColorCountMap=new HashMap<String, Object>();
			float aboveRangecount=0;
			float withinCountYellow=0;
			float withinCountAmber=0;
			float belowCount=0;
			String colorName=null;

			for(String branch:inputJSONKeySet) {

				branchWiseJsonArray=inputJSON.getJSONArray(branch);  // PT,ST,RSV...
				String branchName=branch;

				for(int i=0;i<branchWiseJsonArray.length();i++) { // iterate over list of payloads...

					branchObject=branchWiseJsonArray.getJSONObject(i);

					colorName=null;

					double min=branchObject.getDouble("min");
					double max=branchObject.getDouble("max");
					colorName=branchObject.getString("colorname"); // ranges like "above -12": 8026.....

					if(colorName.equalsIgnoreCase("Red")) {

						for(FilterData data:filterData) {
							//regions.add(data.getRegionCode());
							if(data.getBranchType().equalsIgnoreCase(branchName) && data.getRegionCode().equalsIgnoreCase(region)) {
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) { // 
										//LOGGER.info("getRegionCount(-) RSV wihin time..."+data.getTxnTime());
										aboveRangecount++;
									} else {
										//LOGGER.info("getRegionCount(-) RSV else wihin time..."+data.getTxnTime());
									}
								} else {
									if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2")) { // 
										aboveRangecount++;
									}
								}
							}
						}

						rangeColorCountMap.put(colorName, aboveRangecount);

					} else if (colorName.equalsIgnoreCase("Yellow")) {
						for(FilterData data:filterData) {
							//regions.add(data.getRegionCode());
							if(data.getBranchType().equalsIgnoreCase(branchName) && data.getRegionCode().equalsIgnoreCase(region)) {
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if (temp >= min && temp <= max && !data.getLocSubType().equalsIgnoreCase("2") &&  rsvDateComparator(data.getTxnTime())) { // 
										withinCountYellow++;
									}
								} else {
									if (temp >= min && temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) { // 
										withinCountYellow++;
									}
								}
							}
						}

						rangeColorCountMap.put(colorName, withinCountYellow);

					} else if(colorName.equalsIgnoreCase("Amber")) {

						for(FilterData data:filterData) {
							//regions.add(data.getRegionCode());
							if(data.getBranchType().equalsIgnoreCase(branchName) && data.getRegionCode().equalsIgnoreCase(region)) {
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if (temp >= min && temp <= max && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime()) ) { // 
										withinCountAmber++;
									}
								}
								else {
									if (temp >= min && temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) { // 
										withinCountAmber++;
									}
								}
							}
						}

						rangeColorCountMap.put(colorName, withinCountAmber);

					} else if(colorName.equalsIgnoreCase("Green")) {

						for(FilterData data:filterData) {
							//regions.add(data.getRegionCode());
							if(data.getBranchType().equalsIgnoreCase(branchName) && data.getRegionCode().equalsIgnoreCase(region)) {
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if(temp <= max && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {
										belowCount++;
									}
								}else {
									if(temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) {
										belowCount++;
									}
								}
							}
						}

						rangeColorCountMap.put(colorName, belowCount);

					}

				}

			}

			regionWiseCodeColorCount.put(region, rangeColorCountMap);

		}
		LOGGER.debug("Returning getRegionCount(-,-,-,-)"+regionWiseCodeColorCount);
		return regionWiseCodeColorCount;
	}

	/**
	 * This method is called when fetchDefaultValue or fetchChartValue web-services are called for getting India Compliance.
	 * The method iterates over all devices in payload list passed as argument and calculates percentage compliance for each
	 * device. Afterwards, the final compliance is calculated by taking average of all device compliances.
	 * 
	 * @param filterData - List of device payloads as FilterData objects 
	 * @return Map<String, Double> - a map having percentage compliance value
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Double> getIndiaCompliance(List<FilterData> filterData) {
		//map for device and respective percentage values mapping
		Map<String,Double> devicePercentageMap = new HashMap<String, Double>();

		//Multi value map for mapping device to payloads
		MultiMap devicePayloadMap=new MultiValueMap();

		//creating maps of device-payloads
		for(FilterData data: filterData){
			devicePayloadMap.put(data.getDeviceId(),data);
		}

		//getting key set for iteration over devices
		Set<String> deviceKeySet = devicePayloadMap.keySet();

		//iterating over devices for calculating device-wise percentage 
		for(String device : deviceKeySet){
			int belowCount = 0;
			int totalRecords = 0;
			double percentage = 0.0;
			//fetching payloads for concerned device
			List<FilterData> devicePayload = (List<FilterData>) devicePayloadMap.get(device);
			//iterating over payloads for calculating compliance
			for(FilterData data : devicePayload) {
				if(data.getBranchType().equalsIgnoreCase("RSV")) {
					if(!data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {
						totalRecords++;
						//LOGGER.debug("Current param Value - "+data.getParamValue());
						if(Float.valueOf(data.getParamValue()) <= -20 ){
							belowCount++;
						}
					}
				} else {
					if(!data.getLocSubType().equalsIgnoreCase("2")) {
						totalRecords++;
						//LOGGER.debug("Current param Value - "+data.getParamValue());
						if(Float.valueOf(data.getParamValue()) <= -20 ){
							belowCount++;
						}
					}
				}
			}
			//calculating compliance
			if(totalRecords>0){
				percentage = (((float)belowCount)/totalRecords)*100;
			} else{
				percentage = 0;
			}

			//updating device-wise compliance map
			devicePercentageMap.put(device, percentage);
		}

		//variables required for final compliance
		double finalPercentage = 0.0;
		int deviceCount = 0;

		//iterating over devices to get final compliance
		for(String device: deviceKeySet){
			finalPercentage += devicePercentageMap.get(device);
			deviceCount++;
		}
		//getting final percentage compliance
		if(deviceCount>0){
			finalPercentage = finalPercentage/deviceCount;
		} else{
			finalPercentage = 0;
		}

		Map<String, Double> result=new HashMap<String, Double>();
		result.put("percentage", finalPercentage);

		return result;	
	}

	/**
	 * This method is called when fetchDefaultValue or fetchChartValue web-services are called for getting Temperature Trend.
	 * The method iterates over dates and for each date calculates and stores device wise average of parameter values. Afterwards,
	 * the final date-wise averages are calculated by averaging out device-specific values. The response also includes region-wise
	 * count and coldchain count which is calculated by the help of getRegionalTrend() method.
	 * 
	 * @param filterData - List of device payloads as FilterData objects
	 * @param inputJSON - JSON having branch type wise filter criteria for color coding
	 * @return String - region-wise color counts, coldchain counts and date-wise temperature average values in JSON string format
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public String getTemperatureTrend(List<FilterData> filterData,org.json.JSONObject inputJSON) throws JsonGenerationException, JsonMappingException, IOException{

		//creating regional and coldchain sections of results
		Map<String, Map<String, Map<String, Object>>> resultantMap = getRegionalTrend(filterData, inputJSON);
		resultantMap.remove("coldChainavg");

		String dateStr=null;
		//map for date-average mapping
		Map<String, Float> dateAvgMap=new HashMap<String, Float>();
		//multi-value map for date-payload mapping
		MultiMap datePayloadMap=new MultiValueMap();

		//mapping dates with valid payloads in multi-value map
		for(FilterData data:filterData) {
			if(data.getBranchType().equalsIgnoreCase("RSV")) {
				if(rsvDateComparator(data.getTxnTime()) && !data.getLocSubType().equalsIgnoreCase("2")) {
					String stringDate=data.getTxnTime();
					dateStr=stringDate.substring(0, stringDate.indexOf(" "));
					//LOGGER.info("Value : "+data.getParamValue());
					datePayloadMap.put(dateStr, data);
				}
			}
			else{
				if(!data.getLocSubType().equalsIgnoreCase("2")) {
					String stringDate=data.getTxnTime();
					dateStr=stringDate.substring(0, stringDate.indexOf(" "));
					//LOGGER.info("Value : "+data.getParamValue());
					datePayloadMap.put(dateStr, data);
				}
			}
		}
		//LOGGER.info("date wise payload map:" +datePayloadMap);

		//getting keyset for date iteration
		Set<String> dateSet = datePayloadMap.keySet();
		//maps/variables used
		MultiMap deviceValueMap = null;
		Map<String,Float> deviceAvgMap = null;

		//iterating over dates to calculate date-wise average
		for(String date:dateSet) {
			//LOGGER.info("inside date "+date+" loop");

			//initialising device maps and variables for this date
			deviceValueMap = new MultiValueMap();
			deviceAvgMap = new HashMap<String, Float>();
			float finalAverage = 0f;
			int deviceCount = 0;

			//fetching all payloads for this date
			List<FilterData> payloads = (List<FilterData>) datePayloadMap.get(date);
			//creating device-paramValue map
			for(FilterData data: payloads){
				deviceValueMap.put(data.getDeviceId(),Float.valueOf(data.getParamValue()));
			}
			//LOGGER.info("deviceValue map "+deviceValueMap);

			//fetching key set for device iteration
			Set<String> deviceSet = deviceValueMap.keySet();
			//iterating over devices for this date to calculate device wise average
			for(String device: deviceSet){
				//LOGGER.info("inside device "+device+" loop for date "+date);
				List<Float> values= (List<Float>) deviceValueMap.get(device);
				float total=0.0f;
				float noOfValues=0.0f;

				for(float value:values) {
					noOfValues++;
					total+=value;
				}

				float average = 0f;
				if(noOfValues>0){
					average=total/noOfValues;
				}
				deviceAvgMap.put(device, average);
				//LOGGER.info("noOfValues: "+noOfValues+"; total:"+total+"; average: "+average);
			}

			//iterating over devices again to get final date wise average mapped
			for(String device: deviceSet){
				finalAverage += deviceAvgMap.get(device);
				deviceCount++;
			}
			//LOGGER.info("final average: "+finalAverage+"; deviceCount: "+deviceCount);
			if(deviceCount>0){
				finalAverage = finalAverage/deviceCount;
			}else{
				finalAverage = 0f;
			}
			//LOGGER.info("final average finally: "+finalAverage);

			//updating final average values for date
			dateAvgMap.put(date, finalAverage);
			//LOGGER.info("date average map: "+dateAvgMap);
		}

		String averageString=objectMapper.writeValueAsString(dateAvgMap);

		org.json.JSONObject json1=new org.json.JSONObject(averageString);
		org.json.JSONObject mergedJson= new JSONObject();

		mergedJson.put("temperature", json1);
		mergedJson.put("region", resultantMap.get("region"));
		mergedJson.put("coldChain", resultantMap.get("coldChain"));
		LOGGER.info("Region");

		LOGGER.info("-------------- merged ------------------- ");

		Map<String, Object> result= toMap(mergedJson);

		return objectMapper.writeValueAsString(result);
	}

	/**
	 * This method is called by getTemperatureTrend() and getDrilledValues() methods in order to create a map out of
	 * JSON string.
	 * 
	 * @author a602834 (Krishna Arigela)
	 * 
	 * @param object - JSONObject object created by merging different JSONs
	 * @return Map<String, Object> - map created for the JSON object 
	 * @throws JSONException
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> toMap(JSONObject object) throws JSONException {
		Map<String, Object> map = new HashMap<String, Object>();

		Iterator<String> keysItr = object.keys();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);
			if(value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, value);
		}
		return map;
	}

	/**
	 * This method is called when fetchDefaultValue or fetchChartValue web-services are called for getting Pan India Compliance.
	 * The method iterates over input JSON keyset (branches including FACTORYANTE and DEPOTANTE cases) and calculates percentage
	 * compliance per devices. Afterwards, device values are averaged out to get final branch wise values for percentage compliance. 
	 * 
	 * @param filterData - List of payload as FilterData objects
	 * @param inputJSON - JSON having threshold values for different branch types
	 * @return Map<String, Map<String, Object>> - map having value of branch-wise percentage compliance sent as required 
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Map<String, Object>> getPanIndia(List<FilterData> filterData,org.json.JSONObject inputJSON) {
		LOGGER.info("Entering getPanIndia method");
		Map<String, Map<String, Object>> resultMap = new HashMap<String, Map<String, Object>>();
		Map<String, Object> branchPercentageMap = new HashMap<String, Object>();

		//map for branch-device mapping
		MultiMap branchDeviceMap=new MultiValueMap();
		//Map for device-payload mapping
		MultiMap devicePayloadMap=new MultiValueMap();

		//creating maps of branch-devices and device-payloads
		for(FilterData data: filterData){
			if(!branchDeviceMap.isEmpty() && branchDeviceMap !=null){
				if(!branchDeviceMap.containsValue(data.getDeviceId())){
					branchDeviceMap.put(data.getBranchType(), data.getDeviceId());
				}
			}
			else if(branchDeviceMap.isEmpty()){
				branchDeviceMap.put(data.getBranchType(), data.getDeviceId());
			}
			devicePayloadMap.put(data.getDeviceId(),data);
		}
		//LOGGER.info("branch device map:" +branchDeviceMap+"; devicePayloadMap: "+ devicePayloadMap);

		//Maps for saving device-wise percentages for each branch
		Map<String, Object> devicePercentageMap = null;
		Map<String, Object> deviceAntePercentageMap = null;

		org.json.JSONObject jsonObject=null;
		//getting input JSON keyset for iteration
		Set<String> keys= inputJSON.keySet();
		//iterating over branches
		for(String branch:keys) {
			LOGGER.info("inside loop of branch "+branch);
			//getting devices for respective branch and initialising device-percentage maps 
			List<String> branchDevices = null;
			if(!StringUtils.equalsIgnoreCase(branch, "FACTORYANT") && !StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
				branchDevices = (List<String>) branchDeviceMap.get(branch);
				//creating new instance of map for this branch devices
				devicePercentageMap = new HashMap<String, Object>();
				//LOGGER.info("inside non ante case, branchDevice: "+branchDevices);
			}else if(StringUtils.equalsIgnoreCase(branch, "FACTORYANT")) {
				branchDevices = (List<String>) branchDeviceMap.get("FACTORY");
				//creating new instance of map for this branch devices
				deviceAntePercentageMap = new HashMap<String, Object>();
				//LOGGER.info("inside FACTORY ante case, branchDevice: "+branchDevices);
			}else if(StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
				branchDevices = (List<String>) branchDeviceMap.get("DEPOT");
				//creating new instance of map for this branch devices
				deviceAntePercentageMap = new HashMap<String, Object>();
				//LOGGER.info("inside DEPOTante case, branchDevice: "+branchDevices);
			}

			//iterating over devices in case present
			if(branchDevices!=null && !branchDevices.isEmpty()){
				for(String device: branchDevices){
					LOGGER.info("inside device loop for device "+device);
					float count = 0f, belowCount = 0f;
					//fetching device payloads
					List<FilterData> devicePayloads = (List<FilterData>) devicePayloadMap.get(device);
					if(!StringUtils.equalsIgnoreCase(branch, "FACTORYANT") && !StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
						//getting threshold for calculation as per branch
						Object tempThreshold=inputJSON.get(branch);
						String tempThresholdString=tempThreshold.toString();
						Float belowValue=Float.valueOf(tempThresholdString);

						//iterate over payloads
						for(FilterData data :devicePayloads) {
							if(data.getBranchType().equalsIgnoreCase("RSV")) {
								if(data.getBranchType().equalsIgnoreCase(branch) && !data.getLocSubType().equalsIgnoreCase("2") & rsvDateComparator(data.getTxnTime())) {
									count++;
									if(Float.valueOf(data.getParamValue()) <= belowValue) {
										belowCount++;
									}
								}
							}
							else{
								if(data.getBranchType().equalsIgnoreCase(branch) && !data.getLocSubType().equalsIgnoreCase("2")) {
									count++;
									if(Float.valueOf(data.getParamValue()) <= belowValue) {
										belowCount++;
									}
								}
							}
						}
						Float percentage=0f;
						if(count>0){
							percentage=(belowCount/count)*100;
						}
						devicePercentageMap.put(device, percentage);
						//LOGGER.info("percentage for device +"+device+" for branch "+branch+" is "+percentage);
					} else if(StringUtils.equalsIgnoreCase(branch, "FACTORYANT")) {
						//getting threshold loc subtype
						jsonObject = (org.json.JSONObject)inputJSON.getJSONObject(branch);
						Object locationSubType=null;
						Object antiBelowString=null;
						locationSubType=jsonObject.get("locSubType");
						antiBelowString=jsonObject.get("paramValue");
						String locSubType=locationSubType.toString();
						Float antiBelowValue=Float.valueOf(antiBelowString.toString());

						//iterate over payloads
						for(FilterData data :devicePayloads) {
							if (data.getLocSubType().equalsIgnoreCase(locSubType)) {
								count++;
							}
							if(Float.valueOf(data.getParamValue()) <= antiBelowValue && data.getLocSubType().equalsIgnoreCase(locSubType)) {
								belowCount++;
							}
						}
						Float percentage=0f;
						if(count>0){
							percentage=(belowCount/count)*100;
						}
						devicePercentageMap.put(device, percentage);
						deviceAntePercentageMap.put(device, percentage);
						//LOGGER.info("percentage for device +"+device+" for branch FACTORYANTE is "+percentage);
					} else if(StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
						//getting threshold loc subtype
						jsonObject = (org.json.JSONObject)inputJSON.getJSONObject(branch);
						Object locationSubType=null;
						Object antiBelowString=null;
						locationSubType=jsonObject.get("locSubType");
						antiBelowString=jsonObject.get("paramValue");
						String locSubType=locationSubType.toString();
						Float antiBelowValue=Float.valueOf(antiBelowString.toString());

						//iterate over payloads
						for(FilterData data :devicePayloads) {
							if (data.getLocSubType().equalsIgnoreCase(locSubType)) {
								count++;
							}
							if(Float.valueOf(data.getParamValue()) <= antiBelowValue && data.getLocSubType().equalsIgnoreCase(locSubType)) {
								belowCount++;
							}
						}
						Float percentage=0f;
						if(count>0){
							percentage=(belowCount/count)*100;
						}
						devicePercentageMap.put(device, percentage);
						deviceAntePercentageMap.put(device, percentage);
						//LOGGER.info("percentage for device +"+device+" for branch DEPOTANTE is "+percentage);
					}
				}
			}
			//variables for final calculation
			float finalPercentage = 0f, deviceCount = 0f;

			//iterating over devices again to calculate final branch wise results
			if(branchDevices!=null && !branchDevices.isEmpty()){
				for(String device: branchDevices){
					if(!StringUtils.equalsIgnoreCase(branch, "FACTORYANT") && !StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
						finalPercentage += ((Float)devicePercentageMap.get(device)).floatValue();
						deviceCount++;
					}else if(StringUtils.equalsIgnoreCase(branch, "FACTORYANT")) {
						finalPercentage += ((Float)deviceAntePercentageMap.get(device)).floatValue();
						deviceCount++;
					}else if(StringUtils.equalsIgnoreCase(branch, "DEPOTANT")) {
						finalPercentage += ((Float)deviceAntePercentageMap.get(device)).floatValue();
						deviceCount++;
					}
				}
			}
			if(deviceCount>0){
				finalPercentage = finalPercentage/deviceCount;
			}else{
				finalPercentage = 0f;
			}
			//updating branch wise map
			branchPercentageMap.put(branch, finalPercentage);
		}
		resultMap.put("compliance",branchPercentageMap);
		LOGGER.info("Exiting getPanIndia method");
		return resultMap;
	}

	/**
	 * This method is called at all places where RSV branch type date constraint is checked. The method 
	 * processes Date passed to check whether it lies between the time limits as allowed by RSV or not.
	 * If under limits, method returns TRUE otherwise FALSE.
	 * 
	 * @author a602834 (Krishna Arigela)
	 * 
	 * @param date - String date 
	 * @return boolean - True if date lies within allowed time limits, false otherwise
	 */
	public boolean rsvDateComparator(String date) {
		try {
			//String date="2016-01-25 01:41:16";
			//LOGGER.info("Input date : "+date);

			String[] time=date.split(" ");
			String string1 = "06:00:00";
			Date time1 = new SimpleDateFormat("HH:mm:ss").parse(string1);
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(time1);

			String string2 = "19:00:00";
			Date time2 = new SimpleDateFormat("HH:mm:ss").parse(string2);
			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(time2);

			Date d = new SimpleDateFormat("HH:mm:ss").parse(time[1]);
			Calendar calendar3 = Calendar.getInstance();
			calendar3.setTime(d);

			Date x = calendar3.getTime();
			if (x.after(calendar1.getTime()) && x.before(calendar2.getTime())) {
				//checkes whether the current time is between 06:00:00 and 19:00:00.
				//LOGGER.info("Time is within - "+true);
				return true;
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}
		//LOGGER.info("RSV date comparator: Time is out of range "+false);

		return false;
	}

	/**
	 * This method creates return JSON for fetchDrilledValues service.
	 * 
	 * @param filterData - List of FilterData objects
	 * @param inputJSON - rule criteria JSON 
	 * @return JSON string
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public String getDrilledValue(List<FilterData> filterData,org.json.JSONObject inputJSON) throws JsonGenerationException, JsonMappingException, IOException{
		//map for city-wise colour data gathering
		Map<String,Map<String,Object>> cityWiseCount = new HashMap<String,Map<String,Object>>();

		//map for citi iteration
		MultiMap cityPayloadMap=new MultiValueMap();

		//creating maps of citi-payloads
		for(FilterData data: filterData){
			cityPayloadMap.put(data.getDistrictName(), data);
		}

		//key set to iterate over input JSON for getting colour criteria
		Set<String> inputJSONKeySet=inputJSON.keySet();
		//key set for iterating over cities
		Set<String> cities= cityPayloadMap.keySet();

		//other references used
		Map<String, Object> colorCountMap = null;
		org.json.JSONArray branchWiseJsonArray = null;
		org.json.JSONObject branchObject = null;

		//iterating over cities for mapping
		for(String city: cities){
			colorCountMap = new HashMap<String, Object>();
			float redCount=0f, greenCount=0f, yellowCount=0f, amberCount=0f;
			List<FilterData> cityPayloads = (List<FilterData>) cityPayloadMap.get(city);

			//iterating over payloads for selected city
			for(FilterData data: cityPayloads){

				//iterating over input JSON for getting colour criteria
				for(String branch: inputJSONKeySet){
					if(StringUtils.equalsIgnoreCase(branch, data.getBranchType())){
						branchWiseJsonArray = inputJSON.getJSONArray(branch);
						for(int objectIndex=0;objectIndex<branchWiseJsonArray.length();objectIndex++){
							branchObject = branchWiseJsonArray.getJSONObject(objectIndex);
							double min=branchObject.getDouble("min");
							double max=branchObject.getDouble("max");
							String colorName=branchObject.getString("colorname");

							if(colorName.equalsIgnoreCase("Red")){
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {  
										redCount++;
									} 
								} else {
									if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2")) {  
										redCount++;
									}
								}
							}else if(colorName.equalsIgnoreCase("Yellow")){
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
										yellowCount++;
									}
								}else {
									if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
										yellowCount++;
									}
								}
							}else if(colorName.equalsIgnoreCase("Amber")){
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
										amberCount++;
									}
								}else {
									if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
										amberCount++;
									}
								}
							}else if(colorName.equalsIgnoreCase("Green")){
								Double temp=Double.parseDouble(data.getParamValue());
								if(data.getBranchType().equalsIgnoreCase("RSV")) {
									if ( temp <= max && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {
										greenCount++;
									}
								}else{
									if( temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) {
										greenCount++;
									}	
								}
							}
						}
					}
				}				
			}

			//updating color maps for selected city
			colorCountMap.put("Red", redCount);
			colorCountMap.put("Yellow", yellowCount);
			colorCountMap.put("Amber", amberCount);
			colorCountMap.put("Green", greenCount);

			//updating final city-Wise map
			cityWiseCount.put(city, colorCountMap);
		}
		//map used for mapping into returnJSON
		Map<String,Map<String,Map<String,Object>>> mappingMap = new HashMap<String,Map<String,Map<String,Object>>>();
		mappingMap.put("city", cityWiseCount);

		//converting drilled value result into JSON
		String drilledValueString = getCityDeviceValues(filterData, inputJSON);
		org.json.JSONObject returnJSON=new org.json.JSONObject(drilledValueString);
		returnJSON.put("city", mappingMap.get("city"));
		Map<String, Object> result= toMap(returnJSON);

		return objectMapper.writeValueAsString(result);
	}

	/**
	 * This method is used by getDrilledValues to get city-wise device-wise color counts and averages.
	 * 
	 * @param filterData - List of FilterData objects
	 * @param inputJSON - rule criteria JSON
	 * @return JSON string
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private String getCityDeviceValues(List<FilterData> filterData,org.json.JSONObject inputJSON) throws JsonGenerationException, JsonMappingException, IOException{
		//map for final JSON holding
		Map<String,Map<String,Map<String,Map<String,Object>>>> drilledValue = 
				new HashMap<String,Map<String,Map<String,Map<String,Object>>>>(); 

		//map for citi iteration
		MultiMap cityDeviceMap=new MultiValueMap();
		//Map for device iteration
		MultiMap devicePayloadMap=new MultiValueMap();

		//creating maps of citi-devices and device-payloads
		for(FilterData data: filterData){
			if(!cityDeviceMap.isEmpty() && cityDeviceMap !=null){
				if(!cityDeviceMap.containsValue(data.getDeviceId())){
					cityDeviceMap.put(data.getDistrictName(), data.getDeviceId());
				}
			}
			else if(cityDeviceMap.isEmpty()){
				cityDeviceMap.put(data.getDistrictName(), data.getDeviceId());
			}
			devicePayloadMap.put(data.getDeviceId(),data);
		}

		//key set to iterate over input JSON for getting colour criteria
		Set<String> inputJSONKeySet=inputJSON.keySet();
		//key set for iterating over cities
		Set<String> cities= cityDeviceMap.keySet();

		//other maps/lists/references to be used in the process
		Map<String, Map<String,Map<String, Object>>> preFinalMap = null;
		Map<String,Map<String,Object>> deviceColourCountMap = null;
		Map<String,Map<String,Object>> deviceColourAvgMap = null;
		Map<String,Object> colorCountMap = null;
		Map<String,Object> colorAvgMap = null;
		List<FilterData> devicePayloads = null;
		org.json.JSONArray branchWiseJsonArray = null;
		org.json.JSONObject branchObject = null;

		//here starts the loop for creating citi-wise devise-wise count and averages
		//iterating over cities
		for(String city: cities){
			preFinalMap = new HashMap<String, Map<String,Map<String, Object>>>();
			deviceColourCountMap = new HashMap<String, Map<String,Object>>();
			deviceColourAvgMap = new HashMap<String, Map<String,Object>>();
			List<String> cityDevices = (List<String>) cityDeviceMap.get(city);

			//iterating over devices for selected city
			for(String cityDevice: cityDevices){
				colorCountMap = new HashMap<String, Object>();
				colorAvgMap = new HashMap<String, Object>();
				Double redCount=0.0, yellowCount=0.0, greenCount=0.0, amberCount=0.0;
				Double redSum=0.0, yellowSum=0.0, greenSum=0.0, amberSum=0.0;
				devicePayloads = (List<FilterData>) devicePayloadMap.get(cityDevice);

				//iterating over payloads for selected device
				for(FilterData data: devicePayloads){

					//iterating over input JSON for getting colour criteria
					for(String branch: inputJSONKeySet){
						if(StringUtils.equalsIgnoreCase(branch, data.getBranchType())){
							branchWiseJsonArray = inputJSON.getJSONArray(branch);
							for(int objectIndex=0;objectIndex<branchWiseJsonArray.length();objectIndex++){
								branchObject = branchWiseJsonArray.getJSONObject(objectIndex);
								double min=branchObject.getDouble("min");
								double max=branchObject.getDouble("max");
								String colorName=branchObject.getString("colorname");

								if(colorName.equalsIgnoreCase("Red")){
									Double temp=Double.parseDouble(data.getParamValue());
									if(data.getBranchType().equalsIgnoreCase("RSV")) {
										if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {  
											redCount++;
											redSum+=temp;
										} 
									} else {
										if (temp >= min && !data.getLocSubType().equalsIgnoreCase("2")) {  
											redCount++;
											redSum+=temp;
										}
									}
								}else if(colorName.equalsIgnoreCase("Yellow")){
									Double temp=Double.parseDouble(data.getParamValue());
									if(data.getBranchType().equalsIgnoreCase("RSV")) {
										if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
											yellowCount++;
											yellowSum+=temp;
										}
									}else {
										if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
											yellowCount++;
											yellowSum+=temp;
										}
									}
								}else if(colorName.equalsIgnoreCase("Amber")){
									Double temp=Double.parseDouble(data.getParamValue());
									if(data.getBranchType().equalsIgnoreCase("RSV")) {
										if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")  && rsvDateComparator(data.getTxnTime())) {
											amberCount++;
											amberSum+=temp;
										}
									}else {
										if ((temp >= min && temp <= max )&& !data.getLocSubType().equalsIgnoreCase("2")) {
											amberCount++;
											amberSum+=temp;
										}
									}
								}else if(colorName.equalsIgnoreCase("Green")){
									Double temp=Double.parseDouble(data.getParamValue());
									if(data.getBranchType().equalsIgnoreCase("RSV")) {
										if ( temp <= max && !data.getLocSubType().equalsIgnoreCase("2") && rsvDateComparator(data.getTxnTime())) {
											greenCount++;
											greenSum+=temp;
										}
									}else{
										if( temp <= max && !data.getLocSubType().equalsIgnoreCase("2")) {
											greenCount++;
											greenSum+=temp;
										}	
									}
								}
							}
						}
					}
				}

				//updating color count map for selected device
				colorCountMap.put("Red",redCount);
				colorCountMap.put("Yellow",yellowCount);
				colorCountMap.put("Amber",amberCount);
				colorCountMap.put("Green",greenCount);

				//updating color average map for selected device
				if(redCount>0){
					colorAvgMap.put("Red", (redSum/redCount));
				}else{
					colorAvgMap.put("Red", 0);
				}
				if(yellowCount>0){
					colorAvgMap.put("Yellow", (yellowSum/yellowCount));
				}else{
					colorAvgMap.put("Yellow", 0);
				}
				if(amberCount>0){
					colorAvgMap.put("Amber", (amberSum/amberCount));
				}else{
					colorAvgMap.put("Amber", 0);
				}
				if(greenCount>0){
					colorAvgMap.put("Green", (greenSum/greenCount));
				}else{
					colorAvgMap.put("Green", 0);
				}

				//updating device maps for color count and avg
				deviceColourCountMap.put(cityDevice, colorCountMap);
				deviceColourAvgMap.put(cityDevice, colorAvgMap);
			}
			//creating key values for city final map
			preFinalMap.put("deviceID", deviceColourCountMap);
			preFinalMap.put("deviceIDavg", deviceColourAvgMap);

			//updating final map
			drilledValue.put(city, preFinalMap);
		}

		return objectMapper.writeValueAsString(drilledValue);
	}


	public Map<String, Map<String, Map<String, Map<String, Object>>>> generateMonthlyTrend() {

		List<MonthlyTrendData> data=null;

		Map<String, Map<String, Object>> regionMap=null;
		Map<String, Map<String, Object>> branchWiseRegionCodeColorCount=null;
		Map<String, Map<String, Object>> branchWiseRegionCodeColorAvgCount=null;
		Map<String, Map<String, Map<String, Object>>> resultantMap=null;

		Map<String, Map<String, Map<String, Map<String, Object>>>> monthlyTrendResults=new HashMap<String, Map<String,Map<String,Map<String,Object>>>>();

		Map<String, Object> colorCount=null;
		Map<String, Object> rangeColorCountMap=null;
		Map<String, Object> rangeColorCountAvgMap=null;

		Set<String> regions=new HashSet<String>();
		regions.add("EAST");
		regions.add("WEST");
		regions.add("NORTH");
		regions.add("SOUTH");


		Set<String> branchTypes=new HashSet<String>();
		branchTypes.add("PT");
		branchTypes.add("ST");
		branchTypes.add("RS Cold Room");
		branchTypes.add("DEPOT");
		branchTypes.add("RSV");
		branchTypes.add("FACTORY");


		//String year="2016";
		Set<String> months=new HashSet<String>();
		months.add("Jan");
		months.add("Feb");
		months.add("Mar");
		months.add("Apr");
		months.add("May");
		months.add("Jun");
		months.add("July");
		months.add("Aug");
		months.add("Sept");
		months.add("Oct");
		months.add("Nov");
		months.add("Dec");

		for(String month:months) {

			data = dbConnector.getMonthlyTrendData(month);

			regionMap=new HashMap<String, Map<String,Object>>();
			branchWiseRegionCodeColorCount=new HashMap<String, Map<String,Object>>();
			branchWiseRegionCodeColorAvgCount=new HashMap<String, Map<String,Object>>();

			for(String region:regions) {

				Float complianceGreenCount=0.0f;

				Float complianceYellowCount=0.0f;

				Float complianceAmberCount=0.0f;

				Float complianceRedCount=0.0f;

				colorCount=new HashMap<String, Object>();

				for(MonthlyTrendData mTrend:data) {

					if(mTrend.getRegionCode().equalsIgnoreCase(region)) {
						complianceGreenCount+=Float.valueOf(mTrend.getComplianceGreenCount());
						complianceYellowCount+=Float.valueOf(mTrend.getComplianceYellowCount());
						complianceAmberCount+=Float.valueOf(mTrend.getComplianceAmberCount());
						complianceRedCount+=Float.valueOf(mTrend.getComplianceRedCount());
					}
				}

				colorCount.put("Red", complianceRedCount);
				colorCount.put("Green", complianceGreenCount);
				colorCount.put("Yellow", complianceYellowCount);
				colorCount.put("Amber", complianceAmberCount);

				//add region and its counts
				regionMap.put(region, colorCount);
				LOGGER.info("Month "+month+" data : "+regionMap);

			}

			// For the same month calculate coldChain & coldChainAvg

			for(String branch:branchTypes) {

				rangeColorCountMap=new HashMap<String, Object>();
				rangeColorCountAvgMap=new HashMap<String, Object>();

				Float complianceGreenCount=0.0f;

				Float complianceYellowCount=0.0f;

				Float complianceAmberCount=0.0f;

				Float complianceRedCount=0.0f;

				Float complianceGreenSum=0.0f;

				Float complianceYellowSum=0.0f;

				Float complianceAmberSum=0.0f;

				Float complianceRedSum=0.0f;

				for(MonthlyTrendData mTrend:data) {
					if(branch.equalsIgnoreCase(mTrend.getBranchType())) {
						complianceGreenCount+=Float.valueOf(mTrend.getComplianceGreenCount());
						complianceYellowCount+=Float.valueOf(mTrend.getComplianceYellowCount());
						complianceAmberCount+=Float.valueOf(mTrend.getComplianceAmberCount());
						complianceRedCount+=Float.valueOf(mTrend.getComplianceRedCount());

						complianceGreenSum+=Float.valueOf(mTrend.getComplianceGreenSum());
						complianceYellowSum+=Float.valueOf(mTrend.getComplianceYellowSum());
						complianceAmberSum+=Float.valueOf(mTrend.getComplianceAmberSum());
						complianceRedSum+=Float.valueOf(mTrend.getComplianceRedSum());


					}
				}

				rangeColorCountMap.put("Red", complianceRedCount);
				rangeColorCountMap.put("Green", complianceGreenCount);
				rangeColorCountMap.put("Yellow", complianceYellowCount);
				rangeColorCountMap.put("Amber", complianceAmberCount);

				rangeColorCountAvgMap.put("Red", complianceRedSum/complianceRedCount);
				rangeColorCountAvgMap.put("Green", complianceGreenSum/complianceGreenCount);
				rangeColorCountAvgMap.put("Yellow", complianceYellowSum/complianceYellowCount);
				rangeColorCountAvgMap.put("Amber", complianceAmberSum/complianceAmberCount);

				branchWiseRegionCodeColorCount.put(branch, rangeColorCountMap);
				branchWiseRegionCodeColorAvgCount.put(branch, rangeColorCountAvgMap);

			}
			resultantMap=new HashMap<String, Map<String,Map<String,Object>>>();

			resultantMap.put("region", regionMap);
			resultantMap.put("coldChain", branchWiseRegionCodeColorCount);
			resultantMap.put("coldChainAvg", branchWiseRegionCodeColorAvgCount);

			monthlyTrendResults.put(month, resultantMap);

		}

		return monthlyTrendResults;

	}

}


