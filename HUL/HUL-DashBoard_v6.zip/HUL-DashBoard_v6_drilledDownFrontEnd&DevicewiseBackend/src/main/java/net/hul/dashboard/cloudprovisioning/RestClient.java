/**
 * 
 */
package net.hul.dashboard.cloudprovisioning;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.util.Arrays;

import org.apache.http.HttpHost;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * This class is to handle RestTemplateClient
 * A561065
 *
 */
@Component
public class RestClient {
	
	 /**
     * bean injection for Rest Template
     */
    @Autowired
    private RestTemplate restTemplate;
    	
	@Value("${login.proxy.host}")
	private String proxyHost;

	@Value("${login.proxy.port}")
	private String proxyPort;

    /**
     * Rest Client for POST method.
     * 
     * @param url
     * @param jsonString
     * @return
     */
    public String restPostClient(final String url, final String jsonString) {
    	
    	
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		Proxy proxy= new Proxy(Type.HTTP, new InetSocketAddress(proxyHost, Integer.parseInt(proxyPort)));
	    requestFactory.setProxy(proxy);

		restTemplate.setRequestFactory(requestFactory);

        final HttpEntity<String> requestEntity = new HttpEntity<String>(jsonString, headers);
        final ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);

        return response.getBody();
    }

    /**
     * restExchange
     * 
     * @param url
     * @param inputString
     * @param httpMethod
     * @param headers
     * @return ResponseEntity<String>
     */
    public ResponseEntity<String> restExchange(final String url, final String inputString, HttpMethod httpMethod,
        HttpHeaders headers, MediaType contentType) {

        if (headers == null) {
            headers = new HttpHeaders();
        }
        /*HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		
		DefaultHttpClient httpClient = (DefaultHttpClient) requestFactory.getHttpClient();
		HttpHost proxy = new HttpHost(proxyHost, Integer.parseInt(proxyPort));
		httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,proxy);*/

		headers.setContentType(contentType);
		//restTemplate.setRequestFactory(requestFactory);

        final HttpEntity<String> request = new HttpEntity<String>(inputString, headers);
        final ResponseEntity<String> response = restTemplate.exchange(url, httpMethod, request, String.class);

        return response;
    }
    
    /**
	 * Rest Client for POST method.
	 * 
	 * @param url
	 * @param jsonString
	 * @return
	 */
	public String restPostClient(final String url) {

		try {
			HttpHeaders headers = new HttpHeaders();

			// List<MediaType> mediaTypes = new ArrayList<MediaType>();

			headers.set("Accept", "application/json");

			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			/*SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
			Proxy proxy= new Proxy(Type.HTTP, new InetSocketAddress(proxyHost, Integer.parseInt(proxyPort)));
			requestFactory.setProxy(proxy);
            restTemplate.setRequestFactory(requestFactory);*/
			final HttpEntity<String> requestEntity = new HttpEntity<String>("",headers);
			final ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
			return response.getBody();
		} catch (RestClientException e) {
			throw e;

		}
	}
}
