/**
 * 
 */
package net.hul.dashboard.dto;

import java.util.Date;
import java.util.List;

/**
 * @author a602834(Krishna)
 * 
 *
 */
public class MonthlyTrendData {
	
	private Integer id;
	
	private String complianceYear;
	
	private String complianceMonth;
	
	private String regionCode;
	private String branchType;
	private String paramName;
	
	private String complianceGreenCount;
	
	private String complianceYellowCount;
	
	private String complianceAmberCount;
	
	private String complianceRedCount;
	
	private String complianceGreenSum;
	
	private String complianceYellowSum;
	
	private String complianceAmberSum;
	
	private String complianceRedSum;
	
	private String branchName;
	
	private String locType;
	
	private String districtName;
	
	// Previous values
	
	private String txnTime;
	
	private String paramValue;
	
	private String locSubType;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComplianceYear() {
		return complianceYear;
	}

	public void setComplianceYear(String complianceYear) {
		this.complianceYear = complianceYear;
	}

	public String getComplianceMonth() {
		return complianceMonth;
	}

	public void setComplianceMonth(String complianceMonth) {
		this.complianceMonth = complianceMonth;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getBranchType() {
		return branchType;
	}

	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getComplianceGreenCount() {
		return complianceGreenCount;
	}

	public void setComplianceGreenCount(String complianceGreenCount) {
		this.complianceGreenCount = complianceGreenCount;
	}

	public String getComplianceYellowCount() {
		return complianceYellowCount;
	}

	public void setComplianceYellowCount(String complianceYellowCount) {
		this.complianceYellowCount = complianceYellowCount;
	}

	public String getComplianceAmberCount() {
		return complianceAmberCount;
	}

	public void setComplianceAmberCount(String complianceAmberCount) {
		this.complianceAmberCount = complianceAmberCount;
	}

	public String getComplianceRedCount() {
		return complianceRedCount;
	}

	public void setComplianceRedCount(String complianceRedCount) {
		this.complianceRedCount = complianceRedCount;
	}

	public String getComplianceGreenSum() {
		return complianceGreenSum;
	}

	public void setComplianceGreenSum(String complianceGreenSum) {
		this.complianceGreenSum = complianceGreenSum;
	}

	public String getComplianceYellowSum() {
		return complianceYellowSum;
	}

	public void setComplianceYellowSum(String complianceYellowSum) {
		this.complianceYellowSum = complianceYellowSum;
	}

	public String getComplianceAmberSum() {
		return complianceAmberSum;
	}

	public void setComplianceAmberSum(String complianceAmberSum) {
		this.complianceAmberSum = complianceAmberSum;
	}

	public String getComplianceRedSum() {
		return complianceRedSum;
	}

	public void setComplianceRedSum(String complianceRedSum) {
		this.complianceRedSum = complianceRedSum;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getLocType() {
		return locType;
	}

	public void setLocType(String locType) {
		this.locType = locType;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	
	public String getTxnTime() {
		return txnTime;
	}

	public void setTxnTime(String txnTime) {
		this.txnTime = txnTime;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getLocSubType() {
		return locSubType;
	}

	public void setLocSubType(String locSubType) {
		this.locSubType = locSubType;
	}

	@Override
	public String toString() {
		return "MonthlyTrendData [id=" + id + ", complianceYear="
				+ complianceYear + ", complianceMonth=" + complianceMonth
				+ ", regionCode=" + regionCode + ", branchType=" + branchType
				+ ", paramName=" + paramName + ", complianceGreenCount="
				+ complianceGreenCount + ", complianceYellowCount="
				+ complianceYellowCount + ", complianceAmberCount="
				+ complianceAmberCount + ", complianceRedCount="
				+ complianceRedCount + ", complianceGreenSum="
				+ complianceGreenSum + ", complianceYellowSum="
				+ complianceYellowSum + ", complianceAmberSum="
				+ complianceAmberSum + ", complianceRedSum=" + complianceRedSum
				+ ", branchName=" + branchName + ", locType=" + locType
				+ ", districtName=" + districtName + ", txnTime=" + txnTime
				+ ", paramValue=" + paramValue + ", locSubType=" + locSubType
				+ "]";
	}

}
