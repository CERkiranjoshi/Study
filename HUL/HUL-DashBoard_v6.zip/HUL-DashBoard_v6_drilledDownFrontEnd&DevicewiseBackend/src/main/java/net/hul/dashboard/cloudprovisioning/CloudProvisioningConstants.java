/**
 * 
 */
package net.hul.dashboard.cloudprovisioning;

import java.io.File;

/**
 * @author a561065
 *
 */
public interface CloudProvisioningConstants {
	
	/** The user response. */
	String USER_RESPONSE = "UserResponse";

	/**
	 * The success.
	 */
	String SUCCESS = "success";

	/**
	 * The failure.
	 */
	String FAILURE = "failure";

	/**
	 * The cp authenticate.
	 */
	String CP_AUTHENTICATE = "/authenticateUserWithTenantService.htm";

	/**
	 * The date format.
	 */
	String DATE_FORMAT = "yyyy-MM-dd";

	/**
	 * The time format.
	 */
	String TIME_FORMAT = "yyyy-MM-dd hh:mm:ss.SSS";

	/**
	 * The tenant.
	 */
	String TENANT = "tenant";

	/**
	 * The service.
	 */
	String SERVICE = "serviceCode";

	/**
	 * The spring security remember me.
	 */
	String SPRING_SECURITY_REMEMBER_ME = "_spring_security_remember_me";

	/**
	 * The j password.
	 */
	String J_PASSWORD = "j_password";

	/**
	 * The j username.
	 */
	String J_USERNAME = "j_username";

	/**
	 * The and.
	 */
	String AND = "&";

	/**
	 * The equal.
	 */
	String EQUAL = "=";

	/**
	 * The question.
	 */
	String QUESTION = "?";

	/**
	 * The delete.
	 */
	String DELETE = ".delete";

	/**
	 * The true.
	 */
	String TRUE = "T";

	/**
	 * The false.
	 */
	String FALSE = "F";

	/**
	 * The cp authenticate exception.
	 */
	String CP_AUTHENTICATE_EXCEPTION = "Authentication Failure with Provisoning System";

	/**
	 * The user not found exception.
	 */
	String USER_NOT_FOUND_EXCEPTION = "User Not Found.";

	/**
	 * The default image.
	 */
	String DEFAULT_IMAGE = "images" + File.separator + "default.jpg";

	/**
	 * The token login url.
	 */
	String TOKEN_LOGIN_URL = "login.token.url";

	/**
	 * The spring sec cook.
	 */
	String SPRING_SEC_COOK = "SPRING_SECURITY_REMEMBER_ME_COOKIE";

	/** Cookie. */
	String COOKIE = "Cookie";

	/**
	 * The spring sec session.
	 */
	String SPRING_SEC_SESSION = "JSESSIONID";

	/**
	 * The http cookie header.
	 */
	String HTTP_COOKIE_HEADER = "Cookie";

	/**
	 * The http set cookie header.
	 */
	String HTTP_SET_COOKIE_HEADER = "Set-Cookie";

	/**
	 * The auth er hand url.
	 */
	String AUTH_ER_HAND_URL = "token.authentication.error.handler.path";

	/**
	 * The token bypass url.
	 */
	String TOKEN_BYPASS_URL = "token.bypass.urls";

	/**
	 * The token logout path.
	 */
	String TOKEN_LOGOUT_PATH = "token.logout.path";

	/**
	 * The token login path.
	 */
	String TOKEN_LOGIN_PATH = "token.login.path";

	/**
	 * The token val url.
	 */
	String TOKEN_VAL_URL = "token.validation.url";

	/**
	 * The role code.
	 */
	String ROLE_CODE = "roleCode";

	/**
	 * The role.
	 */
	String ROLE = "role";

	/**
	 * The first login.
	 */
	String FIRST_LOGIN = "firstlogin";

	/**
	 * The user locked.
	 */
	String USER_LOCKED = "userLock";

	/**
	 * The user disabled.
	 */
	String USER_DISABLED = "userDisabled";

	/**
	 * The flag y.
	 */
	String FLAG_Y = "Y";

	/**
	 * The service code valid.
	 */
	String SERVICE_CODE_VALID = "serviceCodeValid";

	/**
	 * The flag n.
	 */
	String FLAG_N = "N";

	/**
	 * The token logout url.
	 */
	String TOKEN_LOGOUT_URL = "token.logout.url";

	/**
	 * The delimiter to email.
	 */
	String DELIMITER_TO_EMAIL = ",";

	/**
	 * The file not upload.
	 */
	String FILE_NOT_UPLOAD = "File Not Uploaded";

	/**
	 * The service order not found exception.
	 */
	String SERVICE_ORDER_NOT_FOUND_EXCEPTION = "Service Order Not Found";

	/**
	 * The service order not found for spcode.
	 */
	String SERVICE_ORDER_NOT_FOUND_FOR_SPCODE = "No service orders assign to ";

	/**
	 * The pdf file.
	 */
	String PDF_FILE = ".pdf";

	/**
	 * The date format for json.
	 */
	String DATE_FORMAT_FOR_JSON = "yyyy-MM-dd";

	/**
	 * The report generation errcode.
	 */
	String REPORT_GENERATION_ERRCODE = "Report generation Is Unsuccessful";

	/**
	 * The FIL e_ imag e1.
	 */
	String FILE_IMAGE1 = "file_image1";

	/**
	 * The FIL e_ imag e2.
	 */
	String FILE_IMAGE2 = "file_image2";

	/**
	 * The FIL e_ imag e3.
	 */
	String FILE_IMAGE3 = "file_image3";

	/**
	 * The logo.
	 */
	String LOGO = "LOGO";

	/**
	 * The service order.
	 */
	String SERVICE_ORDER = "SERVICE_ORDER";

	/**
	 * The call type.
	 */
	String CALL_TYPE = "CALL_TYPE";

	/**
	 * The job start time.
	 */
	String JOB_START_TIME = "JOB_START_TIME";

	/**
	 * The job finish time.
	 */
	String JOB_FINISH_TIME = "JOB_FINISH_TIME";

	/**
	 * The billable time.
	 */
	String BILLABLE_TIME = "BILLABLE_TIME";

	/**
	 * The status.
	 */
	String STATUS = "STATUS";

	/**
	 * The line items.
	 */
	String LINE_ITEMS = "LINE_ITEMS";

	/**
	 * The suburb.
	 */
	String SUBURB = "SUBURBS";

	/**
	 * The labour amount.
	 */
	String LABOUR_AMOUNT = "LABOUR_AMOUNT";

	/**
	 * The parts amount.
	 */
	String PARTS_AMOUNT = "PARTS_AMOUNT";

	/**
	 * The collected cash.
	 */
	String COLLECTED_CASH = "COLLECTED_CASH";

	/**
	 * The collected cheque.
	 */
	String COLLECTED_CHEQUE = "COLLECTED_CHEQUE";

	/**
	 * The collected card.
	 */
	String COLLECTED_CARD = "COLLECTED_CARD";

	/**
	 * The total collected.
	 */
	String TOTAL_COLLECTED = "TOTAL_COLLECTED";

	/**
	 * The relevant date.
	 */
	String RELEVANT_DATE = "RELEVANT_DATE";

	/**
	 * The tech no.
	 */
	String TECH_NO = "TECH_NO";

	/**
	 * The yes.
	 */
	String YES = "Yes";

	/**
	 * The no.
	 */
	String NO = "No";

	/**
	 * The date format for report.
	 */
	String DATE_FORMAT_FOR_REPORT = "dd/MM/yyyy";

	/**
	 * The tech name.
	 */
	String TECH_NAME = "tech_name";

	/**
	 * The invoice no.
	 */
	String INVOICE_NO = "invoice_no";

	/**
	 * The cust name.
	 */
	String CUST_NAME = "cust_name";

	/**
	 * The cust add add.
	 */
	String CUST_ADD_ADD = "cust_add_add";

	/**
	 * The cust add street.
	 */
	String CUST_ADD_STREET = "cust_add_street";

	/**
	 * The cust add suburb.
	 */
	String CUST_ADD_SUBURB = "cust_add_suburb";

	/**
	 * The cust add state.
	 */
	String CUST_ADD_STATE = "cust_add_state";

	/**
	 * The cust add code.
	 */
	String CUST_ADD_CODE = "cust_add_code";

	/**
	 * The cust phone.
	 */
	String CUST_PHONE = "cust_phone";

	/**
	 * The cust email.
	 */
	String CUST_EMAIL = "cust_email";

	/**
	 * The cust dop.
	 */
	String CUST_DOP = "cust_dop";

	/**
	 * The cust serialnumber.
	 */
	String CUST_SERIALNUMBER = "cust_serialNumber";

	/**
	 * The cust mode variant.
	 */
	String CUST_MODE_VARIANT = "cust_mode_variant";

	/**
	 * The cust pnc variant.
	 */
	String CUST_PNC_VARIANT = "cust_pnc_variant";

	/**
	 * The cust dof.
	 */
	String CUST_DOF = "cust_dof";

	/**
	 * The site photo damage.
	 */
	String SITE_PHOTO_DAMAGE = "site_photo_damage";

	/**
	 * The site pano view.
	 */
	String SITE_PANO_VIEW = "site_pano_view";

	/**
	 * The site adjacent.
	 */
	String SITE_ADJACENT = "site_adjacent";

	/**
	 * The site condition.
	 */
	String SITE_CONDITION = "site_condition";

	/**
	 * The site desc damage.
	 */
	String SITE_DESC_DAMAGE = "site_desc_damage";

	/**
	 * The site cause failure.
	 */
	String SITE_CAUSE_FAILURE = "site_cause_failure";

	/**
	 * The site appl user.
	 */
	String SITE_APPL_USER = "site_appl_user";

	/**
	 * The site prog set.
	 */
	String SITE_PROG_SET = "site_prog_set";

	/**
	 * The site changed over.
	 */
	String SITE_CHANGED_OVER = "site_changed_over";

	/**
	 * The site desc injury.
	 */
	String SITE_DESC_INJURY = "site_desc_injury";

	/**
	 * The logo air details.
	 */
	String LOGO_AIR_DETAILS = "logo";

	/**
	 * The field.
	 */
	String FIELD = "field";

	/**
	 * The file image sign.
	 */
	String FILE_IMAGE_SIGN = "file_image_Sign";

	/**
	 * The reports dir.
	 */
	String REPORTS_DIR = "REPORTS_DIR";

	/**
	 * The tech no airdetails.
	 */
	String TECH_NO_AIRDETAILS = "TECH_NO";

	/**
	 * The registered owner name.
	 */
	String REGISTERED_OWNER_NAME = "REGISTERED_OWNER_NAME";

	/**
	 * The registered owner address.
	 */
	String REGISTERED_OWNER_ADDRESS = "REGISTERED_OWNER_ADDRESS";

	/**
	 * The registered owner phone.
	 */
	String REGISTERED_OWNER_PHONE = "REGISTERED_OWNER_PHONE";

	/**
	 * The logo eod cart note.
	 */
	String LOGO_EOD_CART_NOTE = "LOGO";

	/**
	 * The list of report.
	 */
	String LIST_OF_REPORT = "LIST_OF_REPORT";

	/**
	 * The ssp no.
	 */
	String SSP_NO = "SSP_NO";

	/**
	 * The date of eod.
	 */
	String DATE_OF_EOD = "DATE_OF_EOD";

	/**
	 * The logo part qa.
	 */
	String LOGO_PART_QA = "LOGO";

	/**
	 * The service order part qa.
	 */
	String SERVICE_ORDER_PART_QA = "SERVICE_ORDER";

	/**
	 * The invoice no part qa.
	 */
	String INVOICE_NO_PART_QA = "INVOICE_NO";

	/**
	 * The tech no part qa.
	 */
	String TECH_NO_PART_QA = "TECH_NO";

	/**
	 * The customer address.
	 */
	String CUSTOMER_ADDRESS = "CUSTOMER_ADDRESS";

	/**
	 * The suburbs.
	 */
	String SUBURBS = "SUBURBS";

	/**
	 * The call type part qa.
	 */
	String CALL_TYPE_PART_QA = "CALL_TYPE";

	/**
	 * The reported fault.
	 */
	String REPORTED_FAULT = "REPORTED_FAULT";

	/**
	 * The serial no.
	 */
	String SERIAL_NO = "SERIAL_NO";

	/**
	 * The purchase date.
	 */
	String PURCHASE_DATE = "PURCHASE_DATE";

	/**
	 * The pnc.
	 */
	String PNC = "PNC";

	/**
	 * The job start time part qa.
	 */
	String JOB_START_TIME_PART_QA = "JOB_START_TIME";

	/**
	 * The job finish time part qa.
	 */
	String JOB_FINISH_TIME_PART_QA = "JOB_FINISH_TIME";

	/**
	 * The previous time part qa.
	 */
	String PREVIOUS_TIME_PART_QA = "PREVIOUS_TIME";

	/**
	 * The billable time part qa.
	 */
	String BILLABLE_TIME_PART_QA = "BILLABLE_TIME";

	/**
	 * The product component.
	 */
	String PRODUCT_COMPONENT = "PRODUCT_COMPONENT";

	/**
	 * The work performance.
	 */
	String WORK_PERFORMANCE = "WORK_PERFORMANCE";

	/**
	 * The model no.
	 */
	String MODEL_NO = "MODEL_NO";

	/**
	 * The list parts.
	 */
	String LIST_PARTS = "LIST_PARTS";

	/**
	 * The query ms queue.
	 */
	String QUERY_MS_QUEUE = "queue.mtd.ms";

	/**
	 * The mtd in queue.
	 */
	String MTD_IN_QUEUE = "queue.mtd.in";

	/**
	 * The audit queue.
	 */
	String AUDIT_QUEUE = "queue.audit";

	/**
	 * The notification type apns.
	 */
	String NOTIFICATION_TYPE_APNS = "APNS";

	/**
	 * The notification type gcm.
	 */
	String NOTIFICATION_TYPE_GCM = "GCM";

	/** The gcm name. */
	String GCM_NAME = "GCM";

	/** The apns name. */
	String APNS_NAME = "APNS";

	/**
	 * The error code.
	 */
	String ERROR_CODE = "ERROR_CODE";

	/**
	 * The sequenceserviceorderdto to sequenceserviceorder.
	 */
	String SEQUENCESERVICEORDERDTO_TO_SEQUENCESERVICEORDER = "sequenceServiceOrderDtoToSequenceServiceOrder";

	/**
	 * The partdto to partsindto.
	 */
	String PARTDTO_TO_PARTSINDTO = "partDtoToPartsInDto";

	/**
	 * The serviceorderdto to eodreportdetailsindto.
	 */
	String SERVICEORDERDTO_TO_EODREPORTDETAILSINDTO = "serviceOrderDtoToEODReportDetailsInDto";

	/**
	 * The serviceorderdto to eodreportheaderindto.
	 */
	String SERVICEORDERDTO_TO_EODREPORTHEADERINDTO = "serviceOrderDtoToEODReportHeaderInDto";

	/**
	 * The list of serviceorder.
	 */
	String LIST_OF_SERVICEORDER = "LIST_OF_SERVICEORDER";

	/**
	 * The blank.
	 */
	String BLANK = "";

	/**
	 * The serviceorder to jobsin.
	 */
	String SERVICEORDER_TO_JOBSIN = "serviceOrderToJobsIn";

	/**
	 * The date format for eod report details.
	 */
	String DATE_FORMAT_FOR_EOD_REPORT_DETAILS = "HH:mm";

	/**
	 * The date format for last update.
	 */
	String DATE_FORMAT_FOR_LAST_UPDATE = "yyyyMMdd";

	/**
	 * The Constant ELECTROLUX_BASE_URL.
	 */
	public final static String ELECTROLUX_BASE_URL = "electrolux.base.url";

	/**
	 * The Constant CLOUD_PROVISIONING_URL.
	 */
	public final static String CLOUD_PROVISIONING_URL = "cloud.provisioning.url";

	/**
	 * The Constant BLANK_STRING.
	 */
	public final static String BLANK_STRING = "";

	/**
	 * The Constant BLANK_STRING.
	 */
	public final static String GROUP_CODE = "groupcode";

	/** The Constant GROUP_CODE_SG. */
	public final static String GROUP_CODE_SG = "SG";

	/** The Constant GROUP_CODE_SG_VALUE. */
	public final static String GROUP_CODE_SG_VALUE = "002";

	/**
	 * The start end double quotes.
	 */
	String START_END_DOUBLE_QUOTES = "\"\"";

	/**
	 * The parts new check.
	 */
	String PARTS_NEW_CHECK = "NEW";

	/**
	 * The error sequence service not found.
	 */
	String ERROR_SEQUENCE_SERVICE_NOT_FOUND = "Sequence Service Order list is empty or null";

	/**
	 * The error service order not found.
	 */
	String ERROR_SERVICE_ORDER_NOT_FOUND = "Service Order list is empty or null";

	/**
	 * The round up decimal.
	 */
	int ROUND_UP_DECIMAL = 2;

	/**
	 * The sort pattern.
	 */
	String SORT_PATTERN = "sortPattern";

	/**
	 * The sort pattern value.
	 */
	String SORT_PATTERN_VALUE = "list";

	/**
	 * The is partial list.
	 */
	String IS_PARTIAL_LIST = "isPartialList";

	/**
	 * The is partial list value.
	 */
	String IS_PARTIAL_LIST_VALUE = "false";

	/**
	 * The checkbox.
	 */
	String CHECKBOX = "_chk";

	/**
	 * The first page number.
	 */
	int FIRST_PAGE_NUMBER = 0;

	/**
	 * The successmessage.
	 */
	String SUCCESSMESSAGE = "successmessage";

	/**
	 * The no data found messsage.
	 */
	String NO_DATA_FOUND_MESSSAGE = "noDataFoundmesssage";

	/**
	 * The errormessage.
	 */
	String ERRORMESSAGE = "errormessage";

	/**
	 * The enable success.
	 */
	String ENABLE_SUCCESS = "Sucessfully enabled users";

	/**
	 * The enable failed.
	 */
	String ENABLE_FAILED = "Enable users failed";

	/**
	 * The disable success.
	 */
	String DISABLE_SUCCESS = "Sucessfully disabled users";

	/**
	 * The disable failed.
	 */
	String DISABLE_FAILED = "Disable users failed";

	/**
	 * The add refmap success.
	 */
	String ADD_REFMAP_SUCCESS = "Sucessfully added RefMap";

	/**
	 * The add refmap failed.
	 */
	String ADD_REFMAP_FAILED = "Add RefMap failed";

	/**
	 * The add technical manual success.
	 */
	String ADD_TECHNICAL_MANUAL_SUCCESS = "Sucessfully added Technical Manual";

	/**
	 * The add technical manual success failed.
	 */
	String ADD_TECHNICAL_MANUAL_SUCCESS_FAILED = "Add Technical Manual failed";

	/**
	 * The edit refmap success.
	 */
	String EDIT_REFMAP_SUCCESS = "Sucessfully edited RefMap";

	/**
	 * The edit refmap failed.
	 */
	String EDIT_REFMAP_FAILED = "Edit RefMap failed";

	/**
	 * The edit technical manual success.
	 */
	String EDIT_TECHNICAL_MANUAL_SUCCESS = "Sucessfully edited Technical Manual";

	/**
	 * The edit technical manual success failed.
	 */
	String EDIT_TECHNICAL_MANUAL_SUCCESS_FAILED = "Edit Technical Manual failed";

	/**
	 * The Constant EDIT_REFMAP_VALIDATION_FAILED.
	 */
	public static final String EDIT_REFMAP_VALIDATION_FAILED = "Edit RefMap Validation failed";

	/**
	 * The delete refmap success.
	 */
	String DELETE_REFMAP_SUCCESS = "Sucessfully deleted RefMap";

	/**
	 * The delete refmap failed.
	 */
	String DELETE_REFMAP_FAILED = "Delete RefMap failed";

	/**
	 * The delete technical manual success.
	 */
	String DELETE_TECHNICAL_MANUAL_SUCCESS = "Sucessfully deleted Technical Manual";

	/**
	 * The delete technical manual failed.
	 */
	String DELETE_TECHNICAL_MANUAL_FAILED = "Delete Technical Manual failed";

	/**
	 * The sspo part report tech id.
	 */
	String SSPO_PART_REPORT_TECH_ID = "TECH_NO";

	/**
	 * The sspo part report date.
	 */
	String SSPO_PART_REPORT_DATE = "GENERATED_DATE";

	/**
	 * The sspo file name.
	 */
	String SSPO_FILE_NAME = "SSPO_CART_NOTE";

	/**
	 * The update notification message.
	 */
	String UPDATE_NOTIFICATION_MESSAGE = "Master data updated. Please sync master data.";

	/**
	 * The no data found.
	 */
	String NO_DATA_FOUND = "No data available to display";

	/**
	 * The false string.
	 */
	String FALSE_STRING = "FALSE";

	/**
	 * The true string.
	 */
	String TRUE_STRING = "true";

	/**
	 * The S o_ statu s_3.
	 */
	String SO_STATUS_3 = "3";

	/**
	 * The S o_ statu s_9.
	 */
	String SO_STATUS_9 = "9";

	/** The req status a. */
	String REQ_STATUS_A = "A";

	/** The req status r. */
	String REQ_STATUS_R = "R";

	/** The req status n. */
	String REQ_STATUS_N = "N";

	/**
	 * The login time.
	 */
	String LOGIN_TIME = "LOGIN_TIME";

	/**
	 * The login timeout.
	 */
	String LOGIN_TIMEOUT = "token.timeout.config";

	/**
	 * The enable link.
	 */
	String ENABLE_LINK = "/enableUserRest.htm";

	/**
	 * The user name.
	 */
	String USER_NAME = "username";

	/**
	 * The enable flag.
	 */
	String ENABLE_FLAG = "enable";

	/**
	 * The remember me on.
	 */
	String REMEMBER_ME_ON = "on";

	/**
	 * The service order notification message.
	 */
	String SERVICE_ORDER_NOTIFICATION_MESSAGE = "Service order allocated. ";

	/**
	 * The eodreportdetail in message type.
	 */
	String EODREPORTDETAIL_IN_MESSAGE_TYPE = "EODReportDetail_In";

	/**
	 * The file name seperator.
	 */
	String FILE_NAME_SEPERATOR = "_";

	/**
	 * The file name air.
	 */
	String FILE_NAME_AIR = "AIR_";

	/**
	 * The encoded image.
	 */
	String ENCODED_IMAGE = "encodedImage.jpg";

	/**
	 * The eod cart note.
	 */
	String EOD_CART_NOTE = "FACTORY_RETURN";

	/**
	 * The part qa report name.
	 */
	String PART_QA_REPORT_NAME = "PART_QA";

	/**
	 * The service order status finish.
	 */
	String SERVICE_ORDER_STATUS_FINISH = "8";

	/**
	 * The sspo report.
	 */
	String SSPO_REPORT = "SSPO";

	/**
	 * The eod factory cart note.
	 */
	String EOD_FACTORY_CART_NOTE = "EOD Factory Cart Note";

	/**
	 * The qa billable time.
	 */
	String QA_BILLABLE_TIME = "HH:mm";

	/**
	 * The default locale.
	 */
	String DEFAULT_LOCALE = "electrolux.mwp.locale";

	/**
	 * The default timezone.
	 */
	String DEFAULT_TIMEZONE = "electrolux.mwp.timezone";

	/**
	 * The false flag.
	 */
	String FALSE_FLAG = "false";

	/**
	 * The true flag.
	 */
	String TRUE_FLAG = "true";

	/**
	 * The invoice report name.
	 */
	String INVOICE_REPORT_NAME = "TAX_INVOICE";

	/**
	 * The print no.
	 */
	String PRINT_NO = "PRINT_NO";

	/**
	 * The visit no.
	 */
	String VISIT_NO = "VISIT_NO";

	/**
	 * The customer name.
	 */
	String CUSTOMER_NAME = "CUSTOMER_NAME";

	/**
	 * The booking date.
	 */
	String BOOKING_DATE = "BOOKING_DATE";

	/**
	 * The order no.
	 */
	String ORDER_NO = "ORDER_NO";

	/**
	 * The labour.
	 */
	String LABOUR = "LABOUR";

	/**
	 * The parts.
	 */
	String PARTS = "PARTS";

	/**
	 * The collected cash invoice.
	 */
	String COLLECTED_CASH_INVOICE = "COLLECTED_CASH";

	/**
	 * The less labour discount.
	 */
	String LESS_LABOUR_DISCOUNT = "LESS_LABOUR_DISCOUNT";

	/**
	 * The collected cards.
	 */
	String COLLECTED_CARDS = "COLLECTED_CARDS";

	/**
	 * The collected cheque invoice.
	 */
	String COLLECTED_CHEQUE_INVOICE = "COLLECTED_CHEQUE";

	/**
	 * The less parts discount.
	 */
	String LESS_PARTS_DISCOUNT = "LESS_PARTS_DISCOUNT";

	/**
	 * The total payable amount.
	 */
	String TOTAL_PAYABLE_AMOUNT = "TOTAL_PAYABLE_AMOUNT";

	/**
	 * The collected.
	 */
	String COLLECTED = "COLLECTED";

	/**
	 * The end of file.
	 */
	String END_OF_FILE = "eof";

	/**
	 * The file characters.
	 */
	String FILE_CHARACTERS = ";~";

	/**
	 * The report date format.
	 */
	String REPORT_DATE_FORMAT = "dd-MM-yyyy";

	/**
	 * The service order mobile tech id.
	 */
	String SERVICE_ORDER_MOBILE_TECH_ID = "TECH_NO";

	/**
	 * The service order mobile report date.
	 */
	String SERVICE_ORDER_MOBILE_REPORT_DATE = "Q_DATE";

	/**
	 * The service order mobile file.
	 */
	String SERVICE_ORDER_MOBILE_FILE = "SERVICE_ORDER_MOBILE_FILE";

	/**
	 * The electrical contract.
	 */
	String ELECTRICAL_CONTRACT = "ELECTRICAL_CONTRACT";

	/**
	 * The date format milli.
	 */
	String DATE_FORMAT_MILLI = "yyyyMMddHHmmssSSS";

	/**
	 * The air flag.
	 */
	String AIR_FLAG = "Completed";

	/**
	 * The xapikey.
	 */
	String XAPIKEY = "X-ApiKey";

	/**
	 * The xsignature.
	 */
	String XSIGNATURE = "X-Signature";

	/**
	 * The xtimestamp.
	 */
	String XTIMESTAMP = "X-Timestamp";

	/**
	 * The externalcompanyid.
	 */
	String EXTERNALCOMPANYID = "externalCompanyId";

	/**
	 * The externalmobileuserid.
	 */
	String EXTERNALMOBILEUSERID = "externalMobileUserId";

	/**
	 * The list of serviceorder scehdul.
	 */
	String LIST_OF_SERVICEORDER_SCEHDUL = "LIST_OF_REPORT";

	/**
	 * The post.
	 */
	String POST = "POST";

	/**
	 * The delete call.
	 */
	String DELETE_CALL = "DELETE";

	/**
	 * The data.
	 */
	String DATA = "data";

	/**
	 * The change password user name.
	 */
	String CHANGE_PASSWORD_USER_NAME = "userName";

	/**
	 * The current password.
	 */
	String CURRENT_PASSWORD = "currentPassword";

	/**
	 * The new password.
	 */
	String NEW_PASSWORD = "newPassword";

	/**
	 * The claim not found for engId.
	 */
	String CLAIM_NOT_FOUND_FOR_ENGID = "No claims assign to ";

	/**
	 * Requisition part details not found.
	 */
	String REQUISITION_PART_DETAILS_NOTFOUND = " Requisition Part Details not found";

	/**
	 * Requisition engineer id not found.
	 */
	String REQUSISITION_ENG_ID_NOTFOUND = " Requisition Engineer Id Not Found";

	/**
	 * The ALL.
	 */
	String ALL = "ALL";

	/** Current Date. */
	String CURRENT_DATE = "CurrentDate";

	/** Current Date. */
	String NOTIFICATION_TRUE = "true";

	/** The serviceorder format. */
	String SERVICEORDER_FORMAT = "SR";

	/** The simple date format. */
	String SIMPLE_DATE_FORMAT = "yyyyMMdd";

}
