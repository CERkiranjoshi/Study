/**
 * 
 */
package net.hul.dashboard.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @author a561065
 *
 */
@Entity
@Table(name="employee_role")
public class EmployeeRole {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "uid")
	private String uid;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "mail_id")
	private String mailId;
	
	@Column(name = "access_type")
	private String accessType;
	
	@Column(name = "access_zone")
	private String accessZone;
	
	@Column(name = "access_Factory")
	private Boolean accessFactory ;

	@Column(name = "access_PV")
	private Boolean accessPV;

	@Column(name = "access_Depot")
	private Boolean accessDepot;

	@Column(name = "access_SV")
	private Boolean accessSV;

	@Column(name = "access_RS_ColdRoom")
	private Boolean accessRSColdRoom;
	
	@Column(name = "access_RSV")
	private Boolean accessRSV;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}

	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	/**
	 * @return the accessType
	 */
	public String getAccessType() {
		return accessType;
	}

	/**
	 * @param accessType the accessType to set
	 */
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	/**
	 * @return the accessZone
	 */
	public String getAccessZone() {
		return accessZone;
	}

	/**
	 * @param accessZone the accessZone to set
	 */
	public void setAccessZone(String accessZone) {
		this.accessZone = accessZone;
	}

	/**
	 * @return the accessFactory
	 */
	public Boolean getAccessFactory() {
		return accessFactory;
	}

	/**
	 * @param accessFactory the accessFactory to set
	 */
	public void setAccessFactory(Boolean accessFactory) {
		this.accessFactory = accessFactory;
	}

	/**
	 * @return the accessPV
	 */
	public Boolean getAccessPV() {
		return accessPV;
	}

	/**
	 * @param accessPV the accessPV to set
	 */
	public void setAccessPV(Boolean accessPV) {
		this.accessPV = accessPV;
	}

	/**
	 * @return the accessDepot
	 */
	public Boolean getAccessDepot() {
		return accessDepot;
	}

	/**
	 * @param accessDepot the accessDepot to set
	 */
	public void setAccessDepot(Boolean accessDepot) {
		this.accessDepot = accessDepot;
	}

	/**
	 * @return the accessSV
	 */
	public Boolean getAccessSV() {
		return accessSV;
	}

	/**
	 * @param accessSV the accessSV to set
	 */
	public void setAccessSV(Boolean accessSV) {
		this.accessSV = accessSV;
	}

	/**
	 * @return the accessRSColdRoom
	 */
	public Boolean getAccessRSColdRoom() {
		return accessRSColdRoom;
	}

	/**
	 * @param accessRSColdRoom the accessRSColdRoom to set
	 */
	public void setAccessRSColdRoom(Boolean accessRSColdRoom) {
		this.accessRSColdRoom = accessRSColdRoom;
	}

	/**
	 * @return the accessRSV
	 */
	public Boolean getAccessRSV() {
		return accessRSV;
	}

	/**
	 * @param accessRSV the accessRSV to set
	 */
	public void setAccessRSV(Boolean accessRSV) {
		this.accessRSV = accessRSV;
	}

	
	

}
