package net.hul.dashboard.cloudprovisioning;

import java.io.Serializable;

/**
 * User Request
 * 
 * @author A561065
 * 
 */
public class UserRequest implements Serializable {

	private static final long serialVersionUID = -5749498198159869744L;
	private String username;
    private String password;
    private Boolean rememberMeToken;
    private String service;
    private String tenant;

    private String sessionId;
    private String springSecurityCookie;

    public Boolean getRememberMeToken() {
        return rememberMeToken;
    }

    public void setRememberMeToken(Boolean rememberMeToken) {
        this.rememberMeToken = rememberMeToken;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String SessionId) {
        this.sessionId = SessionId;
    }

    public String getSpringSecurityCookie() {
        return springSecurityCookie;
    }

    public void setSpringSecurityCookie(String springSecurityCookie) {
        this.springSecurityCookie = springSecurityCookie;
    }

    @Override
    public String toString() {
        return "UserRequest [username=" + username + ", password=******" + ", rememberMeToken=" + rememberMeToken
                + ", sessionId=" + sessionId + ", springSecurityCookie=" + springSecurityCookie + "]";
    }

	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}

	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}

	/**
	 * @return the tenant
	 */
	public String getTenant() {
		return tenant;
	}

	/**
	 * @param tenant the tenant to set
	 */
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}
}
