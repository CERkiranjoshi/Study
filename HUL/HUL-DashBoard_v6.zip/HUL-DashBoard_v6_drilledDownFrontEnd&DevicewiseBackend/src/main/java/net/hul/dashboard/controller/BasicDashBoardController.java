/**
 * 
 */
package net.hul.dashboard.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.activation.FileTypeMap;
import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.hul.dashboard.cloudprovisioning.CloudProvisioningClient;
import net.hul.dashboard.dto.FilterData;
import net.hul.dashboard.scheduler.MonthlyTrendDataScheduler;
import net.hul.dashboard.util.BaseController;
import net.hul.dashboard.util.CSVGenerator;
import net.hul.dashboard.util.DBConnector;
import net.hul.dashboard.util.HULConstant;
import net.hul.dashboard.util.HulUseCaseHandler;
import net.hul.dashboard.util.POIUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

/**
 * @author a561065
 *
 */
@Controller
public class BasicDashBoardController extends BaseController{

	@Autowired
	private CloudProvisioningClient cloudProvisioningClient;
	
	@Autowired
	private CSVGenerator csvGenerator;

	ObjectMapper objectMapper=new ObjectMapper();

	@Autowired
	private MonthlyTrendDataScheduler mon;
	
	//UAT export path
	//private String reportUploadDir = "C:\\apache-tomcat-7.0.59\\webapps\\huldashboard\\data\\hulreport\\";

	//prod export path
	private String reportUploadDir = "/home/data/hul/apache-tomcat-7.0.56/webapps/huldashboard/data/hulreport/";

	//local machine export path
	//private String reportUploadDir = "C:\\Users\\A603292\\Documents\\projects\\IOT\\HULDashBoardEnv\\";

	//UAT return path
	//private String reportReturnPath = "/huldashboard/data/hulreport/";

	//Prod return path
	private String reportReturnPath = "data/hulreport/";

	@Autowired
	private DBConnector dbConnector;

	@Autowired
	private HulUseCaseHandler hulUseCaseHandler;

	private static final Log LOGGER = LogFactory.getLog(BasicDashBoardController.class);

	@Autowired
	private LoginController loginController;
	/**
	 * This method is used to load the default (basic) jsp page 
	 * @param map
	 * @return main.jsp page
	 */
	@RequestMapping(value="/" , method = RequestMethod.GET)
	public String loginPage(ModelMap map) {
		map.addAttribute("name","HUL");
		return "main"; 
	}

	/**
	 * This method is hit when login page values are submitted
	 * @param hashMap
	 * @param map
	 * @param request
	 * @return success/failure based on authentication and authorization
	 */
	@RequestMapping(value="/submitLogin" , method = RequestMethod.POST)
	public @ResponseBody String submitLogin(@RequestBody HashMap<String,String> hashMap ,HttpServletRequest request) {
		HashMap<String,String> loginResponse = new HashMap<String, String>();
		String emailId= hashMap.get("emailId");
		String password= hashMap.get("password");

		System.out.println("emailId:"+emailId+" password:"+password);
		JSONObject jsonObject = new JSONObject();
		String status = HULConstant.FAILURE;
		//loginResponse = dbConnector.getRoleAndStatus(emailId,password);
		loginResponse = loginController.performLoginValidation(hashMap);
		if(StringUtils.equals(loginResponse.get(HULConstant.STATUS), HULConstant.SUCCESS)){
			status = HULConstant.SUCCESS;
			System.out.println("Values are set in session");
			setSessionValues(loginResponse,request);	
		}
		jsonObject.put(HULConstant.STATUS, status);
		jsonObject.put(HULConstant.MESSAGE, loginResponse.get(HULConstant.MESSAGE));
		return jsonObject.toString();
	}



	/**
	 * This method sets user's access values like AccessToZone,AccessToFactory,AccessToPV,AccessToDepot,AccessToSV,AccessToRSColdRoom,AccessToRSV in session
	 * @param hashMapResponse
	 * @param request
	 */
	private void setSessionValues(HashMap<String, String> hashMapResponse,HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.setAttribute(HULConstant.ACCESS_ZONE, hashMapResponse.get("accessZone"));
		session.setAttribute(HULConstant.ACCESS_FACTORY, hashMapResponse.get("accessFactory"));
		session.setAttribute(HULConstant.ACCESS_PV,hashMapResponse.get("accessPV"));
		session.setAttribute(HULConstant.ACCESS_DEPOT,hashMapResponse.get("accessDepot"));
		session.setAttribute(HULConstant.ACCESS_SV,hashMapResponse.get("accessSV"));
		session.setAttribute(HULConstant.ACCESS_RS_COLDROOM, hashMapResponse.get("accessRSColdRoom"));
		session.setAttribute(HULConstant.ACCESS_RSV, hashMapResponse.get("accessRSV"));	
	}

	/**
	 * This method is used to invalidate session created for user
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="/logoutSession" , method = RequestMethod.POST)
	public @ResponseBody void logoutSession(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Logout");
		request.getSession().invalidate();
	}

	/**
	 * This method is used to fetch the LHS dropdown values based on user-access (Access of Region and Cold chain type)
	 * @param request
	 * @param response
	 * @return list containing uLLevelList,regionsList,coldChainList,tablesJoinList
	 */
	@RequestMapping(value="/roleBasedDropDownData" , method = RequestMethod.POST)
	public @ResponseBody HashMap<String,Object>  roleBasedDropDown(HttpServletRequest request,HttpServletResponse response) {
		HashMap<String,Object> dropDownHashMap = new HashMap<String,Object>();
		HashMap<String,String> hashMap = new HashMap<String,String>();
		hashMap = getSessionValues(request, response);
		dropDownHashMap.put("uLLevelList", dbConnector.getULLevels());
		dropDownHashMap.put("regionsList", dbConnector.getRegions(hashMap));
		dropDownHashMap.put("coldChainList", dbConnector.getColdChainList(hashMap));
		dropDownHashMap.put("tablesJoinList", dbConnector.getTablesJoin(hashMap));
		return dropDownHashMap;
	}

	/**
	 * This method is used to user specific values which are set in session.
	 * The values set in session are AccessToZone,AccessToFactory,AccessToPV,AccessToDepot,AccessToSV,AccessToRSColdRoom,AccessToRSV
	 * @param request
	 * @param response
	 * @return values which are set in session
	 */
	public HashMap<String,String> getSessionValues(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		HashMap<String,String> hashMap = new HashMap<String,String>();
		hashMap.put(HULConstant.ACCESS_ZONE, (String) session.getAttribute(HULConstant.ACCESS_ZONE));
		hashMap.put(HULConstant.ACCESS_FACTORY, (String) session.getAttribute(HULConstant.ACCESS_FACTORY));
		hashMap.put(HULConstant.ACCESS_PV,(String) session.getAttribute(HULConstant.ACCESS_PV));
		hashMap.put(HULConstant.ACCESS_DEPOT,(String) session.getAttribute(HULConstant.ACCESS_DEPOT));
		hashMap.put(HULConstant.ACCESS_SV,(String) session.getAttribute(HULConstant.ACCESS_SV));
		hashMap.put(HULConstant.ACCESS_RS_COLDROOM, (String) session.getAttribute(HULConstant.ACCESS_RS_COLDROOM));
		hashMap.put(HULConstant.ACCESS_RSV, (String) session.getAttribute(HULConstant.ACCESS_RSV));
		System.out.println(dbConnector.fetchBranchTypeValuesFromHashMap(hashMap));
		return hashMap;
	}


	/**
	 * This method returns data required to display google charts which are present on RHS of index page.
	 * This method is called only when user clicks on apply-filters on data
	 * @param hashMapInput
	 * @param request
	 * @param response
	 * @return list of FilterData Objects which contains regionCode,branchType,locCode,deviceId,paramValue,branchName,locType,locSubType,districtName,txnTime values
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonGenerationException 
	 */
	@RequestMapping(value="/fetchChartValues", method=RequestMethod.POST)
	public @ResponseBody String fetchChartValues(@RequestBody String hashMapInputString,HttpServletRequest request,HttpServletResponse response) throws JsonGenerationException, JsonMappingException, IOException{
		LOGGER.info("------ Enterd into fetchChartValues method---------- ");
		LOGGER.info("Input JSON string :"+hashMapInputString);

		HashMap<String,String> hashMap = new HashMap<String,String>();
		HashMap<String,String> hashMapInput = new HashMap<String,String>();
		List<FilterData> filterData = new ArrayList<FilterData>();
		org.json.JSONObject inputJSON=null;

		//LOGGER.info("input map is :"+hashMapInputString);
		org.json.JSONObject inputStringJSON=new org.json.JSONObject(hashMapInputString);
		String type =  inputStringJSON.getString("type");
		//LOGGER.info("type :"+type);

		if(!StringUtils.equalsIgnoreCase(type,"monitor")){
			inputJSON = (org.json.JSONObject) inputStringJSON.get("temperature");
			//LOGGER.info("KJSON :"+inputJSON);
		}
		try {
			// convert JSON string to Map

			Set<String> keySet=inputStringJSON.keySet();

			for(String key:keySet) {
				if(!StringUtils.equalsIgnoreCase(key, "temperature") && !StringUtils.equalsIgnoreCase(key, "coldchain")) {
					hashMapInput.put(key, inputStringJSON.getString(key));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} 

		hashMap = getSessionValues(request, response); // Authorization values...
		hashMap.putAll(hashMapInput);
		//String test1 = objectMapper.writeValueAsString(hashMap);
		//LOGGER.info("our map is :"+test1);

		LOGGER.info("Going to hit DBconnector for DB fetching");
		filterData = dbConnector.getFilteredData(hashMap,HULConstant.FILTER);
		LOGGER.info("BAck to BAsicDashBoardController, fetched data JSON");

		if(StringUtils.equalsIgnoreCase(type, "regional")) {
			Map<String, Map<String, Map<String, Object>>> resultantMap =hulUseCaseHandler.getRegionalTrend(filterData, inputJSON);
			return objectMapper.writeValueAsString(resultantMap);
		} else if(StringUtils.equalsIgnoreCase(type, "monitor")) {
			Map<String, Double> indiaComplianceResponse=hulUseCaseHandler.getIndiaCompliance(filterData);
			return objectMapper.writeValueAsString(indiaComplianceResponse);
		} else if(StringUtils.equalsIgnoreCase(type, "temperature")) {
			return hulUseCaseHandler.getTemperatureTrend(filterData, inputJSON);
			//return objectMapper.writeValueAsString(result);
		} else if(StringUtils.equalsIgnoreCase(type, "compliance")) {
			Map<String,Map<String, Object>> panIndia=hulUseCaseHandler.getPanIndia(filterData, (org.json.JSONObject) inputStringJSON.get("coldchain"));
			return objectMapper.writeValueAsString(panIndia);
		}
		return null;
	}


	/**
	 * @author a602834 Krishna
	 * Map<String, Map<String, Map<String, Object>>>
	 */

	@RequestMapping(value="/fetchDefaultValues", method=RequestMethod.POST)
	public @ResponseBody String fetchDefaultValues(@RequestBody String tempArrayData,HttpServletRequest request,HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException{
		LOGGER.info("------ Enterd into fetchDefaultValues method---------- ");
		LOGGER.info("Input JSON string :"+tempArrayData);

		HashMap<String,String> hashMap = new HashMap<String,String>();
		hashMap = getSessionValues(request, response);
		List<FilterData> filterData = new ArrayList<FilterData>();

		LOGGER.info("Going to hit DBconnector for DB fetching");
		filterData = dbConnector.getFilteredData(hashMap, HULConstant.DEFAULT);
		LOGGER.info("BAck to BAsicDashBoardController, fetched data JSON");
		//JSONParser parser = new JSONParser();
		String type=null;
		org.json.JSONObject inputJSON=null;
		//Process input JSON
		try {

			inputJSON=new org.json.JSONObject(tempArrayData);
			type= inputJSON.getString("type");

		} catch (Exception e) {
			LOGGER.error("Error while converting "+e.getMessage()+" "+e);
		}

		/*try {

			JSONArray jsonArray = (JSONArray) parser.parse(new FileReader("C:\\Users\\A603292\\Documents\\projects\\IOT\\HULDashBoardEnv\\dummyJSON.json"));
			for (Object object : jsonArray) {
				JSONObject data = (JSONObject) object;
				FilterData filter=objectMapper.convertValue(data, FilterData.class);
				filterData.add(filter);
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in reading JSON file"+e.getMessage());
		}*/

		if(StringUtils.equalsIgnoreCase(type, "regional")) {
			Map<String, Map<String, Map<String, Object>>> resultantMap =hulUseCaseHandler.getRegionalTrend(filterData, (org.json.JSONObject) inputJSON.get("temperature"));
			return objectMapper.writeValueAsString(resultantMap);
		} else if(StringUtils.equalsIgnoreCase(type, "monitor")) {
			Map<String, Double> indiaComplianceResponse=hulUseCaseHandler.getIndiaCompliance(filterData);
			return objectMapper.writeValueAsString(indiaComplianceResponse);
		} else if(StringUtils.equalsIgnoreCase(type, "temperature")) {
			return hulUseCaseHandler.getTemperatureTrend(filterData, (org.json.JSONObject) inputJSON.get("temperature"));
			//return objectMapper.writeValueAsString(result);
		} else if(StringUtils.equalsIgnoreCase(type, "compliance")) {
			Map<String,Map<String, Object>> panIndia=hulUseCaseHandler.getPanIndia(filterData, (org.json.JSONObject) inputJSON.get("coldchain"));
			return objectMapper.writeValueAsString(panIndia);
		}
		return null;
	}

	/**
	 * This method is used to generate excel report for HUL compliance using POIUtils utility class
	 * It is called when Export Data is clicked on UI.
	 * 
	 * @author a603292 (Nirvantosh Mishra)
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(value = "/exportToExcel", method=RequestMethod.POST)
	public @ResponseBody String  exportReport(@RequestBody String hashMapInputString,HttpServletRequest request, HttpServletResponse response) throws IOException {
		LOGGER.info("Entering exportReport method");
		HashMap<String,String> hashMap = new HashMap<String,String>();
		HashMap<String,String> hashMapInput = new HashMap<String,String>();
		List<FilterData> filterData = new ArrayList<FilterData>();
		//LOGGER.info("going to create JSON from input string");
		org.json.JSONObject inputStringJSON=new org.json.JSONObject(hashMapInputString);
		//LOGGER.info("inputStringJSON:"+inputStringJSON);
		try {
			//convert JSON string to Map
			Set<String> keySet=inputStringJSON.keySet();
			for(String key:keySet) {
				if(!StringUtils.equalsIgnoreCase(key, "temperature") && !StringUtils.equalsIgnoreCase(key, "coldchain")) {
					hashMapInput.put(key, inputStringJSON.getString(key));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		//LOGGER.info("Going to get session values");
		hashMap = getSessionValues(request, response);
		//LOGGER.info("Got session values, Going to get filterData based on case");
		if(inputStringJSON.getString("isdefault").equalsIgnoreCase("true")){
			//LOGGER.info("its default case");
			filterData = dbConnector.getFilteredData(hashMap, HULConstant.DEFAULT);
			//LOGGER.info("its default case,filterdata: "+filterData);
		} else if(inputStringJSON.getString("isdefault").equalsIgnoreCase("false")){
			//LOGGER.info("its filter case");
			hashMap.putAll(hashMapInput);
			filterData = dbConnector.getFilteredData(hashMap, HULConstant.FILTER);
			//LOGGER.info("its filter case,filterdata: "+filterData);
		}
		/*JSONParser parser = new JSONParser();
		try {

			JSONArray jsonArray = (JSONArray) parser.parse(new FileReader("C:\\Users\\A603292\\Documents\\projects\\IOT\\HULDashBoardEnv\\dummyJSON.json"));
			for (Object object : jsonArray) {
				JSONObject data = (JSONObject) object;
				FilterData filter=objectMapper.convertValue(data, FilterData.class);
				filterData.add(filter);
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in reading JSON file"+e.getMessage());
		}*/
		
		LOGGER.info("Going to call report generator");

		// fetch data
		//POIUtils poiUtils = new POIUtils();
		//String filename = poiUtils.createComplianceCSV(reportUploadDir, filterData);
		String filename = csvGenerator.generateCSV(reportUploadDir,filterData);
		String pathArgument = reportReturnPath + filename;
		org.json.JSONObject filepathJSON=new org.json.JSONObject();
		filepathJSON.put("filepath", pathArgument);
		LOGGER.info(filepathJSON);
		Map<String,String> hashMapoutput = new HashMap<String, String>();

		try {
			// convert JSON string to Map
			Set<String> keySet=filepathJSON.keySet();
			for(String key:keySet) {
				hashMapoutput.put(key, filepathJSON.getString(key));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return objectMapper.writeValueAsString(hashMapoutput);
	}

	/**
	 * This method fetches values for drilling down data to city wise and then further device wise.
	 * It is called when a branchtype is selected to drill down.
	 * 
	 * @author a603292 (Nirvantosh Mishra)
	 * @param hashMapInputString for filter criteria, use case type and frontEnd rule criteria JSON
	 * @param request
	 * @param response
	 * @return JSON string
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	@RequestMapping(value="/fetchDrilledValues", method=RequestMethod.POST)
	public @ResponseBody String fetchDrilledValues(@RequestBody String hashMapInputString,HttpServletRequest request,HttpServletResponse response) throws JsonGenerationException, JsonMappingException, IOException{
		LOGGER.info("------ Enterd into fetchDrilledValues method---------- ");

		HashMap<String,String> hashMap = new HashMap<String,String>();
		HashMap<String,String> hashMapInput = new HashMap<String,String>();
		List<FilterData> filterData = new ArrayList<FilterData>();
		org.json.JSONObject inputJSON=null;
		//JSONParser parser = new JSONParser();

		org.json.JSONObject inputStringJSON=new org.json.JSONObject(hashMapInputString);
		inputJSON = (org.json.JSONObject) inputStringJSON.get("temperature");

		try {
			// convert JSON string to Map
			Set<String> keySet=inputStringJSON.keySet();
			for(String key:keySet) {
				if(!StringUtils.equalsIgnoreCase(key, "temperature") && !StringUtils.equalsIgnoreCase(key, "coldchain")) {
					hashMapInput.put(key, inputStringJSON.getString(key));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 

		hashMap = getSessionValues(request, response);
		hashMap.putAll(hashMapInput);

		filterData = dbConnector.getFilteredData(hashMap,HULConstant.FILTER);
		/*try {

			JSONArray jsonArray = (JSONArray) parser.parse(new FileReader("C:\\Users\\A603292\\Documents\\projects\\IOT\\HULDashBoardEnv\\dummyJSON.json"));
			for (Object object : jsonArray) {
				JSONObject data = (JSONObject) object;
				FilterData filter=objectMapper.convertValue(data, FilterData.class);
				filterData.add(filter);
			}

		} catch (ParseException e) {
			LOGGER.error("Exception in reading JSON file"+e.getMessage());
		}*/

		String resultantMap =hulUseCaseHandler.getDrilledValue(filterData, inputJSON);
		return resultantMap;

	}

	@RequestMapping(value="/fetchMonthlyTrend", method=RequestMethod.POST)
	public @ResponseBody String getMonthlyTrend(@RequestBody String tempArrayData,HttpServletRequest request,HttpServletResponse response) throws JsonParseException, JsonMappingException, IOException{

		LOGGER.info("------ Enterd into getMonthlyTrend method---------- ");
		LOGGER.info("Input JSON string :"+tempArrayData);

		HashMap<String,String> hashMap = new HashMap<String,String>();
		hashMap = getSessionValues(request, response);
		//filterData = dbConnector.getFilteredData(hashMap, HULConstant.DEFAULT);
		//JSONParser parser = new JSONParser();
		String type=null;
		org.json.JSONObject inputJSON=null;

		//Process input JSON
		try {
			inputJSON=new org.json.JSONObject(tempArrayData);
			type= inputJSON.getString("type");
		} catch (Exception e) {
			LOGGER.error("Error while converting "+e.getMessage()+" "+e);
		}

		if(StringUtils.equalsIgnoreCase(type, "monthlytrend")) {
			LOGGER.info("type if() match : "+type); 
			Map<String, Map<String, Map<String, Map<String, Object>>>> monthlyTrend=hulUseCaseHandler.generateMonthlyTrend();
			return objectMapper.writeValueAsString(monthlyTrend);
		}
		return null;
	}

}
