/**
 * 
 */
package net.hul.dashboard.util;

/**
 * @author a561065
 *
 */
public class HULConstant {
	
	public static final String VENDOR = "Vendor";
	public static final String COLD_ROOM = "ColdRoom";
	public static final String DEVICE_ID = "DeviceId";
	public static final String SPLIT_STRING = "--";
	public static final String ROLE ="ROLE";
	public static final String STATUS ="status";
	public static final String FAILURE = "failure";
	public static final String SUCCESS= "success";
	public static final String ACCESS_ZONE = "AccessToZone" ;
	public static final String ACCESS_FACTORY = "AccessToFactory";
	public static final String ACCESS_PV = "AccessToPV";
	public static final String ACCESS_DEPOT = "AccessToDepot" ;
	public static final String ACCESS_SV ="AccessToSV" ;
	public static final String ACCESS_RS_COLDROOM ="AccessToRSColdRoom" ;
	public static final String ACCESS_RSV = "AccessToRSV";
	public static final String PAN_INDIA = "Pan India";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String FROM_DATE = "fromDate";
	public static final String TO_DATE = "toDate";
	public static final String SELECTED_REGIONS = "selectedRegions";
	public static final String SELECTED_UI_LEVEL = "selectedUILevel";
	public static final String SELECTED_REGION = "selectedRegion";
	public static final String SELECTED_COLD_CHAIN = "selectedColdChain";
	public static final String SELECTED_CITY = "selectedCity";
	public static final String SELECTED_BRANCH_NAME = "selectedBranchName";
	public static final String SELECTED_VENDOR = "selectedVendor";
	public static final String SELECTED_COLD_ROOM = "selectedColdRoom";
	public static final String SELECTED_DEVICE_ID = "selectedDeviceID";
	public static final String SELECTED_FROM_DATE = "selectedFromDate";
	public static final String SELECTED_TO_DATE = "selectedToDate";
	public static final String DEFAULT = "default";
	public static final String FILTER = "filter";
	public static final String MESSAGE = "message";

}
