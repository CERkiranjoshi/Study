/**
 * 
 */
package net.hul.dashboard.dto;

import java.util.Date;

/**
 * @author a561065
 *
 */
public class Country {
	  
	 public String tenantId;
	 public String countryCode;
	 public String countryName;
	 //public String active;
	 //public String createdBy;
	 //public Date createdDate;
	 //public String modifiedBy;
	// public Date modifiedDate;
	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}
	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	 

}
