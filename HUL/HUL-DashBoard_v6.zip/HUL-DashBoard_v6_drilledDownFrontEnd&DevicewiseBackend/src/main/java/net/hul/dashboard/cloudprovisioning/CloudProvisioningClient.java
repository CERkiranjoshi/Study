/**
 * 
 */
package net.hul.dashboard.cloudprovisioning;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

/**
 * @author a561065
 *
 */
@Component
public class CloudProvisioningClient {
	
	@Autowired
    private RestClient restClient;

    @Value("${cloud.provisioning.url}")
    private String CLOUD_PROV_URL;

    @Value("${login.token.url}")
    private String LOGIN_URL;

    @Value("${token.logout.url}")
    private String LOGOUT_URL;

    @Value("${token.validation.url}")
    private String VALIDATION_URL;

    
    /**
     * authenticate with CP
     * 
     * @param userRequest
     * @return UserResponse
     */
    public UserResponse authenticateUser(UserRequest userRequest) {

        if (userRequest == null) {
            return null;
        }
        
        String inputString = "j_username=" + userRequest.getUsername() + "&j_password=" + userRequest.getPassword()
                + "&tenant=" + userRequest.getTenant() + "&serviceCode=" + userRequest.getService();

        if (userRequest.getRememberMeToken()) {
            inputString = inputString + "&_spring_security_remember_me=on";
        }

        System.out.println("LOGIN_URL : "+LOGIN_URL);
        System.out.println("inputString: "+inputString);
        
        UserResponse userResponse = new UserResponse();

        ResponseEntity<String> response = restClient.restExchange(LOGIN_URL, inputString, HttpMethod.POST, null,MediaType.APPLICATION_FORM_URLENCODED);
        userResponse.setHttpStatus(response.getStatusCode().value());
        userResponse.setCpResposeCode(CPResposeCode.SUCCESSFUL);
        if (response.getStatusCode() != HttpStatus.FOUND) {
            userResponse.setCpResposeCode(CPResposeCode.FAILED);
        }

        this.getCookies(response, userResponse);

        HttpHeaders httpHeaders = response.getHeaders();

        List<String> firstLogin = httpHeaders.get(CloudProvisioningConstants.FIRST_LOGIN);
        if (firstLogin != null && firstLogin.size() != 0) {
            if (StringUtils.equals(CloudProvisioningConstants.FLAG_Y, firstLogin.get(0))) {
                userResponse.setCpResposeCode(CPResposeCode.FIRST_LOGIN);
            }
        }

        List<String> userLocked = httpHeaders.get(CloudProvisioningConstants.USER_LOCKED);
        if (userLocked != null && userLocked.size() != 0) {
            if (StringUtils.equals(CloudProvisioningConstants.FLAG_Y, userLocked.get(0))) {
                userResponse.setCpResposeCode(CPResposeCode.USER_LOCKED);
            }
        }

        List<String> userDisabled = httpHeaders.get(CloudProvisioningConstants.USER_DISABLED);
        if (userDisabled != null && userDisabled.size() != 0) {
            if (StringUtils.equals(CloudProvisioningConstants.FLAG_Y, userDisabled.get(0))) {
                userResponse.setCpResposeCode(CPResposeCode.USER_DISABLED);
            }
        }

        List<String> serviceCodeValid = httpHeaders.get(CloudProvisioningConstants.SERVICE_CODE_VALID);
        if (serviceCodeValid != null && serviceCodeValid.size() != 0) {
            if (StringUtils.equals(CloudProvisioningConstants.FLAG_N, serviceCodeValid.get(0))) {
                userResponse.setCpResposeCode(CPResposeCode.SERVICE_CODE_INVALID);
            }
        }

        List<String> roles = httpHeaders.get(CloudProvisioningConstants.ROLE);
        if (roles != null && roles.size() != 0) {
            userResponse.setRoles(roles);
        }
       

        return userResponse;

    }

    /**
     * validation of token
     * 
     * @param userRequest
     * @return UserResponse
     */
    public UserResponse validateToken(UserResponse userResponse) {

        if (userResponse == null) {
            return null;
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(CloudProvisioningConstants.COOKIE,CloudProvisioningConstants.SPRING_SEC_COOK + "=" + userResponse.getSpringSecurityCookie());
        httpHeaders.add(CloudProvisioningConstants.COOKIE,CloudProvisioningConstants.SPRING_SEC_SESSION + "=" + userResponse.getSessionId());
        ResponseEntity<String> response = restClient.restExchange(VALIDATION_URL, null, HttpMethod.POST, httpHeaders,MediaType.APPLICATION_FORM_URLENCODED);
        userResponse.setHttpStatus(response.getStatusCode().value());
        this.getCookies(response, userResponse);
        return userResponse;
    }

    /**
     * logout
     * 
     * @param userRequest
     * @return UserResponse
     */
    public UserResponse logout(UserResponse userResponse) {

        HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.add(CloudProvisioningConstants.COOKIE,CloudProvisioningConstants.SPRING_SEC_COOK + "=" + userResponse.getSpringSecurityCookie());
        httpHeaders.add(CloudProvisioningConstants.COOKIE,CloudProvisioningConstants.SPRING_SEC_SESSION + "=" + userResponse.getSessionId());

        ResponseEntity<String> response = restClient.restExchange(LOGOUT_URL, null, HttpMethod.POST, httpHeaders,MediaType.APPLICATION_FORM_URLENCODED);
        userResponse.setHttpStatus(response.getStatusCode().value());

        userResponse.setCpResposeCode(CPResposeCode.SUCCESSFUL);
        if (response.getStatusCode() != HttpStatus.FOUND) {
            userResponse.setCpResposeCode(CPResposeCode.FAILED);
        }

        return userResponse;
    }

    private void getCookies(ResponseEntity<String> response, UserResponse userResponse) {

        List<String> setCookies = response.getHeaders().get(CloudProvisioningConstants.HTTP_SET_COOKIE_HEADER);
        if (setCookies != null) {
            String regex = null;
            for (String setCookie : setCookies) {

                if (setCookie.contains(CloudProvisioningConstants.SPRING_SEC_COOK)) {
                    regex = "(" + CloudProvisioningConstants.SPRING_SEC_COOK + "=)(.*?)(;.*)";
                } else if (setCookie.contains(CloudProvisioningConstants.SPRING_SEC_SESSION)) {
                    regex = "(" + CloudProvisioningConstants.SPRING_SEC_SESSION + "=)(.*?)(;.*)";
                }

                Pattern p = Pattern.compile(regex);
                Matcher m = p.matcher(setCookie);

                while (m.find()) {
                    if (setCookie.contains(CloudProvisioningConstants.SPRING_SEC_COOK)
                            && (!StringUtils.equals(m.group(2), "") && !StringUtils.equals(m.group(2), "\"\""))) {
                        userResponse.setSpringSecurityCookie(m.group(2));
                    } else if (setCookie.contains(CloudProvisioningConstants.SPRING_SEC_SESSION)
                            && (!StringUtils.equals(m.group(2), "") && !StringUtils.equals(m.group(2), "\"\""))) {
                        userResponse.setSessionId(m.group(2));
                    }
                }
            }
        }
    }
    
    
    
 

}
