/**
 * 
 */
package net.hul.dashboard.dto;

import java.util.Date;

/**
 * @author a561065
 *
 */
public class Region {

	private String regionCode;
	private String regionName;
	//private String tenantId;
	private String countryCode;
	//private String active;
	//private String createdBy;
	//private Date createdDate;
	//private String modifiedBy;
	//private Date modifiedDate;
	

	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}
	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}
	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}


	

}
