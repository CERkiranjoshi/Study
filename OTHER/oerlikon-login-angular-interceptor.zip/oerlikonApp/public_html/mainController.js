oerlikonApp.controller('MainController', function ($rootScope, $scope, $location) {
    $scope.logout = function () {
        $scope.$emit('event:logoutRequest');

    };

    $scope.login = function (credentials) {
    	
        $scope.$emit('event:loginRequest', credentials.email, credentials.password);
        
        //$location.path($rootScope.navigateTo);
    };
  
});