oerlikonApp.run(function ($rootScope, $http, $location, Base64Service, AuthenticationService, EmployeeService, localStorageService, editableOptions) {

    editableOptions.theme = 'bs3';
    $rootScope.requests401 = [];
    $rootScope.navigateTo = "/main";

    $rootScope.$on('$routeChangeSuccess', function (event, next, current) {
        $rootScope.userIsLoggedIn = localStorageService.get('userIsLoggedIn');
        if ($rootScope.userIsLoggedIn == 'Y') {
            $rootScope.user = localStorageService.get('localStorageUser');
            $rootScope.employee = localStorageService.get('localStorageEmployee');
        }

        if ($location.path().indexOf("/login") == -1) {
            $rootScope.navigateTo = $location.path();
        }

    });

    /**
     * Holds all the requests which failed due to 401 response.
     */
    $rootScope.$on('event:loginRequired', function () {
        $rootScope.requests401 = [];

        if ($location.path().indexOf("/login") == -1) {
            $rootScope.navigateTo = $location.path();
        }

        $location.path('/login');
        console.log("Login Required.");
    });


    /**
     * On 'event:loginConfirmed', resend all the 401 requests.
     */
    $rootScope.$on('event:loginConfirmed', function () {

        var i,
                requests = $rootScope.requests401,
                retry = function (req) {
                    $http(req.config).then(function (response) {
                        req.deferred.resolve(response);
                    });
                };

        for (i = 0; i < requests.length; i += 1) {
            retry(requests[i]);
        }

        $rootScope.requests401 = [];
        $rootScope.errors = [];
        $location.path($rootScope.navigateTo);
    });

    /**
     * On 'event:loginRequest' send credentials to the server.
     */
    $rootScope.$on('event:loginRequest', function (event, username, password) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + Base64Service.encode(username + ':' + password);
        AuthenticationService.login().then(
                function success() {
                    $rootScope.user = localStorageService.get('localStorageUser');
                    EmployeeService.getEmployeeByUsername($rootScope.user.username).then(
                            function success() {
                                $rootScope.employee = localStorageService.get('localStorageEmployee');
                                $rootScope.$broadcast('event:loginConfirmed');

                            }, function error() {
                        $rootScope.errors = [];
                        $rootScope.errors.push({code: "FETCH_EMPLOYEE_FAILED", message: "Employee is not valid"});
                        $location.path('/login');

                    });


                    $rootScope.userIsLoggedIn = 'Y';
                    localStorageService.set('userIsLoggedIn', $rootScope.userIsLoggedIn);


                },
                function error() {
                    $rootScope.errors = [];
                    $rootScope.errors.push({code: "LOGIN_FAILED", message: "Please enter valid user name and password"});
                    $location.path('/login');

                });
    });

    /**
     * On 'logoutRequest' invoke logout on the server.
     */
    $rootScope.$on('event:logoutRequest', function () {
        $http.defaults.headers.common['Authorization'] = null;

        AuthenticationService.logout().then(
                function success() {


                    $rootScope.user = localStorageService.get('localStorageUser');
                    localStorageService.remove('localStorageEmployee');
                    localStorageService.remove('userIsLoggedIn');
                    $rootScope.userIsLoggedIn = false;
                    $rootScope.employee = null;
                    $rootScope.user = null;
                    $rootScope.errors = [];
                    $location.path('/login');
                    $rootScope.navigateTo = "/main";

                },
                function error() {
                    $rootScope.errors = [];
                    $rootScope.errors.push({code: "LOGOUT_FAILED", message: "Oooooops something went wrong, please try again"});
                })
    });
});