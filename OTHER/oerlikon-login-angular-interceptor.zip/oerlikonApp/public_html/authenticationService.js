oerlikonApp.service('AuthenticationService', function ($http, $q, localStorageService) {
    this.login = function () {
    	
    	var d = $q.defer();

        $http.get('employees/authenticated')
            .success(function (user) {
                localStorageService.set('localStorageUser', user);
                ////console.log('user is__________________'+user);
                ////console.log('user is__________________'+user.username);
               // console.log('grantedAuths_______________'+user.grantedAuths);
                d.resolve();
            })
            .error(function () {
                d.reject();
            });

        return d.promise;
    };

    this.logout = function () {
        var d = $q.defer();

        $http.get('j_spring_security_logout')
            .success(function () {
            	localStorageService.remove('localStorageUser');

                d.resolve();
            })
            .error(function () {
                d.reject();
            });

        return d.promise;
    };
});
