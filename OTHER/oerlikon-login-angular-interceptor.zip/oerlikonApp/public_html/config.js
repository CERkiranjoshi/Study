oerlikonApp.config(['$routeProvider', '$httpProvider', 'localStorageServiceProvider', function ($routeProvider, $httpProvider, localStorageServiceProvider) {

        // ======= local storage configuration ========

        localStorageServiceProvider.prefix = 'example';

        // ======= router configuration =============

        $routeProvider
                .when('/main', {
                    controller: 'WelcomeController',
                    templateUrl: 'resources/views/main.html'
                })
                .when('/login', {
                    templateUrl: 'resources/views/login.html'
                })

                .when('/travelExpense/:employeeId/myTravelExpense', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpense.html'
                })


                .when('/travelExpenseRequests/:employeeId/:travelExpenseId', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpenseRequest.html'
                })


                .when('/travelExpenseRequest/:employeeId/TR', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpenseRequest.html'
                })

                .when('/travelExpense/:employeeId/:travelRequestId/TR', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpenseRequest.html'
                })

                .when('/:role/approveTravelExpenses/:approverId', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpenseApproval.html'
                })

                .when('/approveTravelExpense/:role/:approverId/:travelExpenseId', {
                    controller: 'TravelExpenseController',
                    templateUrl: 'resources/views/expense/travelExpenseApprovalForm.html'
                })






                //travel Request URL

                .when('/travelrequests/:employeeId/pendingTR', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequest.html'
                })

                .when('/travelrequests/:employeeId/approvedTR/"', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequest.html'
                })

                .when('/travelrequest/:baseLocationCode/:employeeId/TR/:travelRequestId', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequestForm.html'
                })
                .when('/travel/:employeeId/TR', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequestForm.html'
                })


                .when('/travel/singleApprove/:nextApproverId/:travelRequestId', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequestApprovalForm.html'
                })

                .when('/travel/:nextApproverId', {
                    controller: 'TravelRequestController',
                    templateUrl: 'resources/views/travel/travelRequestApproval.html'
                })


                .when('/missSwiperequest', {
                    controller: 'MissSwipeController',
                    templateUrl: 'resources/views/missedSwipe/missSwipeForm.html'
                })

                .when('/missSwipe/:employeeId/myMissSwipe', {
                    controller: 'MissSwipeController',
                    templateUrl: 'resources/views/missedSwipe/missSwipe.html'
                })

                .when('/missSwipe/:employeeId/:missSwipeId', {
                    controller: 'MissSwipeController',
                    templateUrl: 'resources/views/missedSwipe/missSwipeForm.html'
                })

                .when('/missSwipe/:role/:employeeId/:missSwipeId/approver', {
                    controller: 'MissSwipeController',
                    templateUrl: 'resources/views/missedSwipe/missSwipeApprovalForm.html'
                })


                .when('/:role/missSwipes/approver/:nextApproverId', {
                    controller: 'MissSwipeController',
                    templateUrl: 'resources/views/missedSwipe/missSwipeApproval.html'
                })

                .when('/leaves/:employeeId/myleaves', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/myLeaves.html'
                })

                .when('/leaverequest', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaverequest.html'
                })

                .when('/leaves/leavedetails', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leavedetails.html'
                })

                .when('/attendance/hr', {
                    controller: 'AttendanceController',
                    templateUrl: 'resources/views/attendence/attendanceReport.html'
                })

                .when('/attendance/employee', {
                    controller: 'AttendanceController',
                    templateUrl: 'resources/views/attendence/attendanceReportForEmployee.html'
                })

                .when('/leaves/:employeeId/myleaves', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/myleaves.html'
                })

                .when('/leaverequest', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaveRequestForm.html'
                })

                .when('/leaverequest/:employeeId/:leaveRequestId', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaveRequestForm.html'
                })

                .when('/approveleave/:role/:approverId/:leaveRequestId', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaveApprovalForm.html'
                })

                .when('/:role/approveleaves/:approverId', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaveApproval.html'
                })

                .when('/leavereport', {
                    controller: 'LeaveController',
                    templateUrl: 'resources/views/leave/leaveReport.html'
                })

                .when('/leavecard', {
                    controller: 'EnquiryReportController',
                    templateUrl: 'resources/views/leave/leaveCard.html'
                })

                .when('/enquiryreport', {
                    controller: 'EnquiryReportController',
                    templateUrl: 'resources/views/leave/enquiryReport.html'
                })

                .when('/timesheet/:employeeId', {
                    controller: 'TimesheetController',
                    templateUrl: 'resources/views/timesheet/timesheetForm.html'
                })

                .when('/timesheet/:employeeId/:timesheetId', {
                    controller: 'TimesheetController',
                    templateUrl: 'resources/views/timesheet/timesheetForm.html'
                })

                .when('/timesheets/:employeeId', {
                    controller: 'TimesheetController',
                    templateUrl: 'resources/views/timesheet/timesheet.html'
                })

                .when('/timesheet/approve/:approverId/:timesheetId', {
                    controller: 'TimesheetController',
                    templateUrl: 'resources/views/timesheet/timesheetApprovalForm.html'
                })

                .when('/timesheets/approve/:approverId', {
                    controller: 'TimesheetController',
                    templateUrl: 'resources/views/timesheet/timesheetApproval.html'
                })

                .otherwise({redirectTo: "/login"});

    }]);

oerlikonApp.factory('authHttpResponseInterceptor', ['$q', '$location', function ($q, $location) {
        return {
            response: function (response) {
                if (response.status == 401) {
                    console.log("Response 401");
                    alert("Inside authHttpResponseInterceptor 401 error occured");
                }
                return response || $q.when(response);
            },
            responseError: function (rejection) {
                if (rejection.status == 401) {
                    console.log("Response Error 401", rejection);
                    $location.path('/login').search('returnTo', $location.path());
                }
                return $q.reject(rejection);
            }
        }
    }])
oerlikonApp.config(['$httpProvider', function ($httpProvider) {
        //Http Intercpetor to check auth failures for xhr requests
        $httpProvider.interceptors.push('authHttpResponseInterceptor');
    }]);

