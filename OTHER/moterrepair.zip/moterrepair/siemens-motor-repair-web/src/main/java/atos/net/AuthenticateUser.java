package atos.net;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthenticateUser {

	@RequestMapping(value="/getindex",method=RequestMethod.GET)
	  public ModelAndView getIndex(@RequestBody String role)
	  {
		System.out.println("calling get Index");
	    ModelAndView model=new ModelAndView("index");
	    model.addObject("usertype",role);
	    return model;
	  }
	
}
