siemensMotorRepairApp.config(['$routeProvider', function($routeProvider) {
   
	$routeProvider
	
		.when('/dashboard', {
			controller: 'motorRepairController',
			templateUrl: 'resources/template/common/views/dashboard.html'
		})
	
		.when('/ccc', {
			controller: 'headerController',
			templateUrl: 'resources/ccc/views/searchResult.html'
		})
		.when('/searchresult', {
			controller: 'headerController',
			templateUrl: 'resources/template/common/views/workflowStatusView.html'
		})
		.when('/repairService', {
			controller: 'TCSController',
			templateUrl: 'resources/ccc/views/repairServiceOrderClosure.html'
		})
		
		.when('/track-status/:trackId', {
			controller: 'TCSController',
			templateUrl: 'resources/trackCallStatus/views/trackCallStatus.html'
		})
		
		.when('/track-gsp-status/:trackId', {
			controller: 'TCSController',
			templateUrl: 'resources/trackCallStatus/views/customerTrackCallStatus.html',
			access: 'public'
		})
		
		.when('/arc/arcDispatchMotor', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/arcDispatchMotor.html'
			
		})
		.when('/arc/dashboard', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/arcDashBoard.html'
			
		})
		.when('/arc/dispatch-motor', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/dispatchMotor.html'
			
		})

		.when('/arc/dispatchMotorForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/arcDispatchMotor.html'
			
		})
		
		.when('/arc/receiveMotorWithGSPView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receiveMotorWithGSPView.html'
			
		})
		.when('/arc/receiveMotorWithGSPForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receivedMotorWithGSP.html'
			
		})
		
		.when('/arc/receiveMotorWithGSPView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receiveMotorWithGSPView.html'
			
		})
		//receive motor Without GSP Form
		.when('/arc/createNewJobReferenceForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receivedMotorWithoutGspRefForm.html'
			
		})
		//receive motor Without GSP View
		.when('/arc/createNewJobReferenceView', {
             controller: 'arcController',
             templateUrl: 'resources/arc/views/receivedMotorWithoutGSPview.html'
        })
        
		.when('/checkCustomerAvailability', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/checkCustomerAvailability.html'
			
		})
		
		//harshad
		.when('/arc/beginRepairsNConfirmSpares', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/beginRepairsNConfirmSpares.html'
			
		})
		//harshad
		.when('/arc/beginRepairsForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/beginRepairs.html'
			
		})
		//harshad
		.when('/arc/confirmSparesForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/confirmSpares.html'
			
		})
		
		//harshad
		.when('/arc/beginRepairsView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/beginRepairsView.html'
			
		})
		
		.when('/arc/Site-inspection', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/siteInspectionAndAReport.html'
		})
		
		.when('/arc/submitCReportForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/SubmitCReportForm.html'
		}).when('/arc/CReportForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/CReportForm.html'
		})
		
		.when('/arc/BnDReportSubmitForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/BnDReportSubmitForm.html'
		})
		
		.when('/arc/dispatchMotorForReplacementForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/dispatchMotorForReplacementForm.html'
			
		})
		
		//calls for arc Views
		.when('/arc/arcDispatchMotorView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/arcDispatchMotorView.html'
			
		}).when('/arc/SubmitCReportView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/SubmitCReportView.html'
		})
		.when('/arc/receivedMotorWithoutGspRefForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receivedMotorWithoutGspRefForm.html'
		})
		
		.when('/arc/receivedMotorWithoutGSP', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/receivedMotorWithoutGspRefForm.html'
		})
		.when('/arc/checkCustomerAvailabilityForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/CheckCustomerAvailabilityandVisitSiteForm.html'
		})
		
		.when('/arc/uploadSiteInspectionAndAReportsForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/SiteInspectionAndAReportUploadForm.html'
		})
		.when('/arc/BnDReportSubmitView', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/BnDReportSubmitView.html'
		})
		
		.when ('/arc/reviewBnDReportForReplacementForm', {
			controller: 'arcController',
			templateUrl: 'resources/arc/views/reviewBnDreportAndProcessForReplacementForm.html'
		})
		.otherwise({ redirectTo : "/dashboard"});
}]);

