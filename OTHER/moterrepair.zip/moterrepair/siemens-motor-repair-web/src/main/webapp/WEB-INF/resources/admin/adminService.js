siemensMotorRepairApp.service('adminService', function ($http,$q) {

	 this.getallFunctionSLAMaster = function(tenantID) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/getAllFunctionsSlaMasterByTenantId/'+ tenantID).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		this.getallEscalationData = function(tenantID) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/escalationHierarchyService/getAllEscalationHierarchyMaster').success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		this.getallFunctionName = function(tenantID) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/actorFunctionMasterService/getAllActorFunctionMasterByTenantId/'+ tenantID).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		this.getdeleteRecords = function(functionId) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/deleteFunctionsSlaMasterByfunctionSlaId/'+ functionId).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		this.getdeleteEscalationRecords = function(escalationHierarchyId) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/escalationHierarchyDataService/deleteEscalationHierarchyDataByEscalationHierarchyDataId/'+ escalationHierarchyId).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		
		this.getdeleteEscalationMasterDataRecord = function(escalationMasterId) {
			var d = $q.defer();
			$http
					.get('/task-mgmt-mwp/escalationHierarchyService/deleteEscalationHierarchyMasterByEscalationHierarchyId/'+ escalationMasterId).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		
		this.createupdateSLA = function(fuctionSlamaster) {
			var d = $q.defer();
			 $http.post('/task-mgmt-mwp/createUpdateFunctionsSlaMaster',fuctionSlamaster).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
		
		
		this.createupdateEscalation = function(escalationmaster) {
			var d = $q.defer();
			 $http.post('/task-mgmt-mwp/escalationHierarchyService/createUpdateEscalationHierarchyMaster',escalationmaster).success(
							function(response) {

								d.resolve(response);
							}).error(function(error) {
						//console.log(JSON.stringify(error));
						d.reject(error);
					});

			return d.promise;
		};
    
	
		this.getConfigDetailByTenantIdNSolCatId = function(tenatId,
				solCat) {
			
			var url = "/task-mgmt-mwp/configDetailService/getAllConfigDetailByTenantIdNSolnCatId/"
					+ tenatId + "/" + solCat;
		
			var d = $q.defer();
			$http.get(url).success(function(response) {
				var elementList = [];
				var dataType;

				angular.forEach(response, function(item) {
					dataType = item.cofigDataType;
					switch (dataType) {
					case 1:
						// pick from config_str_value
						elementList.push({
							"name" : item.configAlias,
							"value" : item.configStrVal,
							"configType" : item.configType,
							"configSubType" : item.configSubType,
							"configKey" : item.configKey,
							"dataType" : item.cofigDataType,
							"configId" : item.configId,
							"configDesc" : item.configDesc,
							"configEnabled" : item.configEnabled,
							"configEditable" : item.configEditable
						});
						break;
					case 2:
						// pick from config_int_value
						elementList.push({
							"name" : item.configAlias,
							"value" : item.configIntVal,
							"configType" : item.configType,
							"configSubType" : item.configSubType,
							"configKey" : item.configKey,
							"dataType" : item.cofigDataType,
							"configId" : item.configId,
							"configDesc" : item.configDesc,
							"configEnabled" : item.configEnabled,
							"configEditable" : item.configEditable
						});
						break;
					case 3:
						// pick from configDoubleVal
						elementList.push({
							"name" : item.configAlias,
							"value" : item.configDoubleVal,
							"configType" : item.configType,
							"configSubType" : item.configSubType,
							"configKey" : item.configKey,
							"dataType" : item.cofigDataType,
							"configId" : item.configId,
							"configDesc" : item.configDesc,
							"configEnabled" : item.configEnabled,
							"configEditable" : item.configEditable
						});
						break;
					case 4:
						// pick from configDateTimeVal
						elementList.push({
							"name" : item.configAlias,
							"value" : item.configDateTimeVal,
							"configType" : item.configType,
							"configSubType" : item.configSubType,
							"configKey" : item.configKey,
							"dataType" : item.cofigDataType,
							"configId" : item.configId,
							"configDesc" : item.configDesc,
							"configEnabled" : item.configEnabled,
							"configEditable" : item.configEditable
						});
						break;
					case 5:
						// pick from configBooleanValue
						elementList.push({
							"name" : item.configAlias,
							"value" : item.configBooleanValue,
							"configType" : item.configType,
							"configSubType" : item.configSubType,
							"configKey" : item.configKey,
							"dataType" : item.cofigDataType,
							"configId" : item.configId,
							"configDesc" : item.configDesc,
							"configEnabled" : item.configEnabled,
							"configEditable" : item.configEditable
						});
						break;
					default:
						// do nothing
					}
				});

			
				d.resolve(elementList);
			}).error(function(error) {

				d.reject(error);
			});

			return d.promise;
		};

		 this.saveConfigDetail = function (configDetailDTO) {
		        var d = $q.defer();
		        
		        $http.post('/task-mgmt-mwp/configDetailService/createUpdateConfigDetail',configDetailDTO)
		            .success(function (response) {
		                d.resolve(response);
		            })
		            .error(function (error) {
		                d.reject(error);
		            });

		        return d.promise;
		    };
	    this.getAllActorsCPRoleMapList = function (tenatId,solCat) {
	        var d = $q.defer();
	        $http.get('/task-mgmt-mwp/actorMasterService/getAllCPUnMappedRoles/'+ tenatId + "/" + solCat)
	            .success(function (response) {
	                d.resolve(response);
	            })
	            .error(function (error) {
	                d.reject(error);
	            });

	        return d.promise;
	    };
	    this.getAllActorsList = function (tenatId,solCat) {
	        var d = $q.defer();
	        $http.get('/task-mgmt-mwp/actorMasterService/getAllActorMastersByTenantIdNSolCatId/'+ tenatId + "/" + solCat)
	            .success(function (response) {
	                d.resolve(response);
	            })
	            .error(function (error) {
	                d.reject(error);
	            });

	        return d.promise;
	    };
	    this.updateCPRoleReferenceEmailId = function (data) {
	        var d = $q.defer();
	        $http.post('/task-mgmt-mwp/actorMasterService/updateCPRoleReferenceEmailId',data)
	            .success(function (response) {
	                d.resolve(response);
	            })
	            .error(function (error) {
	                d.reject(error);
	            });

	        return d.promise;
	    };
	    this.mapCPRoleReferenceTOActorId = function (data) {
	        var d = $q.defer();
	        $http.post('/task-mgmt-mwp/actorMasterService/mapCPRoleReferenceTOActorId',data)
	            .success(function (response) {
	                d.resolve(response);
	            })
	            .error(function (error) {
	                d.reject(error);
	            });

	        return d.promise;
	    };
	    this.refreshConfigDetails = function (tenantId,solCat) {
	        var d = $q.defer();
	        $http.get('/task-mgmt-mwp/configDetailService/refreshConfigDetails/'+tenantId+'/'+solCat)
	            .success(function (response) {
	                d.resolve(response);
	            })
	            .error(function (error) {
	                d.reject(error);
	            });

	        return d.promise;
	    };
});


