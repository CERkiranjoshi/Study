siemensMotorRepairApp
		.controller(
				'arcController',
				function($scope, $rootScope, arcService, motorRepairService, configParameter) {
					
					$scope.motor={};
					$scope.disableSiteReport=true;
					// harshad
					/*$scope.bReportField = {
						motorNamePlateDetail : {}
					};*/
					console.log('ARController');
					$scope.endCustomerDetailsArc={};
					$scope.ticketDetailsDTO={};
					$scope.taskDetailDTO={};
					$scope.active=1;
					$scope.motorAttachmentDetail = {};
					$scope.show = {};
					$scope.AttachmentFlag = new Boolean(false);
					//$scope.uploadedBy = $rootScope.user.userId;
					$scope.motorForm = {};
					$scope.endCustomer={};
					$scope.getBReportFlag=true;
					$scope.tab={};
					$scope.uploadFileTypes=[" ","pdf","jpg","xls","xlsx","doc","docx","txt","png","msg","zip","7z","jpeg","svg","PDF","JPG","XLS","XLSX","DOC","DOCX","TXT","PNG","MSG","zip","7z","JPEG","SVG"];
					$scope.newCommentsList=new Array();
					$scope.todayDate=new Date();
					$scope.motor.bReportTabDisable = true;
					$scope.motor.cReportTabDisable = true;
					$scope.motor.dReportTabDisable = true;
					$scope.motor.reportTabDisable=true;
					
					$scope.getBReportFieldsBySubProcessIdForMainForm = function() {
						
						if($scope.getBReportFlag){
							$scope.getBReportFlag=false;
							motorRepairService.getBReportFieldsBySubProcessId(
									$scope.subprocessFieldId).then(
									function success(response) {
										$scope.motor.bReportField = response;
										$scope.BReportID=$scope.motor.bReportField.bReportFieldId;
									
									}, function error(error) {
										$rootScope.errors = [];
					                      if (error != null) {
					                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                      } else {
					                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                      }  
									});
						}

					};

					$scope.getSubProcessFieldsByWlfwSubProcessId = function(Id) {
						arcService
								.getSubProcessFieldsByWlfwSubProcessId(Id)
								.then(
										function success(response) {
											console.log("success");
											$scope.taskDetailDTO = response;
											// console.log($scope.subProcessField.arcRefId);
											console.log(JSON
													.stringify(response));
											arcService
													.arcDetails(Id)
													.then(
															function success(
																	response) {
																$scope.arcDetail = response;

															});

											// fetch comments for subprocessID
											$scope
													.getCommentDetails($scope.subprocessId);

										}

										, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      }  
										});
					};

					$scope.receiveMotorWithoutGSP = function() {
						// $scope.services=arcService.services;
						$scope.subProcessField = {};
						$scope.subProcessField.masterWorkflowFields = {};

						$scope.subProcessField.masterWorkflowFields.customerDetails = [
								{
									custType : '1'

								}, {
									custType : '2'
								}, {
									custType : '3'
								}, {
									custType : '4'
								} ];
						// window.location = "#/receiveMotorWithoutGPS";

					};

					$scope.saveWithoutGSP = function(subProcessField) {

						arcService.save(subProcessField).then(
								function success(response) {

									console.log("success saved");
								}, function error(error) {
									
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      }  

								});
					};

					$scope.saveCheckCustomerDetails = function(subProcessField) {

						$scope.subProcessField.arcJobRefNo = subProcessField.arcJobRefNo;
						arcService.save($scope.subProcessField).then(
								function success(response) {

									//alert("success saved");
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 

								});
					};
					// Gautam
					$scope.loadNotifier = function(callback, value, from) {
						$scope.notifier({
							title : "Confirm Submit",
							notification : "Do you want to submit form ?",
							type : "confirm"
						}, function(resolve) {
							if (resolve) {
								callback(value, from);
							}
						});
					};
					// harsahd
					$scope.submitBeginRepairs = function(taskDetailDTO, from) {
						if ($scope.motorForm.$invalid) {
							$rootScope.invalidFormCheck();
							return false;
						}
						$scope.loadNotifier($scope.createNUpdateBeginRepairs,
								taskDetailDTO, from);
					};
					// harsahd
					$scope.createNUpdateBeginRepairs = function(taskDetailDTO,
							from) {
						$scope.commentsPush();
						angular
						.forEach(
								taskDetailDTO.subprocessFieldDTO.motorSparesDetails,
								function(motorSparesDetail) {
									
									motorSparesDetail.receivedByArcRefId= $rootScope.user.userId;

								});
						
						var subprocessField = {

							motorSparesDetails : taskDetailDTO.subprocessFieldDTO.motorSparesDetails,
							wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
							repairStatus :taskDetailDTO.subprocessFieldDTO.repairStatus
						};
						/*console.log(JSON.stringify("repaire Status:"+repairStatus));*/
						
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.subprocessFieldDTO = subprocessField;

						
						if (from == 'save') {
							$scope.updateTask($scope.updateTaskDTO);
						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);

						}
					};
					var funcScreenMap = [];

					funcScreenMap["ARC_UC_R2_031"] = "";
					funcScreenMap["ARC_UC_R2_032"] = "";
					funcScreenMap["ARC_UC_R1_033"] = {
						view : "#/arc/receiveMotorWithGSPView",
						form : "#/arc/receiveMotorViewForm",
						title : ""
					};
					funcScreenMap["ARC_UC_R1_034"] = "";
					funcScreenMap["ARC_UC_R1_035"] = {
						view : "#/arc/BnDReportSubmitForm",
						form : "#/arc/BnDReportSubmitForm",
						title : ""
					};
					funcScreenMap["ARC_UC_R1_036"] = {
						view : "#/arc/beginRepairsView",
						form : "#/arc/beginRepairs",
						title : ""
					};
					funcScreenMap["ARC_UC_R1_037"] = {
						view : "#/arc/SubmitCReportView",
						form : "#/arc/SubmitCReportForm",
						title : ""
					};
					funcScreenMap["ARC_UC_R1_038"] = {
						view : "#/arc/arcDispatchMotorView",
						form : "#/arc/arcDispatchMotor",
						title : ""

					};
					funcScreenMap["ARC_UC_R1_063"] = {
							//view : "#/arc/motorReceiptForReplacement",
							form : "#/arc/motorReceiptForReplacement",
							title : ""
					};
					funcScreenMap["ARC_UC_R1_064"] = {
							//view : "#/arc/motorReceiptForReplacement",
							form : "#/arc/dispatchMotorForReplacement",
							title : ""
					};

					/**
					 * *****************************on clicking view details
					 * button in task
					 * list********************************************
					 */
					$scope.viewTaskDetailsForm = function(functionCode, taskId) {
						$rootScope.taskId = taskId;
						$rootScope.functionCode = functionCode;
						window.location
								.assign(funcScreenMap[functionCode].form);

					};

					$scope.viewTaskDetails = function(functionCode, taskId) {
						$rootScope.taskId = taskId;
						$rootScope.functionCode = functionCode;
						window.location
								.assign(funcScreenMap[functionCode].view);
					};

					// Sonal
					$scope.initARCDashboard = function() {
						arcService
								.getActorMasterByActorId($rootScope.user.role,
										configParameter.tenantId,
										configParameter.programId,$rootScope.user.arcRefId)
								.then(
										function success(response) {
											var functionDATA={};
					angular.forEach(response.actorFunctionMaster, function(res) {
							functionDATA[res.functionCode]=res;
							if(res.defaultEnabled==1)
							{
								$scope.defaultSelectedFunction=res;
							}
						});
						console.log("FUNCTION DETAILS FETCHED:",JSON.stringify(functionDATA));
					$scope.userFunction=angular.copy(functionDATA);
											
											// //console.log(response.actorFunctionMaster);
											for (var i = 0; i < response.actorFunctionMaster.length; i++) {
												console
														.log(response.actorFunctionMaster[i].functionCode);

												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_030') {

													$scope.showArcDashBoard = response.actorFunctionMaster[i].functionCode;

												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R2_031') {

													$scope.showArcCheckCustomerAvailability = response.actorFunctionMaster[i].functionCode;
													$scope.arcCheckCustomerAvailabilityFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcCheckCustomerAvailabilityCount =	 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R2_031"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R2_032') {

													$scope.showArcSiteInspectionAndAReportUpload = response.actorFunctionMaster[i].functionCode;
													$scope.arcSiteInspectionAndAReportUploadFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcSiteInspectionAndAReportUploadCount
													 =
													 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R2_032"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_033') {

													$scope.showArcMotorRecievedWithGSPReference = response.actorFunctionMaster[i].functionCode;
													$scope.arcMotorRecievedWithGSPReferenceFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcMotorRecievedWithGSPReferenceCount =	 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_033"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_034') {

													$scope.showArcMotorRecievedWithoutGSPReference = response.actorFunctionMaster[i].functionCode;
													$scope.arcMotorRecievedWithoutGSPReferenceFunctionName = response.actorFunctionMaster[i].functionName;
												 $scope.arcMotorRecievedWithoutGSPReferenceCount =  response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_034"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_035') {

													$scope.showArcBeginInspectionSubmitBReportAndDReport = response.actorFunctionMaster[i].functionCode;
													$scope.arcBeginInspectionSubmitBReportAndDReportFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcBeginInspectionSubmitBReportAndDReportCount
													 =
													 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_035"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_036') {

													$scope.showArcBeginRepairs = response.actorFunctionMaster[i].functionCode;
													$scope.arcBeginRepairsFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcBeginRepairsCount
													 =
													 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_036"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_037') {

													$scope.showArcBeginRepairsAndSubmitCReport = response.actorFunctionMaster[i].functionCode;
													$scope.arcBeginRepairsAndSubmitCReportFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcBeginRepairsAndSubmitCReportCount
													 =
													 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_037"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}
												if (response.actorFunctionMaster[i].functionCode == 'ARC_UC_R1_038') {

													$scope.showArcDispatchMotor = response.actorFunctionMaster[i].functionCode;
													$scope.arcDispatchMotorFunctionName = response.actorFunctionMaster[i].functionName;
													 $scope.arcDispatchMotorCount
													 =
													 response.actorFunctionMaster[i].unassignedCount;
													funcScreenMap["ARC_UC_R1_038"]['title'] = response.actorFunctionMaster[i].displayTitle;
												}

											}
											
											if($rootScope.selectedFunction){
												
													$scope.getAlltasks($rootScope.selectedFunction);
											}
											else
											{
												
													$scope.getAlltasks($scope.defaultSelectedFunction);
											}

											
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});

						
					};

					
					//Rucha
					$scope.submitDispatchMotor = function(taskDetailDTO, from) {
						var dispatchType='';
						var dispatchedFrom='';
						var dispatchedTo='';
						if( $rootScope.user.type==2){
						    dispatchType=1;
							dispatchedFrom=1;
							dispatchedTo=3;
						}
						if( $rootScope.user.type==3){
							dispatchType=3;
							dispatchedFrom=3;
							dispatchedTo=2;
						}
						$scope.commentsPush();
						var dispatchDetail = {
								wlfwSubProcessId : $scope.subprocessFieldId,
								dispatchDate: $scope.motor.dispatchDate,
								docketNo : $scope.motor.docketNo,
								dispatchMode : $scope.motor.dispatchMode,
								transporterName: $scope.motor.transporterName,
								otherModeDetails: $scope.motor.otherModeDetails,
								docketDetail: $scope.motor.docketDetail,
								dispatchType: dispatchType,
								dispatchedFrom: dispatchedFrom,
								dispatchedTo: dispatchedTo,
								dispatchId:$scope.motor.dispatchId
						};
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						
						$scope.updateTaskDTO.subprocessFieldDTO.dispatchDetail=new Array();
						$scope.updateTaskDTO.subprocessFieldDTO.dispatchDetail.push(dispatchDetail);
						if (from == 'save') {
							$scope.updateTask($scope.updateTaskDTO);
						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);
						}
					};

					// Rucha
					$scope.CreateUpdateDispatchMotor = function(taskDetailDTO,
							from) {
						if ($scope.motorForm.$invalid) {
							return false;
						}
						$scope.loadNotifier($scope.submitDispatchMotor,
								taskDetailDTO, from);
					};

					$scope.datePicker = (function() {
						var method = {};
						method.instances = [];

						method.open = function($event, instance) {
							$event.preventDefault();
							$event.stopPropagation();

							method.instances[instance] = true;
						};

						method.options = {
							'show-weeks' : false,
							startingDay : 0
						};

						var formats = [ 'MM/dd/yyyy', 'dd-MMMM-yyyy',
								'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate' ];
						method.format = formats[0];

						return method;
					}());

					$scope.setDispatchMode = function(dispatchmode) {
						$scope.othersCommentBox = false;
						$scope.otherstransporterName = false;
						$scope.otherstransporterDocketNo = false;
						if (dispatchmode == 3) {
							$scope.otherstransporterName = true;
							$scope.otherstransporterDocketNo = true;
						}
						if (dispatchmode == 4) {
							$scope.othersCommentBox = true;
						}
					};

					$scope.getSubProcessFieldsByWlfwSubProcessId = function(Id) {
						motorRepairService
								.getSubProcessFieldsByWlfwSubProcessId(Id)
								.then(
										function success(response) {
											//alert("success");
											$scope.subProcessField = response;
											// alert($scope.subProcessField.arcRefId);
											console.log(JSON
													.stringify(response));
											motorRepairService
													.getARCMasterByArcId(
															$scope.subProcessField.arcRefId)
													.then(
															function success(
																	response) {
																$scope.arcDetail = response;
																// alert(JSON
																// .stringify($scope.arcDetail));
															});
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});
					};

					// Harshad
					$scope.getNotification = function(customer) {

						if (customer.notificationType == 1) {
							$scope.email = 1;
							$scope.sms = 0;

						} else if (customer.notificationType == 2) {
							$scope.email = 0;
							$scope.sms = 1;

						} else if (customer.notificationType == 3) {
							$scope.email = 1;
							$scope.sms = 1;
						}

					};

					// Sagar
					$scope.postData = function() {
						console.log(subProcessField);
						var subProcessField = {
							wlfwSubProcessId : 1,
							finalWarrantyState : $scope.subProcessField.finalWarrantyState,
							spiridonNtfnNo : $scope.subProcessField.spiridonNtfnNo,
							subWarrantyType : $scope.subProcessField.subWarrantyType,
							motorDispatchRoadPermitReq : $scope.subProcessField.motorDispatchRoadPermitReq
						};
						motorRepairService.postDataSub(subProcessField).then(
								function success(response) {
									//alert("success");
									// alert(JSON.stringify(response));

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					};
					/*$scope.getNetCost = function(list) {
						var total = 0;
						angular.forEach(list,
								function(item) {
									total = total + item.qty
											* item.materialRatePerUnit;
								});
						return total;
					};
					$scope.getNetCost1 = function(list) {
						var total = 0;
						angular.forEach(list, function(item) {
							total = total + item.qty * item.totalCost;
						});
						return total;
					};

*/

                    $scope.getNetCost1 = function(list) {
                            var total = 0;
                            angular.forEach(list, function(item) {
                                    total = total + item.qty * item.totalCost;
                            });
                            return total;
                    }

                    // Nitin
                    // calculate Net cost of motor SparesList Total Cost
                    $scope.getNetCost = function(list) {
                            console.log(JSON.stringify(list));
                            var total = 0;
                            angular.forEach(list,function(item) {
                                                    total = total + item.qty* item.materialRatePerUnit;
                                            });
                            return total;
                    }


					
					$scope.getMotorSalesDetailByTenantIdAndSolutionCategoryId = function() {

						motorRepairService
								.getMotorSalesDetailByTenantIdAndSolutionCategoryId(
										"SIEMENS", "1")
								.then(
										function success(response) {
											//alert("success");
											$scope.motorSales = response;
											console
													.log(
															"Motor Sales Dropdown Data :",
															JSON
																	.stringify(response));

										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});
					};

					motorRepairService.getARCRepairEstimates().then(
							function success(response) {
								$scope.ARCRepairEstimates = response;
							}, function error(error) {
								$rootScope.errors = [];
			                      if (error != null) {
			                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
			                      } else {
			                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
			                      } 
							});

					// ///config

					$scope.getConfigDetailByTypeNSubType = function(configType,
							configSubType, subscope) {

						if (typeof $scope[subscope] == 'undefined') {

							motorRepairService.getConfigDetailByTypeNSubType(
									configType, configSubType).then(
									function success(response) {
										$scope[subscope] = response;
									}, function error(error) {
										$rootScope.errors = [];
					                      if (error != null) {
					                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                      } else {
					                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                      } 
									});
						}
					};

					// update task keya

					$scope.updateTask = function(taskDetailDto) {
						console.log(taskDetailDto);
						console
								.log("==============================================calling update task===========================================================");
						motorRepairService
								.updateTask(taskDetailDto)
								.then(
										function success(taskUpdateResponse) {
											
											
											if(taskUpdateResponse)
												{
												$rootScope.taskId=taskUpdateResponse;
												$scope.fetchTaskDetails();
												
												}
											//alert("task updated");
											console
													.log("---------------------------updated tasl dto-------------------------------------------------");
											console.log(taskUpdateResponse);
																						
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});
					};

					// completeTAsk
					$scope.completeusertask = function(taskDetailDTO) {
						console
								.log("=============================================completeeee task===========================================================");
						console.log(taskDetailDTO);
						arcService.completeusertask(taskDetailDTO).then(
								function success(response) {
									console.log(JSON.stringify(response));
									$rootScope.notifyAlert({title: "Success ", notification: "Data Submited SuccessFully"});
									$scope.loadDashboard();

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});

					};
					// harshad
					$scope.fetchTaskDetails = function() {
						motorRepairService
								.getTaskDetailsByTaskId($rootScope.taskId)
								.then(
										function success(response) {
											$scope.taskDetailDTO=$scope.pushAdditionalContact(response);
											console
													.log("----------------------------task details fetched------------------------------------------------------------------");
											console.log(response);
											//$scope.taskDetailDTO = response;
											$scope.subprocessFieldId = $scope.taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId;
											$rootScope.functionName = $scope.taskDetailDTO.functionName;
											if($scope.taskDetailDTO.subprocessFieldDTO.arcRefId)
											{
												$scope
												.getARCMasterByArcId($scope.taskDetailDTO.subprocessFieldDTO.arcRefId);
											}
											
											$scope.getMotorAttachmentCount();
											//to disable reports tab if no data
											if($scope.taskDetailDTO.breportFieldDTO || $scope.taskDetailDTO.creportFieldDTO || $scope.taskDetailDTO.dreportFieldDTO){
												$scope.motor.reportTabDisable=false;
											}
											if ($scope.taskDetailDTO.breportFieldDTO) {
												$scope
														.getBReportFieldsBySubProcessIdForMainForm();
												$scope.motor.bReportTabDisable = false;
											}
											if ($scope.taskDetailDTO.creportFieldDTO) {
												$scope
														.getCReportFieldsBySubProcessID();
												$scope.motor.cReportTabDisable = false;
											}
											if ($scope.taskDetailDTO.dreportFieldDTO) {
												$scope
														.getDReportFieldsBySubProcessID();
												$scope.motor.dReportTabDisable = false;
											}
											// fetch comments for subprocessID
											
											//if($rootScope.user.type==3){
											if($scope.taskDetailDTO.arcType==configParameter.ArcPARAS){
												$scope.getCommentDetailsForPars($scope.subprocessFieldId);
											}else{
												$scope.getCommentDetails($scope.subprocessFieldId,$scope.user.arcRefId);
											}
											
											
											if($scope.taskDetailDTO.subprocessFieldDTO.dispatchDetail.length>0 && $scope.taskDetailDTO.subprocessFieldDTO.dispatchDetail!=null){
												$scope.setDispatchDetail($scope.taskDetailDTO.subprocessFieldDTO.dispatchDetail);
												
											}
											
											 if($scope.taskDetailDTO.comments == null ||$scope.taskDetailDTO.comments.length==0 || typeof $scope.taskDetailDTO.comments == 'undefined')
												 
						                    	{
							                    $scope.taskDetailDTO.comments=[];
						                    	$scope.taskDetailDTO.comments.push({commentType:1,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:2,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:3,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:4,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:5,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:6,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:7,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:8,comment_by_actor_id : $rootScope.user.userId},
						                    			{commentType:9,comment_by_actor_id : $rootScope.user.userId});
						                    			 
						                    	}
							                    else{
							                    	$scope.taskDetailDTO.comments.push({commentType:6,comment_by_actor_id : $rootScope.user.userId});
							                    }
						                    			 
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});

					}
					
					$scope.getAlltasks = function(selectedFunction) {
						
						
						$rootScope.selectedFunction = selectedFunction;
			
						$scope.$emit('event:storeFunction');
						

						var getTaskListObject = {
							tenantId : configParameter.tenantId,
							assignedToGroup : $rootScope.user.role,
							programId : configParameter.programId,
							functionCode : selectedFunction.functionCode,
							userId : $rootScope.user.arcRefId

						};
						/*console.log("Gett ALL TASK :");
						console.log(JSON.stringify(getTaskListObject));*/
						motorRepairService.getAlltasks(getTaskListObject).then(
								function success(response) {
									console.log("Response of Get all Task::::");
									console.log(response);
									$scope.response = response;

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					}

					$scope.claimTask = function() {
						/* TODO: Add userID from a root scope variable */
						// added arcRefId instead of username to filter out all
						// task for ARC center
						var userId = $rootScope.user.arcRefId;
						//alert($rootScope.taskId + " userId " + userId);
						motorRepairService
								.claimTask($rootScope.taskId, userId)
								.then(
										function success(response) {
											/*console
													.log("----------------------------task details fetched------------------------------------------------------------------");*/
										/*	console.log(response);*/
											$scope.subProcessField = response.subprocessFieldDTO;
											
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});

					}
					
					

					// Sagar
					$scope.postCReportFields = function(cReportField,
							motorSpeedDetailLoadTypeOne,
							motorSpeedDetailLoadTypeZero) {
					
							if(!cReportField){
								cReportField={};	
							}
						$scope.disableCReportSave=true;
						if ($scope.CReportID != 'undefined' || $scope.CReportID != null) {
							cReportField.motorCReportFieldId = $scope.CReportID;
						}
						cReportField.subProcessFields = {
							wlfwSubProcessId : $scope.subprocessFieldId,
						};
						if(cReportField.motorSpeedDetail){
							if(motorSpeedDetailLoadTypeOne){
								motorSpeedDetailLoadTypeOne.loadType = 1;
							}
							if(motorSpeedDetailLoadTypeZero){
								motorSpeedDetailLoadTypeZero.loadType = 0;
							}
							cReportField.motorSpeedDetail=[motorSpeedDetailLoadTypeOne,motorSpeedDetailLoadTypeZero];
						}else{
							if(motorSpeedDetailLoadTypeOne){
								motorSpeedDetailLoadTypeOne={
										 loadType : 1,
										 rAmp : motorSpeedDetailLoadTypeOne.rAmp,
										 yAmp : motorSpeedDetailLoadTypeOne.yAmp,
										 bAmp : motorSpeedDetailLoadTypeOne.bAmp,
										 rpm : motorSpeedDetailLoadTypeOne.rpm
								 };
								
							} 
							if(motorSpeedDetailLoadTypeZero){
								motorSpeedDetailLoadTypeZero={
										 loadType : 0,
										 rAmp : motorSpeedDetailLoadTypeZero.rAmp,
										 yAmp : motorSpeedDetailLoadTypeZero.yAmp,
										 bAmp : motorSpeedDetailLoadTypeZero.bAmp,
										 rpm : motorSpeedDetailLoadTypeZero.rpm
								 };
							}
							cReportField.motorSpeedDetail=[motorSpeedDetailLoadTypeOne,motorSpeedDetailLoadTypeZero];
						}

						arcService.postCReportFieldsDataSub(cReportField).then(
								function success(response) {
									// alert("success");
									// alert(JSON.stringify(response));
									$scope.motor.cReportField=response;
									$scope.CReportID = $scope.motor.cReportField.motorCReportFieldId;
									$scope.cReportFieldFlag = true;
									$scope.disableCReportSave=false;
									console.log($scope.motor.cReportField.motorSpeedDetail);
										angular
										.forEach(
												$scope.motor.cReportField.motorSpeedDetail,
												function(item) {
													// alert("forEach");
													if(item != null){
														if (item.loadType == 0) {
															$scope.motor.motorSpeedDetailLoadTypeZero = item;
														} else if (item.loadType == 1) {
															$scope.motor.motorSpeedDetailLoadTypeOne = item;

														}
													}
												});
										$rootScope.notifyAlert({title: "Success ", notification: "C Report Saved Successfully"});

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $scope.cReportFieldFlag = true;
				                    	  $scope.disableCReportSave=false;
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                    	  $scope.cReportFieldFlag = true;
				                    	  $scope.disableCReportSave=false;
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					};

					$scope.getCReportFieldsBySubProcessID = function() {
						motorRepairService
								.getCReportFieldsBySubProcessID(
										$scope.subprocessFieldId)
								.then(

										function success(response) {

											$scope.motor.cReportField = response;
											if(typeof $scope.motor.cReportField.motorCReportFieldId !='undefined'){
												$scope.CReportID=$scope.motor.cReportField.motorCReportFieldId;
												$scope.cReportFieldFlag = true;
											}
											$scope.disableCReportSave=false;
											if($scope.motor.cReportField)
											console
													.log(JSON
															.stringify($scope.motor.cReportField));


											if (($scope.motor.cReportField == "")
													|| (typeof $scope.motor.cReportField == 'undefined')) {

												$scope.motor.motorSpeedDetailLoadTypeZero;
												$scope.motor.motorSpeedDetailLoadTypeOne;

											} else {
												angular
														.forEach(
																$scope.motor.cReportField.motorSpeedDetail,
																function(item) {
																	// alert("forEach");
																	if (item.loadType == 0) {

																		$scope.motor.motorSpeedDetailLoadTypeZero = item;
																	} else if (item.loadType == 1) {
																		$scope.motor.motorSpeedDetailLoadTypeOne = item;

																	}
																});

											}

										
										},

										function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 

										});
					};

					// Sagar Comments function
					$scope.getCommentDetails = function(subprocessId, arcRefID) {
						//alert("in comment Details function");
						arcService
								.getCommentsByTenantIdNSolnCatNSubProcessIdNArcID(
										subprocessId, configParameter.tenantId,
										configParameter.programId, arcRefID)
								.then(

										function success(response) {

											// alert("success");

											$scope.commentsDetailsList = response;
											console.log("Comments Details ",
													JSON.stringify(response));
											if($scope.commentsDetailsList != null & $scope.commentsDetailsList.length > '0') {
												$scope.commmentText = $scope.commentsDetailsList[0].comment_text;
												$scope.functionName = $scope.commentsDetailsList[0].functionName;
												}
											console
													.log(JSON
															.stringify($scope.taskdetail));

										},

										function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 

										});
					};

					$scope.displayCommentDescription = function(commentsId) {
						/* $scope.selectedActor=commentByActor; */

						// alert(commentsId);
						/* alert(timestamp); */
						$scope.commmentText = "";
						$scope.functionName = "";
						angular
								.forEach(
										$scope.commentsDetailsList,
										function(comment) {

											if (comment.commentsId == commentsId) {
												$scope.commentsDetailsList.comment_text = comment.comment_text;
												$scope.commentsDetailsList.functionName=comment.functionName;

											}
										});

					};

					$scope.getSubProcessFieldsByWlfwSubProcessId = function(Id) {

						siemensMotorRepairApp
								.directive(
										'validSubmit',
										[
												'$parse',
												function($parse) {
													return {
														// we need a form
														// controller to be on
														// the same element as
														// this directive
														// in other words: this
														// directive can only be
														// used on a
														// &lt;form&gt;
														require : 'form',
														// one time action per
														// form
														link : function(scope,
																element,
																iAttrs,
																motorForm) {
															motorForm.$submitted = false;
															// get a hold of the
															// function that
															// handles
															// submission when
															// form is
															// valid
															var fn = $parse(iAttrs.validSubmit);

															/* $scope.getMotorSalesDetailByTenantIdAndSolutionCategoryId(); */

															// register DOM
															// event handler and
															// wire into
															// Angular's
															// lifecycle with
															// scope.$apply
															element
																	.on(
																			'submit',
																			function(
																					event) {
																				scope
																						.$apply(function() {
																							// on
																							// submit
																							// event,
																							// set
																							// submitted
																							// to
																							// true
																							// (like
																							// the
																							// previous
																							// trick)

																							motorForm.$submitted = true;
																							// if
																							// form
																							// is
																							// valid,
																							// execute
																							// the
																							// submission
																							// handler
																							// function
																							// and
																							// reset
																							// form
																							// submission
																							// state

																							if (motorForm.$valid) {
																								fn(
																										scope,
																										{
																											$event : event
																										});
																								motorForm.$submitted = false;
																							}
																						});
																			});
														}

													};
												} ]);

						motorRepairService
								.getSubProcessFieldsByWlfwSubProcessId(Id)
								.then(
										function success(response) {
											// alert("success");
											$scope.subProcessField = response;
											// alert($scope.subProcessField.arcRefId);
											// console.log(JSON.stringify(response));
											motorRepairService
													.getARCMasterByArcId(
															$scope.subProcessField.arcRefId)
													.then(
															function success(
																	response) {
																$scope.arcDetail = response;
																// alert(JSON.stringify($scope.arcDetail));
															});
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});
					};

					// harshad
					$scope.createUpdateBReportFields = function(bReportField) {
						if(!bReportField){
							return false;
						}
						
						$scope.disableBRportSave=true;
						if (typeof $scope.BReportID != 'undefined') {
							bReportField.bReportFieldId = $scope.BReportID;
						}
						bReportField.modifiedByRefId=$rootScope.user.userId;
						bReportField.subProcessFields = {
							wlfwSubProcessId : $scope.subprocessFieldId,
						};
						bReportField.functionCode=$rootScope.selectedFunction.functionCode;
						if(!bReportField.motorNamePlateDetail){
							bReportField.motorNamePlateDetail={};
						}
						bReportField.motorNamePlateDetail['frameSize'] = $scope.taskDetailDTO.subprocessFieldDTO.frameSize;
						
						angular.forEach($scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.customerDetails,function(customerDetail) {

							if(customerDetail.custType==1){
								bReportField.contactEmail=customerDetail.emailId;
								bReportField.contactNumber=customerDetail.mobileContactNum;
								bReportField.notificationNum=$scope.taskDetailDTO.subprocessFieldDTO.spiridonNtfnNo;
								bReportField.contactPersonName=customerDetail.customerName;
								bReportField.complaintDetail=$scope.taskDetailDTO.subprocessFieldDTO.faultDesc;
							}
						});
						
						console.log(bReportField);
						arcService.createUpdateBReportFields(bReportField)
								.then(function success(response) {
									$scope.motor.bReportField = angular.copy(response);
									$scope.BReportID=$scope.motor.bReportField.bReportFieldId;
									$scope.bReportFieldFlag = true;
									$scope.disableBRportSave=false;
									$rootScope.notifyAlert({title: "Success ", notification: "B Report Saved Successfully"});
									
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                    	  $scope.disableBRportSave=false;
				                    	  $scope.bReportFieldFlag = true;
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                        $scope.disableBRportSave=false;
				                        $scope.bReportFieldFlag = true;
				                      } 
								});

					};
					// harshad
					$scope.createUpdateDReportFields = function(dReportField) {
						
						if(!dReportField){
							return false;
						}
						$scope.disableDRportSave=true;
						if (typeof $scope.DReportID != 'undefined') {
							dReportField.motorDReportFieldId = $scope.DReportID;
						}
						dReportField.modifiedByRefId=$rootScope.user.userId;
						dReportField.subProcessFields = {
							wlfwSubProcessId : $scope.subprocessFieldId,
						};
						dReportField.functionCode=$rootScope.selectedFunction.functionCode;
						angular.forEach($scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.customerDetails,function(customerDetail) {

							if(customerDetail.custType==1){
								dReportField.notificationNum=$scope.taskDetailDTO.subprocessFieldDTO.spiridonNtfnNo;
							}
						});
						arcService.createUpdateDReportFields(dReportField)
								.then(
										function success(response) {
											
											$scope.motor.dReportField=response;
											$scope.DReportID = $scope.motor.dReportField.motorDReportFieldId;
											$scope.dReportFieldFlag = true;
											$scope.disableDRportSave=false;
											$rootScope.notifyAlert({title: "Success ", notification: "D Report Saved Successfully"});
										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                    	  $scope.disableDRportSave=false;
						                    	  $scope.dReportFieldFlag = true;
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                       	$scope.disableDRportSave=false;
						                        $scope.dReportFieldFlag = true;
						                      } 
										});
					};
					// harsahd
					$scope.submitBnDReports = function(taskDetailDTO, from) {
						if ($scope.motorForm.$invalid)
								 {
							$rootScope.invalidFormCheck();	
							return false;
						}
						$scope.loadNotifier($scope.createNUpdateBnD,
								taskDetailDTO, from);
					};
					// harshad
					$scope.createNUpdateBnD = function(taskDetailDTO, from) {
						
						$scope.commentsPush();
						
						angular.forEach($scope.arcRepairEstimateList,function(arcRepairEstimate) {

							if(!arcRepairEstimate.arcRepairEstimateId){
								arcRepairEstimate.createdByRefId=$rootScope.user.userId;
							}
							arcRepairEstimate.modifiedByRefId=$rootScope.user.userId;
						});
						
						var breportField = {
								totalEstimateCost : $scope.totalEstimateCost,
								arcRepairEstimateList : $scope.arcRepairEstimateList,
								arcSpareEstimateList : $scope.arcSpareEstimateList,
								bReportFieldId : $scope.BReportID,

								subProcessFields : {
									wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId
								}
							};
						console.log(breportField);
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.breportFieldDTO = breportField;

						
						if (from == 'save') {
							$scope.updateTask($scope.updateTaskDTO);
						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);

						}
					};
					// harshad
					$scope.getBReportFieldsBySubProcessId = function() {

						// for priority of function first call
						// getTaskDetailsByTaskId after
						// getBReportFieldsBySubProcessId
						motorRepairService
								.getTaskDetailsByTaskId($rootScope.taskId)
								.then(
										function success(response) {
											console
													.log("----------------------------task details fetched------------------------------------------------------------------");
											console.log(response);
											$scope.taskDetailDTO = $scope.setEmailsSms(response);
											$scope.subprocessFieldId = $scope.taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId;
											$scope
													.getARCMasterByArcId($scope.taskDetailDTO.subprocessFieldDTO.arcRefId);
											motorRepairService
													.getBReportFieldsBySubProcessId(
															$scope.subprocessFieldId)
													.then(
															function success(
																	response) {
																$scope.motor.bReportField = response;
																
																if(typeof $scope.motor.bReportField.bReportFieldId !='undefined'){
																	
																	$scope.bReportFieldFlag = true;
																}
																$scope.disableBRportSave=false;
																
																$scope.arcSpareEstimateList = $scope.motor.bReportField.arcSpareEstimateList;
																$scope.arcRepairEstimateList = $scope.motor.bReportField.arcRepairEstimateList;
																$scope.getCommentDetails($scope.subprocessFieldId,$scope.user.arcRefId);
																$scope
																		.getMotorAttachmentCount();
																$scope.getDReportFieldsBySubProcessID();
																//remove
																$scope
																.getCReportFieldsBySubProcessID();
																
																if($scope.taskDetailDTO.comments == null ||$scope.taskDetailDTO.comments.length==0 || typeof $scope.taskDetailDTO.comments == 'undefined')
																	 
										                    	{
											                    $scope.taskDetailDTO.comments=[];
										                    	$scope.taskDetailDTO.comments.push({commentType:1,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:2,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:3,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:4,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:5,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:6,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:7,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:8,comment_by_actor_id : $rootScope.user.userId},
										                    			{commentType:9,comment_by_actor_id : $rootScope.user.userId});
										                    			 
										                    	}
											                    else{
											                    	$scope.taskDetailDTO.comments.push({commentType:5,comment_by_actor_id : $rootScope.user.userId});
											                    }
															},
															function error(
																	error) {

															});

										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});
					};
					
					//harshad
					$scope.getDReportFieldsBySubProcessID = function() {
						motorRepairService.getDReportFieldsBySubProcessID(
								$scope.subprocessFieldId).then(
								function success(response) {
									$scope.motor.dReportField = response;
									console.log('dreportId  :'+$scope.motor.dReportField.motorDReportFieldId);
									if(typeof $scope.motor.dReportField.motorDReportFieldId !='undefined'){
										
										$scope.dReportFieldFlag = true;	
									}
									console.log('flag :'+$scope.dReportFieldFlag);
									$scope.DReportID=$scope.motor.dReportField.motorDReportFieldId;
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});

					};
					// harshad
					$scope.addArcSpareEstimateList = function() {

						if (typeof $scope.arcSpareEstimateList == 'undefined') {
							$scope.arcSpareEstimateList = new Array();
							$scope.arcSpareEstimateList.push({
								qty : 1
							});
						} else {
							$scope.arcSpareEstimateList.push({
								qty : 1
							});
						}
					};
					// harsahd
					$scope.addArcRepairEstimateList = function() {

						if (typeof $scope.arcRepairEstimateList == 'undefined') {
							$scope.arcRepairEstimateList = new Array();
							$scope.arcRepairEstimateList.push({
								qty : 1
							});
						} else {
							$scope.arcRepairEstimateList.push({
								qty : 1
							});
						}

					};
					// harshad
					$scope.removeRow = function(list, index) {
						list.splice(index, 1);

					};
					// harshad
					$scope.getTotalCost = function(list) {
						var total = 0;
						// console.log(list.length);
						angular.forEach(list, function(repairEstimate) {
							if (typeof repairEstimate.unitCost != 'undefined') {
								total = total + repairEstimate.unitCost;
							}
						});
						$scope.totalEstimateCost = total;
						return total;
					};
					
					// harshad
					/* upload file */
					$scope.uploadFile = function(attachmentType, description,
							picFile) {
						if (!picFile) 
						{
							return false;
						}else if(picFile.size==0){
							$rootScope.notifyAlert({title: "Error ", notification: "File is empty OR size is zero Bytes"});
							$scope.motor.picFile='';
						}
						else{
							
							var val = picFile.name;
				            var val1 = val.substring(val.indexOf(".") + 1);
				            var val2= val1.split(".")[1];
				             if(val2)
				            	 {
				            	 
				            	 if (val2.length > 0)
					            	{
				            		 $rootScope.notifyAlert({title: "Error ", notification: "Invalid filename"});
					            	$scope.motor.picFile='';
						            return false;
					            	}
				            	 }else{
							
						var dots = picFile.name.split(".")
						//get the part AFTER the LAST period.
						var fileType = "." + dots[dots.length-1];

						if(!($scope.uploadFileTypes.join(".").indexOf(fileType) != -1)){
							$rootScope.notifyAlert({title: "Error ", notification: "Invalid file Type"});
							$scope.motor.picFile='';
							return false;
						}
						if(picFile.name.length>80){
							$rootScope.notifyAlert({title: "Error ", notification: "File Name should be less than 80 character: So kindly rename and save it again"});
							$scope.motor.picFile='';
							return false;
						}
						var isInternal = 0;
						if($scope.taskDetailDTO.arcType==configParameter.ArcPARAS){
							isInternal=1;
						}
                        var methodCallValue=0;
						var formData = new FormData();
						formData.append("file", picFile);
						formData.append("description", description);// important:
						formData.append("uploadedBy", $rootScope.user.userId);// important:
						formData.append("attachmentType", attachmentType);
						formData.append("tenantId", configParameter.tenantId);// important:
						formData.append("solCatId", configParameter.programId);// important:
						formData.append("isInternal", isInternal);
						formData.append("methodCallValue", methodCallValue);
						if ((picFile.size / 1024 / 1024) < 3) {

							arcService
									.uploadFile($scope.subprocessFieldId,
											formData)
									.then(
											function success(response) {

												$scope.motorAttachmentDetails = response;
												$scope.motorAttachmentDetails
														.sort($scope.custom_sort);
												$scope.motorAttachmentCount = $scope.motorAttachmentDetails.length;
												$scope.motor.description='';
												$scope.motor.attachmentType='';
												$scope.motor.picFile='';
											}, function error(error) {
											});

						} else {
							$rootScope.notifyAlert({title: "Error ", notification: "File Size should be less than 3MB"});
							$scope.motor.picFile='';
						}
						}
					}
					};

					// harshad
					/* delete file */
					$scope.deleteFile = function(motorAttachmentsId, index) {
						// alert('delete start');
						$scope.deletedBy = $rootScope.user.userId;

						arcService.deleteFile(motorAttachmentsId,
								$scope.deletedBy).then(
								function success(response) {
									console.log(response);

									if($scope.taskDetailDTO.arcType==configParameter.ArcPARAS){
										angular
										.forEach(
												$scope.motorAttachmentDetails,
												function(
														motorAttachment) {
													if (motorAttachment.motorAttachmentsId == motorAttachmentsId) {

														motorAttachment.isDeleted = 1;
														$scope.motorAttachmentCount -= 1;
													}
												});
									}else{
										$scope.motorAttachmentDetails.splice(index,
												1);
										$scope.motorAttachmentCount=$scope.motorAttachmentDetails.length;
									}

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					};
					// harshad
					$scope.downloadFile = function(motorAttachmentsId) {

						//alert('download start');

						var downloadLink = document.createElement("a");

						document.body.appendChild(downloadLink);
						downloadLink.style = "display: none";

						arcService
								.downloadFile(motorAttachmentsId)
								.then(
										function success(result) {
											var disposition = result
													.headers('Content-Disposition')

											var fileName = disposition
													.substring(21,
															disposition.length);
											console.log(fileName);
											var file = new Blob(
													[ result.data ], {
														type : 'application/*'
													});
											var fileURL = (window.URL || window.webkitURL)
													.createObjectURL(file);

											// Blob, client side object created
											// to with holding browser specific
											// download popup, on the URL
											// created with the help of window
											// obj.

											downloadLink.href = fileURL;
											downloadLink.download = fileName;
											downloadLink.click();

										}, function error(error) {
											$rootScope.errors = [];
						                      if (error != null) {
						                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
						                      } else {
						                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
						                      } 
										});

					};
					// harshad
					$scope.custom_sort = function(a, b) {

						return new Date(a.uploadedOn).getTime()
								- new Date(b.uploadedOn).getTime();
					};
					// harsahd
					$scope.submitBeginRecieveMotorWithGSP = function(
							taskDetailDTO, from) {
						if ($scope.motorForm.$invalid) {
							$rootScope.invalidFormCheck();
							return false;
						}
						$scope.loadNotifier($scope.createNUpdateRecieveMotor,
								taskDetailDTO, from);
					};
					// harshad
					$scope.createNUpdateRecieveMotor = function(taskDetailDTO,
							from) {
						$scope.commentsPush();
						var arcMotorReceivedOn='';
						var arcMotorReceivedState='';
						if($scope.motor.checkbox1){
							arcMotorReceivedOn=new Date();
							arcMotorReceivedState=1;
						}else{
							arcMotorReceivedState=0;
						}
						var subprocessField = {
							wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
							arcJobRefNo : taskDetailDTO.subprocessFieldDTO.arcJobRefNo,
							arcMotorReceivedOn : arcMotorReceivedOn,
							arcMotorReceivedState:arcMotorReceivedState
						};

						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.subprocessFieldDTO = subprocessField;

						console.log("upadtetask"
								+ JSON.stringify($scope.updateTaskDTO));
						
						if (from == 'save') {
							$scope.updateTask($scope.updateTaskDTO);
						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							if($scope.updateTaskDTO.dispatchMotorToParas==1){
							$scope.updateTaskDTO.subprocessFieldDTO['replacement_status']=1;
							$scope.updateTaskDTO.subprocessFieldDTO['replacement_state_set_by_id']=$rootScope.user.userId;
							$scope.updateTaskDTO.subprocessFieldDTO['replacement_state_set_on']=new Date();
							};	
							$scope.completeusertask($scope.updateTaskDTO);

						}
					};
					// harsahd
					$scope.getAllMotorAttachmentDetailBySubprocesssId = function() {
						if ($scope.AttachmentFlag == false) {
							var external =true;
							if($scope.taskDetailDTO.arcType==configParameter.ArcPARAS){
								external=false;
							}
							$scope.AttachmentFlag = true;
							var uploadedBy = $rootScope.user.userId;

							motorRepairService
									.getAllMotorAttachmentDetailBySubprocesssId(
											$scope.subprocessFieldId, external,
											uploadedBy)
									.then(
											function success(response) {
												if(response){
													$scope.motorAttachmentDetails = response;
													$scope.motorAttachmentDetails
													.sort($scope.custom_sort);	
												}
											}, function error(error) {
												$rootScope.errors = [];
							                      if (error != null) {
							                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
							                      } else {
							                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
							                      } 
											});
						}
					};
					// harshad
					$scope.getMotorAttachmentCount = function() {
						var external =true;
						if($scope.taskDetailDTO.arcType==configParameter.ArcPARAS){
							external=false;
						}
						var uploadedBy=$rootScope.user.userId;
						var subprocessFieldId = $scope.subprocessFieldId;
						motorRepairService.getMotorAttachmentCount(
								subprocessFieldId, configParameter.tenantId,
								configParameter.programId, external,uploadedBy).then(
								function success(response) {
									$scope.motorAttachmentCount = response;
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});

					};
					// sagar
					// Validations for Submit C report
					$scope.submitCReportDetails = function(taskDetailDTO, from) {
						
						  //alert($scope.motorForm.$invalid); 
						  if ($scope.motorForm.$invalid) { 
							  $rootScope.invalidFormCheck();	
							  return false; 
							 }
						 
						$scope.loadNotifier($scope.postCReportDetails,
								taskDetailDTO, from);
					};

					// Submit C Report
					$scope.postCReportDetails = function(taskDetailDTO, from) {
						$scope.commentsPush();

						console.log("DATAAAAAAAA", JSON
								.stringify(taskDetailDTO));
						
						if (from == 'save') {

							$scope.updateTask(taskDetailDTO);

						} else {
							taskDetailDTO.assignee = $rootScope.user.userId;
							taskDetailDTO.checkAccept = configParameter.accept;
							$scope.completeusertask(taskDetailDTO);

						}

					};

					// get arc details
					$scope.getARCMasterByArcId = function(arcRefID) {
						motorRepairService.getARCMasterByArcId(arcRefID).then(
								function success(response) {
									console.log("ARC DEtails Fetched");
									$scope.arcDetail = response;

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});

					};
					
					
					// get ARCType details
					//Rucha
					$scope.getARCMasterDetailsByArcType = function() {
						arcService.getARCMasterByArcType(3).then(
								function success(response) {
									if(response){
										$scope.arcDetails=response[0];
									}
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					};
					// gautam rana
					$scope.loadDashboard = function() {
						window.location.assign("#/arc");

					};

					// Rucha
					$scope.getRegionMasterListByTenantId = function() {

						motorRepairService.getRegionMasterListByTenantId(
								configParameter.tenantId).then(
								function success(response) {
									console.log("success "
											+ JSON.stringify(response));

									$scope.regionList = response;
									console.log("Region Dropdown Data :", JSON
											.stringify($scope.regionList));

								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      } 
								});
					};
					// harshad
					$scope.commentPush = function(taskDetailDTO) {
						if (typeof taskDetailDTO.comment_text != 'undefined') {
							if (typeof taskDetailDTO.comments == 'undefined'
									|| taskDetailDTO.comments == null) {

								taskDetailDTO.comments = new Array();

							}
							taskDetailDTO.comments
									.push({
										added_by_ref_id : $rootScope.user.userId,
										batch_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.batchProcessId,
										comment_isActive : 1,
										comment_by_actor_id : $rootScope.user.userId,
										mast_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.masterWorkflowFieldId,
										reference_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.gspRefNo,
										//sub_process_id : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
										comment_text : taskDetailDTO.comment_text,
										commentType : 4,
										comment_timestamp : new Date(),
										//solution_category_id:configParameter.programId,
										//taskCode:taskDetailDTO.functionCode,
										//taskRefId:taskDetailDTO.taskId,	
										//taskDetailDTO.taskStatus,
										//tenant_id:configParameter.tenantId,
									});
							taskDetailDTO.comment_text=null;
						}
						return taskDetailDTO.comments;
					};

					// Rucha
					$scope.commentPushRecommendationToARC = function(
							taskDetailDTO) {
						if (typeof taskDetailDTO.rac_comment != 'undefined') {
							if (typeof taskDetailDTO.comments == 'undefined'
									|| taskDetailDTO.comments == null) {

								taskDetailDTO.comments = new Array();

							}
							taskDetailDTO.comments
									.push({
										added_by_ref_id : $rootScope.user.userId,
										batch_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.batchProcessId,
										comment_isActive : 1,
										comment_by_actor_id : $rootScope.user.userId,
										mast_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.masterWorkflowFieldId,
										reference_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.gspRefNo,
										sub_reference_id : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
										comment_text : taskDetailDTO.rac_comment,
										commentType : 4

									});
							taskDetailDTO.rac_comment=null;
						}
						return taskDetailDTO.comments;
					};

					// Sagar checkbox function
					$scope.customerTypeCheckForShipToParty = function(value,
							status) {
						$scope.endCustshipToParty = false;
						$scope.channelCustshipToParty = false;
						$scope.dealerCustshipToParty = false;

						$scope.endCustShipToAddress = false;
						$scope.channelShipToAddress = false;
						$scope.dealerCustShipToAddress = false;

						if (value == "end" && status == 1) {
							$scope.endCustshipToParty = false;
							$scope.channelCustshipToParty = true;
							$scope.dealerCustshipToParty = true;

							$scope.endCustShipToAddress = false;
							$scope.channelShipToAddress = true;
							$scope.dealerCustShipToAddress = true;

						}
						if (value == "chnl" && status == 1) {
							$scope.endCustshipToParty = true;
							$scope.channelCustshipToParty = false;
							$scope.dealerCustshipToParty = true;

							$scope.endCustShipToAddress = true;
							$scope.channelShipToAddress = false;
							$scope.dealerCustShipToAddress = true;
						}
						if (value == "deal" && status == 1) {
							$scope.endCustshipToParty = true;
							$scope.channelCustshipToParty = true;
							$scope.dealerCustshipToParty = false;

							$scope.endCustShipToAddress = true;
							$scope.channelShipToAddress = true;
							$scope.dealerCustShipToAddress = false;
						}

					};
					// harshad
					$scope.showLabel = function(list,value) {
						var selected = null;
						if(list!=undefined){
							angular.forEach(list, function(s) {
								if (s.value == value) {
									selected = s.name;
								}
							});
							return selected ? selected : "NO DATA";	
						}
					};

					$scope.change=function(value){
						
						$scope.active=value;
					};

					/*//harshad
					$scope.getWarrantysubtype=function(warantyTypeList){
						
						angular
						.forEach(
								warantyTypeList,
								function(item) {
									if(item.configKey=='IN_WARRANTY')
										{
											item.value=null;
											}
										
								});
						
						var subwarranty=$scope.showLabel(warantyTypeList,$scope.taskDetailDTO.subprocessFieldDTO.subWarrantyType);
						return subwarranty;
					};*/
					
					$scope.pushAdditionalContact=function(taskDetailDTO)
					{
						//alert("Set CONTACTS");
						var length=taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.additionalContactDetails.length;
						for(var i=length;i<3;i++)
							{
							//alert("contacts"+i);
							taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.additionalContactDetails.push({countryCode : '+91'});
							}
						taskDetailDTO=$scope.setEmailsSms(taskDetailDTO);
						return taskDetailDTO;
					};
					
					//gautam
					$scope.setEmailsSms=function(taskDetailDTO)
					{
						angular.forEach(taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.customerDetails, function(customer) {
						
							var binaryValue="00".substring((customer.notificationType >>> 0).toString(2))+(customer.notificationType >>> 0).toString(2);
							customer['notificationTypeEmail']=binaryValue.charAt(1);
							customer['notificationTypeSms']=binaryValue.charAt(0);
						});
						
						angular
						.forEach(
								taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.additionalContactDetails,
								function(additionalContactDetail) {

									var binaryValue = "00"
											.substring((additionalContactDetail.notificationType >>> 0)
													.toString(2))
											+ (additionalContactDetail.notificationType >>> 0)
													.toString(2);
									additionalContactDetail['notificationTypeEmail'] = binaryValue
											.charAt(1);
									additionalContactDetail['notificationTypeSms'] = binaryValue
											.charAt(0);
								});
					return taskDetailDTO;

					};
					
					
					
					
					
					// Rucha
					$scope.commentCustomer = function(
							taskDetailDTO) {
						if (typeof taskDetailDTO.rac_comment != 'undefined') {
							if (typeof taskDetailDTO.comments == 'undefined'
									|| taskDetailDTO.comments == null) {

								taskDetailDTO.comments = new Array();

							}
							taskDetailDTO.comments
									.push({
										added_by_ref_id : $rootScope.user.userId,
										batch_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.batchProcessId,
										comment_isActive : 1,
										comment_for_actor_id : taskDetailDTO.subprocessFieldDTO.arcRefId,
										comment_by_actor_id : $rootScope.user.userId,
										mast_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.masterWorkflowFieldId,
										reference_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.gspRefNo,
										sub_reference_id : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
										sub_process_id : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
										comment_text : taskDetailDTO.cus_comment,
										commentType : 8

									});
							taskDetailDTO.rac_comment=null;
						}
						return taskDetailDTO.comments;
					};
					
					
					
					
					
// get FSE details
					
					$scope.submitFSEDetails = function(taskDetailDTO, from) {
						
						  //alert($scope.motorForm.$invalid); 
						  if
						  ($scope.motorForm.$invalid) { return false; }
						 
						$scope.loadNotifier($scope.createandupdateFSEDetails,
								taskDetailDTO, from);
					};

				 
					$scope.createandupdateFSEDetails = function(taskDetailDTO, from) {
						$scope.commentsPush();
						 

						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						
						if (from == 'save') {

							$scope.updateTask($scope.updateTaskDTO);

						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);

						}

					};
					
					// harsahd
					$scope.createNUpdateDispatchMotorForReplacement = function(taskDetailDTO, from) {
						if ($scope.motorForm.$invalid)
								 {
							$rootScope.invalidFormCheck();		
							return false;
						}
						$scope.loadNotifier($scope.saveDispatchMotorForReplacement,
								taskDetailDTO, from);
					};
					// harshad
					$scope.saveDispatchMotorForReplacement = function(taskDetailDTO, from) {
						
						$scope.commentsPush();
						var dispatchDetail = {
								wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
								dispatchDate: $scope.motor.dispatchDate,
								docketNo : $scope.motor.docketNo,
								dispatchDate : $scope.motor.dispatchDate,
								dispatchMode : $scope.motor.dispatchMode,
								otherModeDetails: $scope.motor.otherModeDetails,
								transporterName: $scope.motor.transporterName,
								docketDetail: $scope.motor.docketDetail,
								dispatchType:1,
								dispatchedFrom: 1,
								dispatchedTo: 3
								
						};
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.subprocessFieldDTO.dispatchDetail.push(dispatchDetail);
						
						if (from == 'save') {
							$scope.updateTask($scope.updateTaskDTO);
						} else {
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);
						}
					};
					//harshad
					$scope.setDispatchDetail=function(dispatchDetails){
						var dispatchType='';
						if($rootScope.user.type==2){
							dispatchType=1;
						}else if($rootScope.user.type==3){
							dispatchType=3;
						}

						angular
						.forEach(
								dispatchDetails,
								function(dispatchDetail) {
									if(dispatchDetail.dispatchType == dispatchType){
										$scope.motor.dispatchId=dispatchDetail.dispatchId;
										$scope.motor.docketNo=dispatchDetail.docketNo;
										$scope.motor.dispatchDate=dispatchDetail.dispatchDate;
										$scope.motor.dispatchMode=dispatchDetail.dispatchMode;
										$scope.motor.transporterName=dispatchDetail.transporterName;
										$scope.motor.docketDetail=dispatchDetail.docketDetail;
										$scope.motor.otherModeDetails=dispatchDetail.otherModeDetails;
									}
								});
					};
					// harsahd
					//getTicketDetailById
					$scope.getTicketDetailById=function(){
						if($rootScope.taskId == 'undefined' || $rootScope.taskId == null){
                            return false;
                    }
						motorRepairService.getTicketDetailById(
								$rootScope.taskId).then(
									function success(response) {
										$scope.ticketDetailsDTO = response;
										console.log($scope.ticketDetailsDTO);
										 if ($scope.ticketDetailsDTO.motorDetailsArc.initialWarrantyClaim==1 || $scope.ticketDetailsDTO.motorDetailsArc.initialWarrantyClaim==0) {
												
												$scope
														.changeDropDown(
																'WARRANTY_TYPE',
																$scope.ticketDetailsDTO.motorDetailsArc.initialWarrantyClaim,
																'warantySubTypeList');
											}
									}, function error(error) {
										$rootScope.errors = [];
					                      if (error != null) {
					                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                      } else {
					                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                      }  
									});
					};
					// harsahd
					$scope.CreateUpdateReceiveMotorWithoutGSP = function(taskDetailDTO, from) {
						if ($scope.motorForm.$invalid)
								 {
							$rootScope.invalidFormCheck();
							return false;
						}
						$scope.loadNotifier($scope.saveTicketDetail,
								taskDetailDTO, from);
					};
					// harsahd
					//createUpdateTicketDetail
					$scope.saveTicketDetail=function(ticketDetailsDTO,from){
						if(from=='save'){
							ticketDetailsDTO.ticketStatus=0;
							if(!ticketDetailsDTO.ticketdetailsId){
								ticketDetailsDTO.createdBy=$rootScope.user.userId;
							}else{
								ticketDetailsDTO.modifiedBy=$rootScope.user.userId;
							}
						}else{
							ticketDetailsDTO.submittedBy=$rootScope.user.userId;
							ticketDetailsDTO.submittedOn=new Date();
							ticketDetailsDTO.ticketStatus=1;	
						}
						
						ticketDetailsDTO.refId=$rootScope.user.arcRefId;
						ticketDetailsDTO.solutionCategoryId=configParameter.programId;
						ticketDetailsDTO.tenantId=configParameter.tenantId;
						console.log(ticketDetailsDTO);
						motorRepairService.createUpdateTicketDetail(
								ticketDetailsDTO).then(
								function success(response) {
									$scope.ticketId=response;
									console.log($scope.ticketId);
									$scope.loadDashboard();
									
								}, function error(error) {
									$rootScope.errors = [];
				                      if (error != null) {
				                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
				                      } else {
				                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
				                      }  
								});
					};
					//getAllTicketDetails
					$scope.getAllTicketDetails=function(){
						arcService.getAllTicketDetails().then(
									function success(response) {
										$scope.ticketList = response;
                                        
									}, function error(error) {
										$rootScope.errors = [];
					                      if (error != null) {
					                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
					                      } else {
					                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
					                      }  
									});
					};
					
					// Nitin
					$scope.getAllActorsByTenantIdNSolCatId = function(tenantId, solutionCategoryId) 
					{
 					 motorRepairService.getAllActorsByTenantIdNSolCatId(
										configParameter.tenantId,
										configParameter.programId)					 
					.then(function success(response) 
					     {			
						
						   //console.log("=============Actor List==============");
						   //console.log(response);
						   $scope.actorList = [];
						   $scope.allactorList = response;
						   angular.forEach(response, function(value, key) 
						           {
						                 $scope.actorList.push(key);
						           });
						 },
						 function error(error) 
						 {
							$rootScope.errors = [];
							if (error != null) 
							{
								$rootScope.errors
								.push({
										    	code : error.exception,
										     message : error.exceptionMessage
									   });
							} else
							{
								$rootScope.errors
								.push({
											    code : "System Error",
										     message : "Oops Something went wrong . Please contact system administrator"
									   });
							}
						  });
					};

					
					// harshad
					$scope.changeDropDown = function(configType,
							finalWarrantyState, subscope) {
						motorRepairService
						.getConfigDetailByTypeNSubType('WARRANTY_TYPE',
								'WARRANTY')
						.then(
								function success(response) {
									$scope.warantyTypeList = response;
									angular
									.forEach(
											$scope.warantyTypeList,
											function(warantyType) {
												if (warantyType.value == finalWarrantyState) {

													motorRepairService
															.getConfigDetailByTypeNSubType(
																	configType,
																	warantyType.configKey)
															.then(
																	function success(
																			response) {
																		$scope[subscope] = response;
																	},
																	function error(
																			error) {
																		$rootScope.errors = [];
																		if (error != null) {
																			$rootScope.errors
																					.push({
																						code : error.exception,
																						message : error.exceptionMessage
																					});
																		} else {
																			$rootScope.errors
																					.push({
																						code : "System Error",
																						message : "Oops Something went wrong . Please contact system administrator"
																					});
																		}
																	});
												}
											});
								},
								function error(error) {
									$rootScope.errors = [];
									if (error != null) {
										$rootScope.errors
												.push({
													code : error.exception,
													message : error.exceptionMessage
												});
									} else {
										$rootScope.errors
												.push({
													code : "System Error",
													message : "Oops Something went wrong . Please contact system administrator"
												});
									}
								});
					};


					$scope.commentsPush=function()
					{
						$scope.newCommentsList=new Array();

						angular.forEach($scope.taskDetailDTO.comments,function(item)
								{
							if(item.comment_text)
								{
								$scope.newCommentsList.push({commentsId:item.commentsId,comment_text:item.comment_text,
									commentType:item.commentType,comment_by_actor_id : $rootScope.user.userId,comment_for_actor_id:$scope.user.arcRefId,
									mast_process_id : $scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.masterWorkflowFieldId,
									added_by_ref_id : $rootScope.user.userId,
									batch_process_id : $scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.batchProcessId,
									comment_isActive : 1,
									reference_id : $scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.gspRefNo,
									comment_timestamp : new Date(),
									sub_reference_id : $scope.taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId});
								 
								}
						 
								});
						 
						if($scope.newCommentsList.length>0)
						{
						$scope.taskDetailDTO.comments=angular.copy($scope.newCommentsList);
						}
					
						//$scope.newCommentsList=null;
						 
					};

					
					$scope.submitCheckcustomerAvail = function(taskDetailDTO, from) {
						
						//alert($scope.motorForm.$invalid); 
						  if
						  ($scope.motorForm.$invalid) { return false; }
						 
						$scope.loadNotifier($scope.createandupdateCheckcustomerAvail,
								taskDetailDTO, from);
					};

					 
					$scope.createandupdateCheckcustomerAvail = function(taskDetailDTO, from) {
						 
						$scope.commentsPush();
						 
						var subprocessField = {

								wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
								isCustAvailable:taskDetailDTO.subprocessFieldDTO.isCustAvailable,
								 
								fSEVisitDetails : taskDetailDTO.subprocessFieldDTO.fSEVisitDetails
                      };

                       	
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.subprocessFieldDTO = subprocessField;
						
						if (from == 'save') {

							$scope.updateTask($scope.updateTaskDTO);

						} else {
							angular
     						.forEach($scope.taskDetailDTO.subprocessFieldDTO.fSEVisitDetails,
     								function(fSEVisitDetail) {
     									
     									fSEVisitDetail.visitStatus='1';

     								});	
								
							
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);
							

						}

					};
					//harsahd
					$scope.checkValidationForDate=function(PreparedDate,ReviewedDate,value){
						if(!ReviewedDate){
							return false;
						}
						if(PreparedDate.toString()>ReviewedDate.toString() && value=='breport'){
							var date=new Date(PreparedDate);
							//date.setDate(PreparedDate.getDate() + 1);
							$scope.motor.bReportField.arcApprovedOn=date;
							return false;
						}
						if(PreparedDate.toString()>ReviewedDate.toString() && value=='dreport'){
							var date=new Date(PreparedDate);
						   //date.setDate(PreparedDate.getDate() + 1);
							$scope.motor.dReportField.arcApprovedOn=date;
							return false;
						}
					 if(PreparedDate.toString()>ReviewedDate.toString() && value=='creport'){
							var date=new Date(PreparedDate);
							//date.setDate(PreparedDate.getDate() + 1);
							$scope.motor.cReportField.arcApprovedOn=date;
							return false;
						}
					};
					
					//review B & D report & Process for replacement (Validation Check)
					$scope.submitReviewBndDReportAndProcessForReplacement = function(taskDetailDTO, from) {
						
						//alert($scope.motorForm.$invalid); 
						  if
						  ($scope.motorForm.$invalid) { return false; }
						 
						$scope.loadNotifier($scope.reviewBndDReportAndProcessForReplacement,
								taskDetailDTO, from);
					};
					
					//review B & D report & Process for replacement
					$scope.reviewBndDReportAndProcessForReplacement = function(taskDetailDTO, from) {
						 
						$scope.commentsPush();
                        
						
						
						var subprocessField = {

								wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
								replacement_status :taskDetailDTO.subprocessFieldDTO.replacement_status,
								replacement_state_set_by_id : $rootScope.user.userId,
								replacement_state_set_on : new Date()
                      };
						
						$scope.updateTaskDTO = angular.copy(taskDetailDTO);
						$scope.updateTaskDTO.subprocessFieldDTO = subprocessField;
						
						if (from == 'save') {

							$scope.updateTask($scope.updateTaskDTO);

						} else {
							
							$scope.updateTaskDTO.assignee = $rootScope.user.userId;
							$scope.updateTaskDTO.checkAccept = configParameter.accept;
							$scope.completeusertask($scope.updateTaskDTO);
							

						}

					};
					
					$scope.resetFields=function(dispatchMode){
						if(dispatchMode==4){
							$scope.motor.transporterName=null;
							$scope.motor.docketDetail=null;
						}
						if(dispatchMode==3){
							$scope.motor.otherModeDetails=null;
						}
						if(dispatchMode==2){
							$scope.motor.otherModeDetails=null;
							$scope.motor.transporterName=null;
							$scope.motor.docketDetail=null;
						}
						if(dispatchMode==1){
							$scope.motor.otherModeDetails=null;
							$scope.motor.transporterName=null;
							$scope.motor.docketDetail=null;
						}
					};
					
					$scope.getConfigDetailByVlaue = function(configType,configSubType, actualVal, subscope) 
					{
					   if (typeof $scope[subscope] == 'undefined') 
					   {
						motorRepairService.getConfigDetailByTypeNSubType(configType,configSubType)
								.then(function success(response) 
								{
									$scope[subscope] = response;
									angular.forEach($scope[subscope],function(item) 
									{
										if (item.value == actualVal) 
										{
										    $scope.configLabel = item.name;
										}
									});
								},
								function error(error) {
									$rootScope.errors = [];
									if (error != null) 
									{
										$rootScope.errors.push({
								   		code : error.exception,
										message : error.exceptionMessage
										});
									} else {
										$rootScope.errors.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
										});
									}
									});
					    }
				    };
					 
				    //for paras coments fetch method
				    $scope.getCommentDetailsForPars = function(subprocessId) {
						 
						motorRepairService
								.getCommentsBySubProcessIdNTenantIdNSolnCatID(
										subprocessId)
								.then(

										function success(response) {
											
											 
											console.log("success");

											$scope.commentsDetailsList = response;
											console.log("Comments Details ",
													JSON.stringify(response));
											
											if($scope.commentsDetailsList != null & $scope.commentsDetailsList.length > '0') {
											$scope.commmentText = $scope.commentsDetailsList[0].comment_text;
											$scope.functionName = $scope.commentsDetailsList[0].functionName;
											}
											console
													.log(JSON
															.stringify($scope.taskdetail));

										},

										function error(error) {
											$rootScope.errors = [];
											if (error != null) {
												$rootScope.errors
														.push({
															code : error.exception,
															message : error.exceptionMessage
														});
											} else {
												$rootScope.errors
														.push({
															code : "System Error",
															message : "Oops Something went wrong . Please contact system administrator"
														});
											}
										});
					};
				});
