siemensMotorRepairApp.controller('approverController',function($scope, $rootScope, approverService, motorRepairService, configParameter,saveTempObjectService) {
	
	$scope.motor={};
	console.log('ARController');
	$scope.endCustomerDetailsArc={};
	$scope.ticketDetailsDTO={};
	$scope.taskDetailDTO={};
	$scope.active=1;
	$scope.motorAttachmentDetail = {};
	$scope.show = {};
	$scope.AttachmentFlag = new Boolean(false);
	$scope.uploadedBy = $rootScope.user.userId;
	$scope.motorForm = {};
	$scope.endCustomer={};
	$scope.getBReportFlag=true;
	$scope.tab={};
	$scope.uploadFileTypes=[" ","pdf","jpg","xls","xlsx","doc","docx","txt","png","msg","zip","7z","jpeg","svg","PDF","JPG","XLS","XLSX","DOC","DOCX","TXT","PNG","MSG","zip","7z","JPEG","SVG"];
	$scope.newCommentsList=new Array();
	$scope.motor.bReportTabDisable = true;
	$scope.motor.cReportTabDisable = true;
	$scope.motor.dReportTabDisable = true;
	$scope.motor.reportTabDisable=true;
	
	$scope.getBReportFieldsBySubProcessIdForMainForm = function() {
		
		if($scope.getBReportFlag){
			$scope.getBReportFlag=false;
			motorRepairService.getBReportFieldsBySubProcessId(
					$scope.subprocessFieldId).then(
					function success(response) {
						$scope.motor.bReportField = response;
					
					}, function error(error) {
						$rootScope.errors = [];
	                      if (error != null) {
	                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
	                      } else {
	                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
	                      }  
					});
		}

	};
	
	// harshad
	$scope.fetchTaskDetails = function() {
		motorRepairService
				.getTaskDetailsByTaskId($rootScope.taskId)
				.then(
						function success(response) {
							$scope.taskDetailDTO=$scope.pushAdditionalContact(response);
							$scope.getAllActorsByTenantIdNSolCatId(response);
							console.log("----------------------------task details fetched------------------------------------------------------------------");
							console.log(response);
							$scope.subprocessFieldId = response.subprocessFieldDTO.wlfwSubProcessId;
							$rootScope.functionName = $scope.taskDetailDTO.functionName;							
							$scope.getMotorAttachmentCount();
							if($scope.taskDetailDTO.breportFieldDTO || $scope.taskDetailDTO.creportFieldDTO || $scope.taskDetailDTO.dreportFieldDTO){
								$scope.motor.reportTabDisable=false;
							}
							if ($scope.taskDetailDTO.breportFieldDTO) {
								$scope
										.getBReportFieldsBySubProcessId();
								$scope.motor.bReportTabDisable = false;
							}
							if ($scope.taskDetailDTO.creportFieldDTO) {
								$scope
										.getCReportFieldsBySubProcessID();
								$scope.motor.cReportTabDisable = false;
							}
							if ($scope.taskDetailDTO.dreportFieldDTO) {
								$scope
										.getDReportFieldsBySubProcessID();
								$scope.motor.dReportTabDisable = false;
							}
							$scope.getCommentDetails($scope.subprocessId);
							$scope.getApproverCommentDetails();
							 if($scope.taskDetailDTO.comments == null || $scope.taskDetailDTO.comments.length==0 || typeof $scope.taskDetailDTO.comments == 'undefined')
		                    	{
			                    $scope.taskDetailDTO.comments=[];
		                    	$scope.taskDetailDTO.comments.push({commentType:1,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:2,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:3,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:4,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:5,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:6,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:7,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:8,comment_by_actor_id : $rootScope.user.userId},
		                    			{commentType:9,comment_by_actor_id : $rootScope.user.userId});
		                    			 
		                    	}
			                    else{
			                    	$scope.taskDetailDTO.comments.push({commentType:5,comment_by_actor_id : $rootScope.user.userId});
			                    }
			                    
							 
							 if($scope.taskDetailDTO.assignedToGroup=='Approvers'){$scope.commentFilter=2;}else{$scope.commentFilter=5;};
								 
		                    			 
						}, function error(error) {
							$rootScope.errors = [];
		                      if (error != null) {
		                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
		                      } else {
		                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
		                      } 
						});

	}
	
	$scope.pushAdditionalContact=function(taskDetailDTO)
	{
		var length=taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.additionalContactDetails.length;
		for(var i=length;i<3;i++)
			{
			taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.additionalContactDetails.push({countryCode : '+91'});
			}
		taskDetailDTO=$scope.setEmailsSms(taskDetailDTO);
		return taskDetailDTO;
	};
	
	//gautam
	$scope.setEmailsSms=function(taskDetailDTO)
	{
		angular.forEach(taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.customerDetails, function(customer) {
		
			var binaryValue="00".substring((customer.notificationType >>> 0).toString(2))+(customer.notificationType >>> 0).toString(2);
			customer['notificationTypeEmail']=binaryValue.charAt(1);
			customer['notificationTypeSms']=binaryValue.charAt(0);
		});
		
		 
	return taskDetailDTO;

	};
	
	//harshad
	$scope.claimTask = function() {
		var userId = $rootScope.user.userId;
		motorRepairService
				.claimTask($rootScope.taskId, userId)
				.then(
						function success(response) {
							console.log("----------------------------task details fetched------------------------------------------------------------------");
							$scope.taskDetailDTO = response;
							console.log(JSON.stringify(response));
							$scope.loadDashboard();

							}, function error(error) {
			                $rootScope.errors = [];
		                      if (error != null) {
		                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
		                      } else {
		                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
		                      }   
						});

	};

	$scope.updateTask = function(taskDetailDto) {
		console.log("==============================================calling update task===========================================================");
		approverService
				.updateTask(taskDetailDto)
				.then(
						function success(taskUpdateResponse) {
							console.log("task updated");
							console.log("---------------------------updated tasl dto-------------------------------------------------");
							console.log(taskUpdateResponse);
						},
						function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});
	};
	// Sonal
	$scope.completeusertask = function(taskDetailDTO) {

		console
				.log("=============================================completeeee task===========================================================");
		console.log(taskDetailDTO);
		approverService
				.completeusertask(taskDetailDTO)
				.then(function success(response) {
							$scope.statusComplete = response.message;
							if ($scope.statusComplete == 'task_completed') {
								console.log('data submited');
								$scope.loadDashboard();
							} else {
								// alert('error');
							}
						},
						function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});

	};
	//harshad
	$scope.loadDashboard = function() {
		window.location.assign("#/dashboard");
	};
	
	// harshad
	$scope.getDReportFieldsBySubProcessID = function() {
		motorRepairService
				.getDReportFieldsBySubProcessID(
						$scope.subprocessId)
				.then(
						function success(response) {
							$scope.motor.dReportField = response;

							console
									.log("dreportField :"
											+ JSON
													.stringify($scope.motor.dReportField));

						},
						function error(error) {
							$rootScope.errors = [];
							if (error != null) {
								$rootScope.errors
										.push({
											code : error.exception,
											message : error.exceptionMessage
										});
							} else {
								$rootScope.errors
										.push({
											code : "System Error",
											message : "Oops Something went wrong . Please contact system administrator"
										});
							}
						});
	};
	
	// harsahd
	$scope.createNUpdatesubmitReceivePayment = function(taskDetailDTO, from) {
		if ($scope.motorForm.$invalid)
				 {
								
			return false;
		}
		$scope.loadNotifier($scope.submitReceivePayment,
				taskDetailDTO, from);
	};
	// harshad
	$scope.submitReceivePayment = function(taskDetailDTO, from) {
		
		taskDetailDTO.comments = $scope
				.commentPush(taskDetailDTO);
		var subProcessFields = {
			wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
			isPaymentReceived: taskDetailDTO.subprocessFieldDTO.isPaymentReceived,
			motorClearanceToDispatch: taskDetailDTO.subprocessFieldDTO.motorClearanceToDispatch
		};
		
		$scope.updateTaskDTO = angular.copy(taskDetailDTO);
		$scope.updateTaskDTO.subprocessFieldDTO=subProcessFields;
		
		if (from == 'save') {
			$scope.updateTask($scope.updateTaskDTO);
		} else {
			$scope.updateTaskDTO.assignee = $rootScope.user.userId;
			$scope.updateTaskDTO.checkAccept = configParameter.accept;
			$scope.completeusertask($scope.updateTaskDTO);
		}
	};
	
	// harsahd
	$scope.createNUpdateProformaInvoice = function(taskDetailDTO, from) {
		if ($scope.motorForm.$invalid)
				 {
								
			return false;
		}
		$scope.loadNotifier($scope.submitProformaInvoice,
				taskDetailDTO, from);
	};
	// harshad
	$scope.submitProformaInvoice = function(taskDetailDTO, from) {
		
		taskDetailDTO.comments = $scope
				.commentPush(taskDetailDTO);
		var subProcessFields = {
			wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
			isProformaInvoiced: taskDetailDTO.subprocessFieldDTO.isProformaInvoiced,
			invoiceRefNo: taskDetailDTO.subprocessFieldDTO.invoiceRefNo,
			custInvoiceDate: taskDetailDTO.subprocessFieldDTO.custInvoiceDate
		};
		
		$scope.updateTaskDTO = angular.copy(taskDetailDTO);
		$scope.updateTaskDTO.subprocessFieldDTO=subProcessFields;
		
		if (from == 'save') {
			$scope.updateTask($scope.updateTaskDTO);
		} else {
			$scope.updateTaskDTO.assignee = $rootScope.user.userId;
			$scope.updateTaskDTO.checkAccept = configParameter.accept;
			$scope.completeusertask($scope.updateTaskDTO);
		}
	};
	
	// harshad
	/* upload file */
	$scope.uploadFile = function(attachmentType, description,
			picFile) {
		if (!picFile) 
		{
			return false;
		}
		else{
			
			var val = picFile.name;
            var val1 = val.substring(val.indexOf(".") + 1);
            var val2= val1.split(".")[1];
             if(val2)
            	 {
            	 
            	 if (val2.length > 0)
	            	{
	            	alert("invalid");
	            	$scope.motor.picFile='';
		            return false;
	            	}
            	 }else{
			
		var dots = picFile.name.split(".")
		//get the part AFTER the LAST period.
		var fileType = "." + dots[dots.length-1];

		if(!($scope.uploadFileTypes.join(".").indexOf(fileType) != -1)){
			alert("Invalid File Type");
			$scope.motor.picFile='';
			return false;
		}
		if(picFile.name.length>80){
			alert('file Name should be less than 80 character: so kindly rename and save it again');
			$scope.motor.picFile='';
			return false;
		}					
		var isInternal = 0;

		var formData = new FormData();
		formData.append("file", picFile);
		formData.append("description", description);// important:
		formData.append("uploadedBy", $scope.uploadedBy);// important:
		formData.append("attachmentType", attachmentType);
		formData.append("tenantId", configParameter.tenantId);// important:
		formData.append("solCatId", configParameter.programId);// important:
		formData.append("isInternal", isInternal);

		if ((picFile.size / 1024 / 1024) < 3) {

			arcService
					.uploadFile($scope.subprocessFieldId,
							formData)
					.then(
							function success(response) {

								$scope.motorAttachmentDetails = response;
								$scope.motorAttachmentDetails
										.sort($scope.custom_sort);
								$scope.motorAttachmentCount = $scope.motorAttachmentDetails.length;
								$scope.motor.description='';
								$scope.motor.attachmentType='';
								$scope.motor.picFile='';
							}, function error(error) {
							});

		} else {
			alert(picFile.size / 1024 / 1024
					+ " size, should be less than 3MB");
		}
		}
	}
	};
	
	// harshad
	/* delete file */
	$scope.deleteFile = function(motorAttachmentsId, index) {
		// alert('delete start');
		$scope.deletedBy = $rootScope.user.userId;

		arcService.deleteFile(motorAttachmentsId,
				$scope.deletedBy).then(
				function success(response) {
					console.log(response);

					$scope.motorAttachmentDetails.splice(index,
							1);
					$scope.motorAttachmentCount=$scope.motorAttachmentDetails.length;

				}, function error(error) {
					$rootScope.errors = [];
                      if (error != null) {
                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
                      } else {
                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
                      } 
				});
	};
	
	// harshad
	$scope.downloadFile = function(motorAttachmentsId) {

		//alert('download start');

		var downloadLink = document.createElement("a");

		document.body.appendChild(downloadLink);
		downloadLink.style = "display: none";

		arcService
				.downloadFile(motorAttachmentsId)
				.then(
						function success(result) {
							var disposition = result
									.headers('Content-Disposition')

							var fileName = disposition
									.substring(21,
											disposition.length);
							console.log(fileName);
							var file = new Blob(
									[ result.data ], {
										type : 'application/*'
									});
							var fileURL = (window.URL || window.webkitURL)
									.createObjectURL(file);

							// Blob, client side object created
							// to with holding browser specific
							// download popup, on the URL
							// created with the help of window
							// obj.

							downloadLink.href = fileURL;
							downloadLink.download = fileName;
							downloadLink.click();

						}, function error(error) {
							$rootScope.errors = [];
		                      if (error != null) {
		                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
		                      } else {
		                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
		                      } 
						});

	};
	// harshad
	$scope.custom_sort = function(a, b) {

		return new Date(a.uploadedOn).getTime()
				- new Date(b.uploadedOn).getTime();
	};
	
	//gautam
	$scope.loadNotifier = function(callback, value, from) {

		$scope.notifier({
			title : "Confirm Submit",
			notification : "Do you want to submit form ?",
			type : "confirm"
		}, function(resolve) {
			if (resolve) {

				callback(value, from);
			}
		});
	};
	
	//harshad
	$scope.getCReportFieldsBySubProcessID=function(){
		motorRepairService.getCReportFieldsBySubProcessID($scope.subprocessFieldId).then(
                  function success(response) {
                                        $scope.motor.cReportField = response;
                                              },	function error(error) {
                      							$rootScope.errors = [];
                    							if (error != null) {
                    								$rootScope.errors
                    										.push({
                    											code : error.exception,
                    											message : error.exceptionMessage
                    										});
                    							} else {
                    								$rootScope.errors
                    										.push({
                    											code : "System Error",
                    											message : "Oops Something went wrong . Please contact system administrator"
                    										});
                    							}
                    						});	
		};
		//harshad
			$scope.getDReportFieldsBySubProcessID = function() {
			motorRepairService.getDReportFieldsBySubProcessID(
					$scope.subprocessFieldId).then(
					function success(response) {
						$scope.motor.dReportField = response;
						console.log(JSON
								.stringify($scope.motor.dReportField));

					}, 	function error(error) {
						$rootScope.errors = [];
						if (error != null) {
							$rootScope.errors
									.push({
										code : error.exception,
										message : error.exceptionMessage
									});
						} else {
							$rootScope.errors
									.push({
										code : "System Error",
										message : "Oops Something went wrong . Please contact system administrator"
									});
						}
					});
		};
		//harshad
		$scope.getBReportFieldsBySubProcessId=function(){
		motorRepairService.getBReportFieldsBySubProcessId($scope.subprocessFieldId).then(
                  function success(response) {
                                        $scope.motor.bReportField = response;
                                              }, 	function error(error) {
                      							$rootScope.errors = [];
                    							if (error != null) {
                    								$rootScope.errors
                    										.push({
                    											code : error.exception,
                    											message : error.exceptionMessage
                    										});
                    							} else {
                    								$rootScope.errors
                    										.push({
                    											code : "System Error",
                    											message : "Oops Something went wrong . Please contact system administrator"
                    										});
                    							}
                    						});
		};
		// harshad
		$scope.commentPush = function(taskDetailDTO, from) {
			if (typeof taskDetailDTO.comment_text != 'undefined') {
				if (typeof taskDetailDTO.comments == 'undefined'
						|| taskDetailDTO.comments == null) {
					taskDetailDTO.comments = new Array();
				}
				taskDetailDTO.comments = new Array();
				taskDetailDTO.comments
						.push({
							added_by_ref_id : $rootScope.user.userId,
							batch_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.batchProcessId,
							comment_isActive : 1,
							comment_by_actor_id : $rootScope.user.userId,
							mast_process_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.masterWorkflowFieldId,
							reference_id : taskDetailDTO.subprocessFieldDTO.masterWorkflowFields.gspRefNo,
							// sub_process_id :
							// taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
							comment_text : taskDetailDTO.comment_text,
							commentType : 1,
							comment_timestamp : new Date(),
						// solution_category_id:configParameter.programId,
						// taskCode:taskDetailDTO.functionCode,
						// taskRefId:taskDetailDTO.taskId,
						// taskDetailDTO.taskStatus,
						// tenant_id:configParameter.tenantId,
						});
				if (from == 'save') {
					taskDetailDTO.comment_text = null;
				}
			}
			return taskDetailDTO.comments;
		};
		// harsahd
		$scope.getAllMotorAttachmentDetailBySubprocesssId = function() {
			if ($scope.AttachmentFlag == false) {
				var external = new Boolean(false);
				$scope.AttachmentFlag = true;
				var uploadedBy = $rootScope.user.userId;

				motorRepairService
						.getAllMotorAttachmentDetailBySubprocesssId(
								$scope.subprocessFieldId, external,uploadedBy)
						.then(
								function success(response) {
									$scope.motorAttachmentDetails = response;
									console.log(response);
								}, function error(error) {
								});
			}
		};
		
		//harshad
		$scope.getMotorAttachmentCount = function() {
				var external = false;
				var subprocessFieldId=$scope.subprocessFieldId;
				var uploadedBy = $rootScope.user.userId;
				motorRepairService
						.getMotorAttachmentCount(
								subprocessFieldId,configParameter.tenantId,configParameter.programId,external,uploadedBy)
						.then(
								function success(response) {
									$scope.motorAttachmentCount = response;
								}, function error(error) {
								});
			
		};
		// Sagar Comments function
		$scope.getCommentDetails = function(subprocessFieldId) {
			console.log("in comment Details function");
			motorRepairService
					.getCommentsBySubProcessIdNTenantIdNSolnCatID(
							subprocessFieldId)
					.then(
							function success(response) {
								console.log("success");
								$scope.commentsDetailsList = response;
								console.log("Comments Details ",
										JSON.stringify(response));
								$scope.commmentText = $scope.commentsDetailsList[0].comment_text;
								$scope.functionName =$scope.commentsDetailsList[0].functionName;
								console.log(JSON.stringify($scope.taskdetail));
							},
							function error(error) {
							});
		};
		
		// Rucha Approver Comments function
		$scope.getApproverCommentDetails = function() {	
			var preApprovalFunctionCode = $scope.taskDetailDTO.prevApprovalFunctionCode;	
			var approvalCommentType=2;
			motorRepairService.getApproverCommentsBySubProcessIdNTenantIdNSolnCatID(
					$scope.subprocessFieldId,configParameter.tenantId,
					configParameter.programId,approvalCommentType,preApprovalFunctionCode)
					.then(function success(response) {
								$scope.approvalCommentsDetailsList = response;
								$scope.functionNameMap=saveTempObjectService.getProperty();	
								
								if($scope.approvalCommentsDetailsList.length>0 || $scope.approvalCommentsDetailsList){
									
									angular.forEach($scope.approvalCommentsDetailsList,
											function(approvalCommentsDetail) {
												approvalCommentsDetail.functionName=$scope.functionNameMap[approvalCommentsDetail.taskCode];
											});
								}
							},
							function error(error) {
							});
		};
	
		$scope.Comment = function(taskDetailDTO) {
			var comment = {
				comment_text : taskDetailDTO.comment_text,
				commentType : 1
			};
			delete taskDetailDTO.comment_text;
			taskDetailDTO.comments.push(comment);
			taskDetailDTO.assignee = $rootScope.user.userId;
			taskDetailDTO.checkAccept = configParameter.accept;
			console.log("DATAAAAAAAA", JSON
					.stringify(taskDetailDTO));
			return taskDetailDTO;
		};
		
		$scope.commentsPush=function()
		{
			angular.forEach($scope.taskDetailDTO.comments,function(item)
					{
				if(item.comment_text)
					{
					$scope.newCommentsList.push({commentsId:item.commentsId,comment_text:item.comment_text,commentType:item.commentType,comment_by_actor_id : $rootScope.user.userId});
					}
					});		 
			$scope.taskDetailDTO.comments=angular.copy($scope.newCommentsList);	 
		};
		
		// harshad
		$scope.getConfigDetailByTypeNSubType = function(configType,
				configSubType, subscope) {
			if (typeof $scope[subscope] == 'undefined') {
				motorRepairService
						.getConfigDetailByTypeNSubType(configType,
								configSubType)
						.then(
								function success(response) {
									$scope[subscope] = '';
									$scope[subscope] = response;
								},
								function error(error) {
									$rootScope.errors = [];
									if (error != null) {
										$rootScope.errors
												.push({
													code : error.exception,
													message : error.exceptionMessage
												});
									} else {
										$rootScope.errors
												.push({
													code : "System Error",
													message : "Oops Something went wrong . Please contact system administrator"
												});
									}
								});
			}
		};
		// harshad
		$scope.showLabel = function(list, value) {
			var selected = null;
			angular.forEach(list, function(s) {
				if (s.value == value) {
					selected = s.name;
				}
			});
			return selected ? selected : "NO DATA";
		};

		$scope.getConfigDetailByVlaue = function(configType,
				configSubType, actualVal, subscope) {
			if (typeof $scope[subscope] == 'undefined') {
				motorRepairService
						.getConfigDetailByTypeNSubType(configType,
								configSubType)
						.then(
								function success(response) {
									$scope[subscope] = response;
									angular
											.forEach(
													$scope[subscope],
													function(item) {

														if (item.value == actualVal) {
															$scope.configLabel = item.name;
														}
													});
								},
								function error(error) {
									$rootScope.errors = [];
									if (error != null) {
										$rootScope.errors
												.push({
													code : error.exception,
													message : error.exceptionMessage
												});
									} else {
										$rootScope.errors
												.push({
													code : "System Error",
													message : "Oops Something went wrong . Please contact system administrator"
												});
									}
								});
			}

		};
		
		$scope.getMotorSalesDetailByTenantIdAndSolutionCategoryId = function() {
			motorRepairService.getMotorSalesDetailByTenantIdAndSolutionCategoryId(
							"SIEMENS", "1")
					.then(function success(response) {
								//alert("success");
								$scope.motorSales = response;
								console.log("Motor Sales Dropdown Data :",JSON.stringify(response));
							}, function error(error) {
								$rootScope.errors = [];
			                      if (error != null) {
			                    	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
			                      } else {
			                        $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
			                      } 
							});
		};
		
		// Rucha...Common Method
		$rootScope.commonDTOmethod = function(taskDetailDTO) {
			subprocessField = {
				wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
				spiridonNtfnNo : taskDetailDTO.subprocessFieldDTO.spiridonNtfnNo,
				masterWorkflowFields : $scope.taskDetailDTO.subprocessFieldDTO.masterWorkflowFields,
				salesOrgRefId : $scope.taskDetailDTO.subprocessFieldDTO.salesOrgRefId,
				salesDivRefId : $scope.taskDetailDTO.subprocessFieldDTO.salesDivRefId,
				salesGrpRefId : $scope.taskDetailDTO.subprocessFieldDTO.salesGrpRefId,
				salesOfficeRefId : $scope.taskDetailDTO.subprocessFieldDTO.salesOfficeRefId,
				productGrp : $scope.taskDetailDTO.subprocessFieldDTO.productGrp,
				motorIBaseNum : $scope.taskDetailDTO.subprocessFieldDTO.motorIBaseNum,
				initialWarrantyClaim : $scope.taskDetailDTO.subprocessFieldDTO.initialWarrantyClaim,
				faultDesc : $scope.taskDetailDTO.subprocessFieldDTO.faultDesc	
			};
			return subprocessField;
		}
		
		// Nitin
		$rootScope.getAllActorsByTenantIdNSolCatId = function(taskDetailDTO) 
		{
			 motorRepairService.getAllActorsByTenantIdNSolCatId(configParameter.tenantId,configParameter.programId).then(function success(response) 
		     {			
				$scope.dropDownFunctionList={};
				$scope.approverList;
				$scope.actorList = response;							   
			   angular.forEach(response, function(actor) 
			           {
				   			if(actor.actorName=='Approvers')
				   				{
				   				$scope.approverList=actor.actorsCPRoleMapDTOList;
				   					angular.forEach(actor.actorsCPRoleMapDTOList, function(cp) 
							           {							   						
				   						$scope.dropDownFunctionList[cp.cpRoleReferenceName]=actor.functionDTOList;
							           });
				   				}
				   			else
				   				{
				   				$scope.dropDownFunctionList[actor.actorName]=actor.functionDTOList;
				   				}
			           });
			 },
			 function error(error) 
			 {
				$rootScope.errors = [];
				if (error != null) 
				{
					$rootScope.errors.push({code : error.exception,message : error.exceptionMessage });
				} else
				{
					$rootScope.errors.push({code : "System Error", message : "Oops Something went wrong . Please contact system administrator"});
				}
			  });
		};


		
		// Rucha // Approver
		$scope.submitApproveTask = function(taskDetailDTO, from) {
			$scope.commentsPush();
			taskDetailDTO.checkAccept = configParameter.accept;
			subprocessField = {
					wlfwSubProcessId : taskDetailDTO.subprocessFieldDTO.wlfwSubProcessId,
					motorDispatchDocketNo : taskDetailDTO.subprocessFieldDTO.motorDispatchDocketNo
			};
			$scope.updateTaskDTO = angular.copy(taskDetailDTO);
			if (from == 'save') {
				$scope.updateTask($scope.updateTaskDTO);
			} else {
				taskDetailDTO.assignee = $rootScope.user.userId;				
				$scope.completeusertask($scope.updateTaskDTO);
			}
		};

		// Rucha
		$scope.CreateUpdateApproveTask = function(taskDetailDTO,
				from) {
			if ($scope.motorForm.$invalid) {
				return false;
			}
			$scope.loadNotifier($scope.submitApproveTask,
					taskDetailDTO, from);
		};
		
});
