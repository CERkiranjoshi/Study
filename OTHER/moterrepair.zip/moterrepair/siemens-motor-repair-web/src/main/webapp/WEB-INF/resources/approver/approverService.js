siemensMotorRepairApp.service('approverService', function ($http,$q) {


	this.updateTask = function (taskDetailDto) {
        var d = $q.defer();
        console.log("/task-mgmt-mwp/taskmanagementservice/updatetask/");
        
        $http.post('/task-mgmt-mwp/taskmanagementservice/updatetask/',taskDetailDto)
            .success(function (response) {
                d.resolve(response);
            })
            .error(function (error) {
                d.reject(error);
            });

        return d.promise;
    };
    
    this.completeusertask = function (processInstance) {
    	//alert("in CCC  service");
        var d = $q.defer();
        console.log("/task-mgmt-mwp/taskmanagementservice/completeusertask");
        
        $http.post('/task-mgmt-mwp/taskmanagementservice/completeusertask',processInstance)
            .success(function (response) {
                d.resolve(response);
            })
            .error(function (error) {
                d.reject(error);
            });

        return d.promise;
    };
    
        this.getSubProcessFieldsByWlfwSubProcessId = function (Id) {
  	        var d = $q.defer();
  	        $http.get("/task-mgmt-mwp/subProcessFieldsService/getSubProcessFieldsByWlfwSubProcessId/"+Id)
  	            .success(function (response) {
  	            	
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	            	
  		                 d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	    
  	    this.arcDetails = function (Id) { 
  	        var d = $q.defer();
  	        $http.get("/task-mgmt-mwp/arcMasterService/getARCMasterByArcId/"+Id)
  	            .success(function (response) {
  	            	
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	            	
  		                 d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	    
  	    this.save = function (subProcessField) {
  	        var d = $q.defer();
  	        $http.post("/task-mgmt-mwp/subProcessFieldsService/createUpdateSubProcessFields",subProcessField)
  	            .success(function (response) {
  	            	alert("success");
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	            	
  		                 d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	    
  	    this.getMotorSalesDetailByTenantIdAndSolutionCategoryId = function (tenantId,programId) {
  	        var d = $q.defer();

  	        $http.get('/task-mgmt-mwp/motorSalesDetailService/getMotorSalesDetailByTenantIdAndSolutionCategoryId/'+ tenantId+'/'+programId)
  	            .success(function (response) {
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	                d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	    
  	    this.createUpdateSubProcessFields= function (subProcessField) {
  	        var d = $q.defer();
  	        $http.post("/task-mgmt-mwp/subProcessFieldsService/createUpdateSubProcessFields",subProcessField)
  	            .success(function (response) {
  	            	
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	            	
  		                 d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	  //RUCHA 14TH DECEMBER
  	    
  //Sagar
  	    
  	    this.postCReportFieldsDataSub = function(cReportField) {
  	      	 //alert("submit");
  	      	 console.log(JSON.stringify(cReportField));
  	           var d = $q.defer();
  	      
  	           
  	           $http.post("/task-mgmt-mwp/cReportFieldsService/createUpdateCReportFields",cReportField)
  	           .success(function (response) {
  	               	
  	                   d.resolve(response);
  	               })
  	               .error(function (error) {
  	   	                 d.reject(error);
  	               });

  	           return d.promise;
  	       };
  	       
  	     //harshad
  	       this.createUpdateBReportFields = function(BReportField) {
  	   		//alert("gfgfhgfhgfhgfhgf");
  	   		//alert(JSON.stringify(BReportField));
  	   		console.log(JSON.stringify(BReportField));
  	   		var d = $q.defer();
  	   		$http
  	   				.post('/task-mgmt-mwp/bReportFieldsService/createUpdateBReportFields',
  	   						BReportField).success(
  	   						function(response) {
  	   							d.resolve(response);
  	   						}).error(function(error) {
  	   					d.reject(error);
  	   				});

  	   		return d.promise;
  	   	};
  	   	//hasrahd
  	   	this.createUpdateDReportFields = function(DReportField) {
  	   		//alert(JSON.stringify(DReportField));
  	   		console.log(JSON.stringify(DReportField));
  	   		var d = $q.defer();
  	   		$http
  	   				.post('/task-mgmt-mwp/dReportFieldsService/createUpdateDReportFields',
  	   						DReportField).success(
  	   						function(response) {
  	   							d.resolve(response);
  	   						}).error(function(error) {
  	   					d.reject(error);
  	   				});
  	   		return d.promise;
  	   	};

  	   	//harshad: for attachment delte file
  	   	this.deleteFile = function(motorAttachmentsId,deletedBy) {
  	   		var d = $q.defer();
  	   		$http.post(
  	   				'/task-mgmt-mwp/uploadAttachmentsService/deleteDocument/'
  	   						+ motorAttachmentsId+"/"+deletedBy).success(
  	   				function(response) {
  	   					d.resolve(response);
  	   				}).error(function(response) {
  	   			alert("Error ... " + response);
  	   		});
  	   		return d.promise;
  	   	};

  	   	//harshad: for attachment download file
  	   	this.downloadFile = function(motorAttachmentsId) {
  	   	//	alert('download file service');

  	   		var d = $q.defer();
  	   		return $http
  	   				.get(
  	   						'/task-mgmt-mwp/uploadAttachmentsService/downloadDocument/'
  	   								+ motorAttachmentsId, {

  	   							responseType : 'arraybuffer',
  	   							params : {
  	   							//Required params
  	   							},
  	   						}).then(
  	   						function(response, status, headers,
  	   								config) {

  	   							return response;
  	   						});

  	   	};
  	   	//harshad: for attachment upload file
  	   	this.uploadFile = function(Id,formData) {

  	   		var d = $q.defer();
  	   		$http.post(
  	   				'/task-mgmt-mwp/uploadAttachmentsService/uploadDocument/'
  	   						+ Id,
  	   				formData,
  	   				{
  	   					transformRequest : function(data,
  	   							headersGetterFunction) {
  	   						return data;
  	   					},
  	   					headers : {
  	   						'Content-Type' : undefined
  	   					}
  	   				}).success(function(response) {
  	   			d.resolve(response);
  	   		}).error(function(error) {
  	   			d.reject(error);
  	   		});
  	   		return d.promise;
  	   	};
  	   	
  	   	// complete user task
  	   	this.completeusertask = function (processInstance) {
  	    	//alert("in ARC  service");
  	        var d = $q.defer();
  	        console.log("/task-mgmt-mwp/taskmanagementservice/completeusertask");
  	        
  	        $http.post('/task-mgmt-mwp/taskmanagementservice/completeusertask',processInstance)
  	            .success(function (response) {
  	                d.resolve(response);
  	            })
  	            .error(function (error) {
  	                d.reject(error);
  	            });

  	        return d.promise;
  	    };
  	    
  		// Sagar : To fetch Task Deatils for comments
  		this.getCommentsByTenantIdNSolnCatNSubProcessIdNArcID = function(
  				subProcessId,tenantId,solCat,arcRefId) {

  			var d = $q.defer();
  			$http.get(
  					"/task-mgmt-mwp/commentsService/getCommentsByTenantIdNSolnCatNSubProcessIdNArcID/"
  							+ subProcessId + "/" + tenantId + "/"
  							+ solCat+"/"+arcRefId).success(function(response) {

  				d.resolve(response);
  			}).error(function(error) {

  				d.reject(error);
  			});

  			return d.promise;
  		};
  		// harshad
  		this.getAllMotorAttachmentDetailBySubprocesssId = function(
  				Id, external,uploadedBy) {
  			var d = $q.defer();
  			$http
  					.get(
  							"/task-mgmt-mwp/uploadAttachmentsService/getAllMotorAttachmentDetailBySubprocesssId/"
  									+ Id + "/" + external+"/"+uploadedBy).success(
  							function(response) {
  								d.resolve(response);
  							}).error(function(error) {
  						d.reject(error);
  					});

  			return d.promise;
  		};
  		//harshad
  		this.getActorMasterByActorId = function(role,tenantId,solCatId,arcRefId) {
  			var d = $q.defer();
  			// TODO: actor id is hard coded here need to get it from
  			// logged in user i.e. $rootScope
  			$http.get('/task-mgmt-mwp/actorMasterService/getActorMasterByRoleNTenantIdNSolCatIdNArcRefId/'+role+'/'+tenantId+'/'+solCatId+'/'+arcRefId)

  					.success(function(response) {
  						console.log(response);
  						d.resolve(response);
  					}).error(function(error) {
  						d.reject(error);
  					});

  			return d.promise;
  		};

  		   this.getTicketDetailById = function (ticketId) {
  		        var d = $q.defer();
  		        $http.get("/task-mgmt-mwp/ticketDetails/getTicketDeteailByTicketdetailsId/"+ticketId)
  		            .success(function (response) {
  		            	
  		                d.resolve(response);
  		            })
  		            .error(function (error) {
  		            	
  			                 d.reject(error);
  		            });

  		        return d.promise;
  		    };

  			   this.createUpdateTicketDetail = function (ticketDetailDTO) {
  			        var d = $q.defer();
  			        $http.post('/task-mgmt-mwp/ticketDetails/createUpdateTicketDetails',ticketDetailDTO)
  			            .success(function (response) {
  			            	
  			                d.resolve(response);
  			            })
  			            .error(function (error) {
  			            	
  				                 d.reject(error);
  			            });

  			        return d.promise;
  			    };
  			    
  			 // Rucha
  				// Get ARC Master Details by its arcType
  				this.getARCMasterByArcType = function(arcType) {
  					var d = $q.defer();
  					$http.get("/task-mgmt-mwp/arcMasterService/getARCMasterByArcType/"+ arcType).success(function(response)
  							{
  						d.resolve(response);
  							}).error(function(error) {
  						d.reject(error);
  					});

  					return d.promise;
  				};
  				
});


