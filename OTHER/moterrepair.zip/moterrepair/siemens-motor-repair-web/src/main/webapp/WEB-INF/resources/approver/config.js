siemensMotorRepairApp.config(['$routeProvider', function($routeProvider) {
   
	$routeProvider
		.when('/dashboard', {
			controller: 'motorRepairController',
			templateUrl: 'resources/template/common/views/dashboard.html'
		})
		.when('/ccc', {
			controller: 'headerController',
			templateUrl: 'resources/ccc/views/searchResult.html'
		})
		.when('/searchresult', {
			controller: 'headerController',
			templateUrl: 'resources/template/common/views/workflowStatusView.html'
		})
		
		.when('/repairService', {
			controller: 'TCSController',
			templateUrl: 'resources/ccc/views/repairServiceOrderClosure.html'
		})
		
		.when('/track-status/:trackId', {
			controller: 'TCSController',
			templateUrl: 'resources/trackCallStatus/views/trackCallStatus.html'
		})
		
		.when('/track-gsp-status/:trackId', {
			controller: 'TCSController',
			templateUrl: 'resources/trackCallStatus/views/customerTrackCallStatus.html',
			access: 'public'
		})
		.when('/app/provideApprovalForm', {
			controller: 'approverController',
			templateUrl: 'resources/approver/views/ApproveTaskForm.html'
		})
		.otherwise({ redirectTo : "/dashboard"});
}]);

