siemensMotorRepairApp.controller('adminController',function($scope, $rootScope, adminService, motorRepairService, configParameter) {
					
	// ashish	
	 $scope.escalationValue={};
	 $scope.showEscalation=false;
	 $scope.showError=false;
	 $scope.functionIdExist=false;
	 
	 
	$scope.fetchSLA=function()
	{
		$scope.fetchFunctionName();
		adminService
		.getallFunctionSLAMaster(configParameter.tenantId)
		.then(
				function success(response) {
					$scope.functionsSlaMasterDTO = response;
					if($scope.functionsSlaMasterDTO.length >0)
					{
						$scope.showEscalation=true;
					}
					else{
						 $scope.showEscalation=false;
					}
			  
					
				}, function error(error) {
				});

	};
	
	$scope.FetchEscalation=function()
	
	{
		
		
		$scope.fetchFunctionName();
		adminService
		.getallEscalationData(configParameter.tenantId)
		.then(
				function success(response) {
					
					$scope.escalationHierarchyMaster =  response;
					for(var i=0;i<=$scope.escalationHierarchyMaster.length;i++){
						if($scope.escalationHierarchyMaster[i])
							{
							 
							$scope.escalationHierarchyDataN=$scope.escalationHierarchyMaster[i].escalationHierarchyData;
							
						
					
					/*for(var j=0;j<$scope.escalationHierarchyDataN.length;j++)
					 {*/
						 
						/*var escalationNotiFicationDataMode=$scope.escalationHierarchyDataN[j];
						*/
							angular.forEach($scope.escalationHierarchyDataN,function(escalationNotiFicationDataMode)
									{
								
									
						if( escalationNotiFicationDataMode.notification_mode==0)
							{
							escalationNotiFicationDataMode['notificationTypeEmail']=''
								escalationNotiFicationDataMode['notificationTypeSms']=''
									 
							}
						else if( escalationNotiFicationDataMode.notification_mode==1)
							{
							escalationNotiFicationDataMode['notificationTypeEmail']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==2)
							{
								escalationNotiFicationDataMode['notificationTypeSms']='Y'
							}
							else  
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeSms']='Y'
							}
							/*else if( escalationNotiFicationDataMode.notification_mode==4)
							{
								escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==5)
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==6)
							{
								escalationNotiFicationDataMode['notificationTypeSms']='Y'
									escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==7)
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeSms']='Y'
										escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==8)
							{
								escalationNotiFicationDataMode['notificationTypeAmq']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==9)
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeAmq']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==10)
							{
								escalationNotiFicationDataMode['notificationTypeSms']='Y'
									escalationNotiFicationDataMode['notificationTypeAmq']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==11)
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeSms']='Y'
										escalationNotiFicationDataMode['notificationTypeAmq']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==12)
							{
								escalationNotiFicationDataMode['notificationTypeAmq']='Y'
									escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==13)
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeAmq']='Y'
										escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else if( escalationNotiFicationDataMode.notification_mode==14)
							{
								escalationNotiFicationDataMode['notificationTypeSms']='Y'
									escalationNotiFicationDataMode['notificationTypeAmq']='Y'
										escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}
							else 
							{
								escalationNotiFicationDataMode['notificationTypeEmail']='Y'
									escalationNotiFicationDataMode['notificationTypeSms']='Y'
										escalationNotiFicationDataMode['notificationTypeAmq']='Y'
											escalationNotiFicationDataMode['notificationTypeGcm']='Y'
							}*/
									})
						
							}		 
						 }
						
							 
					
					
				}, function error(error) {
				});
	};
	
	
	$scope.fetchFunctionName=function()
	{
		adminService
		.getallFunctionName(configParameter.tenantId)
		.then(
				function success(response) {
					$scope.actorFunctionMaster = response;
					$scope.actorFunctionNameList=$scope.actorFunctionMaster
					
					console.log("actorfunctionlist"+JSON.stringify($scope.actorFunctionMaster));
					
				}, function error(error) {
				});
	}
	
	$scope.deleteFunctionSLARecords=function(functionId)
	{
		 
		angular.forEach($scope.escalationHierarchyMaster,function(item)
		{
			if(item.functionsSlaMaster.functionSlaId==functionId)
			{
				$scope.functionIdExist=true;
				$rootScope.notifyAlert({title: "Error ", notification: "Escalation already exist for this functionId"});
				return false;
			}
		})
		if($scope.functionIdExist==false)
		{
			adminService
		.getdeleteRecords(functionId)
		.then(
				function success(response) {
					$scope.deleter = response;
					if($scope.deleter==true)
					{
						$rootScope.notifyAlert({title: "Success ", notification: "Record has been deleted"});
						$scope.fetchSLA();
					}
					
					
				}, function error(error) {
				});
		}
		
	}
	
	$scope.onChangePriorityType=function(functionsSlaMasterDTO)
	{
		angular.forEach($scope.functionsSlaMasterDTO,function(item)
				{
			if(item.priorityType==functionsSlaMasterDTO.priorityType &&
					item.actorFunctionMaster.functionName==functionsSlaMasterDTO.actorFunctionMaster.functionName)
				{
				$scope.showError=true;
				  return false;
				}
				else{
					$scope.showError=false;
				}
				});
	}
	
	$scope.saveAndsubmitSLA=function(functionsSlaMasterDTO)
	{			 
		if(!functionsSlaMasterDTO.actorFunctionMaster.functionId)
			{
			angular.forEach($scope.actorFunctionMaster,function(item)
			{
				if(item.functionName==functionsSlaMasterDTO.actorFunctionMaster.functionName)
					{
					functionsSlaMasterDTO.actorFunctionMaster.functionId=item.functionId;
					
					functionsSlaMasterDTO.tenantId=configParameter.tenantId;
					return false;
					}
			});
			}
		var functionSlamasterList=angular.copy(functionsSlaMasterDTO);
		console.log(functionSlamasterList)
		 
		 
			
			adminService
		.createupdateSLA(functionSlamasterList)
		.then(
				function success(response) {
					$scope.message = response;
					 
					$scope.fetchSLA();
					$("#sla-module").modal('hide');
				}, function error(error) {
				})
		
		
		;
	}
	
	
	/*$scope.escalationAddNewEscalation=function()
	{
		$scope.escalationData=null;
	}*/
	
	$scope.functionSLAPush=function(functionsSlaMasterDTO)
	{
		$scope.functionsSlaMasterDTO.push(functionsSlaMasterDTO);
	}
	
	
	
	$scope.saveAndsubmitEscalation=function(escalationMasterDTO)
	
	{
		if(!escalationMasterDTO.functionsSlaMaster.functionSlaId)
		{
		angular.forEach($scope.functionsSlaMasterDTO,function(item)
		{
			if(item.slaName==escalationMasterDTO.functionsSlaMaster.slaName)
				{
				escalationMasterDTO.functionsSlaMaster.functionSlaId=item.functionSlaId;
				escalationMasterDTO.tenantId=configParameter.tenantId;
				
				if(!escalationMasterDTO.functionsSlaMaster.actorFunctionMaster.functionId)
				{
				angular.forEach($scope.actorFunctionMaster,function(item)
				{
					if(item.functionName==escalationMasterDTO.functionsSlaMaster.actorFunctionMaster.functionName)
						{
						escalationMasterDTO.functionsSlaMaster.actorFunctionMaster.functionId=item.functionId;
					 	}
				});
				return false;
				}
		}
		});
		}
		var escalationData=escalationMasterDTO.escalationHierarchyData;
		for(var i=0;i<escalationData.length;i++)
			{
			var escalationNotificationData=escalationData[i];
			var notificationType = $scope.getNotificationTypeEmailorSms(escalationNotificationData);
			delete escalationMasterDTO.escalationHierarchyData[i]['notificationTypeEmail'];
			delete escalationMasterDTO.escalationHierarchyData[i]['notificationTypeSms'];
			 
			escalationMasterDTO.escalationHierarchyData[i].notification_mode = notificationType;
			}
		 
		var escalationmasterList=angular.copy(escalationMasterDTO);
		
		adminService
		.createupdateEscalation(escalationmasterList)
		.then(
				function success(response) {
					$scope.message = response;
					$scope.FetchEscalation();
					$("#esclation-module").modal('hide');
					  
					
				}, function error(error) {
				});

	 
	};
	
	$scope.functionValue=function(functionSLA)
	{	
		$scope.functionSLA=functionSLA;
		$scope.functionValue=angular.copy($scope.functionSLA);
		 
	}
	$scope.escalationHierarchyMaster=[];
	$scope.saveSubmit=function(escalationValue){
		if($scope.index){
			$scope.escalationHierarchyMaster[$scope.index]=$scope.escalationValue;
		}else{
			$scope.escalationHierarchyMaster.push(escalationValue);
		}
	}
/*	$scope.escalationPush=function(escalationValue)
	{
		
		
		
		if($scope.escalationValue.id==0){
			escalationValue=$scope.escalationHierarchyMaster.length+1;
			$scope.escalationHierarchyMaster.push($scope.escalationValue);
			$scope.escalationValueDefault();
			$scope.escalationValue.id+=1;
			
		}else{
			$scope.escalationHierarchyMaster[$scope.index]=$scope.escalationValue;
			console.log('print');
			console.log($scope.escalationHierarchyMaster);
			for(var i=0;i<=$scope.escalationHierarchyMaster.length;i++){
				if($scope.escalationHierarchyMaster[i].id==$scope.escalationValue.id){
					$scope.escalationHierarchyMaster[indexs]=$scope.escalationValue;
					break;
				}
			}
		}
		
		if($scope.escalationData)
			{
			 
			$scope.escalationHierarchyMaster[index-1]=angular.copy($scope.escalationValue);
			 
		 
			}else{
				$scope.escalationHierarchyMaster.push(escalationValue);
				 
			}
	
	}*/
	$scope.escalationValueEdit=function(escalationData)
	{	
		  
		for(var i=0;i<=$scope.escalationHierarchyMaster.length;i++){
			if($scope.escalationHierarchyMaster[i].escalationHierarchyId==escalationData.escalationHierarchyId){
				$scope.escalationValue=angular.copy($scope.escalationHierarchyMaster[i]);
				break;
			}
		}
		
		 
	}
	
	
	/*$scope.escalationValue=function()
	{
		$scope.escalationValue.escalationName=null;
	}*/
	
	$scope.functionValueEdit=function(functionSLAData)
	{	
		  
		for(var i=0;i<=$scope.functionsSlaMasterDTO.length;i++){
			if($scope.functionsSlaMasterDTO[i].functionSlaId==functionSLAData.functionSlaId){
				$scope.functionValue=angular.copy($scope.functionsSlaMasterDTO[i]);
				break;
			}
		}
		
		 
	}
	
	
	$scope.escalationValueDefault=function(){
		$scope.escalationValue={
				 
				escalationHierarchyData:new Array()
		};
	};
	
	$scope.functionSLAValueDefault=function()
	{
		$scope.functionValue={};
	}
	$scope.deleteEscalationRecords=function(escalationHierarchyDataId,index)
	{
		if(escalationHierarchyDataId)
			{
			adminService
			.getdeleteEscalationRecords(escalationHierarchyDataId)
			.then(
					function success(response) {
						if(response){
							$scope.escalationValue.escalationHierarchyData.splice(index, 1);
                             						
						}
						
									 
						
					}, function error(error) {
					});
			}else{
				$scope.escalationValue.escalationHierarchyData.splice(index, 1);
			}
		
		
			
	};
	 
	$scope.escalationValue={
			 
			escalationHierarchyData:new Array()
	};
	$scope.addNewRow = function() 
	{
		
	 $scope.escalationValue.escalationHierarchyData.push({ escalationToUserRefId : null});
		
	};
	
	$scope.getNotificationTypeEmailorSms = function(subprocess) {

		var binaryVariable = "";

		 
		if (subprocess.notificationTypeSms == true) {
			binaryVariable = binaryVariable + "1";
		} else {
			binaryVariable = binaryVariable + "0";
		}
		if (subprocess.notificationTypeEmail == true) {
			binaryVariable = binaryVariable + "1";
		} else {
			binaryVariable = binaryVariable + "0";
		}
		 
		var decimal = parseInt(binaryVariable, 2);
		 
		return decimal;

	};
	 
	
	$scope.deleteEscalationMasterDataRecords=function(escalationMasterId)
	{
		adminService
		.getdeleteEscalationMasterDataRecord(escalationMasterId)
		.then(
				function success(response) {
					$scope.deleteMaster = response;
					
					if($scope.deleteMaster==true)
					{
						$rootScope.notifyAlert({title: "Success ", notification: "Record has been deleted"});
						$scope.FetchEscalation();
					}
				}, function error(error) {
				});
	};
	

	$scope.getConfigDetailByTenantIdNSolCatId=function(subScope,copyscope){
		$scope.workFLowStatusList=new Array();
		$scope.warrantyTypeList=new Array();
		
		adminService.getConfigDetailByTenantIdNSolCatId(configParameter.tenantId,configParameter.programId).then(
				function success(response) {
					console.log(subScope);
					$scope[subScope] = response;
					console.log($scope[subScope]);
					$scope[copyscope] = angular.copy($scope[subScope]);
					console.log(copyscope);
					console.log($scope[copyscope]);
					angular.forEach($scope[subScope], function(configObj) 
					           {
					                 if(configObj.configType=='WORKFLOW_CLOSURE_TYPE'){
					                	 $scope.workFLowStatusList.push(configObj);
					                 }
					                 if(configObj.configType=='WARRANTY_TYPE'){
					                	 $scope.warrantyTypeList.push(configObj);
					                 }
					           });
					$scope.workFLowStatusMainList=angular.copy($scope.workFLowStatusList);
					$scope.warrantyTypeListMain=angular.copy($scope.warrantyTypeList);
				},
				function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
	};
	
	
	$scope.resetData=function(configId,name){
		if(name=='Warranty'){
			if($scope.warrantyTypeListMain!=undefined){
				var tempobj={};
				for(var i=0;i<$scope.warrantyTypeListMain.length;i++){
					if($scope.warrantyTypeListMain[i].configId==configId){
						 tempobj=$scope.warrantyTypeListMain[i];
						break;
					}
				}
				for(var i=0;i<$scope.warrantyTypeList.length;i++){
					if($scope.warrantyTypeList[i].configId==configId){
						$scope.warrantyTypeList[i]=tempobj;
						$scope.warrantyTypeListMain=angular.copy($scope.warrantyTypeList);
						break;
					}
				}
			}
		}
		else if(name=='WorkFLowStatus'){
			if($scope.workFLowStatusMainList!=undefined){
				var tempobj={};
				for(var i=0;i<$scope.workFLowStatusMainList.length;i++){
					if($scope.workFLowStatusMainList[i].configId==configId){
						 tempobj=$scope.workFLowStatusMainList[i];
						break;
					}
				}
				for(var i=0;i<$scope.workFLowStatusList.length;i++){
					if($scope.workFLowStatusList[i].configId==configId){
						$scope.workFLowStatusList[i]=tempobj;
						$scope.workFLowStatusMainList=angular.copy($scope.workFLowStatusList);
						break;
					}
				}
			}
		}
		else if(name=='configMain'){
			if($scope.configMainList!=undefined){
				var tempobj={};
				for(var i=0;i<$scope.configMainList.length;i++){
					if($scope.configMainList[i].configId==configId){
						 tempobj=$scope.configMainList[i];
						break;
					}
				}
				for(var i=0;i<$scope.configList.length;i++){
					if($scope.configList[i].configId==configId){
						$scope.configList[i]=tempobj;
						$scope.configMainList=angular.copy($scope.configList);
						break;
					}
				}
			}
		}
		
	};
	
    $scope.saveConfigData=function(configDetailDTO){
    	var configStrVal='';
    	var configIntVal='';
    	if(configDetailDTO.dataType==1){
    		configStrVal=configDetailDTO.value;
    	}
    	else if(configDetailDTO.dataType==2){
    		configIntVal=configDetailDTO.value;
    	}
    	var configDetail={
    			configAlias: configDetailDTO.name,
    			configStrVal : configStrVal,
    			configIntVal : configIntVal,
    			configId : configDetailDTO.configId
    	};
    	adminService.saveConfigDetail(configDetail).then(
				function success(response) {
					if(response){
						configDetailDTO.showText=false;
					}
				},
				function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
    };
    
    $scope.saveWorkFlowStatus=function(workFLowStatussDTO){
    	
    	var configDetail={
    			configAlias : workFLowStatussDTO.name,
    			configDesc : workFLowStatussDTO.configDesc,
    			configId : workFLowStatussDTO.configId
    	};
    	
    	adminService.saveConfigDetail(configDetail).then(
				function success(response) {
					if(response){
						workFLowStatussDTO.showText=false;
					}
				},
				function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
    };
    
    $scope.filterByWarranty=function(obj){
    	if(obj.configSubType !='WARRANTY'){
    		return true;
    	}else{
    		return false;
    	}
    };
    
    $scope.saveWarranty=function(warrantyTypeDTO,Type){
    	
    	var warrantyTypeDetail=warrantyTypeDTO;
    	if(warrantyTypeDetail.configId==null){
    		
    		warrantyTypeDetail.configType = 'WARRANTY_TYPE';
    		warrantyTypeDetail.tenantId = configParameter.tenantId;
    		warrantyTypeDetail.solutionCategoryId = configParameter.programId;
    		warrantyTypeDetail.configVisiblity = 1;
    		warrantyTypeDetail.modifiedByRefId=$rootScope.user.userId;
    		warrantyTypeDetail.createdByRefId=$rootScope.user.userId;
    		warrantyTypeDetail.configEnabled = 1;
    		warrantyTypeDetail.configAlias = warrantyTypeDTO.name;
    		
    	}else{
    		
    		warrantyTypeDetail={
        			configAlias : warrantyTypeDTO.name,
        			configDesc : warrantyTypeDTO.configDesc,
        			configId : warrantyTypeDTO.configId,
        			modifiedByRefId : $rootScope.user.userId,
        			configEnabled : warrantyTypeDTO.configEnabled
        	};	
    	}
    	console.log(warrantyTypeDetail);
    	adminService.saveConfigDetail(warrantyTypeDetail).then(
				function success(response) {
					if(response){
						warrantyTypeDTO.showText=false;
						console.log(response);
						if(Type=='Save'){
							$scope.warrantyTypeList.push(warrantyTypeDetail);
							$scope.warrantyType=null;
							 $scope.motorForm.newWarrantyModal.$setPristine();
						}
						$scope.warrantyTypeListMain=angular.copy($scope.warrantyTypeList);
						 $("#warranty-modal").modal('hide');
					}
				},
				function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
    };
    
    $scope.filterIncludeWarranty=function(warrantyTypeObj){
    	if(warrantyTypeObj.configSubType !='WARRANTY'){
    		return false;
    	}else{
    		return true;
    	}
    };
    
    $scope.deleteRecords=function(index){
    	$scope.warrantyTypeList.splice(index,1);
    };
    
    $scope.disable=function(warrantyType){
    	$scope.saveWarranty(warrantyType,'Disable');
    };
    $scope.createObject=function(){
    	$scope.warrantyType={};
    };
    
    // Nitin
	$scope.getAllActorsByTenantIdNSolCatId = function(tenantId, solutionCategoryId) 
	{
		 motorRepairService.getAllActorsByTenantIdNSolCatId(
						configParameter.tenantId,
						configParameter.programId)					 
	.then(function success(response) 
	     {			
		
		   //console.log("=============Actor List==============");
		   //console.log(response);
		   $scope.actorList = [];
		   $scope.allactorList = response;
		   angular.forEach(response, function(value, key) 
		           {
		                 $scope.actorList.push(key);
		           });
		 },
		 function error(error) 
		 {
			$rootScope.errors = [];
			if (error != null) 
			{
				$rootScope.errors
				.push({
						    	code : error.exception,
						     message : error.exceptionMessage
					   });
			} else
			{
				$rootScope.errors
				.push({
							    code : "System Error",
						     message : "Oops Something went wrong . Please contact system administrator"
					   });
			}
		  });
	};
	
	
	/*code for matrices milestone matrix*/
    $scope.matrix={};
    $scope.getMatrixMasterByTenantIdNSolnCatId=function()
    {
    	 motorRepairService.getMatrixMasterByTenantIdNSolnCatId('SIEMENS',1)  
         .then(
               function success(response)
                {      
            	   console.log("data for admin");			
         			console.log(response);
         			$scope.matrix=$scope.convertToBinary(response);
         			console.log($scope.matrix.matricesMaster[0].actorMatricesMap);
                }, 
            function error(error) {$rootScope.errors = [];
            if (error != null) {
            	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
              } else {
                $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
              } 
          });   
    };
    
    $scope.convertToBinary=function(list)
    {
    	
    	angular.forEach(list.matricesMaster,function(matrix) {
					
    		var number=matrix.matricesType;
    		var converted=[]
    		while(number>=1){converted.push(number%2); number=Math.floor(number/2);}
    		while(converted.length<8){converted.push(0);}
    		
    		matrix["matricesBinary"] = converted;
		});
    	return list;
    };
    
    $scope.ConvertBinaryToDecimal=function(list)
    {
    	var binary="";
    	for(var i=list.length;i>=0;i--)
    		{
    		binary=binary+list[i-1];
    		}
    	var decimal = parseInt(binary, 2);
    	return decimal;
    }
    
    $scope.DuplicateMatrixList={};
    $scope.formEdit=function(obj)
    {
    	$scope.DuplicateMatrixList[obj.matricesId]=angular.copy(obj);
    	
    };
    
    $scope.formCancel=function(obj)
    {
    	
    	var oldObj=($scope.DuplicateMatrixList[obj.matricesId]);
    	var index=$scope.matrix.matricesMaster.indexOf(obj);
    	
    	$scope.matrix.matricesMaster[index]=oldObj;
    	
    };
    
    $scope.saveMatrix=function(obj)
    {
    	var matrices=angular.copy(obj);
    	matrices.matricesType=($scope.ConvertBinaryToDecimal(obj.matricesBinary));
    	delete matrices['matricesBinary'];
    	matrices.matrixId=$scope.matrix.matrixId;
    	$scope.createUpdateMatricesMaster(matrices);
    };
    
    $scope.createUpdateMatricesMaster=function(matrices)
    {
    	console.log(matrices);
    	motorRepairService.createUpdateMatricesMaster(matrices).then(function success(response)
                {      			
         			console.log(response);
                }, 
            function error(error) {$rootScope.errors = [];
            if (error != null) {
            	  $rootScope.errors.push({ code: error.exception, message:  error.exceptionMessage });
              } else {
                $rootScope.errors.push({ code : "System Error",message : "Oops Something went wrong . Please contact system administrator" });
              } 
          });   
    };
    
    $scope.saveWarranty=function(warrantyTypeDTO,Type){
    	
    	var warrantyTypeDetail=warrantyTypeDTO;
    	if(warrantyTypeDetail.configId==null){
    		
    		warrantyTypeDetail.configType = 'WARRANTY_TYPE';
    		warrantyTypeDetail.tenantId = configParameter.tenantId;
    		warrantyTypeDetail.solutionCategoryId = configParameter.programId;
    		warrantyTypeDetail.configVisiblity = 1;
    		warrantyTypeDetail.modifiedByRefId=$rootScope.user.userId;
    		warrantyTypeDetail.createdByRefId=$rootScope.user.userId;
    		warrantyTypeDetail.configEnabled = 1;
    		warrantyTypeDetail.configAlias = warrantyTypeDTO.name;
    		
    	}else{
    		
    		warrantyTypeDetail={
        			configAlias : warrantyTypeDTO.name,
        			configDesc : warrantyTypeDTO.configDesc,
        			configId : warrantyTypeDTO.configId,
        			modifiedByRefId : $rootScope.user.userId,
        			configEnabled : $scope.value
        	};	
    	}
    	console.log(warrantyTypeDetail);
    	adminService.saveConfigDetail(warrantyTypeDetail).then(
				function success(response) {
					if(response){
						warrantyTypeDTO.showText=false;
						console.log(response);
						if(Type=='Save'){
							$scope.warrantyTypeList.push(warrantyTypeDetail);
							$scope.warrantyType=null;
							 $scope.motorForm.newWarrantyModal.$setPristine();
						}
						$scope.warrantyTypeListMain=angular.copy($scope.warrantyTypeList);
						 $("#warranty-modal").modal('hide');
					}
				},
				function error(error) {
					$rootScope.errors = [];
					if (error != null) {
						$rootScope.errors
								.push({
									code : error.exception,
									message : error.exceptionMessage
								});
					} else {
						$rootScope.errors
								.push({
									code : "System Error",
									message : "Oops Something went wrong . Please contact system administrator"
								});
					}
				});
    };
    
    
    $scope.getConfigDetailByTypeNSubType = function(configType,
			configSubType, subscope) {
		if (typeof $scope[subscope] == 'undefined') {
			motorRepairService
					.getConfigDetailByTypeNSubType(configType,
							configSubType)
					.then(
							function success(response) {
								$scope[subscope] = '';
								$scope[subscope] = response;
							},
							function error(error) {
								$rootScope.errors = [];
								if (error != null) {
									$rootScope.errors
											.push({
												code : error.exception,
												message : error.exceptionMessage
											});
								} else {
									$rootScope.errors
											.push({
												code : "System Error",
												message : "Oops Something went wrong . Please contact system administrator"
											});
								}
							});
		}
	};
	
	$scope.refreshConfig=function(){
		adminService.refreshConfigDetails(configParameter.tenantId,configParameter.programId).then(
				function success(response) {
					if(response){
						$rootScope.notifyAlert({title: "Success ", notification: "Refershed Successfully"});
					}
				},
				function error(error) {
				});
	};
	
});
siemensMotorRepairApp.controller('systemAdminController',function($scope,$timeout, $rootScope, adminService, motorRepairService, configParameter) {

		$scope.init=function(){
			$scope.selectedActor="Select Actor";
			$scope.selectedRole="Select Role Reference";
			$scope.getAllActorsList();
			$scope.getAllActorsCPRoleMapList();
			$scope.systemMapData={};

		}
		$scope.getAllActorsCPRoleMapList=function(){
			$scope.selectedActor="Select Actor";
			$scope.selectedRole="Select Role Reference";
			adminService.getAllActorsCPRoleMapList(configParameter.tenantId,configParameter.programId).then(
					function success(response) {
					
						$scope.systemMapData=response;
						$scope.systemCopyMapData=angular.copy($scope.systemMapData);
					},
					function error(error) {
						
					});
		}
		$scope.filterByActorNull=function(obj){
			if(obj.actorMaster==null){
				return true;
			}else{
				return false;
			}
			
		};
		$scope.filterByActorMap=function(obj){
			if(obj.actorMaster==null){
				return false;
			}else{
				return true;
			}
			
		}
		$scope.getAllActorsList=function(){
			adminService.getAllActorsList(configParameter.tenantId,configParameter.programId).then(
					function success(response) {
						$scope.systemActorsList=response;
					},
					function error(error) {
						
					});
		}
		
		$scope.deleteActorReference=function(map){
			$rootScope.notifier({title: "warning", notification: "Are You Sure you want to remove this Actor Reference?", type: "confirm"}, function(resolve) {
				if (resolve) {
					var obj= $scope.getUpdateObj(map);
					adminService.updateCPRoleReferenceEmailId(obj).then(
							function success(response) {
								$scope.getAllActorsCPRoleMapList();
							},
							function error(error) {
								
							});
				}
			});
			
		};
		$scope.saveSystemMapData=function(error,map){
			if(error){
			    $scope.notifyAlert({'title' : "Error!",'notification':'Please Correct the email!'});
				return;
			}else{
				//console.log(JSON.stringify(map));
				var obj= $scope.getUpdateObj(map);
				obj.actorMaster={"actorId" : map.actorMaster.actorId };
				adminService.updateCPRoleReferenceEmailId(obj).then(
						function success(response) {
							map.isedit=false;
						},
						function error(error) {
							
						});
			
			}
		};
		$scope.getUpdateObj=function(map){
			return {
				  "id" : map.id,
				  "groupEmailId" : map.groupEmailId,
				  "cpRoleReferenceName" : map.cpRoleReferenceName,
				  "aliasName" : map.aliasName,
				  "oldCPRoleReferenceName" : map.oldCPRoleReferenceName,
				  "newCPRoleReferenceName" :  map.newCPRoleReferenceName,
				  "tenantId" : map.tenantId,
				  "solutionCategoryId" : map.solutionCategoryId,
				  "createdOn" : map.createdOn,
				  "createdBy" : map.createdBy,
				  "modifiedBy":map.modifiedBy,
				  "enabled":map.enabled,
				  "visible":map.visible
				};
		}
		$scope.resetSystemMapData=function(map){
			for(var i=0;i<$scope.systemCopyMapData.length;i++){
				if($scope.systemCopyMapData[i].id==map.id){
					$scope.systemMapData[i]=$scope.systemCopyMapData[i];
					$scope.systemCopyMapData=angular.copy($scope.systemMapData);
					break;
				}
			}
		}
		$scope.mapSystemActor=function(selectedActor,selectedRole){
			var sa=JSON.parse(selectedActor);
			var sr=JSON.parse(selectedRole);
			var obj= $scope.getUpdateObj(sr);
			obj.actorMaster={"actorId" :sa.actorId };
			adminService.mapCPRoleReferenceTOActorId(obj).then(
					function success(response) {
						$scope.notifyAlert({'title' : "Success!",'notification':'Role is mapped with actor successfully !'});
						$scope.getAllActorsCPRoleMapList();
					},
					function error(error) {
					});
		}
		$scope.init();
});

