package net.atos.motorrepairmgmt.repository;

import java.util.List;
import net.atos.motorrepairmgmt.entity.ParallelProcess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603975
 * 
 */

public interface ParallelProcessRepository extends JpaRepository<ParallelProcess, Long> {
	@Query("select p from ParallelProcess p where p.parallelProcessState=:parallelProcessState")
	List<ParallelProcess> findParallelProcessByParallelProcessState(
			@Param("parallelProcessState") String parallelProcessState);

	@Query("select p from ParallelProcess p where p.parallelProcessThreadId=:parallelProcessThreadId")
	ParallelProcess findParallelProcessByParallelProcessThreadId(@Param("parallelProcessThreadId") Long parallelProcessThreadId);

	@Query("select p from ParallelProcess p where p.parallelProcessId=:parallelProcessId")
	List<ParallelProcess> findParallelProcessByParallelProcessId(@Param("parallelProcessId") String parallelProcessId);
	
	@Query("select p from ParallelProcess p where p.parallelProcessType=:parallelProcessType")
	List<ParallelProcess> findParallelProcessByType(@Param("parallelProcessType") String parallelProcessType);
	
	@Query("select p from ParallelProcess p where p.parallelProcessId=:parallelProcessId and p.parallelProcessState = :parallelProcessState")
	List<ParallelProcess> findByParallelProcessIdAndState(@Param("parallelProcessId") String parallelProcessId, @Param("parallelProcessState") String parallelProcessState);
	
	@Query("SELECT p from ParallelProcess p where p.parallelProcessId=:parallelProcessId AND p.tenantId=:tenantId AND p.solutionCategoryId=:solutionCategoryId  ")
	ParallelProcess findParallelProcessByParallelProcessIdAndTenantIdAndSolCatId(
			@Param("parallelProcessId") Long parallelProcessId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
}
