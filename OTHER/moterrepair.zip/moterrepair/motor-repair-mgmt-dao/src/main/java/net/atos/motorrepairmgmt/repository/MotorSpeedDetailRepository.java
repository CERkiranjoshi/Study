package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a603981
 *
 */
public interface MotorSpeedDetailRepository extends JpaRepository<MotorSpeedDetail, Long> {
}
