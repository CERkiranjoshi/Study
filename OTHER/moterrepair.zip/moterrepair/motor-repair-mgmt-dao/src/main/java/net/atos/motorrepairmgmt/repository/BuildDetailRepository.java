/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.BuildDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 *
 */
public interface BuildDetailRepository extends JpaRepository<BuildDetail, Long> {
	
	@Query("SELECT bd from BuildDetail bd where bd.tenantId=:tenantId and bd.solutionCategoryId=:solCatId and isCurrent= 1")
	public BuildDetail getCurrentBuildDetail(@Param ("tenantId")String tenantId,@Param ( "solCatId") String solCategoryId);
}
