package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.FSEVisitDetail;
import net.atos.motorrepairmgmt.entity.MotorAttachmentDetail;
import net.atos.motorrepairmgmt.entity.MotorOrderDetail;
import net.atos.motorrepairmgmt.entity.MotorSparesDetail;
import net.atos.motorrepairmgmt.entity.ParallelProcess;
import net.atos.motorrepairmgmt.entity.SubProcessFields;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a610039
 * 
 */
public interface SubProcessFieldsRepository extends JpaRepository<SubProcessFields, Long> {

	@Query("SELECT spf from SubProcessFields spf where spf.tenantId=:tenantId")
	List<SubProcessFields> findAllSubProcessFieldsByTenantId(@Param("tenantId") String tenantId);

	@Query("SELECT spf from SubProcessFields spf where spf.frameSize=:frameSize")
	List<SubProcessFields> findSubProcessFieldsByFrameSize(@Param("frameSize") Integer frameSize);

	@Query("SELECT spf from SubProcessFields spf where spf.grnVrreId=:grnVrreId")
	List<SubProcessFields> findSubProcessFieldsByGrnVrreId(@Param("grnVrreId") String grnVrreId);

	@Query("SELECT spf.motorSparesDetails from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<MotorSparesDetail> findMotorSparesDetailsByWlfwSubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("SELECT spf.motorAttachmentDetails from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<MotorAttachmentDetail> findMotorAttachmentDetailByWlfwSubProcessId(
			@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("SELECT spf.fSEVisitDetails from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<FSEVisitDetail> findFSEVisitDetailByWlfwSubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("SELECT spf.parallelProcess from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<ParallelProcess> findParallelProcessByWlfwSubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("SELECT spf.motorOrderDetails from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<MotorOrderDetail> findMotorOrderDetailByWlfwSubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("SELECT spf.arcRefId from SubProcessFields spf where spf.wlfwSubProcessId=:subProcessId")
	Long findARCRefIdBySubProcessId(@Param("subProcessId") Long wlfwSubProcessId);
	
	@Query("SELECT spf from SubProcessFields spf where spf.subProcState=:subProcState and spf.masterWorkflowFields.masterWorkflowFieldId=:masterWorkflowId")
	List<SubProcessFields> findSubProcessFieldsByStateAndMasterWorkflowId(@Param("subProcState") Integer subProcState,
			@Param("masterWorkflowId") Long masterWorkflowId);
	
	@Query("SELECT spf from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId AND spf.tenantId=:tenantId AND spf.solutionCategoryId=:solutionCategoryId  ")
	SubProcessFields findSubProcessFieldsByWlfwSubProcessIdAndTenantIdAndSolCatId(
			@Param("wlfwSubProcessId") Long wlfwSubProcessId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
	
	@Query("SELECT spf from SubProcessFields spf where spf.motorSnNum=:motorSnNum AND spf.tenantId=:tenantId AND spf.solutionCategoryId=:solutionCategoryId  ")
	List<SubProcessFields> findSubProcessFieldsByMotorSnNumAndTenantIdAndSolCatId(
			@Param("motorSnNum") String motorSnNum,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
	
	@Query("select spf.motorAttachmentDetails from SubProcessFields spf where spf.wlfwSubProcessId=:wlfwSubProcessId")
	List<MotorAttachmentDetail> findAllMotorAttachmentDetailBySubprocesssId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("select spfm from SubProcessFields spf join spf.motorAttachmentDetails spfm where spf.wlfwSubProcessId=:wlfwSubProcessId AND spfm.isInternal=:isInternal AND spfm.isDeleted=:isDeleted")
	List<MotorAttachmentDetail> findAllMotorAttachmentDetailBySubprocesssIdAndIsInternal(@Param("wlfwSubProcessId") Long wlfwSubProcessId,@Param("isInternal") Integer isInternal,@Param("isDeleted") Integer isDeleted);
	
	@Query("SELECT  spf from SubProcessFields spf where spf.masterWorkflowFields.gspRefNo=:gspRefNo  ")
	List<SubProcessFields> findSubProcessFieldsByGSPRefNo(@Param("gspRefNo") String gspRefNo);
	
	@Query("SELECT  spf from SubProcessFields spf  left join fetch spf.subProcessGroupDetail where spf.masterWorkflowFields.masterWorkflowFieldId=:masterWorkflowId")
	List<SubProcessFields> findSubProcessFieldsByMasterWorkflowId(@Param("masterWorkflowId") Long id);

	@Query("SELECT  spf.subProcessGroupDetail.groupId from SubProcessFields spf  where spf.wlfwSubProcessId=:wlfwSubProcessId")
	Long findSubProcessFieldsGroupIdBywlfwSubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

}
