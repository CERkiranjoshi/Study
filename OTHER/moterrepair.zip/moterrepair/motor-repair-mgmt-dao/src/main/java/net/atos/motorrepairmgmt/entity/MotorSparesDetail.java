/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775
 * 
 */
@Entity
@Table(name = "rmt_motor_spares_detail")
public class MotorSparesDetail extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5769897397204715204L;

	@Id
	@Column(name = "material_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long materialId;

	@Column(name = "material_code", length = 9)
	private String materialCode;

	@Column(name = "material_number", length = 9)
	private String materialNumber;

	@Column(name = "material_desc", length = 200)
	private String materialDesc;

	@Column(name = "qty")
	private Integer qty;

	@Column(name = "material_rate_per_unit")
	private Float materialRatePerUnit;

	@Column(name = "material_dispatch_to_address", length = 100)
	private String materialDispatchToAddress;

	@Column(name = "is_cts")
	private Integer isCts;

	@Column(name = "received_by_lc_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receivedByLcOn;

	@Column(name = "received_by_lc_status")
	private Integer receivedByLcStatus;

	@Column(name = "received_by_lc_ref_id", length = 20)
	private String receivedByLcRefId;

	@Column(name = "dispatched_on")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dispatchedOn;

	@Column(name = "dispatched_by_ref_id", length = 20)
	private String dispatchedByRefId;

	@Column(name = "dispatch_docket_num", length = 60)
	private String dispatchDocketNum;

	@Column(name = "dispatch_status")
	private Integer dispatchStatus;

	@Column(name = "received_by_arc_on")
	@Temporal(TemporalType.TIMESTAMP)
    private Date receivedByArcOn;

	@Column(name = "received_by_arc_ref_id", length = 20)
	private String receivedByArcRefId;

	@Column(name = "received_by_arc_status")
	private Integer receivedByArcStatus;

	@Column(name = "spares_dispatch_rp_req")
	private Integer sparesDispatchRpReq;

	@Column(name = "spares_dispatch_rp_requested_on")
	@Temporal(TemporalType.TIMESTAMP)
    private Date sparesDispatchRpRequestedOn;

	@Column(name = "spares_dispatch_rp_received")
	private Integer sparesDispatchRpReceived;

	@Column(name = "spares_dispatch_rp_received_on")
	@Temporal(TemporalType.TIMESTAMP)
    private Date sparesDispatchRpReceivedOn;

	@Column(name = "external_cost")
	private Float externalCost;

	@Column(name = "spares_comment", length = 200)
	private String sparesComment;

	@Column(name = "item_unit")
	private String itemUnit;                
	
	@Column(name = "ship_to_party_type",length=10)
	private Integer shipToPartyType;
	
	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = "created_by_ref_id")
    private String createdByRefId;
	
	//get updated on review spares list
	@Column(name = "reviewed_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date reviewdOn;

	@Column(name = "reviewed_by_ref_id")
    private String reviewedByRefId;
	
	@Column(name = "spare_status")
    private Integer spareStatus;
	
	@Column(name = "spare_po_number")
    private String sparePONumber;
	
	@Column(name = "spare_est_delivery_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date spareEstDeliveryDate; 

	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;
	
	@Column(name = "received_by_ccc_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receivedByCCCOn;

	@Column(name = "received_by_ccc_ref_id", length = 20)
	private String receivedByCCCRefId;

	@Column(name = "received_by_ccc_status")
	private Integer receivedByCCCStatus;
		
	@Column(name = "repair_status")
	private String repairStatus;
	
	/**
	 * @return the receivedByCCCOn
	 */
	public Date getReceivedByCCCOn() {
		return receivedByCCCOn;
	}

	/**
	 * @param receivedByCCCOn the receivedByCCCOn to set
	 */
	public void setReceivedByCCCOn(Date receivedByCCCOn) {
		this.receivedByCCCOn = receivedByCCCOn;
	}

	/**
	 * @return the receivedByCCCRefId
	 */
	public String getReceivedByCCCRefId() {
		return receivedByCCCRefId;
	}

	/**
	 * @param receivedByCCCRefId the receivedByCCCRefId to set
	 */
	public void setReceivedByCCCRefId(String receivedByCCCRefId) {
		this.receivedByCCCRefId = receivedByCCCRefId;
	}

	/**
	 * @return the receivedByCCCStatus
	 */
	public Integer getReceivedByCCCStatus() {
		return receivedByCCCStatus;
	}

	/**
	 * @param receivedByCCCStatus the receivedByCCCStatus to set
	 */
	public void setReceivedByCCCStatus(Integer receivedByCCCStatus) {
		this.receivedByCCCStatus = receivedByCCCStatus;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}
	/**
	 * @return the shipToPartyType
	 */
	public Integer getShipToPartyType() {
		return shipToPartyType;
	}

	/**
	 * @param shipToPartyType the shipToPartyType to set
	 */
	public void setShipToPartyType(Integer shipToPartyType) {
		this.shipToPartyType = shipToPartyType;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the reviewdOn
	 */
	public Date getReviewdOn() {
		return reviewdOn;
	}

	/**
	 * @param reviewdOn the reviewdOn to set
	 */
	public void setReviewdOn(Date reviewdOn) {
		this.reviewdOn = reviewdOn;
	}

	/**
	 * @return the reviewedByRefId
	 */
	public String getReviewedByRefId() {
		return reviewedByRefId;
	}

	/**
	 * @param reviewedByRefId the reviewedByRefId to set
	 */
	public void setReviewedByRefId(String reviewedByRefId) {
		this.reviewedByRefId = reviewedByRefId;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit
	 *            the itemUnit to set
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the materialId
	 */
	public Long getMaterialId() {
		return materialId;
	}

	/**
	 * @param materialId
	 *            the materialId to set
	 */
	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}

	/**
	 * @return the materialCode
	 */
	public String getMaterialCode() {
		return materialCode;
	}

	/**
	 * @param materialCode
	 *            the materialCode to set
	 */
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	/**
	 * @return the materialNumber
	 */
	public String getMaterialNumber() {
		return materialNumber;
	}

	/**
	 * @param materialNumber
	 *            the materialNumber to set
	 */
	public void setMaterialNumber(String materialNumber) {
		this.materialNumber = materialNumber;
	}

	/**
	 * @return the materialDesc
	 */
	public String getMaterialDesc() {
		return materialDesc;
	}

	/**
	 * @param materialDesc
	 *            the materialDesc to set
	 */
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}
	

	/**
	 * @return the qty


   	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the materialRatePerUnit
	 */
	public Float getMaterialRatePerUnit() {
		return materialRatePerUnit;
	}

	/**
	 * @param materialRatePerUnit
	 *            the materialRatePerUnit to set
	 */
	public void setMaterialRatePerUnit(Float materialRatePerUnit) {
		this.materialRatePerUnit = materialRatePerUnit;
	}

	/**
	 * @return the materialDispatchToAddress
	 */
	public String getMaterialDispatchToAddress() {
		return materialDispatchToAddress;
	}

	/**
	 * @param materialDispatchToAddress
	 *            the materialDispatchToAddress to set
	 */
	public void setMaterialDispatchToAddress(String materialDispatchToAddress) {
		this.materialDispatchToAddress = materialDispatchToAddress;
	}

	/**
	 * @return the isCts
	 */
	public Integer getIsCts() {
		return isCts;
	}

	/**
	 * @param isCts
	 *            the isCts to set
	 */
	public void setIsCts(Integer isCts) {
		this.isCts = isCts;
	}

	/**
	 * @return the receivedByLogisticsOn
	 */
	public Date getReceivedByLcOn() {
		return receivedByLcOn;
	}

	/**
	 * @param receivedByLogisticsOn
	 *            the receivedByLogisticsOn to set
	 */
	public void setReceivedByLcOn(Date receivedByLcOn) {
		this.receivedByLcOn = receivedByLcOn;
	}

	/**
	 * @return the receivedByLogisticsStatus
	 */
	public Integer getReceivedByLcStatus() {
		return receivedByLcStatus;
	}

	/**
	 * @param receivedByLogisticsStatus
	 *            the receivedByLogisticsStatus to set
	 */
	public void setReceivedByLcStatus(Integer receivedByLcStatus) {
		this.receivedByLcStatus = receivedByLcStatus;
	}

	/**
	 * @return the receivedByLogisticsRefId
	 */
	public String getReceivedByLcRefId() {
		return receivedByLcRefId;
	}

	/**
	 * @param receivedByLogisticsRefId
	 *            the receivedByLogisticsRefId to set
	 */
	public void setReceivedByLcRefId(String receivedByLcRefId) {
		this.receivedByLcRefId = receivedByLcRefId;
	}

	/**
	 * @return the dispatchedOn
	 */
	public Date getDispatchedOn() {
		return dispatchedOn;
	}

	/**
	 * @param dispatchedOn
	 *            the dispatchedOn to set
	 */
	public void setDispatchedOn(Date dispatchedOn) {
		this.dispatchedOn = dispatchedOn;
	}

	/**
	 * @return the dispatchedByRefId
	 */
	public String getDispatchedByRefId() {
		return dispatchedByRefId;
	}

	/**
	 * @param dispatchedByRefId
	 *            the dispatchedByRefId to set
	 */
	public void setDispatchedByRefId(String dispatchedByRefId) {
		this.dispatchedByRefId = dispatchedByRefId;
	}

	/**
	 * @return the dispatchDocketNum
	 */
	public String getDispatchDocketNum() {
		return dispatchDocketNum;
	}

	/**
	 * @param dispatchDocketNum
	 *            the dispatchDocketNum to set
	 */
	public void setDispatchDocketNum(String dispatchDocketNum) {
		this.dispatchDocketNum = dispatchDocketNum;
	}

	/**
	 * @return the dispatchStatus
	 */
	public Integer getDispatchStatus() {
		return dispatchStatus;
	}

	/**
	 * @param dispatchStatus
	 *            the dispatchStatus to set
	 */
	public void setDispatchStatus(Integer dispatchStatus) {
		this.dispatchStatus = dispatchStatus;
	}

	/**
	 * @return the receivedByArcOn
	 */
	public Date getReceivedByArcOn() {
		return receivedByArcOn;
	}

	/**
	 * @param receivedByArcOn
	 *            the receivedByArcOn to set
	 */
	public void setReceivedByArcOn(Date receivedByArcOn) {
		this.receivedByArcOn = receivedByArcOn;
	}

	/**
	 * @return the receivedByArcRefId
	 */
	public String getReceivedByArcRefId() {
		return receivedByArcRefId;
	}

	/**
	 * @param receivedByArcRefId
	 *            the receivedByArcRefId to set
	 */
	public void setReceivedByArcRefId(String receivedByArcRefId) {
		this.receivedByArcRefId = receivedByArcRefId;
	}

	/**
	 * @return the receivedByArcStatus
	 */
	public Integer getReceivedByArcStatus() {
		return receivedByArcStatus;
	}

	/**
	 * @param receivedByArcStatus
	 *            the receivedByArcStatus to set
	 */
	public void setReceivedByArcStatus(Integer receivedByArcStatus) {
		this.receivedByArcStatus = receivedByArcStatus;
	}

	/**
	 * @return the sparesDispatchRoadPermitReq
	 */
	public Integer getSparesDispatchRpReq() {
		return sparesDispatchRpReq;
	}

	/**
	 * @param sparesDispatchRpReq
	 *            the sparesDispatchRoadPermitReq to set
	 */
	public void setSparesDispatchRpReq(Integer sparesDispatchRpReq) {
		this.sparesDispatchRpReq = sparesDispatchRpReq;
	}

	/**
	 * @return the sparesDispatchRoadPermitRequestedOn
	 */
	public Date getSparesDispatchRpRequestedOn() {
		return sparesDispatchRpRequestedOn;
	}

	/**
	 * @param sparesDispatchRoadPermitRequestedOn
	 *            the sparesDispatchRoadPermitRequestedOn to set
	 */
	public void setSparesDispatchRpRequestedOn(Date sparesDispatchRpRequestedOn) {
		this.sparesDispatchRpRequestedOn = sparesDispatchRpRequestedOn;
	}

	/**
	 * @return the sparesDispatchRoadPermitReceived
	 */
	public Integer getSparesDispatchRpReceived() {
		return sparesDispatchRpReceived;
	}

	/**
	 * @param sparesDispatchRoadPermitReceived
	 *            the sparesDispatchRoadPermitReceived to set
	 */
	public void setSparesDispatchRpReceived(Integer sparesDispatchRpReceived) {
		this.sparesDispatchRpReceived = sparesDispatchRpReceived;
	}

	/**
	 * @return the sparesDispatchRoadPermitReceivedOn
	 */
	public Date getSparesDispatchRpReceivedOn() {
		return sparesDispatchRpReceivedOn;
	}

	/**
	 * @param sparesDispatchRoadPermitReceivedOn
	 *            the sparesDispatchRoadPermitReceivedOn to set
	 */
	public void setSparesDispatchRpReceivedOn(Date sparesDispatchRpReceivedOn) {
		this.sparesDispatchRpReceivedOn = sparesDispatchRpReceivedOn;
	}

	/**
	 * @return the externalCost
	 */
	public Float getExternalCost() {
		return externalCost;
	}

	/**
	 * @param externalCost
	 *            the externalCost to set
	 */
	public void setExternalCost(Float externalCost) {
		this.externalCost = externalCost;
	}

	/**
	 * @return the sparesComment
	 */
	public String getSparesComment() {
		return sparesComment;
	}

	/**
	 * @param sparesComment
	 *            the sparesComment to set
	 */
	public void setSparesComment(String sparesComment) {
		this.sparesComment = sparesComment;
	}

	public Integer getSpareStatus() {
		return spareStatus;
	}

	public void setSpareStatus(Integer spareStatus) {
		this.spareStatus = spareStatus;
	}

	public String getSparePONumber() {
		return sparePONumber;
	}

	public void setSparePONumber(String sparePONumber) {
		this.sparePONumber = sparePONumber;
	}

	public Date getSpareEstDeliveryDate() {
		return spareEstDeliveryDate;
	}

	public void setSpareEstDeliveryDate(Date spareEstDeliveryDate) {
		this.spareEstDeliveryDate = spareEstDeliveryDate;
	}

	/**
	 * @return the repairStatus
	 */
	public String getRepairStatus() {
		return repairStatus;
	}

	/**
	 * @param repairStatus the repairStatus to set
	 */
	public void setRepairStatus(String repairStatus) {
		this.repairStatus = repairStatus;
	}
	
}
