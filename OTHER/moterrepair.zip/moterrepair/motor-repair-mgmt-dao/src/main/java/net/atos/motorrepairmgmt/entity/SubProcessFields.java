/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775
 *
 */
@Entity
@Table(name = "rmt_motor_sub_proc_fields") 
public class SubProcessFields extends RMTBasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7126766669160493143L;

	@Id
	@Column(name = "subprocess_id",insertable = true, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long wlfwSubProcessId;

	@Column(name = "z_option_val",length=100)
	private String zOptionVal;

	@Column(name = "motor_spiridon_material_code",length=100)
	private String motorSpiridonMaterialCode;

	@Column(name = "motor_ibase_num",length=100)
	private String motorIBaseNum;

	@Column(name = "motor_sn_num",length=30)
	private String motorSnNum;

	@Column(name = "fault_desc",length=2000)
	private String faultDesc;

	@Column(name = "mlfb_spiridon",length=30)
	private String mlfbSpiridon;

	@Column(name = "motor_material_spec")
	private String motorMaterialSpec;

	@Column(name = "frame_size")
	private Integer frameSize;

	@Column(name = "initial_warranty_claim")
	private Integer initialWarrantyClaim;

	@Column(name = "final_warranty_state")
	private Integer finalWarrantyState;
	
	@Column(name = "motor_ship_to_address",length=255)
	private String motorShipToAddress;
	
	@Column(name = "sub_warranty_type")
	private Integer subWarrantyType;

	@Column(name = "sales_grp_ref_id",length=50)
	private String salesGrpRefId;

	@Column(name = "sales_div_ref_id",length=50)
	private String salesDivRefId;

	@Column(name = "sales_office_ref_id",length=50)
	private String salesOfficeRefId;

	@Column(name = "sales_org_ref_id",length=50)
	private String salesOrgRefId;

	@Column(name = "product_grp",length=50)
	private String productGrp;

	@Column(name = "region_id",length=50)
	private String regionId;

	@Column(name = "arc_code",length=50)
	private String arcCode;

	@Column(name = "arc_Ref_Id")
	private Long arcRefId;

	@Column(name = "arc_job_ref_no",length=50)
	private String arcJobRefNo;

	@Column(name = "spridion_ntfn_no",length=12)
	private String spiridonNtfnNo;

	@Column(name = "vrre_created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date vrreCreatedOn;

	@Column(name = "repair_sales_order_no",length=50)
	private String repairSalesOrderNo;

	@Column(name = "arc_motor_received_state")
	private Integer arcMotorReceivedState;

	@Column(name = "cust_motor_dispatched_state")
	private Integer custMotorDispatchedState;

	@Column(name = "is_cts")
	private Integer isCts;

	@Column(name = "po_ref_no",length=50)
	private String poRefNo;

	@Column(name = "quotation_ref_num",length=50)
	private String quotationRefNum;

	@Column(name = "quotation_acceptance")
	private Integer quotationAcceptance;

	@Column(name = "grn_vrre_id",length=50)
	private String grnVrreId;

	@Column(name = "DI_PGI_Number",length=50)
	private String dIPGINumber;

	@Column(name = "cost_cleared_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date costClearedOn;

	@Column(name = "invoice_ref_no",length=50)
	private String invoiceRefNo;

	@Column(name = "is_payment_received")
	private Integer isPaymentReceived;

	@Column(name = "has_cleared_cost")
	private Integer hasClearedCost;

	@Column(name = "payment_received_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date paymentReceivedOn;

	@Column(name = "motor_clearance_to_dispatch")
	private Integer motorClearanceToDispatch;

	@Column(name = "motor_dispatch_clearance_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date motorDispatchClearanceOn;

	@Column(name = "arc_repair_clearance")
	private Integer arcRepairClearance;

	@Column(name = "arc_repair_clearance_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date arcRepairClearanceOn;

	@Column(name = "motor_dispatch_road_permit_req")
	private Integer motorDispatchRoadPermitReq;

	@Column(name = "a_report_approved_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date aReportApprovedOn;

	@Column(name = "a_report_approval")
	private Integer aReportApproval;

	@Column(name = "a_report_created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date aReportCreatedOn;

	@Column(name = "is_transit_damage")
	private Integer isTransitDamage;

	@Column(name = "repair_status")
	private Integer repairStatus;

	@Column(name = "motor_dispatch_docket_no",length=100)
	private String motorDispatchDocketNo;

	@Column(name = "quotation_ref_no",length=100)
	private String quotationRefNo;

	@Column(name = "obs_ref_no",length=100)
	private String obsRefNo;

	@Column(name = "spares_po_no",length=100)
	private String sparesPoNo;

	@Column(name = "spare_dispatch_docket_no",length=100)
	private String spareDispatchDocketNo;

	@Column(name = "arc_motor_received_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date arcMotorReceivedOn;

	@Column(name = "arc_motor_dispatch_On")
	@Temporal(TemporalType.TIMESTAMP)
	private Date arcMotorDispatchOn;

	@Column(name = "td_reco_num",length=50)
	private String tdRecoNum;

	@Column(name = "tenant_id",length=50)
	private String tenantId;

	@Column(name = "solution_category_id",length=25)
	private String solutionCategoryId;

	@Column(name = "ts_support_decision")
	private int tsSupportDecision;

	@Column(name = "initial_warranty_claim_set_by_ref_id")
	private String initialWarrantyClaimSetByRefId;

	@Column(name = "final_warranty_state_set_by_ref_id")
	private String finalWarrantyStateSetByRefId;

	@Column(name = "final_warranty_state_set_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date finalWarrantyStateSetOn;

	@Column(name = "final_warranty_state_modified_by_ref_id")
	private String finalWarrantyStateModifiedByRefId;

	@Column(name = "final_warranty_state_modified_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date finalWarrantyStateModifiedOn;

	@Column(name = "ccl_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date cclOn;

	@Column(name = "has_ccl")
	private Integer hasCcl;

	@Column(name = "sub_proc_state")
	private Integer subProcState;

	@Column(name = "ccl_teco")
	private Integer cclTeco;

	@Column(name = "mdc_teco")
	private Integer mdcTeco;

	@Column(name = "notification_teco")
	private Integer notificationTeco;

	@Column(name = "sub_proc_closed_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date subProcClosedOn;

	@Column(name = "sub_proc_closed_by_ref_id",length=100)
	private String subProcClosedByRefId;

	@Column(name = "is_job_completed")
	private Integer isJobCompleted;

	@Column(name = "job_completed_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date jobCompletedOn;

	@Column(name = "job_completed_by_ref_id",length=100)
	private String jobCompletedByRefId;

	@Column(name = "is_job_closed")
	private Integer isJobClosed;

	@Column(name = "job_closed_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date jobClosedOn;

	@Column(name = "job_closed_by_ref_id",length=100)
	private String jobClosedByRefId;

	@Column(name = "cust_feedback")
	private Integer custFeedback;

	@Column(name = "batch_proc_id")
	private String batchProcId;

	@Column(name = "created_by_ref_id" ,length=100)
	private String createdByRefId;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@Column(name = "dispatch_mode")
	private Integer dispatchMode;
	
	@Column(name = "other_mode_details",length=200)
	private String otherModeDetails;
	
	@Column(name = "transporter_name",length=200)
	private String transporterName;
	
	@Column(name = "transporter_docketNo",length=200)
	private String transporterDocketNo;
	
	@Column(name = "replacementStatus")
	private Integer replacement_status;
	
	@Column(name = "replacementStateSetById", length = 50)
	private String replacement_state_set_by_id;
	
	@Column(name = "replacementStateSetOn")
	@Temporal(TemporalType.TIMESTAMP)
	private Date replacement_state_set_on;
	
	//Customer PO Received Date
	@Column(name = "custPO_Rec_Date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date custPORecDate;
	
	@Column(name = "is_workflow_closed")
	private Integer isWorkflowClosed;
	
    @OneToMany(fetch = FetchType.LAZY, cascade ={CascadeType.MERGE,CascadeType.REMOVE,CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval=true)
	@JoinColumn(name = "subprocess_id")
	private List<MotorSparesDetail> motorSparesDetails;

	@OneToMany(fetch = FetchType.LAZY, cascade =CascadeType.MERGE)
	@JoinColumn(name = "subprocess_id")
	private List<MotorAttachmentDetail> motorAttachmentDetails;

	@OneToMany(fetch = FetchType.LAZY, cascade ={CascadeType.MERGE,CascadeType.REMOVE,CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval=true)
	@JoinColumn(name = "subprocess_id")
	private List<FSEVisitDetail> fSEVisitDetails;

	@OneToMany(fetch = FetchType.LAZY, cascade ={CascadeType.MERGE,CascadeType.REMOVE,CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval=true)
	@JoinColumn(name = "subprocess_id")
	private List<MotorOrderDetail> motorOrderDetails;

	@OneToMany(fetch = FetchType.LAZY, cascade ={CascadeType.MERGE,CascadeType.REMOVE,CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval=true)
	@JoinColumn(name = "subprocess_id")
	private List<ParallelProcess> parallelProcess;

	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.PERSIST})
	@JoinColumn(name = "master_workflow_id",insertable=true,updatable=true)
	private MasterWorkflowFields masterWorkflowFields;
	
	@Column(name = "workflow_closure_type")
	private Integer workflowClosureType; 

	/**
	 * @return the referToTS
	 */
	public Integer getReferToTS() {
		return referToTS;
	}
	
	@Column(name = "is_Cust_Available")
	private Integer isCustAvailable;
	
	/**
	 * @param referToTS the referToTS to set
	 */
	public void setReferToTS(Integer referToTS) {
		this.referToTS = referToTS;
	}

	@OneToMany(fetch = FetchType.LAZY, cascade ={CascadeType.MERGE,CascadeType.REMOVE,CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval=true)
	@JoinColumn(name = "subprocess_id")
	private List<DispatchDetail> dispatchDetail;
	
	@Column(name = "process_instance_id", length = 100)
	private String processInstanceId;
	
	@Column(name = "subject_title",length=100)
	private String subjectTitle;
	
	@Column(name = "is_proforma_invoiced")
	private Integer isProformaInvoiced;
	
	@Column(name = "cust_invoice_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date custInvoiceDate;
	
	@Column(name = "quotationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date quotationDate;

	@Column(name = "received_by_ccc_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receivedByCCCOn;

	@Column(name = "received_by_ccc_ref_id", length = 20)
	private String receivedByCCCRefId;

	@Column(name = "received_by_ccc_status")
	private Integer receivedByCCCStatus;
	
	@Column(name = "refer_To_Task")
	private Integer referToTS;
	
	@Column(name = "refer_TecSupport")
	private Integer referToTecSupport;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "group_id")
	private SubProcessGroupDetail subProcessGroupDetail;
	
	@Column(name = "ship_to_party_type",length=10)
	private Integer shipToPartyType;
	
	@Column(name = "material_dispatch_to_address", length = 100)
	private String materialDispatchToAddress;
	
	@Column(name = "spares_dispatch_rp_req")
	private Integer sparesDispatchRpReq;
	
	
	public Integer getReferToTecSupport() {
		return referToTecSupport;
	}

	public void setReferToTecSupport(Integer referToTecSupport) {
		this.referToTecSupport = referToTecSupport;
	}
	
	/**
	 * @return the shipToPartyType
	 */
	public Integer getShipToPartyType() {
		return shipToPartyType;
	}

	/**
	 * @param shipToPartyType the shipToPartyType to set
	 */
	public void setShipToPartyType(Integer shipToPartyType) {
		this.shipToPartyType = shipToPartyType;
	}

	/**
	 * @return the materialDispatchToAddress
	 */
	public String getMaterialDispatchToAddress() {
		return materialDispatchToAddress;
	}

	/**
	 * @param materialDispatchToAddress the materialDispatchToAddress to set
	 */
	public void setMaterialDispatchToAddress(String materialDispatchToAddress) {
		this.materialDispatchToAddress = materialDispatchToAddress;
	}

	/**
	 * @return the sparesDispatchRpReq
	 */
	public Integer getSparesDispatchRpReq() {
		return sparesDispatchRpReq;
	}

	/**
	 * @param sparesDispatchRpReq the sparesDispatchRpReq to set
	 */
	public void setSparesDispatchRpReq(Integer sparesDispatchRpReq) {
		this.sparesDispatchRpReq = sparesDispatchRpReq;
	}

	/**
	 * @return the receivedByCCCOn
	 */
	public Date getReceivedByCCCOn() {
		return receivedByCCCOn;
	}

	/**
	 * @param receivedByCCCOn the receivedByCCCOn to set
	 */
	public void setReceivedByCCCOn(Date receivedByCCCOn) {
		this.receivedByCCCOn = receivedByCCCOn;
	}

	/**
	 * @return the receivedByCCCRefId
	 */
	public String getReceivedByCCCRefId() {
		return receivedByCCCRefId;
	}

	/**
	 * @param receivedByCCCRefId the receivedByCCCRefId to set
	 */
	public void setReceivedByCCCRefId(String receivedByCCCRefId) {
		this.receivedByCCCRefId = receivedByCCCRefId;
	}

	/**
	 * @return the receivedByCCCStatus
	 */
	public Integer getReceivedByCCCStatus() {
		return receivedByCCCStatus;
	}

	/**
	 * @param receivedByCCCStatus the receivedByCCCStatus to set
	 */
	public void setReceivedByCCCStatus(Integer receivedByCCCStatus) {
		this.receivedByCCCStatus = receivedByCCCStatus;
	}

	/**
	 * @return the quotationDate
	 */
	public Date getQuotationDate() {
		return quotationDate;
	}

	/**
	 * @param quotationDate the quotationDate to set
	 */
	public void setQuotationDate(Date quotationDate) {
		this.quotationDate = quotationDate;
	}

	

	/**
	 * @return the replacement_status
	 */
	public Integer getReplacement_status() {
		return replacement_status;
	}

	/**
	 * @param replacement_status the replacement_status to set
	 */
	public void setReplacement_status(Integer replacement_status) {
		this.replacement_status = replacement_status;
	}

	/**
	 * @return the replacement_state_set_by_id
	 */
	public String getReplacement_state_set_by_id() {
		return replacement_state_set_by_id;
	}

	/**
	 * @param replacement_state_set_by_id the replacement_state_set_by_id to set
	 */
	public void setReplacement_state_set_by_id(String replacement_state_set_by_id) {
		this.replacement_state_set_by_id = replacement_state_set_by_id;
	}

	/**
	 * @return the replacement_state_set_on
	 */
	public Date getReplacement_state_set_on() {
		return replacement_state_set_on;
	}

	/**
	 * @param replacement_state_set_on the replacement_state_set_on to set
	 */
	public void setReplacement_state_set_on(Date replacement_state_set_on) {
		this.replacement_state_set_on = replacement_state_set_on;
	}

	/**
	 * @return the custPORecDate
	 */
	public Date getCustPORecDate() {
		return custPORecDate;
	}

	/**
	 * @param custPORecDate the custPORecDate to set
	 */
	public void setCustPORecDate(Date custPORecDate) {
		this.custPORecDate = custPORecDate;
	}

	/**
	 * @return the subjectTitle
	 */
	public String getSubjectTitle() {
		return subjectTitle;
	}

	/**
	 * @param subjectTitle the subjectTitle to set
	 */
	public void setSubjectTitle(String subjectTitle) {
		this.subjectTitle = subjectTitle;
	}

	/**
	 * @return the processInstanceId
	 */
	public String getProcessInstanceId() {
		return processInstanceId;
	}

	/**
	 * @param processInstanceId the processInstanceId to set
	 */
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	/**
	 * @return the masterWorkflowFields
	 */
	public MasterWorkflowFields getMasterWorkflowFields() {
		return masterWorkflowFields;
	}

	/**
	 * @param masterWorkflowFields
	 *            the masterWorkflowFields to set
	 */
	public void setMasterWorkflowFields(MasterWorkflowFields masterWorkflowFields) {
		this.masterWorkflowFields = masterWorkflowFields;
	}

	/**
	 * @return the wlfwSubProcessId
	 */
	public Long getWlfwSubProcessId() {
		return wlfwSubProcessId;
	}

	/**
	 * @param wlfwSubProcessId
	 *            the wlfwSubProcessId to set
	 */
	public void setWlfwSubProcessId(Long wlfwSubProcessId) {
		this.wlfwSubProcessId = wlfwSubProcessId;
	}

	/**
	 * @return the zOptionVal
	 */
	public String getzOptionVal() {
		return zOptionVal;
	}

	/**
	 * @param zOptionVal
	 *            the zOptionVal to set Z option
	 */
	public void setzOptionVal(String zOptionVal) {
		this.zOptionVal = zOptionVal;
	}

	/**
	 * @return the motorSpiridonMaterialCode
	 */
	public String getMotorSpiridonMaterialCode() {
		return motorSpiridonMaterialCode;
	}

	/**
	 * @param motorSpiridonMaterialCode
	 *            the motorSpiridonMaterialCode to set
	 */
	public void setMotorSpiridonMaterialCode(String motorSpiridonMaterialCode) {
		this.motorSpiridonMaterialCode = motorSpiridonMaterialCode;
	}

	/**
	 * @return the motorIBaseNum
	 */
	public String getMotorIBaseNum() {
		return motorIBaseNum;
	}

	/**
	 * @param motorIBaseNum
	 *            the motorIBaseNum to set
	 */
	public void setMotorIBaseNum(String motorIBaseNum) {
		this.motorIBaseNum = motorIBaseNum;
	}

	/**
	 * @return the motorSnNum
	 */
	public String getMotorSnNum() {
		return motorSnNum;
	}

	/**
	 * @param motorSnNum
	 *            the motorSnNum to set S/N is of 22 blocks of 3 chars
	 *            alphanumeric field
	 */
	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}

	/**
	 * @return the faultDesc
	 */
	public String getFaultDesc() {
		return faultDesc;
	}

	/**
	 * @param faultDesc
	 *            the faultDesc to set Motor Fault Desc
	 */
	public void setFaultDesc(String faultDesc) {
		this.faultDesc = faultDesc;
	}

	/**
	 * @return the mlfbSpiridon
	 */
	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}

	/**
	 * @param mlfbSpiridon
	 *            the mlfbSpiridon to set
	 */
	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}

	/**
	 * @return the motorMaterialSpec
	 */
	public String getMotorMaterialSpec() {
		return motorMaterialSpec;
	}

	/**
	 * @param motorMaterialSpec
	 *            the motorMaterialSpec to set
	 */
	public void setMotorMaterialSpec(String motorMaterialSpec) {
		this.motorMaterialSpec = motorMaterialSpec;
	}

	/**
	 * @return the frameSize
	 */
	public Integer getFrameSize() {
		return frameSize;
	}

	/**
	 * @param frameSize
	 *            the frameSize to set
	 */
	public void setFrameSize(Integer frameSize) {
		this.frameSize = frameSize;
	}

	/**
	 * @return the initialWarrantyClaim
	 */
	public Integer getInitialWarrantyClaim() {
		return initialWarrantyClaim;
	}

	/**
	 * @param initialWarrantyClaim
	 *            the initialWarrantyClaim to set 0 - Out of Warranty; 1 - In
	 *            Warranty
	 */
	public void setInitialWarrantyClaim(Integer initialWarrantyClaim) {
		this.initialWarrantyClaim = initialWarrantyClaim;
	}

	/**
	 * @return the finalWarrantyState
	 */
	public Integer getFinalWarrantyState() {
		return finalWarrantyState;
	}

	/**
	 * @param finalWarrantyState
	 *            the finalWarrantyState to set 0 - Out of Warranty; 1 - In
	 *            Warranty
	 */
	public void setFinalWarrantyState(Integer finalWarrantyState) {
		this.finalWarrantyState = finalWarrantyState;
	}

	/**
	 * @return the motorShipToAddress
	 */
	public String getMotorShipToAddress() {
		return motorShipToAddress;
	}

	/**
	 * @param motorShipToAddress
	 *            the motorShipToAddress to set
	 */
	public void setMotorShipToAddress(String motorShipToAddress) {
		this.motorShipToAddress = motorShipToAddress;
	}

	/**
	 * @return the subWarrantyType
	 */
	public Integer getSubWarrantyType() {
		return subWarrantyType;
	}

	/**
	 * @param subWarrantyType
	 *            the subWarrantyType to set 1: Paid; 2:Void;3-Product Warranty;
	 *            4:Repair Warranty; 5: CTS & contract
	 */
	public void setSubWarrantyType(Integer subWarrantyType) {
		this.subWarrantyType = subWarrantyType;
	}

	/**
	 * @return the salesGrpRefId
	 */
	public String getSalesGrpRefId() {
		return salesGrpRefId;
	}

	/**
	 * @param salesGrpRefId
	 *            the salesGrpRefId to set
	 */
	public void setSalesGrpRefId(String salesGrpRefId) {
		this.salesGrpRefId = salesGrpRefId;
	}

	/**
	 * @return the salesDivRefId
	 */
	public String getSalesDivRefId() {
		return salesDivRefId;
	}

	/**
	 * @param salesDivRefId
	 *            the salesDivRefId to set
	 */
	public void setSalesDivRefId(String salesDivRefId) {
		this.salesDivRefId = salesDivRefId;
	}

	/**
	 * @return the salesOfficeRefId
	 */
	public String getSalesOfficeRefId() {
		return salesOfficeRefId;
	}

	/**
	 * @param salesOfficeRefId
	 *            the salesOfficeRefId to set
	 */
	public void setSalesOfficeRefId(String salesOfficeRefId) {
		this.salesOfficeRefId = salesOfficeRefId;
	}

	/**
	 * @return the salesOrgRefId
	 */
	public String getSalesOrgRefId() {
		return salesOrgRefId;
	}

	/**
	 * @param salesOrgRefId
	 *            the salesOrgRefId to set
	 */
	public void setSalesOrgRefId(String salesOrgRefId) {
		this.salesOrgRefId = salesOrgRefId;
	}

	/**
	 * @return the productGrp
	 */
	public String getProductGrp() {
		return productGrp;
	}

	/**
	 * @param productGrp
	 *            the productGrp to set
	 */
	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	/**
	 * @return the regionId
	 */
	public String getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId
	 *            the regionId to set Region Reference Id
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the arcCode
	 */
	public String getArcCode() {
		return arcCode;
	}

	/**
	 * @param arcCode
	 *            the arcCode to set
	 */
	public void setArcCode(String arcCode) {
		this.arcCode = arcCode;
	}

	/**
	 * @return the arcRefId
	 */
	public Long getArcRefId() {
		return arcRefId;
	}

	
	/**
	 * @return the arcJobRefNo
	 */
	public String getArcJobRefNo() {
		return arcJobRefNo;
	}

	/**
	 * @param arcRefId the arcRefId to set
	 */
	public void setArcRefId(Long arcRefId) {
		this.arcRefId = arcRefId;
	}

	/**
	 * @param arcJobRefNo
	 *            the arcJobRefNo to set
	 */
	public void setArcJobRefNo(String arcJobRefNo) {
		this.arcJobRefNo = arcJobRefNo;
	}

	/**
	 * @return the spiridonNtfnNo
	 */
	public String getSpiridonNtfnNo() {
		return spiridonNtfnNo;
	}

	/**
	 * @param spiridonNtfnNo
	 *            the spiridonNtfnNo to set ZR notification type for ARC; Z8
	 *            Notification type for FSE cases
	 */
	public void setSpiridonNtfnNo(String spiridonNtfnNo) {
		this.spiridonNtfnNo = spiridonNtfnNo;
	}

	/**
	 * @return the vrreCreatedOn
	 */
	public Date getVrreCreatedOn() {
		return vrreCreatedOn;
	}

	/**
	 * @param vrreCreatedOn
	 *            the vrreCreatedOn to set
	 */
	public void setVrreCreatedOn(Date vrreCreatedOn) {
		this.vrreCreatedOn = vrreCreatedOn;
	}

	/**
	 * @return the repairSalesOrderNo
	 */
	public String getRepairSalesOrderNo() {
		return repairSalesOrderNo;
	}

	/**
	 * @param repairSalesOrderNo
	 *            the repairSalesOrderNo to set
	 */
	public void setRepairSalesOrderNo(String repairSalesOrderNo) {
		this.repairSalesOrderNo = repairSalesOrderNo;
	}

	/**
	 * @return the arcMotorReceivedState
	 */
	public Integer getArcMotorReceivedState() {
		return arcMotorReceivedState;
	}

	/**
	 * @param arcMotorReceivedState
	 *            the arcMotorReceivedState to set 0: Not Received; 1: Received
	 */
	public void setArcMotorReceivedState(Integer arcMotorReceivedState) {
		this.arcMotorReceivedState = arcMotorReceivedState;
	}

	/**
	 * @return the custMotorDispatchedState
	 */
	public Integer getCustMotorDispatchedState() {
		return custMotorDispatchedState;
	}

	/**
	 * @param custMotorDispatchedState
	 *            the custMotorDispatchedState to set 0: Not Dispatched; 1:
	 *            Dispatched
	 */
	public void setCustMotorDispatchedState(Integer custMotorDispatchedState) {
		this.custMotorDispatchedState = custMotorDispatchedState;
	}

	/**
	 * @return the isCts
	 */
	public Integer getIsCts() {
		return isCts;
	}

	/**
	 * @param isCts
	 *            the isCts to set 0: Not a CTS; 1: CTS
	 */
	public void setIsCts(Integer isCts) {
		this.isCts = isCts;
	}

	/**
	 * @return the poRefNo
	 */
	public String getPoRefNo() {
		return poRefNo;
	}

	/**
	 * @param poRefNo
	 *            the poRefNo to set
	 */
	public void setPoRefNo(String poRefNo) {
		this.poRefNo = poRefNo;
	}

	/**
	 * @return the quotationRefNum
	 */
	public String getQuotationRefNum() {
		return quotationRefNum;
	}

	/**
	 * @param quotationRefNum
	 *            the quotationRefNum to set
	 */
	public void setQuotationRefNum(String quotationRefNum) {
		this.quotationRefNum = quotationRefNum;
	}

	/**
	 * @return the quotationAcceptance
	 */
	public Integer getQuotationAcceptance() {
		return quotationAcceptance;
	}

	/**
	 * @param quotationAcceptance
	 *            the quotationAcceptance to set 0: Not Accepted; 1: Accepted
	 */
	public void setQuotationAcceptance(Integer quotationAcceptance) {
		this.quotationAcceptance = quotationAcceptance;
	}

	/**
	 * @return the grnVrreId
	 */
	public String getGrnVrreId() {
		return grnVrreId;
	}

	/**
	 * @param grnVrreId
	 *            the grnVrreId to set
	 */
	public void setGrnVrreId(String grnVrreId) {
		this.grnVrreId = grnVrreId;
	}

	/**
	 * @return the dIPGINumber
	 */
	public String getdIPGINumber() {
		return dIPGINumber;
	}

	/**
	 * @param dIPGINumber
	 *            the dIPGINumber to set
	 */
	public void setdIPGINumber(String dIPGINumber) {
		this.dIPGINumber = dIPGINumber;
	}

	/**
	 * @return the costClearedOn
	 */
	public Date getCostClearedOn() {
		return costClearedOn;
	}

	/**
	 * @param costClearedOn
	 *            the costClearedOn to set
	 */
	public void setCostClearedOn(Date costClearedOn) {
		this.costClearedOn = costClearedOn;
	}

	/**
	 * @return the invoiceRefNo
	 */
	public String getInvoiceRefNo() {
		return invoiceRefNo;
	}

	/**
	 * @param invoiceRefNo
	 *            the invoiceRefNo to set
	 */
	public void setInvoiceRefNo(String invoiceRefNo) {
		this.invoiceRefNo = invoiceRefNo;
	}

	/**
	 * @return the isPaymentReceived
	 */
	public Integer getIsPaymentReceived() {
		return isPaymentReceived;
	}

	/**
	 * @param isPaymentReceived
	 *            the isPaymentReceived to set 0: Not Received; 1: Received
	 */
	public void setIsPaymentReceived(Integer isPaymentReceived) {
		this.isPaymentReceived = isPaymentReceived;
	}

	/**
	 * @return the hasClearedCost
	 */
	public Integer getHasClearedCost() {
		return hasClearedCost;
	}

	/**
	 * @param hasClearedCost
	 *            the hasClearedCost to set 0: Not Cleared; 1: Cleared
	 */
	public void setHasClearedCost(Integer hasClearedCost) {
		this.hasClearedCost = hasClearedCost;
	}

	/**
	 * @return the paymentReceivedOn
	 */
	public Date getPaymentReceivedOn() {
		return paymentReceivedOn;
	}

	/**
	 * @param paymentReceivedOn
	 *            the paymentReceivedOn to set
	 */
	public void setPaymentReceivedOn(Date paymentReceivedOn) {
		this.paymentReceivedOn = paymentReceivedOn;
	}

	/**
	 * @return the motorClearanceToDispatch
	 */
	public Integer getMotorClearanceToDispatch() {
		return motorClearanceToDispatch;
	}

	/**
	 * @param motorClearanceToDispatch
	 *            the motorClearanceToDispatch to set 0: Hold; 1: Dispatch
	 */
	public void setMotorClearanceToDispatch(Integer motorClearanceToDispatch) {
		this.motorClearanceToDispatch = motorClearanceToDispatch;
	}

	/**
	 * @return the motorDispatchClearanceOn
	 */
	public Date getMotorDispatchClearanceOn() {
		return motorDispatchClearanceOn;
	}

	/**
	 * @param motorDispatchClearanceOn
	 *            the motorDispatchClearanceOn to set
	 */
	public void setMotorDispatchClearanceOn(Date motorDispatchClearanceOn) {
		this.motorDispatchClearanceOn = motorDispatchClearanceOn;
	}

	/**
	 * @return the arcRepairClearance
	 */
	public Integer getArcRepairClearance() {
		return arcRepairClearance;
	}

	/**
	 * @param arcRepairClearance
	 *            the arcRepairClearance to set 0: Hold; 1: Begin Repairs
	 */
	public void setArcRepairClearance(Integer arcRepairClearance) {
		this.arcRepairClearance = arcRepairClearance;
	}

	/**
	 * @return the arcRepairClearanceOn
	 */
	public Date getArcRepairClearanceOn() {
		return arcRepairClearanceOn;
	}

	/**
	 * @param arcRepairClearanceOn
	 *            the arcRepairClearanceOn to set
	 */
	public void setArcRepairClearanceOn(Date arcRepairClearanceOn) {
		this.arcRepairClearanceOn = arcRepairClearanceOn;
	}

	/**
	 * @return the motorDispatchRoadPermitReq
	 */
	public Integer getMotorDispatchRoadPermitReq() {
		return motorDispatchRoadPermitReq;
	}

	/**
	 * @param motorDispatchRoadPermitReq
	 *            the motorDispatchRoadPermitReq to set 0: Not Required; 1:
	 *            Required;
	 */
	public void setMotorDispatchRoadPermitReq(Integer motorDispatchRoadPermitReq) {
		this.motorDispatchRoadPermitReq = motorDispatchRoadPermitReq;
	}

	/**
	 * @return the aReportApprovedOn
	 */
	public Date getaReportApprovedOn() {
		return aReportApprovedOn;
	}

	/**
	 * @param aReportApprovedOn
	 *            the aReportApprovedOn to set
	 */
	public void setaReportApprovedOn(Date aReportApprovedOn) {
		this.aReportApprovedOn = aReportApprovedOn;
	}

	/**
	 * @return the aReportApproval
	 */
	public Integer getaReportApproval() {
		return aReportApproval;
	}

	/**
	 * @param aReportApproval
	 *            the aReportApproval to set 0: Not Approved; 1: Approved; 2:
	 *            Referred to TS; 3: Approved by TS
	 */
	public void setaReportApproval(Integer aReportApproval) {
		this.aReportApproval = aReportApproval;
	}

	/**
	 * @return the aReportCreatedOn
	 */
	public Date getaReportCreatedOn() {
		return aReportCreatedOn;
	}

	/**
	 * @param aReportCreatedOn
	 *            the aReportCreatedOn to set
	 */
	public void setaReportCreatedOn(Date aReportCreatedOn) {
		this.aReportCreatedOn = aReportCreatedOn;
	}

	/**
	 * @return the isTransitDamage
	 */
	public Integer getIsTransitDamage() {
		return isTransitDamage;
	}

	/**
	 * @param isTransitDamage
	 *            the isTransitDamage to set 0: No; 1: Yes
	 */
	public void setIsTransitDamage(Integer isTransitDamage) {
		this.isTransitDamage = isTransitDamage;
	}

	/**
	 * @return the repairStatus
	 */
	public Integer getRepairStatus() {
		return repairStatus;
	}

	/**
	 * @param repairStatus
	 *            the repairStatus to set 0: WIP(BEGIN REPAIRS); 1: REPAIR_COMPLETE; 2:
	 *            WITHOUT_REPAIRS
	 */
	public void setRepairStatus(Integer repairStatus) {
		this.repairStatus = repairStatus;
	}

	/**
	 * @return the motorDispatchDocketNo
	 */
	public String getMotorDispatchDocketNo() {
		return motorDispatchDocketNo;
	}

	/**
	 * @param motorDispatchDocketNo
	 *            the motorDispatchDocketNo to set
	 */
	public void setMotorDispatchDocketNo(String motorDispatchDocketNo) {
		this.motorDispatchDocketNo = motorDispatchDocketNo;
	}

	/**
	 * @return the quotationRefNo
	 */
	public String getQuotationRefNo() {
		return quotationRefNo;
	}

	/**
	 * @param quotationRefNo
	 *            the quotationRefNo to set
	 */
	public void setQuotationRefNo(String quotationRefNo) {
		this.quotationRefNo = quotationRefNo;
	}

	/**
	 * @return the obsRefNo
	 */
	public String getObsRefNo() {
		return obsRefNo;
	}

	/**
	 * @param obsRefNo
	 *            the obsRefNo to set
	 */
	public void setObsRefNo(String obsRefNo) {
		this.obsRefNo = obsRefNo;
	}

	/**
	 * @return the sparesPoNo
	 */
	public String getSparesPoNo() {
		return sparesPoNo;
	}

	/**
	 * @param sparesPoNo
	 *            the sparesPoNo to set
	 */
	public void setSparesPoNo(String sparesPoNo) {
		this.sparesPoNo = sparesPoNo;
	}

	/**
	 * @return the spareDispatchDocketNo
	 */
	public String getSpareDispatchDocketNo() {
		return spareDispatchDocketNo;
	}

	/**
	 * @param spareDispatchDocketNo
	 *            the spareDispatchDocketNo to set
	 */
	public void setSpareDispatchDocketNo(String spareDispatchDocketNo) {
		this.spareDispatchDocketNo = spareDispatchDocketNo;
	}

	/**
	 * @return the arcMotorReceivedOn
	 */
	public Date getArcMotorReceivedOn() {
		return arcMotorReceivedOn;
	}

	/**
	 * @param arcMotorReceivedOn
	 *            the arcMotorReceivedOn to set
	 */
	public void setArcMotorReceivedOn(Date arcMotorReceivedOn) {
		this.arcMotorReceivedOn = arcMotorReceivedOn;
	}

	/**
	 * @return the arcMotorDispatchOn
	 */
	public Date getArcMotorDispatchOn() {
		return arcMotorDispatchOn;
	}

	/**
	 * @param arcMotorDispatchOn
	 *            the arcMotorDispatchOn to set
	 */
	public void setArcMotorDispatchOn(Date arcMotorDispatchOn) {
		this.arcMotorDispatchOn = arcMotorDispatchOn;
	}

	/**
	 * @return the tdRecoNum
	 */
	public String getTdRecoNum() {
		return tdRecoNum;
	}

	/**
	 * @param tdRecoNum
	 *            the tdRecoNum to set RECO field to be added in case of transit
	 *            damage
	 */
	public void setTdRecoNum(String tdRecoNum) {
		this.tdRecoNum = tdRecoNum;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}


	public int getTsSupportDecision() {
		return tsSupportDecision;
	}

	public void setTsSupportDecision(int tsSupportDecision) {
		this.tsSupportDecision = tsSupportDecision;
	}

	/**
	 * @return the initialWarrantyClaimSetByRefId
	 */
	public String getInitialWarrantyClaimSetByRefId() {
		return initialWarrantyClaimSetByRefId;
	}

	/**
	 * @param initialWarrantyClaimSetByRefId
	 *            the initialWarrantyClaimSetByRefId to set
	 */
	public void setInitialWarrantyClaimSetByRefId(String initialWarrantyClaimSetByRefId) {
		this.initialWarrantyClaimSetByRefId = initialWarrantyClaimSetByRefId;
	}

	/**
	 * @return the finalWarrantyStateSetByRefId
	 */
	public String getFinalWarrantyStateSetByRefId() {
		return finalWarrantyStateSetByRefId;
	}

	/**
	 * @param finalWarrantyStateSetByRefId
	 *            the finalWarrantyStateSetByRefId to set
	 */
	public void setFinalWarrantyStateSetByRefId(String finalWarrantyStateSetByRefId) {
		this.finalWarrantyStateSetByRefId = finalWarrantyStateSetByRefId;
	}

	/**
	 * @return the finalWarrantyStateSetOn
	 */
	public Date getFinalWarrantyStateSetOn() {
		return finalWarrantyStateSetOn;
	}

	/**
	 * @param finalWarrantyStateSetOn
	 *            the finalWarrantyStateSetOn to set
	 */
	public void setFinalWarrantyStateSetOn(Date finalWarrantyStateSetOn) {
		this.finalWarrantyStateSetOn = finalWarrantyStateSetOn;
	}

	/**
	 * @return the finalWarrantyStateModifiedByRefId
	 */
	public String getFinalWarrantyStateModifiedByRefId() {
		return finalWarrantyStateModifiedByRefId;
	}

	/**
	 * @param finalWarrantyStateModifiedByRefId
	 *            the finalWarrantyStateModifiedByRefId to set
	 */
	public void setFinalWarrantyStateModifiedByRefId(String finalWarrantyStateModifiedByRefId) {
		this.finalWarrantyStateModifiedByRefId = finalWarrantyStateModifiedByRefId;
	}

	/**
	 * @return the finalWarrantyStateModifiedOn
	 */
	public Date getFinalWarrantyStateModifiedOn() {
		return finalWarrantyStateModifiedOn;
	}

	/**
	 * @param finalWarrantyStateModifiedOn
	 *            the finalWarrantyStateModifiedOn to set
	 */
	public void setFinalWarrantyStateModifiedOn(Date finalWarrantyStateModifiedOn) {
		this.finalWarrantyStateModifiedOn = finalWarrantyStateModifiedOn;
	}

	/**
	 * @return the cclOn
	 */
	public Date getCclOn() {
		return cclOn;
	}

	/**
	 * @param cclOn
	 *            the cclOn to set
	 */
	public void setCclOn(Date cclOn) {
		this.cclOn = cclOn;
	}

	/**
	 * @return the hasCcl
	 */
	public Integer getHasCcl() {
		return hasCcl;
	}

	/**
	 * @param hasCcl
	 *            the hasCcl to set
	 */
	public void setHasCcl(Integer hasCcl) {
		this.hasCcl = hasCcl;
	}

	/**
	 * @return the subProcState
	 */
	public Integer getSubProcState() {
		return subProcState;
	}

	/**
	 * @param subProcState
	 *            the subProcState to set 0:Completed,1:IN-EXEC; 2:
	 *            RESOLVED_CLOSURE; 3: CUSTOMER_DECLINED; 4: SHORT_CLOSED; 5:
	 *            DUPLICATED; 6: WRONGLY_CREATED;
	 */
	public void setSubProcState(Integer subProcState) {
		this.subProcState = subProcState;
	}

	/**
	 * @return the cclTeco
	 */
	public Integer getCclTeco() {
		return cclTeco;
	}

	/**
	 * @param cclTeco
	 *            the cclTeco to set
	 */
	public void setCclTeco(Integer cclTeco) {
		this.cclTeco = cclTeco;
	}

	/**
	 * @return the mdcTeco
	 */
	public Integer getMdcTeco() {
		return mdcTeco;
	}

	/**
	 * @param mdcTeco
	 *            the mdcTeco to set
	 */
	public void setMdcTeco(Integer mdcTeco) {
		this.mdcTeco = mdcTeco;
	}

	/**
	 * @return the notificationTeco
	 */
	public Integer getNotificationTeco() {
		return notificationTeco;
	}

	/**
	 * @param notificationTeco
	 *            the notificationTeco to set
	 */
	public void setNotificationTeco(Integer notificationTeco) {
		this.notificationTeco = notificationTeco;
	}

	/**
	 * @return the subProcClosedOn
	 */
	public Date getSubProcClosedOn() {
		return subProcClosedOn;
	}

	/**
	 * @param subProcClosedOn
	 *            the subProcClosedOn to set
	 */
	public void setSubProcClosedOn(Date subProcClosedOn) {
		this.subProcClosedOn = subProcClosedOn;
	}

	/**
	 * @return the subProcClosedByRefId
	 */
	public String getSubProcClosedByRefId() {
		return subProcClosedByRefId;
	}

	/**
	 * @param subProcClosedByRefId
	 *            the subProcClosedByRefId to set
	 */
	public void setSubProcClosedByRefId(String subProcClosedByRefId) {
		this.subProcClosedByRefId = subProcClosedByRefId;
	}

	/**
	 * @return the isJobCompleted
	 */
	public Integer getIsJobCompleted() {
		return isJobCompleted;
	}

	/**
	 * @param isJobCompleted
	 *            the isJobCompleted to set 0: not completed,1:completed
	 */
	public void setIsJobCompleted(Integer isJobCompleted) {
		this.isJobCompleted = isJobCompleted;
	}

	/**
	 * @return the jobCompletedOn
	 */
	public Date getJobCompletedOn() {
		return jobCompletedOn;
	}

	/**
	 * @param jobCompletedOn
	 *            the jobCompletedOn to set
	 */
	public void setJobCompletedOn(Date jobCompletedOn) {
		this.jobCompletedOn = jobCompletedOn;
	}

	/**
	 * @return the jobCompletedByRefId
	 */
	public String getJobCompletedByRefId() {
		return jobCompletedByRefId;
	}

	/**
	 * @param jobCompletedByRefId
	 *            the jobCompletedByRefId to set
	 */
	public void setJobCompletedByRefId(String jobCompletedByRefId) {
		this.jobCompletedByRefId = jobCompletedByRefId;
	}

	/**
	 * @return the isJobClosed
	 */
	public Integer getIsJobClosed() {
		return isJobClosed;
	}

	/**
	 * @param isJobClosed
	 *            the isJobClosed to set 0:not closed ,1:closed
	 */
	public void setIsJobClosed(Integer isJobClosed) {
		this.isJobClosed = isJobClosed;
	}

	/**
	 * @return the jobClosedOn
	 */
	public Date getJobClosedOn() {
		return jobClosedOn;
	}

	/**
	 * @param jobClosedOn
	 *            the jobClosedOn to set
	 */
	public void setJobClosedOn(Date jobClosedOn) {
		this.jobClosedOn = jobClosedOn;
	}

	/**
	 * @return the jobClosedByRefId
	 */
	public String getJobClosedByRefId() {
		return jobClosedByRefId;
	}

	/**
	 * @param jobClosedByRefId
	 *            the jobClosedByRefId to set
	 */
	public void setJobClosedByRefId(String jobClosedByRefId) {
		this.jobClosedByRefId = jobClosedByRefId;
	}

	/**
	 * @return the custFeedback
	 */
	public Integer getCustFeedback() {
		return custFeedback;
	}

	/**
	 * @param custFeedback
	 *            the custFeedback to set 0: Not Satisfied; 1: Satisfied; 2: No
	 *            Feedback; 3: Refer To Tech Support
	 */
	public void setCustFeedback(Integer custFeedback) {
		this.custFeedback = custFeedback;
	}

	/**
	 * @return the batchProcId
	 */
	public String getBatchProcId() {
		return batchProcId;
	}

	/**
	 * @param batchProcId
	 *            the batchProcId to set
	 */
	public void setBatchProcId(String batchProcId) {
		this.batchProcId = batchProcId;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the motorSparesDetails
	 */
	public List<MotorSparesDetail> getMotorSparesDetails() {
		return motorSparesDetails;
	}

	/**
	 * @param motorSparesDetails
	 *            the motorSparesDetails to set
	 */
	public void setMotorSparesDetails(List<MotorSparesDetail> motorSparesDetails) {
		this.motorSparesDetails = motorSparesDetails;
	}

	/**
	 * @return the motorAttachmentDetails
	 */
	public List<MotorAttachmentDetail> getMotorAttachmentDetails() {
		return motorAttachmentDetails;
	}

	/**
	 * @param motorAttachmentDetails
	 *            the motorAttachmentDetails to set
	 */
	public void setMotorAttachmentDetails(List<MotorAttachmentDetail> motorAttachmentDetails) {
		this.motorAttachmentDetails = motorAttachmentDetails;
	}

	/**
	 * @return the fSEVisitDetails
	 */
	public List<FSEVisitDetail> getfSEVisitDetails() {
		return fSEVisitDetails;
	}

	/**
	 * @param fSEVisitDetails
	 *            the fSEVisitDetails to set
	 */
	public void setfSEVisitDetails(List<FSEVisitDetail> fSEVisitDetails) {
		this.fSEVisitDetails = fSEVisitDetails;
	}

	/**
	 * @return the motorOrderDetails
	 */
	public List<MotorOrderDetail> getMotorOrderDetails() {
		return motorOrderDetails;
	}

	/**
	 * @param motorOrderDetails
	 *            the motorOrderDetails to set
	 */
	public void setMotorOrderDetails(List<MotorOrderDetail> motorOrderDetails) {
		this.motorOrderDetails = motorOrderDetails;
	}

	/**
	 * @return the parallelProcess
	 */
	public List<ParallelProcess> getParallelProcess() {
		return parallelProcess;
	}

	/**
	 * @param parallelProcess
	 *            the parallelProcess to set
	 */
	public void setParallelProcess(List<ParallelProcess> parallelProcess) {
		this.parallelProcess = parallelProcess;
	}

	public Integer getDispatchMode() {
		return dispatchMode;
	}

	public void setDispatchMode(Integer dispatchMode) {
		this.dispatchMode = dispatchMode;
	}

	public String getOtherModeDetails() {
		return otherModeDetails;
	}

	public void setOtherModeDetails(String otherModeDetails) {
		this.otherModeDetails = otherModeDetails;
	}

	public String getTransporterName() {
		return transporterName;
	}

	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	public String getTransporterDocketNo() {
		return transporterDocketNo;
	}

	public void setTransporterDocketNo(String transporterDocketNo) {
		this.transporterDocketNo = transporterDocketNo;
	}

	/**
	 * @return the dispatchDetail
	 */
	public List<DispatchDetail> getDispatchDetail() {
		return dispatchDetail;
	}

	/**
	 * @param dispatchDetail the dispatchDetail to set
	 */
	public void setDispatchDetail(List<DispatchDetail> dispatchDetail) {
		this.dispatchDetail = dispatchDetail;
	}

	/**
	 * @return the isProformaInvoiced
	 */
	public Integer getIsProformaInvoiced() {
		return isProformaInvoiced;
	}

	/**
	 * @param isProformaInvoiced the isProformaInvoiced to set
	 */
	public void setIsProformaInvoiced(Integer isProformaInvoiced) {
		this.isProformaInvoiced = isProformaInvoiced;
	}

	/**
	 * @return the custInvoiceDate
	 */
	public Date getCustInvoiceDate() {
		return custInvoiceDate;
	}

	/**
	 * @param custInvoiceDate the custInvoiceDate to set
	 */
	public void setCustInvoiceDate(Date custInvoiceDate) {
		this.custInvoiceDate = custInvoiceDate;
	}

	/**
	 * @return the workflowClosureType
	 */
	public Integer getWorkflowClosureType() {
		return workflowClosureType;
	}

	/**
	 *            0:Completed,1:IN-EXEC; 2:
	 *            RESOLVED_CLOSURE; 3: CUSTOMER_DECLINED; 4: SHORT_CLOSED; 5:
	 *            DUPLICATED; 6: WRONGLY_CREATED;
	 */
	public void setWorkflowClosureType(Integer workflowClosureType) {
		this.workflowClosureType = workflowClosureType;
	}

	/**
	 * @return the subProcessGroupDetail
	 */
	public SubProcessGroupDetail getSubProcessGroupDetail() {
		return subProcessGroupDetail;
	}

	/**
	 * @param subProcessGroupDetail the subProcessGroupDetail to set
	 */
	public void setSubProcessGroupDetail(SubProcessGroupDetail subProcessGroupDetail) {
		this.subProcessGroupDetail = subProcessGroupDetail;
	}
	
	/**
	 * @return the isCustAvailable
	 */
	public Integer getIsCustAvailable() {
		return isCustAvailable;
	}

	/**
	 * @param isCustAvailable the isCustAvailable to set
	 */
	public void setIsCustAvailable(Integer isCustAvailable) {
		this.isCustAvailable = isCustAvailable;
	}

	/**
	 * @return the isWorkflowClosed
	 */
	public Integer getIsWorkflowClosed() {
		return isWorkflowClosed;
	}

	/**
	 * @param isWorkflowClosed the isWorkflowClosed to set
	 */
	public void setIsWorkflowClosed(Integer isWorkflowClosed) {
		this.isWorkflowClosed = isWorkflowClosed;
	}
	
	 


}
