package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a593775 entity to store Motor Voltage Detail
 */
@Entity
@Table(name = "rmt_motor_voltage_detail")
public class MotorVoltageDetail extends BasicEntity implements Serializable {

	private static final long serialVersionUID = -18993740232L;

	@Id
	@Column(name = "rmt_motor_voltage_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorVoltageDetailId;

	@Column(name = "ry")
	private Float ry;

	@Column(name = "yb")
	private Float yb;

	@Column(name = "br")
	private Float br;

	@Column(name = "freq_hz")
	private Float freqHz;
	
	/**
	 * @return the motorVoltageDetailId
	 */
	public Long getMotorVoltageDetailId() {
		return motorVoltageDetailId;
	}

	/**
	 * @param motorVoltageDetailId
	 *            the motorVoltageDetailId to set
	 */
	public void setMotorVoltageDetailId(Long motorVoltageDetailId) {
		this.motorVoltageDetailId = motorVoltageDetailId;
	}

	/**
	 * @return the ry
	 */
	public Float getRy() {
		return ry;
	}

	/**
	 * @param ry
	 *            the ry to set
	 */
	public void setRy(Float ry) {
		this.ry = ry;
	}

	/**
	 * @return the yb
	 */
	public Float getYb() {
		return yb;
	}

	/**
	 * @param yb
	 *            the yb to set
	 */
	public void setYb(Float yb) {
		this.yb = yb;
	}

	/**
	 * @return the br
	 */
	public Float getBr() {
		return br;
	}

	/**
	 * @param br
	 *            the br to set
	 */
	public void setBr(Float br) {
		this.br = br;
	}

	/**
	 * @return the freqHz
	 */
	public Float getFreqHz() {
		return freqHz;
	}

	/**
	 * @param freqHz
	 *            the freqHz to set
	 */
	public void setFreqHz(Float freqHz) {
		this.freqHz = freqHz;
	}
}
