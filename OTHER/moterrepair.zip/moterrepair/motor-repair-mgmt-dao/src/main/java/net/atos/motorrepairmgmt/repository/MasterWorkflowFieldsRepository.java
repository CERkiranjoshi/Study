package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.AdditionalContactDetail;
import net.atos.motorrepairmgmt.entity.CustomerDetail;
import net.atos.motorrepairmgmt.entity.MasterWorkflowFields;
import net.atos.motorrepairmgmt.entity.WorkflowState;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a610039
 *
 */
public interface MasterWorkflowFieldsRepository extends JpaRepository<MasterWorkflowFields, Long> {

	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.tenantId=:tenantId")
	List<MasterWorkflowFields> findAllMasterWorkflowFieldsByTenantId(@Param("tenantId") String tenantId);

	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.tenantId=:tenantId AND mwf.solutionCategoryId=:solutionCategoryId")
	List<MasterWorkflowFields> findMasterWorkflowFieldsByTenantIdAndSolutionCategoryId(
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solutionCategoryId);

	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.tenantId=:tenantId AND mwf.solutionCategoryId=:solutionCategoryId AND mwf.gspRefNo=:gspRefNo")
	List<MasterWorkflowFields> findMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solutionCategoryId,
			@Param("gspRefNo") String gspRefNo);

	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.tenantId=:tenantId AND mwf.solutionCategoryId=:solutionCategoryId AND mwf.workflowState.stateName=:stateName")
	List<MasterWorkflowFields> findMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solutionCategoryId,
			@Param("stateName") String stateName);

	@Query("SELECT mwf.customerDetails from MasterWorkflowFields mwf where mwf.masterWorkflowFieldId=:masterWorkflowFieldId")
	List<CustomerDetail> findCustomerDetailListByMasterWorkflowFieldId(
			@Param("masterWorkflowFieldId") Long masterWorkflowId);

	@Query("SELECT mwf.additionalContactDetails from MasterWorkflowFields mwf where mwf.masterWorkflowFieldId=:masterWorkflowFieldId")
	List<AdditionalContactDetail> findAdditionalContactDetailByMasterWorkflowFieldId(
			@Param("masterWorkflowFieldId") Long masterWorkflowId);

	@Query("SELECT mwf.workflowState from MasterWorkflowFields mwf where mwf.masterWorkflowFieldId=:masterWorkflowFieldId")
	WorkflowState findWorkflowStateByMasterWorkflowFieldId(@Param("masterWorkflowFieldId") Long masterWorkflowId);

	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.gspRefNo=:gspRefNo")
	MasterWorkflowFields findMasterWorkflowFieldsByGspRefNo(@Param("gspRefNo") String gspRefNo);
	
	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.masterWorkflowFieldId=:masterWorkflowFieldId AND mwf.tenantId=:tenantId AND mwf.solutionCategoryId=:solutionCategoryId  ")
	MasterWorkflowFields findMasterWorkflowFieldsByMasterWorkflowFieldIdAndTenantIdAndSolCatId(
			@Param("masterWorkflowFieldId") Long masterWorkflowFieldId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
	
	@Query("SELECT mwf from MasterWorkflowFields mwf where mwf.gspRefNo=:gspRefNo AND mwf.tenantId=:tenantId AND mwf.solutionCategoryId=:solutionCategoryId  ")
	MasterWorkflowFields findMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState(
			@Param("gspRefNo") String gspRefNo,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
}

