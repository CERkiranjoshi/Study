/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import net.atos.motorrepairmgmt.entity.BasicEntity;
import net.atos.motorrepairmgmt.entity.RMTBasicEntity;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;




/**
 * @author a545466
 *
 */
@Repository
public class ClusterNodeRepository {

	@Value("${cluster.nodeId}")
	private String nodeId;
	
	
	/**
	 * @return the nodeId
	 */
	public String getNodeId() {		
		return nodeId;
	}

	
}