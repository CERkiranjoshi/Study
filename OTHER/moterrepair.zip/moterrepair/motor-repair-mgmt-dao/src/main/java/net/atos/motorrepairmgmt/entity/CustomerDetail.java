package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a593775
 * 
 */
@Entity
@Table(name = "rmt_customer_detail")
public class CustomerDetail extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6588396478132570029L;

	@Id
	@Column(name = "customer_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "cust_contact_name")
	private String custContactName;

	@Column(name = "mobile_contact_num")
	private String mobileContactNum;

	@Column(name = "office_contact_num")
	private String officeContactNum;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "cust_type")
	private String custType;

	@Column(name = "gsp_ref_code")
	private String gspRefCode;

	@Column(name = "spiridon_ref_code")
	private String spiridonRefCode;

	@Column(name = "notification_type")
	private Integer notificationType;

	@Column(name = "cust_address", length = 200)
	private String custAddress;

	@Column(name = "cust_state", length = 100)
	private String custState;

	@Column(name = "cust_city", length = 100)
	private String custCity;

	@Column(name = "cust_pin_code", length = 10)
	private Integer custPinCode;

	@Column(name = "ship_to_address")
	private String shipToAddress;

	@Column(name = "is_ship_to_party")
	private Integer isShipToParty;

	@Column(name = "is_sold_to_party")
	private Integer isSoldToParty;

	@Column(name = "country_code", length = 10)
	private String countyCode;

	// for storing partner type for channel partner ,like OEM ,etc
	@Column(name = "partner_type")
	private Integer partnerType;

	/**
	 * @return the partnerType
	 */
	public Integer getPartnerType() {
		return partnerType;
	}

	/**
	 * @param partnerType
	 *            the partnerType to set
	 */
	public void setPartnerType(Integer partnerType) {
		this.partnerType = partnerType;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode
	 *            the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * @return the customerId
	 */
	public Long getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the custContactName
	 */
	public String getCustContactName() {
		return custContactName;
	}

	/**
	 * @param custContactName
	 *            the custContactName to set
	 */
	public void setCustContactName(String custContactName) {
		this.custContactName = custContactName;
	}

	/**
	 * @return the mobileContactNum
	 */
	public String getMobileContactNum() {
		return mobileContactNum;
	}

	/**
	 * @param mobileContactNum
	 *            the mobileContactNum to set
	 */
	public void setMobileContactNum(String mobileContactNum) {
		this.mobileContactNum = mobileContactNum;
	}

	/**
	 * @return the officeContactNum
	 */
	public String getOfficeContactNum() {
		return officeContactNum;
	}

	/**
	 * @param officeContactNum
	 *            the officeContactNum to set
	 */
	public void setOfficeContactNum(String officeContactNum) {
		this.officeContactNum = officeContactNum;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the custType
	 */
	public String getCustType() {
		return custType;
	}

	/**
	 * @param custType
	 *            the custType to set
	 */
	public void setCustType(String custType) {
		this.custType = custType;
	}

	/**
	 * @return the gspRefCode
	 */
	public String getGspRefCode() {
		return gspRefCode;
	}

	/**
	 * @param gspRefCode
	 *            the gspRefCode to set
	 */
	public void setGspRefCode(String gspRefCode) {
		this.gspRefCode = gspRefCode;
	}

	/**
	 * @return the spiridonRefCode
	 */
	public String getSpiridonRefCode() {
		return spiridonRefCode;
	}

	/**
	 * @param spiridonRefCode
	 *            the spiridonRefCode to set
	 */
	public void setSpiridonRefCode(String spiridonRefCode) {
		this.spiridonRefCode = spiridonRefCode;
	}

	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType
	 *            the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the custAddress
	 */
	public String getCustAddress() {
		return custAddress;
	}

	/**
	 * @param custAddress
	 *            the custAddress to set
	 */
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	/**
	 * @return the shipToAddress
	 */
	public String getShipToAddress() {
		return shipToAddress;
	}

	/**
	 * @param shipToAddress
	 *            the shipToAddress to set
	 */
	public void setShipToAddress(String shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	/**
	 * @return the isShipToParty
	 */
	public Integer getIsShipToParty() {
		return isShipToParty;
	}

	/**
	 * @param isShipToParty
	 *            the isShipToParty to set
	 */
	public void setIsShipToParty(Integer isShipToParty) {
		this.isShipToParty = isShipToParty;
	}

	/**
	 * @return the isSoldToParty
	 */
	public Integer getIsSoldToParty() {
		return isSoldToParty;
	}

	/**
	 * @param isSoldToParty
	 *            the isSoldToParty to set
	 */
	public void setIsSoldToParty(Integer isSoldToParty) {
		this.isSoldToParty = isSoldToParty;
	}
	
	public String getCustState() {
		return custState;
	}

	public void setCustState(String custState) {
		this.custState = custState;
	}

	public String getCustCity() {
		return custCity;
	}

	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}

	public Integer getCustPinCode() {
		return custPinCode;
	}

	public void setCustPinCode(Integer custPinCode) {
		this.custPinCode = custPinCode;
	}

}
