package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.ElectricalObservation;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a610051
 * 
 */
public interface ElectricalObservationRepository extends JpaRepository<ElectricalObservation, Long> {

}
