/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Anand Ved
 * 
 */
@Entity
@Table(name = "rmt_schedule_details")
public class SchedulerDetails implements Serializable {

	private static final long serialVersionUID = 15658623384L;

	@Id
	@Column(name = "scheduler_id")
	private String schedulerId;

	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;

	@Column(name = "scheduler_type")
	private Integer schedulerType;

	@Column(name = "next_run_timestamp")
	private Long nextRunTimestamp;

	@Column(name = "scheduled_by")
	private String scheduledBy;

	@Column(name = "run_number")
	private Integer runNumber;

	@Column(name = "task_ref_id")
	private String taskRefId;

	@Column(name = "task_sla_type")
	private Integer taskSLAType;

	@Column(name = "task_priority", length = 3)
	private String taskPriority;

	@Column(name = "proc_inst_ref_id")
	private String procInstRefId;

	@Column(name = "subprocess_id")
	private Long subprocessId;

	@Column(name = "master_wflw_id")
	private Long masterWorkflowId;

	@Column(name = "post_restart_run")
	private Integer postRestartRun;

	@Column(name = "last_run_ts")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastRunTs;

	@Column(name = "has_executed")
	private Integer hasExecuted;

	@Column(name = "batch_process_id")
	private String batchProcessId;

	@Column(name = "parallel_process_id")
	private String paralelProcessId;

	@Column(name = "gsp_ref_num")
	private String gspRefNum;

	@Column(name = "function_code", length = 255)
	private String functionCode;

	@Column(name = "node_id", length = 8)
	private String nodeId;
	
	/**
	 * @return the schedulerId
	 */
	public String getSchedulerId() {
		return schedulerId;
	}

	/**
	 * @param schedulerId
	 *            the schedulerId to set
	 */
	public void setSchedulerId(String schedulerId) {
		this.schedulerId = schedulerId;
	}

	/**
	 * @return the schedulerType
	 */
	public Integer getSchedulerType() {
		return schedulerType;
	}

	/**
	 * @param schedulerType
	 *            the schedulerType to set
	 */
	public void setSchedulerType(Integer schedulerType) {
		this.schedulerType = schedulerType;
	}

	/**
	 * @return the nextRunTimestamp
	 */
	public Long getNextRunTimestamp() {
		return nextRunTimestamp;
	}

	/**
	 * @param nextRunTimestamp
	 *            the nextRunTimestamp to set
	 */
	public void setNextRunTimestamp(Long nextRunTimestamp) {
		this.nextRunTimestamp = nextRunTimestamp;
	}

	/**
	 * @return the scheduledBy
	 */
	public String getScheduledBy() {
		return scheduledBy;
	}

	/**
	 * @param scheduledBy
	 *            the scheduledBy to set
	 */
	public void setScheduledBy(String scheduledBy) {
		this.scheduledBy = scheduledBy;
	}

	/**
	 * @return the runNumber
	 */
	public Integer getRunNumber() {
		return runNumber;
	}

	/**
	 * @param runNumber
	 *            the runNumber to set
	 */
	public void setRunNumber(Integer runNumber) {
		this.runNumber = runNumber;
	}

	/**
	 * @return the taskRefId
	 */
	public String getTaskRefId() {
		return taskRefId;
	}

	/**
	 * @param taskRefId
	 *            the taskRefId to set
	 */
	public void setTaskRefId(String taskRefId) {
		this.taskRefId = taskRefId;
	}

	/**
	 * @return the taskSLAType
	 */
	public Integer getTaskSLAType() {
		return taskSLAType;
	}

	/**
	 * @param taskSLAType
	 *            the taskSLAType to set
	 */
	public void setTaskSLAType(Integer taskSLAType) {
		this.taskSLAType = taskSLAType;
	}

	/**
	 * @return the procInstRefId
	 */
	public String getProcInstRefId() {
		return procInstRefId;
	}

	/**
	 * @param procInstRefId
	 *            the procInstRefId to set
	 */
	public void setProcInstRefId(String procInstRefId) {
		this.procInstRefId = procInstRefId;
	}

	/**
	 * @return the subprocessId
	 */
	public Long getSubprocessId() {
		return subprocessId;
	}

	/**
	 * @param subprocessId
	 *            the subprocessId to set
	 */
	public void setSubprocessId(Long subprocessId) {
		this.subprocessId = subprocessId;
	}

	/**
	 * @return the masterWorkflowId
	 */
	public Long getMasterWorkflowId() {
		return masterWorkflowId;
	}

	/**
	 * @param masterWorkflowId
	 *            the masterWorkflowId to set
	 */
	public void setMasterWorkflowId(Long masterWorkflowId) {
		this.masterWorkflowId = masterWorkflowId;
	}

	/**
	 * @return the postRestartRun
	 */
	public Integer getPostRestartRun() {
		return postRestartRun;
	}

	/**
	 * @param postRestartRun
	 *            the postRestartRun to set
	 */
	public void setPostRestartRun(Integer postRestartRun) {
		this.postRestartRun = postRestartRun;
	}

	/**
	 * @return the lastRunTs
	 */
	public Date getLastRunTs() {
		return lastRunTs;
	}

	/**
	 * @param lastRunTs
	 *            the lastRunTs to set
	 */
	public void setLastRunTs(Date lastRunTs) {
		this.lastRunTs = lastRunTs;
	}

	/**
	 * @return the batchProcessId
	 */
	public String getBatchProcessId() {
		return batchProcessId;
	}

	/**
	 * @param batchProcessId
	 *            the batchProcessId to set
	 */
	public void setBatchProcessId(String batchProcessId) {
		this.batchProcessId = batchProcessId;
	}

	/**
	 * @return the paralelProcessId
	 */
	public String getParalelProcessId() {
		return paralelProcessId;
	}

	/**
	 * @param paralelProcessId
	 *            the paralelProcessId to set
	 */
	public void setParalelProcessId(String paralelProcessId) {
		this.paralelProcessId = paralelProcessId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */

	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the hasExecuted
	 */
	public Integer getHasExecuted() {
		return hasExecuted;
	}

	/**
	 * @param hasExecuted
	 *            the hasExecuted to set
	 */
	public void setHasExecuted(Integer hasExecuted) {
		this.hasExecuted = hasExecuted;
	}

	/**
	 * @return the gspRefNum
	 */
	public String getGspRefNum() {
		return gspRefNum;
	}

	/**
	 * @param gspRefNum
	 *            the gspRefNum to set
	 */
	public void setGspRefNum(String gspRefNum) {
		this.gspRefNum = gspRefNum;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode
	 *            the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	/**
	 * @return the taskPriority
	 */
	public String getTaskPriority() {
		return taskPriority;
	}

	/**
	 * @param taskPriority the taskPriority to set
	 */
	public void setTaskPriority(String taskPriority) {
		this.taskPriority = taskPriority;
	}

	/**
	 * @return the nodeId
	 */
	public String getNodeId() {
		return nodeId;
	}

	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

}
