package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a603975
 * 
 */

@Entity
@Table(name = "rmt_parallel_proc")
public class ParallelProcess extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4479768148057425394L;

	@Id
	@Column(name = "parallel_proc_thread_id")
	// @GeneratedValue(strategy = GenerationType.IDENTITY). ID manually set
	private Long parallelProcessThreadId;
	
	@Column(name = "parallel_proc_id")
	private String parallelProcessId;

	@Column(name = "parallel_proc_type")
	private String parallelProcessType;

	@Column(name = "pp_batch_proc_id")
	private String ppBatchProcessId;

	@Column(name = "parallel_proc_state")
	private String parallelProcessState;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = " created_by_ref_id")
	private String createdByRefId;

	@Column(name="task_id")
	private String taskId;
	
	
	@Column(name="initiator_task_id")
	private String initTaskId;
	
	@Column(name="initiator_processInstance_id")
	private String initProcessInsId;
	
	@Column(name="process_instance_id")
	private String processInstancId;
		
	@Column(name="init_task_code")
	private String initTaskCode;
		
	@Column(name="closed_by_ref_id",length=100)
	private String closedByRefId;
	
	@Column(name = "closed_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date closedOn;
	
	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the parallelProcessThreadId
	 */
	public Long getParallelProcessThreadId() {
		return parallelProcessThreadId;
	}

	/**
	 * @param parallelProcessThreadId the parallelProcessThreadId to set
	 */
	public void setParallelProcessThreadId(Long parallelProcessThreadId) {
		this.parallelProcessThreadId = parallelProcessThreadId;
	}

	/**
	 * @return the parallelProcessType
	 */
	public String getParallelProcessType() {
		return parallelProcessType;
	}

	/**
	 * @param parallelProcessType the parallelProcessType to set
	 */
	public void setParallelProcessType(String parallelProcessType) {
		this.parallelProcessType = parallelProcessType;
	}

	/**
	 * @return the parallelProcessId
	 */
	public String getParallelProcessId() {
		return parallelProcessId;
	}

	/**
	 * @param parallelProcessId the parallelProcessId to set
	 */
	public void setParallelProcessId(String parallelProcessId) {
		this.parallelProcessId = parallelProcessId;
	}

	public String getInitTaskCode() {
		return initTaskCode;
	}

	public void setInitTaskCode(String initTaskCode) {
		this.initTaskCode = initTaskCode;
	}

	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the initTaskId
	 */
	public String getInitTaskId() {
		return initTaskId;
	}

	/**
	 * @param initTaskId the initTaskId to set
	 */
	public void setInitTaskId(String initTaskId) {
		this.initTaskId = initTaskId;
	}

	/**
	 * @return the initProcessInsId
	 */
	public String getInitProcessInsId() {
		return initProcessInsId;
	}

	/**
	 * @param initProcessInsId the initProcessInsId to set
	 */
	public void setInitProcessInsId(String initProcessInsId) {
		this.initProcessInsId = initProcessInsId;
	}

	/**
	 * @return the processInstancId
	 */
	public String getProcessInstancId() {
		return processInstancId;
	}

	/**
	 * @param processInstancId the processInstancId to set
	 */
	public void setProcessInstancId(String processInstancId) {
		this.processInstancId = processInstancId;
	}

	/**
	 * @return the closedByRefId
	 */
	public String getClosedByRefId() {
		return closedByRefId;
	}

	/**
	 * @param closedByRefId the closedByRefId to set
	 */
	public void setClosedByRefId(String closedByRefId) {
		this.closedByRefId = closedByRefId;
	}

	/**
	 * @return the closedOn
	 */
	public Date getClosedOn() {
		return closedOn;
	}

	/**
	 * @param closedOn the closedOn to set
	 */
	public void setClosedOn(Date closedOn) {
		this.closedOn = closedOn;
	}

	/**
	 * @return the ppBatchProcessId Parallel Process Batch process Id
	 */
	public String getPpBatchProcessId() {
		return ppBatchProcessId;
	}

	/**
	 * @param ppBatchProcessId
	 *            the ppBatchProcessId to set Parallel Process Batch process Id
	 */
	public void setPpBatchProcessId(String ppBatchProcessId) {
		this.ppBatchProcessId = ppBatchProcessId;
	}

	/**
	 * @return the parallelProcessState
	 */
	public String getParallelProcessState() {
		return parallelProcessState;
	}

	/**
	 * @param parallelProcessState
	 *            the parallelProcessState to set
	 */
	public void setParallelProcessState(String parallelProcessState) {
		this.parallelProcessState = parallelProcessState;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

}
