/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.RMTAuditDTO;
import net.atos.motorrepairmgmt.dto.RMTTaskLogDTO;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

/**
 * @author a545466
 * 
 */
@Repository
public class AuditLogRepository {

	@Value("${jdbc.url}")
	private String connectionURL;
	@Value("${jdbc.driver}")
	private String drivers;
	@Value("${jdbc.username}")
	private String username;
	@Value("${jdbc.password}")
	private String password;

	private SimpleDateFormat in = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss.SSS");

	private SimpleDateFormat out = new SimpleDateFormat("dd MMM yyyy, hh:mma");

	private Connection getDBConnection() {
		Connection con = null;
		try {
			Class.forName(drivers);
			con = DriverManager
					.getConnection(connectionURL, username, password);
		} catch (SQLException e) {
			e.getMessage();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}

	private String getAuditQuery() {
		StringBuilder querySQL = new StringBuilder();

		// select clause
		querySQL.append("select task_code, "
				// + "function_name as task_desc, "
				+ "(select function_name from rmt_actors_function where rmt_actors_function.function_code=rmt_audit.task_code) as task_desc, "
				// +
				// "--(select alias_name from rmt_column_detail where rmt_column_detail.column_name=rmt_audit_detail.column_name) as"
				+ "rmt_audit_detail.column_name," + "alias_name,"
				+ "old_value,new_value ,action_timestamp ,user_name ");

		// from clause
		querySQL.append("from rmt_audit_detail  inner join  rmt_audit on rmt_audit.rmt_audit_id=rmt_audit_detail.rmt_audit_id "
				// +
				// "inner join rmt_actors_function on rmt_actors_function.function_code=rmt_audit.task_code "
				+ "left outer join rmt_column_detail on rmt_audit_detail.column_name=rmt_column_detail.column_name ");
		// where clause

		querySQL.append("where ( rmt_column_detail.is_audit_enabled='1' and	"
				+ "(rmt_audit.subprocess_id=? or "
				+ "( rmt_audit.table_name in ('rmt_additional_contact_detail','rmt_customer_detail') and rmt_audit.master_workflow_id in (select rmt_audit.master_workflow_id from rmt_audit where rmt_audit.subprocess_id=?)) "
				+ ")" + ") and action='u' "
		// + "order by rmt_audit.rmt_audit_id,task_code "
		);

		return querySQL.toString();
	}

	public Map<String, List<RMTAuditDTO>> fetchAuditLogsBySubprocessId(
			Long subprocessId) throws SQLException {
		Map<String, List<RMTAuditDTO>> taskWiseAuditLog = null;

		if (null != subprocessId) {
			Connection con = getDBConnection();
			if (null != con) {
				String currentTask = null;
				taskWiseAuditLog = new HashMap<String, List<RMTAuditDTO>>();
				PreparedStatement auditPstmt = con
						.prepareStatement(getAuditQuery());
				auditPstmt.setLong(1, Long.valueOf(subprocessId));
				auditPstmt.setLong(2, Long.valueOf(subprocessId));
				ResultSet auditRS = auditPstmt.executeQuery();
				while (auditRS.next()) {
					List<RMTAuditDTO> list = null;

					currentTask = auditRS.getString("task_code");
					RMTAuditDTO auditLog = new RMTAuditDTO();
					auditLog.setFieldName(auditRS.getString("alias_name"));
					// auditLog.setOldValue(auditRS.getString("old_value"));
					// auditLog.setNewValue(auditRS.getString("new_value"));
					auditLog.setOldValue(getValue(
							auditRS.getString("column_name"),
							auditRS.getString("old_value")));
					auditLog.setNewValue(getValue(
							auditRS.getString("column_name"),
							auditRS.getString("new_value")));
					auditLog.setActionTimestamp(out.format(auditRS
							.getTimestamp("action_timestamp")));
					auditLog.setUserName(auditRS.getString("user_name"));

					if (taskWiseAuditLog.containsKey(currentTask)) {
						list = taskWiseAuditLog.get(currentTask);
						list.add(auditLog);
					} else {
						list = new ArrayList<RMTAuditDTO>();
						list.add(auditLog);
					}
					taskWiseAuditLog.put(currentTask, list);
				}
				closeConnection(con, auditPstmt, auditRS);
			}
		}

		return taskWiseAuditLog;
	}

	private void closeConnection(Connection con, PreparedStatement stmt,
			ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("Error closing ResultSet rs " + e);
			}
		}
		try {
			stmt.close();
		} catch (SQLException e) {
			System.out.println("Error closing statement rs " + e);
		}
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("Error SQLException " + e);
		}
	}

	private String getValue(String columnName, String code) {
		String desc = null;
		if (null != code && !code.isEmpty()) {
			if (columnName.equalsIgnoreCase("initial_warranty_claim")
					|| columnName.equalsIgnoreCase("final_warranty_state")) {
				desc = MotorRepairConstants.WARRANTY_TYPE.of(
						Integer.valueOf(code)).toString();
			} else if (columnName.equalsIgnoreCase("sub_warranty_type")) {
				desc = MotorRepairConstants.WARRANTY_SUB_TYPE.of(
						Integer.valueOf(code)).toString();
			} else if (columnName.equalsIgnoreCase("ts_support_decision")) {
				desc = MotorRepairConstants.TS_SUPPORT_DECISION.of(
						Integer.valueOf(code)).toString();
			} else if (columnName.equalsIgnoreCase("a_report_approval")) {
				desc = MotorRepairConstants.REPORT_STATUS.of(
						Integer.valueOf(code)).toString();
			} else if (columnName.equalsIgnoreCase("is_job_closed")
					|| columnName.equalsIgnoreCase("is_job_completed")
					|| columnName.equalsIgnoreCase("is_cts")
					|| columnName.equalsIgnoreCase("is_proforma_invoiced")
					|| columnName.equalsIgnoreCase("is_payment_received")
					|| columnName.equalsIgnoreCase("is_sold_to_party")
					|| columnName.equalsIgnoreCase("is_transit_damage")
					|| columnName.equalsIgnoreCase("is_ship_to_party")) {
				desc = Integer.valueOf(code)==0?"No":"Yes";
			} else {
				desc = code;
			}

		}
		return desc;

	}
}
