/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.ConfigDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 *
 */
public interface ConfigDetailRepository extends JpaRepository<ConfigDetail, Long>{

	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.configType=:configType and e.solutionCategoryId=:solnCatId ")
	List<ConfigDetail> findAllConfigDetailsByConfigType(@Param("configType") String configType, @Param("tenantId") String tenantId,@Param("solnCatId") String solnCatId);

	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.configType=:configType and e.configSubType=:subType  and e.solutionCategoryId=:solnCatId")
	List<ConfigDetail> findAllConfigDetailsByConfigTypeNSubtype(@Param("configType")  String configType, @Param("subType")  String subType, @Param("tenantId")  String tenantId,@Param("solnCatId") String solnCatId);

	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.configType=:configType and e.configEnabled=1 and e.configVisiblity=1  and e.solutionCategoryId=:solnCatId")
	List<ConfigDetail> findEnabledNVisibleConfigDetailsByConfigType(@Param("configType") String configType, @Param("tenantId") String tenantId,@Param("solnCatId") String solnCatId);

	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.configType=:configType and e.configSubType=:subType and e.configEnabled=1 and e.configVisiblity=1  and e.solutionCategoryId=:solnCatId")
	List<ConfigDetail> findEnabledNVisibleConfigDetailsByConfigTypeNSubtype(@Param("configType")  String configType, @Param("subType")  String subType, @Param("tenantId")  String tenantId,@Param("solnCatId") String solnCatId);

	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.solutionCategoryId=:solnCatId and e.configEnabled=1 and e.configVisiblity=1")
    List<ConfigDetail> findAllConfigDetailsByTenantNSolnCatId( @Param("tenantId") String tenantId,@Param("solnCatId") String solCatId);
	
	@Query("Select e from ConfigDetail e where e.tenantId=:tenantId and e.solutionCategoryId=:solnCatId")
    List<ConfigDetail> findAllConfigDetailsByTenantNSolnCatIdData( @Param("tenantId") String tenantId,@Param("solnCatId") String solCatId);

}
