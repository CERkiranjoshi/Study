package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.ARCSparesEstimates;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ARCSparesEstimatesRepository extends JpaRepository<ARCSparesEstimates, Long> {

}
