package net.atos.motorrepairmgmt.repository;


import net.atos.motorrepairmgmt.entity.TicketDetailsArc;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TicketDetailsRepository extends JpaRepository<TicketDetailsArc, Long>{
	@Query("SELECT COUNT(*) FROM TicketDetailsArc td where (td.ticketStatus=:firstStatus) OR (td.ticketStatus=:secondStatus AND td.claimRefId=:userId)")
	Long findTicketDeteailCountByTicketStatus(@Param("firstStatus") Integer firstStatus,@Param("secondStatus") Integer secondStatus,@Param("userId") String userId);
	
	@Query("SELECT COUNT(*) FROM TicketDetailsArc td where td.ticketStatus=0 AND td.refId=:arcRefId")
	Long findTicketDeteailCountByTicketStatusZero(@Param("arcRefId") Long arcRefId);
	
}
