package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a610039
 * 
 */
@Entity
@Table(name = "rmt_master_workflow_fields") 
public class MasterWorkflowFields extends RMTBasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7016238068822987477L;

	@Id
	@Column(name = "master_workflow_id",insertable = true, updatable = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long masterWorkflowFieldId;

	@Column(name = "gsp_ref_no")
	private String gspRefNo;

	@Column(name = "batch_process_id")
	private String batchProcessId;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = "company_id")
	private String companyId;

	@Column(name = "quantity")
	private Integer quantity;

	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "location")
	private String location;

	@Column(name = "solution_Category_id")
	private String solutionCategoryId;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "master_workflow_id")
	private List<CustomerDetail> customerDetails;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "master_workflow_id")
	private List<AdditionalContactDetail> additionalContactDetails;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name = "workflow_state_id")
	private WorkflowState workflowState;

	/**
	 * @return the masterWorkflowFieldId
	 */
	public Long getMasterWorkflowFieldId() {
		return masterWorkflowFieldId;
	}

	/**
	 * @param masterWorkflowFieldId
	 *            the masterWorkflowFieldId to set
	 */
	public void setMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		this.masterWorkflowFieldId = masterWorkflowFieldId;
	}

	/**
	 * @return the gspRefNo
	 */
	public String getGspRefNo() {
		return gspRefNo;
	}

	/**
	 * @param gspRefNo
	 *            the gspRefNo to set GSP customer code
	 */
	public void setGspRefNo(String gspRefNo) {
		this.gspRefNo = gspRefNo;
	}

	/**
	 * @return the batchProcessId
	 */
	public String getBatchProcessId() {
		return batchProcessId;
	}

	/**
	 * @param batchProcessId
	 *            the batchProcessId to set
	 */
	public void setBatchProcessId(String batchProcessId) {
		this.batchProcessId = batchProcessId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId
	 *            the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set Number of motors sent for repairs
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set plant location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the customerDetails
	 */
	public List<CustomerDetail> getCustomerDetails() {
		return customerDetails;
	}

	/**
	 * @param customerDetails
	 *            the customerDetails to set
	 */
	public void setCustomerDetails(List<CustomerDetail> customerDetails) {
		this.customerDetails = customerDetails;
	}

	/**
	 * @return the additionalContactDetails
	 */
	public List<AdditionalContactDetail> getAdditionalContactDetails() {
		return additionalContactDetails;
	}

	/**
	 * @param additionalContactDetails
	 *            the additionalContactDetails to set
	 */
	public void setAdditionalContactDetails(List<AdditionalContactDetail> additionalContactDetails) {
		this.additionalContactDetails = additionalContactDetails;
	}

	/**
	 * @return the workflowState
	 */
	public WorkflowState getWorkflowState() {
		return workflowState;
	}

	/**
	 * @param workflowState
	 *            the workflowState to set
	 */
	public void setWorkflowState(WorkflowState workflowState) {
		this.workflowState = workflowState;
	}
}