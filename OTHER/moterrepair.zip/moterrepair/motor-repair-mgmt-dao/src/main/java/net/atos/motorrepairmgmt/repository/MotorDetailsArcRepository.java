package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorDetailsArc;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MotorDetailsArcRepository extends JpaRepository<MotorDetailsArc, Long>{

}
