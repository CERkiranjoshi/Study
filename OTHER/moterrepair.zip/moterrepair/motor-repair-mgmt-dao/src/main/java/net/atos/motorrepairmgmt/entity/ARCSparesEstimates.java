/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a610051
 * 
 */
@Entity
@Table(name = "rmt_arc_spare_estimates")
public class ARCSparesEstimates extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8490259014012519365L;

	@Id
	@Column(name = "arc_spares_estimate_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long arcSparesEstimateId;

	@Column(name = "material_code")
	private String materialCode;

	@Column(name = "material_desc")
	private String materialDesc;

	@Column(name = "qty")
	private Integer qty;

	@Column(name = "item_unit")
	private String itemUnit;
	
	@Column(name = "total_cost")
	private Double totalCost;
	
	/**
	 * @return the arcSparesEstimateId
	 */
	public Long getArcSparesEstimateId() {
		return arcSparesEstimateId;
	}

	/**
	 * @param arcSparesEstimateId
	 *            the arcSparesEstimateId to set
	 */
	public void setArcSparesEstimateId(Long arcSparesEstimateId) {
		this.arcSparesEstimateId = arcSparesEstimateId;
	}

	/**
	 * @return the materialCode
	 */
	public String getMaterialCode() {
		return materialCode;
	}

	/**
	 * @param materialCode
	 *            the materialCode to set
	 */
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	/**
	 * @return the materialDesc
	 */
	public String getMaterialDesc() {
		return materialDesc;
	}

	/**
	 * @param materialDesc
	 *            the materialDesc to set
	 */
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	/**
	 * @return the qty
	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit the itemUnit to set
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the totalCost
	 */
	public Double getTotalCost() {
		return totalCost;
	}

	/**
	 * @param totalCost
	 *            the totalCost to set
	 */
	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

}
