package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.WorkflowState;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603975
 * 
 */

public interface WorkflowStateRepository extends JpaRepository<WorkflowState, Integer> {
	@Query("SELECT w from WorkflowState w where w.workflowStateId=:workflowStateId")
	WorkflowState findWorkflowStateByWorkflowstateId(@Param("workflowStateId") Integer workflowStateId);

	@Query("SELECT w from WorkflowState w where w.stateName=:stateName")
	WorkflowState findWorkflowStateByStateName(@Param("stateName") String stateName);
	
	@Query("SELECT w from WorkflowState w where w.workflowStateId=:workflowStateId AND w.tenantId=:tenantId AND w.solutionCategoryId=:solutionCategoryId  ")
	WorkflowState findWorkflowStateByWorkflowstateIdAndTenantIdAndSolCatId(
			@Param("workflowStateId") Integer workflowStateId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);


}
