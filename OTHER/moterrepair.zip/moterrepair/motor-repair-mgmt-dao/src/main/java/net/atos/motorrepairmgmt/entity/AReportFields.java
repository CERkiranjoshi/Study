/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775
 *
 */
// not required as of now
// @Entity(name="rmt_motor_a_report_fields")
public class AReportFields implements Serializable {

	private static final long serialVersionUID = 13458758998L;

	@Id
	@Column(name = "motor_a_report_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String motorAReportId;

	@Column(name = "application_equipment")
	private String applicationEquipment;

	@Column(name = "gdsqr_equipment")
	private String gdSqrEquipment;

	@Column(name = "coupling_type")
	private String couplingType;

	@Column(name = "belt_type")
	private String beltType;

	@Column(name = "belt_no")
	private String beltNo;

	@Column(name = "belt_size")
	private String beltSize;

	@Column(name = "motor_diameter")
	private Float motorDiameter;

	@Column(name = "drivenPulley_diameter")
	private Float drivenPulleyDiameter;

	@Column(name = "pulley_width")
	private Float pulleyWidth;

	@Column(name = "pulley_weight")
	private Float pulleyWeight;

	@Column(name = "motor_inlet_temp")
	private Float motorInletTemp;

	@Column(name = "body_temp")
	private Float bodyTemp;

	@Column(name = "winding_temp")
	private Float windingTemp;

	@Column(name = "min_ambient_temp")
	private Float minAmbientTemp;

	@Column(name = "max_ambient_temp")
	private Float maxAmbientTemp;

	@Column(name = "changes_operating_before_failure")
	private Boolean changesOperatingBefFailure;

	@Column(name = "foundation_detail")
	private Boolean foundationDetail;

	@Column(name = "installationCondition")
	private Boolean installation_condition;

	@Column(name = "starting_method")
	private Boolean startingMethod;

	@Column(name = "starter_details")
	private Boolean starterDetails;

	@Column(name = "starter_timer")
	private Float starterTimer;

	@Column(name = "fuse_protect")
	private Integer fuseProtect;

	@Column(name = "cable_lugs_type")
	private String cableLugsType;

	@Column(name = "motor_earthing")
	private Boolean motorEarthing;

	@Column(name = "motor_meach_assembly")
	private Boolean motorMeachAssembly;

	@Column(name = "motor_cable")
	private Boolean motorCable;

	@Column(name = "motor_type")
	private Boolean motorType;

	@Column(name = "motor_size")
	private Boolean motorSize;

	@Column(name = "commisioning_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date commisioningDate;

	@Column(name = "operate_hrs")
	private float operateHours;

	@Column(name = "grease_type")
	private String greaseType;

	@Column(name = "vibration_detail")
	private String vibrationDetail;

	@Column(name = "other_findings")
	private String otherFindings;

	@Column(name = "motor_interval")
	private float motorInterval;

	@Column(name = "drive_end_no")
	private String driveEndNo;

	@Column(name = "non_drive_end_no")
	private String nonDriveEndNo;

	@Column(name = "housing_ribs_cond")
	private Boolean housingRibsCond;

	@Column(name = "log_book_state")
	private Boolean logBookState;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "motor_location")
	private String motorLocation;

	@Column(name = "complaint_ref_detail")
	private String complaintRefDetail;

	@Column(name = "attended_by")
	private String attendedBy;

	@Column(name = "attended_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date attendedOn;

	@Column(name = "contact_person_detail")
	private String contactPersonDetail;

	@Column(name = "complaint_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date complaintDate;

	@Column(name = "po_number")
	private String poNumber;

	@Column(name = "motor_nameplate")
	private String motorNameplate;

	@Column(name = "operation_hrs_bef_failure")
	private String operationHrsBefFailure;

	@Column(name = "operating_hrs_per_day")
	private String operatingHrsPerDay;

	@Column(name = "rewond_or_repair")
	private Boolean rewoundOrRepair;

	@Column(name = "rewoundDetail")
	private String rewoundDetail;

	@Column(name = "log_book_detail")
	private String logBookDetail;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "rmt_motor_voltage_detail_id")
	private MotorVoltageDetail motorVoltageDetail;

	/**
	 * @return the motorAReportId
	 */
	public String getMotorAReportId() {
		return motorAReportId;
	}

	/**
	 * @param motorAReportId
	 *            the motorAReportId to set
	 */
	public void setMotorAReportId(String motorAReportId) {
		this.motorAReportId = motorAReportId;
	}

	/**
	 * @return the applicationEquipment
	 */
	public String getApplicationEquipment() {
		return applicationEquipment;
	}

	/**
	 * @param applicationEquipment
	 *            the applicationEquipment to set
	 */
	public void setApplicationEquipment(String applicationEquipment) {
		this.applicationEquipment = applicationEquipment;
	}

	/**
	 * @return the gdSqrEquipment
	 */
	public String getGdSqrEquipment() {
		return gdSqrEquipment;
	}

	/**
	 * @param gdSqrEquipment
	 *            the gdSqrEquipment to set
	 */
	public void setGdSqrEquipment(String gdSqrEquipment) {
		this.gdSqrEquipment = gdSqrEquipment;
	}

	/**
	 * @return the couplingType
	 */
	public String getCouplingType() {
		return couplingType;
	}

	/**
	 * @param couplingType
	 *            the couplingType to set
	 */
	public void setCouplingType(String couplingType) {
		this.couplingType = couplingType;
	}

	/**
	 * @return the beltType
	 */
	public String getBeltType() {
		return beltType;
	}

	/**
	 * @param beltType
	 *            the beltType to set
	 */
	public void setBeltType(String beltType) {
		this.beltType = beltType;
	}

	/**
	 * @return the beltNo
	 */
	public String getBeltNo() {
		return beltNo;
	}

	/**
	 * @param beltNo
	 *            the beltNo to set
	 */
	public void setBeltNo(String beltNo) {
		this.beltNo = beltNo;
	}

	/**
	 * @return the beltSize
	 */
	public String getBeltSize() {
		return beltSize;
	}

	/**
	 * @param beltSize
	 *            the beltSize to set
	 */
	public void setBeltSize(String beltSize) {
		this.beltSize = beltSize;
	}

	/**
	 * @return the motorDiameter
	 */
	public Float getMotorDiameter() {
		return motorDiameter;
	}

	/**
	 * @param motorDiameter
	 *            the motorDiameter to set
	 */
	public void setMotorDiameter(Float motorDiameter) {
		this.motorDiameter = motorDiameter;
	}

	/**
	 * @return the drivenPulleyDiameter
	 */
	public Float getDrivenPulleyDiameter() {
		return drivenPulleyDiameter;
	}

	/**
	 * @param drivenPulleyDiameter
	 *            the drivenPulleyDiameter to set
	 */
	public void setDrivenPulleyDiameter(Float drivenPulleyDiameter) {
		this.drivenPulleyDiameter = drivenPulleyDiameter;
	}

	/**
	 * @return the pulleyWidth
	 */
	public Float getPulleyWidth() {
		return pulleyWidth;
	}

	/**
	 * @param pulleyWidth
	 *            the pulleyWidth to set
	 */
	public void setPulleyWidth(Float pulleyWidth) {
		this.pulleyWidth = pulleyWidth;
	}

	/**
	 * @return the pulleyWeight
	 */
	public Float getPulleyWeight() {
		return pulleyWeight;
	}

	/**
	 * @param pulleyWeight
	 *            the pulleyWeight to set
	 */
	public void setPulleyWeight(Float pulleyWeight) {
		this.pulleyWeight = pulleyWeight;
	}

	/**
	 * @return the motorInletTemp
	 */
	public Float getMotorInletTemp() {
		return motorInletTemp;
	}

	/**
	 * @param motorInletTemp
	 *            the motorInletTemp to set
	 */
	public void setMotorInletTemp(Float motorInletTemp) {
		this.motorInletTemp = motorInletTemp;
	}

	/**
	 * @return the bodyTemp
	 */
	public Float getBodyTemp() {
		return bodyTemp;
	}

	/**
	 * @param bodyTemp
	 *            the bodyTemp to set
	 */
	public void setBodyTemp(Float bodyTemp) {
		this.bodyTemp = bodyTemp;
	}

	/**
	 * @return the windingTemp
	 */
	public Float getWindingTemp() {
		return windingTemp;
	}

	/**
	 * @param windingTemp
	 *            the windingTemp to set
	 */
	public void setWindingTemp(Float windingTemp) {
		this.windingTemp = windingTemp;
	}

	/**
	 * @return the minAmbientTemp
	 */
	public Float getMinAmbientTemp() {
		return minAmbientTemp;
	}

	/**
	 * @param minAmbientTemp
	 *            the minAmbientTemp to set
	 */
	public void setMinAmbientTemp(Float minAmbientTemp) {
		this.minAmbientTemp = minAmbientTemp;
	}

	/**
	 * @return the maxAmbientTemp
	 */
	public Float getMaxAmbientTemp() {
		return maxAmbientTemp;
	}

	/**
	 * @param maxAmbientTemp
	 *            the maxAmbientTemp to set
	 */
	public void setMaxAmbientTemp(Float maxAmbientTemp) {
		this.maxAmbientTemp = maxAmbientTemp;
	}

	/**
	 * @return the changesOperatingBefFailure
	 */
	public Boolean getChangesOperatingBefFailure() {
		return changesOperatingBefFailure;
	}

	/**
	 * @param changesOperatingBefFailure
	 *            the changesOperatingBefFailure to set
	 */
	public void setChangesOperatingBefFailure(Boolean changesOperatingBefFailure) {
		this.changesOperatingBefFailure = changesOperatingBefFailure;
	}

	/**
	 * @return the foundationDetail
	 */
	public Boolean getFoundationDetail() {
		return foundationDetail;
	}

	/**
	 * @param foundationDetail
	 *            the foundationDetail to set
	 */
	public void setFoundationDetail(Boolean foundationDetail) {
		this.foundationDetail = foundationDetail;
	}

	/**
	 * @return the installation_condition
	 */
	public Boolean getInstallation_condition() {
		return installation_condition;
	}

	/**
	 * @param installation_condition
	 *            the installation_condition to set
	 */
	public void setInstallation_condition(Boolean installation_condition) {
		this.installation_condition = installation_condition;
	}

	/**
	 * @return the startingMethod
	 */
	public Boolean getStartingMethod() {
		return startingMethod;
	}

	/**
	 * @param startingMethod
	 *            the startingMethod to set
	 */
	public void setStartingMethod(Boolean startingMethod) {
		this.startingMethod = startingMethod;
	}

	/**
	 * @return the starterDetails
	 */
	public Boolean getStarterDetails() {
		return starterDetails;
	}

	/**
	 * @param starterDetails
	 *            the starterDetails to set
	 */
	public void setStarterDetails(Boolean starterDetails) {
		this.starterDetails = starterDetails;
	}

	/**
	 * @return the starterTimer
	 */
	public Float getStarterTimer() {
		return starterTimer;
	}

	/**
	 * @param starterTimer
	 *            the starterTimer to set
	 */
	public void setStarterTimer(Float starterTimer) {
		this.starterTimer = starterTimer;
	}

	/**
	 * @return the fuseProtect
	 */
	public Integer getFuseProtect() {
		return fuseProtect;
	}

	/**
	 * @param fuseProtect
	 *            the fuseProtect to set
	 */
	public void setFuseProtect(Integer fuseProtect) {
		this.fuseProtect = fuseProtect;
	}

	/**
	 * @return the cableLugsType
	 */
	public String getCableLugsType() {
		return cableLugsType;
	}

	/**
	 * @param cableLugsType
	 *            the cableLugsType to set
	 */
	public void setCableLugsType(String cableLugsType) {
		this.cableLugsType = cableLugsType;
	}

	/**
	 * @return the motorEarthing
	 */
	public Boolean getMotorEarthing() {
		return motorEarthing;
	}

	/**
	 * @param motorEarthing
	 *            the motorEarthing to set
	 */
	public void setMotorEarthing(Boolean motorEarthing) {
		this.motorEarthing = motorEarthing;
	}

	/**
	 * @return the motorMeachAssembly
	 */
	public Boolean getMotorMeachAssembly() {
		return motorMeachAssembly;
	}

	/**
	 * @param motorMeachAssembly
	 *            the motorMeachAssembly to set
	 */
	public void setMotorMeachAssembly(Boolean motorMeachAssembly) {
		this.motorMeachAssembly = motorMeachAssembly;
	}

	/**
	 * @return the motorCable
	 */
	public Boolean getMotorCable() {
		return motorCable;
	}

	/**
	 * @param motorCable
	 *            the motorCable to set
	 */
	public void setMotorCable(Boolean motorCable) {
		this.motorCable = motorCable;
	}

	/**
	 * @return the motorType
	 */
	public Boolean getMotorType() {
		return motorType;
	}

	/**
	 * @param motorType
	 *            the motorType to set
	 */
	public void setMotorType(Boolean motorType) {
		this.motorType = motorType;
	}

	/**
	 * @return the motorSize
	 */
	public Boolean getMotorSize() {
		return motorSize;
	}

	/**
	 * @param motorSize
	 *            the motorSize to set
	 */
	public void setMotorSize(Boolean motorSize) {
		this.motorSize = motorSize;
	}

	/**
	 * @return the commisioningDate
	 */
	public Date getCommisioningDate() {
		return commisioningDate;
	}

	/**
	 * @param commisioningDate
	 *            the commisioningDate to set
	 */
	public void setCommisioningDate(Date commisioningDate) {
		this.commisioningDate = commisioningDate;
	}

	/**
	 * @return the operateHours
	 */
	public float getOperateHours() {
		return operateHours;
	}

	/**
	 * @param operateHours
	 *            the operateHours to set
	 */
	public void setOperateHours(float operateHours) {
		this.operateHours = operateHours;
	}

	/**
	 * @return the greaseType
	 */
	public String getGreaseType() {
		return greaseType;
	}

	/**
	 * @param greaseType
	 *            the greaseType to set
	 */
	public void setGreaseType(String greaseType) {
		this.greaseType = greaseType;
	}

	/**
	 * @return the vibrationDetail
	 */
	public String getVibrationDetail() {
		return vibrationDetail;
	}

	/**
	 * @param vibrationDetail
	 *            the vibrationDetail to set
	 */
	public void setVibrationDetail(String vibrationDetail) {
		this.vibrationDetail = vibrationDetail;
	}

	/**
	 * @return the otherFindings
	 */
	public String getOtherFindings() {
		return otherFindings;
	}

	/**
	 * @param otherFindings
	 *            the otherFindings to set
	 */
	public void setOtherFindings(String otherFindings) {
		this.otherFindings = otherFindings;
	}

	/**
	 * @return the motorInterval
	 */
	public float getMotorInterval() {
		return motorInterval;
	}

	/**
	 * @param motorInterval
	 *            the motorInterval to set
	 */
	public void setMotorInterval(float motorInterval) {
		this.motorInterval = motorInterval;
	}

	/**
	 * @return the driveEndNo
	 */
	public String getDriveEndNo() {
		return driveEndNo;
	}

	/**
	 * @param driveEndNo
	 *            the driveEndNo to set
	 */
	public void setDriveEndNo(String driveEndNo) {
		this.driveEndNo = driveEndNo;
	}

	/**
	 * @return the nonDriveEndNo
	 */
	public String getNonDriveEndNo() {
		return nonDriveEndNo;
	}

	/**
	 * @param nonDriveEndNo
	 *            the nonDriveEndNo to set
	 */
	public void setNonDriveEndNo(String nonDriveEndNo) {
		this.nonDriveEndNo = nonDriveEndNo;
	}

	/**
	 * @return the housingRibsCond
	 */
	public Boolean getHousingRibsCond() {
		return housingRibsCond;
	}

	/**
	 * @param housingRibsCond
	 *            the housingRibsCond to set
	 */
	public void setHousingRibsCond(Boolean housingRibsCond) {
		this.housingRibsCond = housingRibsCond;
	}

	/**
	 * @return the logBookState
	 */
	public Boolean getLogBookState() {
		return logBookState;
	}

	/**
	 * @param logBookState
	 *            the logBookState to set
	 */
	public void setLogBookState(Boolean logBookState) {
		this.logBookState = logBookState;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks
	 *            the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the motorLocation
	 */
	public String getMotorLocation() {
		return motorLocation;
	}

	/**
	 * @param motorLocation
	 *            the motorLocation to set
	 */
	public void setMotorLocation(String motorLocation) {
		this.motorLocation = motorLocation;
	}

	/**
	 * @return the complaintRefDetail
	 */
	public String getComplaintRefDetail() {
		return complaintRefDetail;
	}

	/**
	 * @param complaintRefDetail
	 *            the complaintRefDetail to set
	 */
	public void setComplaintRefDetail(String complaintRefDetail) {
		this.complaintRefDetail = complaintRefDetail;
	}

	/**
	 * @return the attendedBy
	 */
	public String getAttendedBy() {
		return attendedBy;
	}

	/**
	 * @param attendedBy
	 *            the attendedBy to set
	 */
	public void setAttendedBy(String attendedBy) {
		this.attendedBy = attendedBy;
	}

	/**
	 * @return the attendedOn
	 */
	public Date getAttendedOn() {
		return attendedOn;
	}

	/**
	 * @param attendedOn
	 *            the attendedOn to set
	 */
	public void setAttendedOn(Date attendedOn) {
		this.attendedOn = attendedOn;
	}

	/**
	 * @return the contactPersonDetail
	 */
	public String getContactPersonDetail() {
		return contactPersonDetail;
	}

	/**
	 * @param contactPersonDetail
	 *            the contactPersonDetail to set
	 */
	public void setContactPersonDetail(String contactPersonDetail) {
		this.contactPersonDetail = contactPersonDetail;
	}

	/**
	 * @return the complaintDate
	 */
	public Date getComplaintDate() {
		return complaintDate;
	}

	/**
	 * @param complaintDate
	 *            the complaintDate to set
	 */
	public void setComplaintDate(Date complaintDate) {
		this.complaintDate = complaintDate;
	}

	/**
	 * @return the poNumber
	 */
	public String getPoNumber() {
		return poNumber;
	}

	/**
	 * @param poNumber
	 *            the poNumber to set
	 */
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	/**
	 * @return the motorNameplate
	 */
	public String getMotorNameplate() {
		return motorNameplate;
	}

	/**
	 * @param motorNameplate
	 *            the motorNameplate to set
	 */
	public void setMotorNameplate(String motorNameplate) {
		this.motorNameplate = motorNameplate;
	}

	/**
	 * @return the operationHrsBefFailure
	 */
	public String getOperationHrsBefFailure() {
		return operationHrsBefFailure;
	}

	/**
	 * @param operationHrsBefFailure
	 *            the operationHrsBefFailure to set
	 */
	public void setOperationHrsBefFailure(String operationHrsBefFailure) {
		this.operationHrsBefFailure = operationHrsBefFailure;
	}

	/**
	 * @return the operatingHrsPerDay
	 */
	public String getOperatingHrsPerDay() {
		return operatingHrsPerDay;
	}

	/**
	 * @param operatingHrsPerDay
	 *            the operatingHrsPerDay to set
	 */
	public void setOperatingHrsPerDay(String operatingHrsPerDay) {
		this.operatingHrsPerDay = operatingHrsPerDay;
	}

	/**
	 * @return the rewoundOrRepair
	 */
	public Boolean getRewoundOrRepair() {
		return rewoundOrRepair;
	}

	/**
	 * @param rewoundOrRepair
	 *            the rewoundOrRepair to set
	 */
	public void setRewoundOrRepair(Boolean rewoundOrRepair) {
		this.rewoundOrRepair = rewoundOrRepair;
	}

	/**
	 * @return the rewoundDetail
	 */
	public String getRewoundDetail() {
		return rewoundDetail;
	}

	/**
	 * @param rewoundDetail
	 *            the rewoundDetail to set
	 */
	public void setRewoundDetail(String rewoundDetail) {
		this.rewoundDetail = rewoundDetail;
	}

	/**
	 * @return the logBookDetail
	 */
	public String getLogBookDetail() {
		return logBookDetail;
	}

	/**
	 * @param logBookDetail
	 *            the logBookDetail to set
	 */
	public void setLogBookDetail(String logBookDetail) {
		this.logBookDetail = logBookDetail;
	}

}
