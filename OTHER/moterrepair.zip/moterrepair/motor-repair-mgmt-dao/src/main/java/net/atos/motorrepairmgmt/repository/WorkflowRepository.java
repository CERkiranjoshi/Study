package net.atos.motorrepairmgmt.repository;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.entity.ConfigDetail;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

/**
 * 
 * @author a610013
 * 
 */
@Repository
public class WorkflowRepository {

	@Value("${jdbc.url}")
	private String connectionURL;
	@Value("${jdbc.driver}")
	private String drivers;
	@Value("${jdbc.username}")
	private String username;
	@Value("${jdbc.password}")
	private String password;

	@Autowired
	private ConfigDetailRepository configDetailRepo;

	public String findAllMasterWorkflowFieldsWorkflow(String gspRefNo,
			String subProcessId) {

		String fileName = null;
		Statement stmt = null;
		Connection con = null;
		ResultSet mastWflwRS = null;
		ResultSet subProFieldsRS = null;
		List<Map<String, String>> list = null;
		Map<String, String> map = null;
		ResultSet colDetailsRS = null;
		Map<String, Map<String, String>> tableColAlias = null;
		try {
			Class.forName(drivers);
			con = DriverManager
					.getConnection(connectionURL, username, password);

			PreparedStatement colDetailsPstmt = con
					.prepareStatement("SELECT r.table_name,r.column_name, r.alias_name FROM rmt_column_detail r  WHERE r.is_csv_enabled=1 order by 1 ");
			colDetailsRS = colDetailsPstmt.executeQuery();
			tableColAlias = new HashMap<String, Map<String, String>>();
			Map<String, String> colLevel = null;
			String lastTableChange = null;
			String currentTableChange = null;
			while (colDetailsRS.next()) {
				currentTableChange = colDetailsRS.getString("table_name");
				if (!tableColAlias.containsKey(lastTableChange)) {

					if (lastTableChange != null && colLevel != null
							&& (!lastTableChange.equals(currentTableChange))) {
						tableColAlias.put(lastTableChange, colLevel);
					}

				}
				if (colLevel == null
						|| (!lastTableChange.equals(currentTableChange))) {
					colLevel = new HashMap<String, String>();
				}
				colLevel.put(colDetailsRS.getString("column_name"),
						colDetailsRS.getString("alias_name"));
				lastTableChange = currentTableChange;
			}
			tableColAlias.put(lastTableChange, colLevel);

			String mastCol = "*", custCol = "*", addCol = "*", subCol = "*", odCol = "*", sdCol = "*", bCol = "*", dCol = "*";
			Map<String, String> mastMap = null, custMap = null, addMap = null, subMap = null, odMap = null, sdMap = null, bMap = null, dMap = null;
			List<String> subprocessColNames = new ArrayList<String>();
			List<String> custDetailsColNames = new ArrayList<String>();
			List<String> addDetailsColNames = new ArrayList<String>();
			List<String> orderDetailsColNames = new ArrayList<String>();
			List<String> sparesColNames = new ArrayList<String>();
			List<String> bReportColNames = new ArrayList<String>();
			List<String> dReportColNames = new ArrayList<String>();
			int masterCount = 0;
			int subprocessMaxRowCtr = 0;
			int custDetailsMaxRowCtr = 0;
			int addDetailsMaxRowCtr = 0;
			int sparesMaxRowCtr = 0;
			int orderDetailsMaxRowCtr = 0;
			int bReportMaxRowCtr = 0;
			int dReportMaxRowCtr = 0;

			int custDetailsRowCtr = 0;
			int addDetailsRowCtr = 0;
			int subProcessFieldsRowCtr = 0;
			int orderDetailsRowCtr = 0;
			int sparesDetailsRowCtr = 0;
			int bReportRowCtr = 0;
			int dReportRowCtr = 0;

			Map<Integer, Integer> sub_order_count = new HashMap<Integer, Integer>();
			Map<Integer, Integer> sub_spare_count = new HashMap<Integer, Integer>();
			Map<Integer, Integer> sub_b_count = new HashMap<Integer, Integer>();
			Map<Integer, Integer> sub_d_count = new HashMap<Integer, Integer>();
			List<String> finalMasterFieldsHeaders = new ArrayList<String>();

			mastMap = tableColAlias.get("rmt_master_workflow_fields");
			if (mastMap != null) {
				mastCol = mastMap.keySet().toString().replace("[", "")
						.replace("]", "");
				StringBuilder sql = new StringBuilder("Select " + mastCol
						+ " from rmt_master_workflow_fields");
				PreparedStatement mastWflwPstmt = null;
				if (null != gspRefNo && !gspRefNo.equals("")) {
					sql = sql.append(" where gsp_ref_no= ? ");

					mastWflwPstmt = con.prepareStatement(sql.toString());
					mastWflwPstmt.setString(1, gspRefNo);

				} else {
					mastWflwPstmt = con.prepareStatement(sql.toString());
					fileName = "AllMasterWorkflow.csv";
				}

				mastWflwRS = mastWflwPstmt.executeQuery();
				stmt = con.createStatement();

				list = new ArrayList<Map<String, String>>();
				ResultSetMetaData mastWflwMeta = mastWflwRS.getMetaData();

				while (mastWflwRS.next()) {

					masterCount++;
					subProcessFieldsRowCtr = 0;
					custDetailsRowCtr = 0;
					addDetailsRowCtr = 0;
					orderDetailsRowCtr = 0;
					sparesDetailsRowCtr = 0;
					dReportRowCtr = 0;

					map = new HashMap<String, String>();
					String masterWorkflowId = null;
					for (int i = 1; i <= mastWflwMeta.getColumnCount(); i++) {
						String colName = mastWflwMeta.getColumnName(i);
						String colValue = String.valueOf(mastWflwRS
								.getObject(i));
						map.put(mastMap.get(colName), colValue);
						if ("master_workflow_id".equals(colName)) {
							masterWorkflowId = colValue;
							if (fileName == null) {
								fileName = "MasterWorkflow_" + masterWorkflowId
										+ ".csv";
							}
						}
						if (masterCount == 1) {
							finalMasterFieldsHeaders.add(mastMap.get(colName));

						}
					}
					list.add(map);

					custMap = tableColAlias.get("rmt_customer_detail");
					if (custMap != null) {
						custCol = custMap.keySet().toString().replace("[", "")
								.replace("]", "");
						PreparedStatement custDetailsPstmt = con
								.prepareStatement(new StringBuilder(
										"SELECT "
												+ custCol
												+ " FROM rmt_customer_detail where master_workflow_id = ?")
										.toString());
						custDetailsPstmt.setLong(1,
								Long.valueOf(masterWorkflowId));
						ResultSet custDetailsRS = custDetailsPstmt
								.executeQuery();
						ResultSetMetaData custDetailsMeta = custDetailsRS
								.getMetaData();
						int custDetailsCtr = 1;
						while (custDetailsRS.next()) {
							custDetailsRowCtr++;
							for (int i = 1; i <= custDetailsMeta
									.getColumnCount(); i++) {
								String colName = custDetailsMeta
										.getColumnName(i);
								String colValue = custDetailsRS
										.getString(colName);
								map.put("CD_" + custMap.get(colName) + "_"
										+ custDetailsCtr, colValue);
								if (custDetailsRowCtr == 1
										&& custDetailsMaxRowCtr == 0) {
									custDetailsColNames.add(colName);
								}
							}
							custDetailsCtr++;
						}
						if (custDetailsMaxRowCtr < custDetailsRowCtr)
							custDetailsMaxRowCtr = custDetailsRowCtr;
					}

					addMap = tableColAlias.get("rmt_additional_contact_detail");
					if (addMap != null) {
						addCol = addMap.keySet().toString().replace("[", "")
								.replace("]", "");
						PreparedStatement addDetailsPstmt = con
								.prepareStatement("SELECT "
										+ addCol
										+ " FROM rmt_additional_contact_detail where master_workflow_id = ?");
						addDetailsPstmt.setLong(1,
								Long.valueOf(masterWorkflowId));
						ResultSet addDetailsRS = addDetailsPstmt.executeQuery();
						ResultSetMetaData addDetailsMeta = addDetailsRS
								.getMetaData();
						int addDetailsCtr = 1;
						while (addDetailsRS.next()) {
							addDetailsRowCtr++;
							for (int i = 1; i <= addDetailsMeta
									.getColumnCount(); i++) {
								String colName = addDetailsMeta
										.getColumnName(i);
								String colValue = addDetailsRS
										.getString(colName);
								map.put("AD_" + addMap.get(colName) + "_"
										+ addDetailsCtr, colValue);
								if (addDetailsRowCtr == 1
										&& addDetailsMaxRowCtr == 0) {
									addDetailsColNames.add(colName);
								}
							}
							addDetailsCtr++;
						}
						if (addDetailsMaxRowCtr < addDetailsRowCtr)
							addDetailsMaxRowCtr = addDetailsRowCtr;
					}

					subMap = tableColAlias.get("rmt_motor_sub_proc_fields");
					if (subMap != null) {
						subCol = subMap.keySet().toString().replace("[", "")
								.replace("]", "");
						String sql1 = "Select "
								+ subCol
								+ " from rmt_motor_sub_proc_fields where master_workflow_id = ?";
						if (null != subProcessId) {
							String subprocsql = "and subprocess_id= ? ";
							sql1 += subprocsql;

						}
						PreparedStatement subProFieldsPstmt = con
								.prepareStatement(sql1);
						subProFieldsPstmt.setLong(1,
								Long.valueOf(masterWorkflowId));
						if (null != subProcessId) {
							subProFieldsPstmt.setLong(2,
									Long.valueOf(subProcessId));
						}
						subProFieldsRS = subProFieldsPstmt.executeQuery();
						stmt = con.createStatement();

						ResultSetMetaData subProFieldsMeta = subProFieldsRS
								.getMetaData();
						int subProFieldsCtr = 1;
						while (subProFieldsRS.next()) {

							String wlfwSubProcessId = null;
							subProcessFieldsRowCtr++;

							for (int i = 1; i <= subProFieldsMeta
									.getColumnCount(); i++) {
								String colName = subProFieldsMeta
										.getColumnName(i);
								String colValue = subProFieldsRS
										.getString(colName);
								StringBuilder subprocessfieldsColValue = new StringBuilder();
								if (colValue == null) {
									subprocessfieldsColValue.append("");
								} else {
									subprocessfieldsColValue.append(colValue);
								}

								map.put("SF_" + subMap.get(colName) + "_"
										+ subProFieldsCtr,
										subprocessfieldsColValue.toString());
								if (subProcessFieldsRowCtr == 1
										&& subprocessMaxRowCtr == 0) {
									subprocessColNames.add(colName);
								}
								if ("subprocess_id".equals(colName)) {

									wlfwSubProcessId = colValue;
								}
							}

							odMap = tableColAlias.get("rmt_motor_order_detail");
							if (odMap != null) {
								odCol = odMap.keySet().toString()
										.replace("[", "").replace("]", "");
								PreparedStatement orderDetailsPstmt = con
										.prepareStatement("SELECT "
												+ odCol
												+ " FROM rmt_motor_order_detail where subprocess_id = ?");
								orderDetailsPstmt.setLong(1,
										Long.valueOf(wlfwSubProcessId));
								ResultSet orderDetailsRS = orderDetailsPstmt
										.executeQuery();
								ResultSetMetaData orderDetailsMeta = orderDetailsRS
										.getMetaData();
								int orderDetailsCtr = 1;
								while (orderDetailsRS.next()) {

									orderDetailsRowCtr++;
									for (int i = 1; i <= orderDetailsMeta
											.getColumnCount(); i++) {
										String colName = orderDetailsMeta
												.getColumnName(i);
										String colValue = orderDetailsRS
												.getString(colName);
										map.put("OD_" + odMap.get(colName)
												+ "_" + subProFieldsCtr + "_"
												+ orderDetailsCtr, colValue);
										if (orderDetailsRowCtr == 1
												&& orderDetailsMaxRowCtr == 0) {
											orderDetailsColNames.add(colName);
										}

									}
									orderDetailsCtr++;
								}
								if (orderDetailsMaxRowCtr < orderDetailsRowCtr)
									orderDetailsMaxRowCtr = orderDetailsRowCtr;

								if (sub_order_count
										.containsKey(subProcessFieldsRowCtr)) {
									int val = sub_order_count
											.get(subProcessFieldsRowCtr);
									if (val < orderDetailsCtr - 1)
										sub_order_count.put(
												subProcessFieldsRowCtr,
												orderDetailsCtr - 1);
								} else {
									sub_order_count.put(subProcessFieldsRowCtr,
											orderDetailsCtr - 1);
								}

							}

							sdMap = tableColAlias
									.get("rmt_motor_spares_detail");
							if (sdMap != null) {
								sdCol = sdMap.keySet().toString()
										.replace("[", "").replace("]", "");
								PreparedStatement sparesDetailsPstmt = con
										.prepareStatement("SELECT "
												+ sdCol
												+ " FROM rmt_motor_spares_detail where subprocess_id = ?");
								sparesDetailsPstmt.setLong(1,
										Long.valueOf(wlfwSubProcessId));
								ResultSet sparesDetailsRS = sparesDetailsPstmt
										.executeQuery();
								ResultSetMetaData sparesDetailsMeta = sparesDetailsRS
										.getMetaData();
								int sparesDetailsCtr = 1;
								while (sparesDetailsRS.next()) {
									sparesDetailsRowCtr++;
									for (int i = 1; i <= sparesDetailsMeta
											.getColumnCount(); i++) {
										String colName = sparesDetailsMeta
												.getColumnName(i);
										String colValue = sparesDetailsRS
												.getString(colName);
										map.put("SD_" + sdMap.get(colName)
												+ "_" + subProFieldsCtr + "_"
												+ sparesDetailsCtr, colValue);
										if (sparesDetailsRowCtr == 1
												&& sparesMaxRowCtr == 0) {
											sparesColNames.add(colName);
										}
									}
									sparesDetailsCtr++;
								}
								if (sparesMaxRowCtr < sparesDetailsRowCtr)
									sparesMaxRowCtr = sparesDetailsRowCtr;

								if (sub_spare_count
										.containsKey(subProcessFieldsRowCtr)) {
									int val = sub_spare_count
											.get(subProcessFieldsRowCtr);
									if (val < sparesDetailsCtr - 1)
										sub_spare_count.put(
												subProcessFieldsRowCtr,
												sparesDetailsCtr - 1);
								} else {
									sub_spare_count.put(subProcessFieldsRowCtr,
											sparesDetailsCtr - 1);
								}
							}

							bMap = tableColAlias
									.get("rmt_motor_b_report_fields");
							if (bMap != null) {
								bCol = bMap.keySet().toString()
										.replace("[", "").replace("]", "");
								PreparedStatement bReportPstmt = con
										.prepareStatement("SELECT "
												+ bCol
												+ " FROM rmt_motor_b_report_fields where subprocess_id = ?");
								bReportPstmt.setLong(1,
										Long.valueOf(wlfwSubProcessId));
								ResultSet bReportRS = bReportPstmt
										.executeQuery();
								ResultSetMetaData bReportMeta = bReportRS
										.getMetaData();
								int bReportCtr = 1;
								while (bReportRS.next()) {
									bReportRowCtr++;
									for (int i = 1; i <= bReportMeta
											.getColumnCount(); i++) {
										String colName = bReportMeta
												.getColumnName(i);
										String colValue = bReportRS
												.getString(colName);
										map.put("BR_" + bMap.get(colName) + "_"
												+ subProFieldsCtr + "_"
												+ bReportCtr, colValue);
										if (bReportRowCtr == 1
												&& bReportMaxRowCtr == 0) {
											bReportColNames.add(colName);
										}
									}
									bReportCtr++;
								}
								if (bReportMaxRowCtr < bReportRowCtr)
									bReportMaxRowCtr = bReportRowCtr;

								if (sub_b_count
										.containsKey(subProcessFieldsRowCtr)) {
									int val = sub_b_count
											.get(subProcessFieldsRowCtr);
									if (val < bReportCtr - 1)
										sub_b_count.put(subProcessFieldsRowCtr,
												bReportCtr - 1);
								} else {
									sub_b_count.put(subProcessFieldsRowCtr,
											bReportCtr - 1);
								}
							}

							dMap = tableColAlias
									.get("rmt_motor_d_report_fields");
							if (dMap != null) {
								dCol = dMap.keySet().toString()
										.replace("[", "").replace("]", "");
								PreparedStatement dReportPstmt = con
										.prepareStatement("SELECT "
												+ dCol
												+ " FROM rmt_motor_d_report_fields where subprocess_id = ?");
								dReportPstmt.setLong(1,
										Long.valueOf(wlfwSubProcessId));
								ResultSet dReportRS = dReportPstmt
										.executeQuery();
								ResultSetMetaData dReportMeta = dReportRS
										.getMetaData();
								int dReportCtr = 1;
								while (dReportRS.next()) {
									dReportRowCtr++;
									for (int i = 1; i <= dReportMeta
											.getColumnCount(); i++) {
										String colName = dReportMeta
												.getColumnName(i);
										String colValue = dReportRS
												.getString(colName);
										map.put("DR_" + dMap.get(colName) + "_"
												+ subProFieldsCtr + "_"
												+ dReportCtr, colValue);
										if (dReportRowCtr == 1
												&& dReportMaxRowCtr == 0) {
											dReportColNames.add(colName);
										}
									}
									dReportCtr++;
								}
								if (dReportMaxRowCtr < dReportRowCtr)
									dReportMaxRowCtr = dReportRowCtr;

								if (sub_d_count
										.containsKey(subProcessFieldsRowCtr)) {
									int val = sub_d_count
											.get(subProcessFieldsRowCtr);
									if (val < dReportCtr - 1)
										sub_d_count.put(subProcessFieldsRowCtr,
												dReportCtr - 1);
								} else {
									sub_d_count.put(subProcessFieldsRowCtr,
											dReportCtr - 1);
								}
							}

							subProFieldsCtr++;
						}

						if (subprocessMaxRowCtr < subProcessFieldsRowCtr)
							subprocessMaxRowCtr = subProcessFieldsRowCtr;
					}

				} // master end

			}

			/******************* HEADER FOR SUB PROCESS FIELDS ***********************/
			String COMMA_DELIMITER = ",";
			String NEW_LINE_SEPARATOR = "\n";
			List<String> finalCustDetailsHeaders = new ArrayList<String>();
			List<String> finalAddDetailsHeaders = new ArrayList<String>();
			List<String> finalSparesDetailsHeaders = new ArrayList<String>();
			List<String> finalOrderDetailsHeaders = new ArrayList<String>();
			List<String> finalSubProcessFieldsHeaders = new ArrayList<String>();
			List<String> finalBReportHeaders = new ArrayList<String>();
			List<String> finalDReportHeaders = new ArrayList<String>();

			for (int i = 1; i <= custDetailsMaxRowCtr; i++) {
				for (String custDetailsColName : custDetailsColNames) {

					StringBuilder custDetailsColHeader = new StringBuilder();
					custDetailsColHeader.append("CD_");
					// custDetailsColHeader.append(custDetailsColName);
					custDetailsColHeader
							.append(custMap.get(custDetailsColName));
					custDetailsColHeader.append("_");
					custDetailsColHeader.append(i);
					finalCustDetailsHeaders
							.add(custDetailsColHeader.toString());

				}
			}

			for (int i = 1; i <= addDetailsMaxRowCtr; i++) {
				for (String addDetailsColName : addDetailsColNames) {

					StringBuilder addDetailsColHeader = new StringBuilder();
					addDetailsColHeader.append("AD_");
					addDetailsColHeader.append(addMap.get(addDetailsColName));
					addDetailsColHeader.append("_");
					addDetailsColHeader.append(i);
					finalAddDetailsHeaders.add(addDetailsColHeader.toString());

				}
			}

			for (int j = 1; j <= subprocessMaxRowCtr; j++) {
				for (String subprocessColName : subprocessColNames) {
					StringBuilder subprocessFieldsColHeader = new StringBuilder();
					subprocessFieldsColHeader.append("SF_");
					subprocessFieldsColHeader.append(subMap
							.get(subprocessColName));
					subprocessFieldsColHeader.append("_");
					subprocessFieldsColHeader.append(j);
					finalSubProcessFieldsHeaders.add(subprocessFieldsColHeader
							.toString());

				}

				for (int i = 1; i <= orderDetailsMaxRowCtr; i++) {
					for (String orderDetailsColName : orderDetailsColNames) {

						StringBuilder orderDetailsColHeader = new StringBuilder();
						orderDetailsColHeader.append("OD_");
						orderDetailsColHeader.append(odMap
								.get(orderDetailsColName));
						orderDetailsColHeader.append("_");
						orderDetailsColHeader.append(j);
						orderDetailsColHeader.append("_");
						orderDetailsColHeader.append(i);
						if (sub_order_count.get(j) >= i) {
							finalOrderDetailsHeaders.add(orderDetailsColHeader
									.toString());
						}

					}
				}

				for (int i = 1; i <= sparesMaxRowCtr; i++) {
					for (String sparesDetailsColName : sparesColNames) {

						StringBuilder spareDetailsColHeader = new StringBuilder();
						spareDetailsColHeader.append("SD_");
						spareDetailsColHeader.append(sdMap
								.get(sparesDetailsColName));
						spareDetailsColHeader.append("_");
						spareDetailsColHeader.append(j);
						spareDetailsColHeader.append("_");
						spareDetailsColHeader.append(i);
						if (sub_spare_count.get(j) >= i) {
							finalSparesDetailsHeaders.add(spareDetailsColHeader
									.toString());
						}

					}
				}

				for (int i = 1; i <= bReportMaxRowCtr; i++) {
					for (String bReportColName : bReportColNames) {

						StringBuilder bReportColHeader = new StringBuilder();
						bReportColHeader.append("BR_");
						bReportColHeader.append(bMap.get(bReportColName));
						bReportColHeader.append("_");
						bReportColHeader.append(j);
						bReportColHeader.append("_");
						bReportColHeader.append(i);
						if (sub_b_count.get(j) >= i) {
							finalBReportHeaders
									.add(bReportColHeader.toString());
						}
					}
				}

				for (int i = 1; i <= dReportMaxRowCtr; i++) {
					for (String dReportColName : dReportColNames) {

						StringBuilder dReportColHeader = new StringBuilder();
						dReportColHeader.append("DR_");
						dReportColHeader.append(dMap.get(dReportColName));
						dReportColHeader.append("_");
						dReportColHeader.append(j);
						dReportColHeader.append("_");
						dReportColHeader.append(i);
						if (sub_d_count.get(j) >= i) {
							finalDReportHeaders
									.add(dReportColHeader.toString());
						}
					}
				}
			}// sub process end

			/************************* DATA LOOP BEGINS ***************************/

			// TODO ITERATE LIST OF MAP
			StringBuilder masterWflw = new StringBuilder();

			masterWflw.append(finalMasterFieldsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalSubProcessFieldsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalCustDetailsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalAddDetailsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalSparesDetailsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalOrderDetailsHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalBReportHeaders);
			masterWflw.append(COMMA_DELIMITER);
			masterWflw.append(finalDReportHeaders);

			// masterWflw=new
			// StringBuilder(masterWflw.toString().replace(",[],", ","));
			for (Map<String, String> dataMap : list) {

				// / Master
				StringBuilder masterFields = new StringBuilder();
				for (String masterColName : finalMasterFieldsHeaders) {
					String masterVal = dataMap.get(masterColName);

					if (masterVal == null) {
						masterFields.append("");
					} else {
						masterVal = masterVal.replace(",", ";");
						masterFields.append(masterVal);
					}
					masterFields.append(COMMA_DELIMITER);
				}
				String masterResult = masterFields.toString();

				// / SUBPROCESS
				StringBuilder subProcessFields = new StringBuilder();
				for (String subProcessFieldsColName : finalSubProcessFieldsHeaders) {
					String subProcessFieldsVal = dataMap
							.get(subProcessFieldsColName);

					if (subProcessFieldsVal == null) {
						subProcessFields.append("");
					} else {
						subProcessFieldsVal = subProcessFieldsVal.replace(",",
								";");
						subProcessFields.append(subProcessFieldsVal);
					}
					subProcessFields.append(COMMA_DELIMITER);
				}
				String subProcessResult = subProcessFields.toString();

				// CUSTDETAILS
				StringBuilder custDetail = new StringBuilder();
				for (String custDetailscolName : finalCustDetailsHeaders) {
					String custDetailVal = dataMap.get(custDetailscolName);

					if (custDetailVal == null) {
						custDetail.append("");
					} else {
						custDetailVal = custDetailVal.replace(",", ";");
						custDetail.append(custDetailVal);
					}
					custDetail.append(COMMA_DELIMITER);
				}
				String custDetailResult = custDetail.toString();

				// ADDITIONAL CONTACT dETAILS
				StringBuilder addDetail = new StringBuilder();
				for (String addDetailColName : finalAddDetailsHeaders) {
					String addDetailVal = dataMap.get(addDetailColName);

					if (addDetailVal == null) {
						addDetail.append("");
					} else {
						addDetailVal = addDetailVal.replace(",", ";");
						addDetail.append(addDetailVal);
					}
					addDetail.append(COMMA_DELIMITER);
				}
				String addDetailResult = addDetail.toString();

				// SPARE DETAILS
				StringBuilder sparesDetail = new StringBuilder();
				for (String sparesDetailColName : finalSparesDetailsHeaders) {
					String sparesDetailVal = dataMap.get(sparesDetailColName);

					if (sparesDetailVal == null) {
						sparesDetail.append("");
					} else {
						sparesDetailVal = sparesDetailVal.replace(",", ";");
						sparesDetail.append(sparesDetailVal);
					}
					sparesDetail.append(COMMA_DELIMITER);
				}
				String sparesDetailResult = sparesDetail.toString();

				// ORDER DETAILS
				StringBuilder orderDetail = new StringBuilder();
				for (String orderDetailColName : finalOrderDetailsHeaders) {
					String orderDetailVal = dataMap.get(orderDetailColName);

					if (orderDetailVal == null) {
						orderDetail.append("");
					} else {
						orderDetailVal = orderDetailVal.replace(",", ";");
						orderDetail.append(orderDetailVal);
					}
					orderDetail.append(COMMA_DELIMITER);
				}
				String orderDetailsResult = orderDetail.toString();

				// BREPORT
				StringBuilder bReport = new StringBuilder();
				for (String bReportColName : finalBReportHeaders) {
					String bReportVal = dataMap.get(bReportColName);

					if (bReportVal == null) {
						bReport.append("");
					} else {
						bReportVal = bReportVal.replace(",", ";");
						bReport.append(bReportVal);
					}
					bReport.append(COMMA_DELIMITER);
				}
				String bReportValResult = bReport.toString();

				// DREPORT
				StringBuilder dReport = new StringBuilder();
				for (String dReportColName : finalDReportHeaders) {
					String dReportVal = dataMap.get(dReportColName);

					if (dReportVal == null) {
						dReport.append("");
					} else {
						dReportVal = dReportVal.replace(",", ";");
						dReport.append(dReportVal);
					}
					dReport.append(COMMA_DELIMITER);
				}
				String dReportValResult = dReport.toString();

				masterWflw.append(NEW_LINE_SEPARATOR);
				masterWflw.append(masterResult);
				masterWflw.append(subProcessResult);
				masterWflw.append(custDetailResult);
				masterWflw.append(addDetailResult);
				masterWflw.append(sparesDetailResult);
				masterWflw.append(orderDetailsResult);
				masterWflw.append(bReportValResult);
				masterWflw.append(dReportValResult);

			}

			/********************* CSV ************************/

			String finalMaster = masterWflw.toString().replace(",[],", ",")
					.replace("[", "").replace("]", "");
			if (fileName == null) {
				fileName = "MasterWorkFlow.csv";
			}
			List<ConfigDetail> configList = configDetailRepo
					.findAllConfigDetailsByConfigTypeNSubtype(
							MotorRepairConstants.CSV_DOWNLOAD,
							MotorRepairConstants.BASE_LOCATION,
							MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);
			//if (configList != null && configList.size() > 0) {
				ConfigDetail confDet = configList.get(0);
				FileWriter br = new FileWriter(confDet.getConfigStrVal()
						+ fileName);
				br.append(finalMaster);
				br.flush();
				br.close();
			//}

			try {
				if (subProFieldsRS != null) {
					subProFieldsRS.close();
				}
			} catch (Exception e) {
				System.out.println("Error closing ResultSet rs " + e);
			}
			try {
				if (mastWflwRS != null) {
					mastWflwRS.close();
				}
			} catch (Exception e) {
				System.out.println("Error closing ResultSet rs " + e);
			}

		} catch (SQLException se) {
			// Handle errors for JDBC
			System.out.println("Error SQLException " + se);
		} catch (Exception e) {
			// Handle errors for Class.forName
			System.out.println("Error Exception " + e);
		} finally {

			// finally block used to close resources
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error SQLException " + e);
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error SQLException " + e);
				}
			}
		}
		return fileName;

	}
}
