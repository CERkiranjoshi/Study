/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorSparesDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603327
 *
 */
public interface MotorSparesDetailRepository extends JpaRepository<MotorSparesDetail, Long> {
	@Query("SELECT msd from MotorSparesDetail msd where msd.materialId=:materialId AND msd.tenantId=:tenantId AND msd.solutionCategoryId=:solutionCategoryId  ")
	MotorSparesDetail findMotorSparesDetailsByMaterialIdAndTenantIdAndSolCatId(
			@Param("materialId") Long materialId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);

}
