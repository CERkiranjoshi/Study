/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Sweety Kothari
 * BuildDetail entity store all information related to build
 */
@Entity
@Table(name="rmt_build_detail")
public class BuildDetail implements Serializable{

	/**
	 * serial version id
	 */
	private static final long serialVersionUID = -6395009521152650217L;
	
	@Id
	@Column(name="id")
	private Long id;
	
	@Column(name="build_version",length=50)
	private String buildVersion;
	
	@Column(name="build_date")
	private Date buildDate;
	
	@Column(name="is_current")
	//1: means current build
	private Integer isCurrent;
	
	@Column(name = "tenant_id",length=50)
	private String tenantId;

	@Column(name = "solution_category_id",length=25)
	private String solutionCategoryId;
	
	@Column(name = "release_notes")
	private String releaseNotes;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the buildVersion
	 */
	public String getBuildVersion() {
		return buildVersion;
	}

	/**
	 * @param buildVersion the buildVersion to set
	 */
	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}

	/**
	 * @return the buildDate
	 */
	public Date getBuildDate() {
		return buildDate;
	}

	/**
	 * @param buildDate the buildDate to set
	 */
	public void setBuildDate(Date buildDate) {
		this.buildDate = buildDate;
	}

	/**
	 * @return the isCurrent
	 */
	public Integer getIsCurrent() {
		return isCurrent;
	}

	/**
	 * @param isCurrent the isCurrent to set
	 */
	public void setIsCurrent(Integer isCurrent) {
		this.isCurrent = isCurrent;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the releaseNotes
	 */
	public String getReleaseNotes() {
		return releaseNotes;
	}

	/**
	 * @param releaseNotes the releaseNotes to set
	 */
	public void setReleaseNotes(String releaseNotes) {
		this.releaseNotes = releaseNotes;
	}
	
}
