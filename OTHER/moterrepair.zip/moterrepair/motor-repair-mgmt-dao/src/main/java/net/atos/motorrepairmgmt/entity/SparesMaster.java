/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Sweety Kothari
 *
 */
@Entity
@Table(name="rmt_spares_master")
public class SparesMaster implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3236781941316077683L;
	
	
	
	
	@Id
	@Column(name = "spares_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private Long spareId;
	
	@Column(name = "spare_mlfb")
	private long spareMLFB;
	
	@Column(name = "spare_name")
	private String spareName;
	
	@Column(name = "spare_desc")
	private String spareDesc;
	
	@Column(name = "spare_type")
	private int spareType;
	
	@Column(name = "spare_series_type")
	private int spareSeriesType;
	
	@Column(name = "spare_sub_type")
	private String spareSubType;
	
	@Column(name = "spare_frame_size")
	private int spareFrameSize;
	
	@Column(name = "price_per_unit")
	private double pricePerUnit;
	
	@Column(name = "spare_unit")
	private String spareUnit;
	
	@Column(name = "product_type")
	private String productType;
	
	@Column(name = "solution_category_id")
	private String solutionCategoryId;
	
	@Column(name = "tenant_id")
	private String tenantId;

	/**
	 * @return the spareId
	 */
	public Long getSpareId() {
		return spareId;
	}

	/**
	 * @param spareId the spareId to set
	 */
	public void setSpareId(Long spareId) {
		this.spareId = spareId;
	}

	/**
	 * @return the spareMLFB
	 */
	public long getSpareMLFB() {
		return spareMLFB;
	}

	/**
	 * @param spareMLFB the spareMLFB to set
	 */
	public void setSpareMLFB(long spareMLFB) {
		this.spareMLFB = spareMLFB;
	}

	/**
	 * @return the spareName
	 */
	public String getSpareName() {
		return spareName;
	}

	/**
	 * @param spareName the spareName to set
	 */
	public void setSpareName(String spareName) {
		this.spareName = spareName;
	}

	/**
	 * @return the spareDesc
	 */
	public String getSpareDesc() {
		return spareDesc;
	}

	/**
	 * @param spareDesc the spareDesc to set
	 */
	public void setSpareDesc(String spareDesc) {
		this.spareDesc = spareDesc;
	}

	/**
	 * @return the spareType
	 */
	public int getSpareType() {
		return spareType;
	}

	/**
	 * @param spareType the spareType to set
	 */
	public void setSpareType(int spareType) {
		this.spareType = spareType;
	}

	/**
	 * @return the spareSeriesType
	 */
	public int getSpareSeriesType() {
		return spareSeriesType;
	}

	/**
	 * @param spareSeriesType the spareSeriesType to set
	 */
	public void setSpareSeriesType(int spareSeriesType) {
		this.spareSeriesType = spareSeriesType;
	}

	/**
	 * @return the spareSubType
	 */
	public String getSpareSubType() {
		return spareSubType;
	}

	/**
	 * @param spareSubType the spareSubType to set
	 */
	public void setSpareSubType(String spareSubType) {
		this.spareSubType = spareSubType;
	}

	/**
	 * @return the spareFrameSize
	 */
	public int getSpareFrameSize() {
		return spareFrameSize;
	}

	/**
	 * @param spareFrameSize the spareFrameSize to set
	 */
	public void setSpareFrameSize(int spareFrameSize) {
		this.spareFrameSize = spareFrameSize;
	}

	/**
	 * @return the pricePerUnit
	 */
	public double getPricePerUnit() {
		return pricePerUnit;
	}

	/**
	 * @param pricePerUnit the pricePerUnit to set
	 */
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	/**
	 * @return the spareUnit
	 */
	public String getSpareUnit() {
		return spareUnit;
	}

	/**
	 * @param spareUnit the spareUnit to set
	 */
	public void setSpareUnit(String spareUnit) {
		this.spareUnit = spareUnit;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
}
