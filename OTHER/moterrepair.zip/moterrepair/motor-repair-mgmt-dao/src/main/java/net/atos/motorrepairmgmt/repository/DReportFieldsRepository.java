package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.DReportFields;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a610051
 * 
 */
public interface DReportFieldsRepository extends JpaRepository<DReportFields, Long> {

	@Query("Select drf from DReportFields drf where drf.subProcessFields.wlfwSubProcessId=:wlfwSubProcessId")
	DReportFields findDReportFieldsBySubProcessID(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("Select drf.motorNamePlateDetail from DReportFields drf where drf.motorDReportFieldId=:motorDReportFieldId")
	MotorNamePlateDetail findNamePlateByDReportId(@Param("motorDReportFieldId") Long motorDReportFieldId);

	@Query("Select drf.motorDReportFieldId,drf.approvalStatus,drf.statusUpdatedOn,drf.statusUpdatedByRefId from DReportFields drf where drf.subProcessFields.wlfwSubProcessId=:wlfwSubProcessId")
	Object[] findDReportFieldsApprovedStatusSubProcessID(@Param("wlfwSubProcessId") Long wlfwSubProcessId);
}
