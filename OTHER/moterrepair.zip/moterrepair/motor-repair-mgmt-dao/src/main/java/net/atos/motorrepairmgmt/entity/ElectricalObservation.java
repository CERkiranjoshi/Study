/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a610051
 * 
 */
@Entity
@Table(name = "rmt_motor_elec_obs")
public class ElectricalObservation extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1905093985995592640L;

	@Id
	@Column(name = "motor_elec_obs_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorElecObssId;

	@Column(name = "megger_volt")
	private Float meggerVolt;

	@Column(name = "phase_n_earth_UE")
	private Float phaseNEarthUE;

	@Column(name = "phase_n_earth_VE")
	private Float phaseNEarthVE;

	@Column(name = "phase_n_earth_WE")
	private Float phaseNEarthWE;

	@Column(name = "btwn_phases_UV")
	private Float btwnPhasesUV;

	@Column(name = "btwn_phases_VW")
	private Float btwnPhasesVW;

	@Column(name = "btwn_phases_WU")
	private Float btwnPhasesWU;

	@Column(name = "winding_res_temp")
	private Float windingResTemp;

	@Column(name = "winding_res_phase_u")
	private Float windingResPhaseU;

	@Column(name = "winding_res_phase_v")
	private Float windingResPhaseV;

	@Column(name = "winding_res_phase_w")
	private Float windingResPhasew;
	
	/**
	 * @return the motorElecObsId
	 */
	public Long getMotorElecObsId() {
		return motorElecObssId;
	}

	/**
	 * @param motorElecObsId
	 *            the motorElecObsId to set
	 */
	public void setMotorElecObsId(Long motorElecObsId) {
		this.motorElecObssId = motorElecObsId;
	}

	/**
	 * @return the meggerVolt
	 */
	public Float getMeggerVolt() {
		return meggerVolt;
	}

	/**
	 * @param meggerVolt
	 *            the meggerVolt to set
	 */
	public void setMeggerVolt(Float meggerVolt) {
		this.meggerVolt = meggerVolt;
	}

	/**
	 * @return the phaseNEarthUE
	 */
	public Float getPhaseNEarthUE() {
		return phaseNEarthUE;
	}

	/**
	 * @param phaseNEarthUE
	 *            the phaseNEarthUE to set
	 */
	public void setPhaseNEarthUE(Float phaseNEarthUE) {
		this.phaseNEarthUE = phaseNEarthUE;
	}

	/**
	 * @return the phaseNEarthVE
	 */
	public Float getPhaseNEarthVE() {
		return phaseNEarthVE;
	}

	/**
	 * @param phaseNEarthVE
	 *            the phaseNEarthVE to set
	 */
	public void setPhaseNEarthVE(Float phaseNEarthVE) {
		this.phaseNEarthVE = phaseNEarthVE;
	}

	/**
	 * @return the phaseNEarthWE
	 */
	public Float getPhaseNEarthWE() {
		return phaseNEarthWE;
	}

	/**
	 * @param phaseNEarthWE
	 *            the phaseNEarthWE to set
	 */
	public void setPhaseNEarthWE(Float phaseNEarthWE) {
		this.phaseNEarthWE = phaseNEarthWE;
	}

	/**
	 * @return the btwnPhasesUV
	 */
	public Float getBtwnPhasesUV() {
		return btwnPhasesUV;
	}

	/**
	 * @param btwnPhasesUV
	 *            the btwnPhasesUV to set
	 */
	public void setBtwnPhasesUV(Float btwnPhasesUV) {
		this.btwnPhasesUV = btwnPhasesUV;
	}

	/**
	 * @return the btwnPhasesVW
	 */
	public Float getBtwnPhasesVW() {
		return btwnPhasesVW;
	}

	/**
	 * @param btwnPhasesVW
	 *            the btwnPhasesVW to set
	 */
	public void setBtwnPhasesVW(Float btwnPhasesVW) {
		this.btwnPhasesVW = btwnPhasesVW;
	}

	/**
	 * @return the btwnPhasesWU
	 */
	public Float getBtwnPhasesWU() {
		return btwnPhasesWU;
	}

	/**
	 * @param btwnPhasesWU
	 *            the btwnPhasesWU to set
	 */
	public void setBtwnPhasesWU(Float btwnPhasesWU) {
		this.btwnPhasesWU = btwnPhasesWU;
	}

	/**
	 * @return the windingResTemp
	 */
	public Float getWindingResTemp() {
		return windingResTemp;
	}

	/**
	 * @param windingResTemp
	 *            the windingResTemp to set
	 */
	public void setWindingResTemp(Float windingResTemp) {
		this.windingResTemp = windingResTemp;
	}

	/**
	 * @return the windingResPhaseU
	 */
	public Float getWindingResPhaseU() {
		return windingResPhaseU;
	}

	/**
	 * @param windingResPhaseU
	 *            the windingResPhaseU to set
	 */
	public void setWindingResPhaseU(Float windingResPhaseU) {
		this.windingResPhaseU = windingResPhaseU;
	}

	/**
	 * @return the windingResPhaseV
	 */
	public Float getWindingResPhaseV() {
		return windingResPhaseV;
	}

	/**
	 * @param windingResPhaseV
	 *            the windingResPhaseV to set
	 */
	public void setWindingResPhaseV(Float windingResPhaseV) {
		this.windingResPhaseV = windingResPhaseV;
	}

	/**
	 * @return the windingResPhasew
	 */
	public Float getWindingResPhasew() {
		return windingResPhasew;
	}

	/**
	 * @param windingResPhasew
	 *            the windingResPhasew to set
	 */
	public void setWindingResPhasew(Float windingResPhasew) {
		this.windingResPhasew = windingResPhasew;
	}
}
