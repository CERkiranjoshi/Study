package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.MotorSalesDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a610039
 *
 */
public interface MotorSalesDetailRepository extends JpaRepository<MotorSalesDetail, Long> {

	@Query("SELECT mwf from MotorSalesDetail mwf where mwf.tenantId=:tenantId")
	List<MotorSalesDetail> findAllMotorSalesDetailByTenantId(@Param("tenantId") String tenantId);

	@Query("SELECT mwf from MotorSalesDetail mwf where mwf.tenantId=:tenantId and mwf.solutionCategoryId=:solutionCategoryId")
	List<MotorSalesDetail> findMotorSalesDetailByTenantIdAndSolutionCategoryId(@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);

	@Query("SELECT mwf from MotorSalesDetail mwf where mwf.tenantId=:tenantId and mwf.solutionCategoryId=:solutionCategoryId and mwf.salesType=:salesType")
	List<MotorSalesDetail> findMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solutionCategoryId,
			@Param("salesType") Integer salesType);
}
