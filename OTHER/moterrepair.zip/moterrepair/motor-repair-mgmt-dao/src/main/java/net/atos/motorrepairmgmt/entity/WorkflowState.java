package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a603975
 * 
 */

@Entity
@Table(name = "rmt_wlfw_state")
public class WorkflowState implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8160663758073019203L;

	@Id
	@Column(name = "workflow_state_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer workflowStateId;

	@Column(name = "state_name")
	private String stateName;

	@Column(name = "alias_name")
	private String aliasName;

	@Column(name = "created_by_ref_id")
	private String createdByRefId;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = " modified_by_ref_id")
	private String modifiedByRefId;

	@Column(name = "modified_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedOn;

	@Column(name = "state_enabled")
	private String stateEnabled;
	
	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;
	
	

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the workflowStateId
	 */
	public Integer getWorkflowStateId() {
		return workflowStateId;
	}

	/**
	 * @param workflowStateId
	 *            the workflowStateId to set
	 */
	public void setWorkflowStateId(Integer workflowStateId) {
		this.workflowStateId = workflowStateId;
	}

	/**
	 * @return the stateName
	 */
	public String getStateName() {
		return stateName;
	}

	/**
	 * @param stateName
	 *            the stateName to set
	 */
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	/**
	 * @return the aliasName
	 */
	public String getAliasName() {
		return aliasName;
	}

	/**
	 * @param aliasName
	 *            the aliasName to set
	 */
	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId
	 *            the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn
	 *            the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the stateEnabled
	 */
	public String getStateEnabled() {
		return stateEnabled;
	}

	/**
	 * @param stateEnabled
	 *            the stateEnabled to set
	 */
	public void setStateEnabled(String stateEnabled) {
		this.stateEnabled = stateEnabled;
	}

}
