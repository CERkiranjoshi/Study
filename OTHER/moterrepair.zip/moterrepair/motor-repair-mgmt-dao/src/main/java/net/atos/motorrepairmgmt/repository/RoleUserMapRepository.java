/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.RoleUserMap;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 * Repository for ARCUserMap entity
 */
public interface RoleUserMapRepository  extends  JpaRepository<RoleUserMap, Long> {

	@Query("Select e.referenceId,e.type from RoleUserMap e where e.userName=:userName and e.enabled=1")
	public Object[] getARCRefIdByUserName(@Param("userName") String userName);
}
