package net.atos.motorrepairmgmt.repository;

import java.util.List;
import net.atos.motorrepairmgmt.entity.ARCMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603975
 * 
 */

public interface ARCMasterRepository extends JpaRepository<ARCMaster, Long> {
	@Query("SELECT a from ARCMaster a where a.arcId=:arcId and a.arcEnabled='1'")
	ARCMaster findArcMasterByARCId(@Param("arcId") Long arcId);
	
	@Query("SELECT a from ARCMaster a where a.arcName=:arcName and a.arcEnabled='1'")
	List<ARCMaster> findArcMasterByARCName(@Param("arcName") String arcName);

	@Query("SELECT a from ARCMaster a where a.regionMaster.regionId=:regionId and a.arcEnabled='1'")
	List<ARCMaster> findArcMasterByRegionId(@Param("regionId") Long regionId);

	@Query("SELECT a from ARCMaster a where a.arcType=:arcType and a.arcEnabled='1'")
	List<ARCMaster> findArcMasterByArcType(@Param("arcType") Integer arcType);
	
}
