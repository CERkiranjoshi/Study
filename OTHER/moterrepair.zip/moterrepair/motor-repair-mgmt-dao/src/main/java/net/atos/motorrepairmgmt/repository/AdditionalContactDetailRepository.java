package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.AdditionalContactDetail;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a603981
 *
 */
public interface AdditionalContactDetailRepository extends JpaRepository<AdditionalContactDetail, Long> {
}
