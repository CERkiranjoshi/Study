package net.atos.motorrepairmgmt.entity;

import java.util.Date;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775
 *
 */
@Entity
@Table(name = "rmt_dispatch_detail")
public class DispatchDetail extends BasicEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7502597011067515586L;
	
	
	@Id
	@Column(name = "dispatch_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long dispatchId;
	
	@Column(name = "docket_no",length=100)
	private String docketNo;
	
	@Column(name = "dispatch_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dispatchDate;
	
	@Column(name = "transporter_name",length=255)
	private String transporterName;
	
	@Column(name = "dispatched_from")
	private Integer dispatchedFrom;
	
	@Column(name = "dispatched_to")
	private Integer dispatchedTo;
	
	@Column(name = "dispatched_by_ref_id",length=100)
	private String dispatchedByRefId;
	
	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@Column(name = "dispatch_to_address",length=255)
	private String dispatchToAddress;
	
	@Column(name = "received_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date receivedOn;
	
	@Column(name = "received_by_ref_id",length=100)
	private String receivedByRefId;
	
	@Column(name = "received")
	private Integer received;
	
	@Column(name = "dispatch_type")
	private Integer dispatchType;
	
	@Column(name = "dispatch_mode")
	private Integer dispatchMode;
	
	@Column(name = "other_mode_Details",length=100)
	private String otherModeDetails;
	
	@Column(name = "docket_detail",length=30)
	private String docketDetail;
	
	/**
	 * @return the dispatchId
	 */
	public Long getDispatchId() {
		return dispatchId;
	}

	/**
	 * @param dispatchId the dispatchId to set
	 */
	public void setDispatchId(Long dispatchId) {
		this.dispatchId = dispatchId;
	}

	/**
	 * @return the docketNo
	 */
	public String getDocketNo() {
		return docketNo;
	}

	/**
	 * @param docketNo the docketNo to set
	 */
	public void setDocketNo(String docketNo) {
		this.docketNo = docketNo;
	}

	/**
	 * @return the dispatchDate
	 */
	public Date getDispatchDate() {
		return dispatchDate;
	}

	/**
	 * @param dispatchDate the dispatchDate to set
	 */
	public void setDispatchDate(Date dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	/**
	 * @return the transporterName
	 */
	public String getTransporterName() {
		return transporterName;
	}

	/**
	 * @param transporterName the transporterName to set
	 */
	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}

	/**
	 * @return the dispatchedFrom
	 */
	public Integer getDispatchedFrom() {
		return dispatchedFrom;
	}

	/**
	 * @param dispatchedFrom the dispatchedFrom to set
	 */
	public void setDispatchedFrom(Integer dispatchedFrom) {
		this.dispatchedFrom = dispatchedFrom;
	}

	/**
	 * @return the dispatchedTo
	 */
	public Integer getDispatchedTo() {
		return dispatchedTo;
	}

	/**
	 * @param dispatchedTo the dispatchedTo to set
	 */
	public void setDispatchedTo(Integer dispatchedTo) {
		this.dispatchedTo = dispatchedTo;
	}

	/**
	 * @return the dispatchedByRefId
	 */
	public String getDispatchedByRefId() {
		return dispatchedByRefId;
	}

	/**
	 * @param dispatchedByRefId the dispatchedByRefId to set
	 */
	public void setDispatchedByRefId(String dispatchedByRefId) {
		this.dispatchedByRefId = dispatchedByRefId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the dispatchToAddress
	 */
	public String getDispatchToAddress() {
		return dispatchToAddress;
	}

	/**
	 * @param dispatchToAddress the dispatchToAddress to set
	 */
	public void setDispatchToAddress(String dispatchToAddress) {
		this.dispatchToAddress = dispatchToAddress;
	}

	/**
	 * @return the receivedOn
	 */
	public Date getReceivedOn() {
		return receivedOn;
	}

	/**
	 * @param receivedOn the receivedOn to set
	 */
	public void setReceivedOn(Date receivedOn) {
		this.receivedOn = receivedOn;
	}

	/**
	 * @return the receivedByRefId
	 */
	public String getReceivedByRefId() {
		return receivedByRefId;
	}

	/**
	 * @param receivedByRefId the receivedByRefId to set
	 */
	public void setReceivedByRefId(String receivedByRefId) {
		this.receivedByRefId = receivedByRefId;
	}

	/**
	 * @return the received
	 */
	public Integer getReceived() {
		return received;
	}

	/**
	 * @param received the received to set
	 */
	public void setReceived(Integer received) {
		this.received = received;
	}

	/**
	 * @return the dispatchType
	 */
	public Integer getDispatchType() {
		return dispatchType;
	}

	/**
	 * @param dispatchType the dispatchType to set
	 */
	public void setDispatchType(Integer dispatchType) {
		this.dispatchType = dispatchType;
	}

	/**
	 * @return the dispatchMode
	 */
	public Integer getDispatchMode() {
		return dispatchMode;
	}

	/**
	 * @param dispatchMode the dispatchMode to set
	 */
	public void setDispatchMode(Integer dispatchMode) {
		this.dispatchMode = dispatchMode;
	}

	/**
	 * @return the otherModeDetails
	 */
	public String getOtherModeDetails() {
		return otherModeDetails;
	}

	/**
	 * @param otherModeDetails the otherModeDetails to set
	 */
	public void setOtherModeDetails(String otherModeDetails) {
		this.otherModeDetails = otherModeDetails;
	}

	/**
	 * @return the docketDetail
	 */
	public String getDocketDetail() {
		return docketDetail;
	}

	/**
	 * @param docketDetail the docketDetail to set
	 */
	public void setDocketDetail(String docketDetail) {
		this.docketDetail = docketDetail;
	}
	
}
