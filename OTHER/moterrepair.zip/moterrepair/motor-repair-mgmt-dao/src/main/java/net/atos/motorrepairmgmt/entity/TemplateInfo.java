/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Sweety Kothari
 *This entity will represent mapping between functionCode and email template 
 *This will be used for sending notification
 */
@Entity
@Table(name = "rmt_email_template_info")
public class TemplateInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -526855449963644165L;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name="function_code")
	private String functionCode;

	@Column(name = "template_code", length = 100)
	private String templateCode;
	
	@Column(name="template_name",length=200)
	private String templateName;
	
	@Column(name="enabled")
	private Integer enabled;

	@Column(name="notify_type")
	private Integer notificationType;
	
	@Column(name="receipient_type")
	private Integer receipientType;
	
	@Column(name="template_type")
	private Integer templateType;
	
	@Column(name="template_visibility")
	private Integer templateVisibility;
	
	@Column(name="template_editable")
	private Integer templateEditable;

	
	@Column(name="subject_line" ,length=255)
	private String subjectLine;
	
	@Column(name="status_text")
	private String statusText;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	
	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}
	

	/**
	 * @return the templateCode
	 */
	public String getTemplateCode() {
		return templateCode;
	}

	/**
	 * @param templateCode the templateCode to set
	 */
	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the templateType
	 */
	public Integer getTemplateType() {
		return templateType;
	}

	/**
	 * @param templateType the templateType to set
	 */
	public void setTemplateType(Integer templateType) {
		this.templateType = templateType;
	}

	/**
	 * @return the subjectLine
	 */
	public String getSubjectLine() {
		return subjectLine;
	}

	/**
	 * @param subjectLine the subjectLine to set
	 */
	public void setSubjectLine(String subjectLine) {
		this.subjectLine = subjectLine;
	}

	/**
	 * @return the enabled
	 */
	public Integer getEnabled() {
		return enabled;
	}

	/**
	 * @param enabled the enabled to set
	 */
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the receipientType
	 */
	public Integer getReceipientType() {
		return receipientType;
	}

	/**
	 * @param receipientType the receipientType to set
	 */
	public void setReceipientType(Integer receipientType) {
		this.receipientType = receipientType;
	}

	/**
	 * @return the templateVisibility
	 */
	public Integer getTemplateVisibility() {
		return templateVisibility;
	}

	/**
	 * @param templateVisibility the templateVisibility to set
	 */
	public void setTemplateVisibility(Integer templateVisibility) {
		this.templateVisibility = templateVisibility;
	}

	/**
	 * @return the templateEditable
	 */
	public Integer getTemplateEditable() {
		return templateEditable;
	}

	/**
	 * @param templateEditable the templateEditable to set
	 */
	public void setTemplateEditable(Integer templateEditable) {
		this.templateEditable = templateEditable;
	}

	/**
	 * @return the statusText
	 */
	public String getStatusText() {
		return statusText;
	}

	/**
	 * @param statusText the statusText to set
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}
	
}
