package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.ARCMaster;
import net.atos.motorrepairmgmt.entity.RegionMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RegionMasterRepository extends JpaRepository<RegionMaster, Long> {
	@Query("select rm.arcMasterList from RegionMaster rm where rm.regionId=:regionId and rm.tenantId=:tenantId and rm.solutionCategoryId=:solutionCategoryId")
	List<ARCMaster> findARCMasterByRegionIDAndTenantIdAndSolCatId(@Param("regionId") Long regionId,
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solnCategory);

	@Query("select rm from RegionMaster rm where  rm.tenantId = :tenantId and rm.solutionCategoryId=:solutionCategoryId")
	List<RegionMaster> findRegionMasterByTenantIdAndSolCatId(@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solnCategory);

	@Query("select rm from RegionMaster rm where rm.tenantId = :tenantId ")
	List<RegionMaster> findRegionMasterByTenantId(@Param("tenantId") String tenantId);

	@Query("select rm from RegionMaster rm where  rm.tenantId = :tenantId and rm.solutionCategoryId=:solutionCategoryId and rm.regionId=:regionId")
	RegionMaster findRegionMasterByRegionIdAndTenantIdAndSolCatId(@Param("regionId") Long regionId,@Param("solutionCategoryId") String solnCategory, @Param("tenantId") String tenantId);

}
