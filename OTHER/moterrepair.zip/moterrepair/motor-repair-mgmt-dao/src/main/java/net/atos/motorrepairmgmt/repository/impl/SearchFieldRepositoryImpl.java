/**
 * 
 */
package net.atos.motorrepairmgmt.repository.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import org.springframework.stereotype.Repository;

import net.atos.motorrepairmgmt.dto.SearchByParameterDTO;

import net.atos.motorrepairmgmt.repository.SearchFieldRepository;

/**
 * @author a603975
 *
 */
@Repository
public class SearchFieldRepositoryImpl implements SearchFieldRepository {
	/**
	 * Logger
	 */
	/*
	 * private static final Logger LOGGER = Logger
	 * .getLogger(SearchFieldRepositoryImpl.class);
	 */

	@PersistenceUnit(unitName = "programMgmtPersistenceUnit")
	private EntityManagerFactory emf;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.repository.SearchFieldRepository#searchByParameter
	 * ()
	 */
	@Override
	public List<SearchByParameterDTO> searchByParameter(
			SearchByParameterDTO searchByParameterDTO) {
		/* LOGGER.info("SearchFieldRepositoryImpl : searchByParameter : Start"); */
		EntityManager em = emf.createEntityManager();

		List<SearchByParameterDTO> searchParameterList = null;

		// String value=searchByParameterDTO.getValue();

		/*
		 * String sql=
		 * "select m.gspRefNo,s.motorSnNum,s.mlfbSpiridon,c.customerName from SubProcessFields s"
		 * +
		 * " join MasterWorkflowFields m on s.masterworkflowfieldid=m.masterworkflowfieldid  join CustomerDetail c on m.masterworkflowfieldid=c.masterworkflowfieldid "
		 * ;
		 */

		String sql = "select  m.gsp_ref_no ,s.motor_sn_num,s.mlfb_spiridon,c.customer_name ,s.subject_title,c.mobile_contact_num,s.subprocess_id"
				+ " from rmt_motor_sub_proc_fields s join rmt_master_workflow_fields m "
				+ " on s.master_workflow_id=m.master_workflow_id join rmt_customer_detail c  "
				+ "on m.master_workflow_id=c.master_workflow_id ";

		String clause = "";
		if ("true" == searchByParameterDTO.getCustomerName()) {
			clause = " where LOWER(c.customer_name) LIKE (LOWER('%"
					+ searchByParameterDTO.getValue() + "%'))";

			sql += clause;

		}
		if ("true" == searchByParameterDTO.getMobileContactNum()) {

			if (clause.isEmpty()) {
				clause = " where  c.mobile_contact_num LIKE ('%"
						+ searchByParameterDTO.getValue() + "%')";
			} else {
				clause = " or c.mobile_contact_num LIKE ('%"
						+ searchByParameterDTO.getValue() + "%')";
			}
			sql += clause;
		}
		if ("true" == searchByParameterDTO.getGspRefNo()) {
			if (clause.isEmpty()) {
				clause = " where c.cust_type='1' and LOWER(m.gsp_ref_no) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			} else {
				clause = " or LOWER(m.gsp_ref_no) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			}
			sql += clause;
		}
		if ("true" == searchByParameterDTO.getMotorSnNum()) {

			if (clause.isEmpty()) {
				clause = " where c.cust_type='1' and LOWER(s.motor_sn_num) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			} else {
				clause = " or LOWER(s.motor_sn_num) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			}
			sql += clause;
		}
		if ("true" == searchByParameterDTO.getMlfbSpiridon()) {

			if (clause.isEmpty()) {
				clause = " where c.cust_type='1' and s.mlfb_spiridon LIKE ('%"
						+ searchByParameterDTO.getValue() + "%')";
			} else {
				clause = " or s.mlfb_spiridon LIKE ('%"
						+ searchByParameterDTO.getValue() + "%')";
			}
			sql += clause;
		}
		
		if ("true" == searchByParameterDTO.getSubjectTitle()) {

			if (clause.isEmpty()) {
				clause = " where c.cust_type='1' and LOWER(s.subject_title) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			} else {
				clause = " or LOWER(s.subject_title) LIKE (LOWER('%"
						+ searchByParameterDTO.getValue() + "%'))";
			}
			sql += clause;
		}

		List<Object[]> subprocessList = em.createNativeQuery(sql)
				.getResultList();
		// List<Object> subprocessListObject=new ArrayList<Object>();
		// subprocessListObject.addAll(subprocessList);
		// List<SubProcessFields> subprocessListNew= null;

		// (List<SubProcessFields>)(List<Object[]>)subprocessList;
		if (null != subprocessList) {
			// subprocessListNew = new ArrayList<SubProcessFields>();

			searchParameterList = new ArrayList<SearchByParameterDTO>();
			// SubProcessFields subProcess=null;

			for (Object[] objectArr : subprocessList) {
				SearchByParameterDTO searchByParameterDTOnew = new SearchByParameterDTO();

				if (null != objectArr[0]) {
					searchByParameterDTOnew
							.setGspRefNo(objectArr[0].toString());
				}
				if (null != objectArr[1]) {
					searchByParameterDTOnew.setMotorSnNum(objectArr[1]
							.toString());
				}

				if (null != objectArr[2]) {
					searchByParameterDTOnew.setMlfbSpiridon(objectArr[2]
							.toString());
				}
				if (null != objectArr[3]) {
					searchByParameterDTOnew.setCustomerName(objectArr[3]
							.toString());
				}
				if (null != objectArr[4]) {
					searchByParameterDTOnew.setSubjectTitle(objectArr[4]
							.toString());
				}
				if (null != objectArr[5]) {
					searchByParameterDTOnew.setMobileContactNum(objectArr[5]
							.toString());

				}
				if (null != objectArr[6]) {
					searchByParameterDTOnew.setWlfwSubProcessId(Long
							.parseLong(objectArr[6].toString()));

				}

				searchParameterList.add(searchByParameterDTOnew);

			}
		}

		/* LOGGER.info("SearchFieldRepositoryImpl : searchByParameter : End"); */
		// TODO Auto-generated method stub
		return searchParameterList;
	}

}
