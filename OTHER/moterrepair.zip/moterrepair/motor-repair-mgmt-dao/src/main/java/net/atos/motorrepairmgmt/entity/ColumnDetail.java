/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a545466
 *
 */
@Entity
@Table(name="rmt_column_detail")
public class ColumnDetail extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1185033352052864591L;
	
	@Id
	@Column(name = "column_detail_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long columnDetailId;
	
	@Column(name = "table_name")
	private String tableName;
	
	@Column(name = "column_name")
	private String columnName;
	
	@Column(name = "alias_name")
	private String aliasName;
	
	@Column(name = "is_csv_enabled")
	private int isCsvEnabled;
	
	@Column(name = "is_audit_enabled")
	private int isAuditEnabled;

	/**
	 * @return the columnDetailId
	 */
	public Long getColumnDetailId() {
		return columnDetailId;
	}

	/**
	 * @param columnDetailId the columnDetailId to set
	 */
	public void setColumnDetailId(Long columnDetailId) {
		this.columnDetailId = columnDetailId;
	}

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return the columnName
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * @param columnName the columnName to set
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * @return the aliasName
	 */
	public String getAliasName() {
		return aliasName;
	}

	/**
	 * @param aliasName the aliasName to set
	 */
	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	/**
	 * @return the isCsvEnabled
	 */
	public int getIsCsvEnabled() {
		return isCsvEnabled;
	}

	/**
	 * @param isCsvEnabled the isCsvEnabled to set
	 */
	public void setIsCsvEnabled(int isCsvEnabled) {
		this.isCsvEnabled = isCsvEnabled;
	}

	/**
	 * @return the isAuditEnabled
	 */
	public int getIsAuditEnabled() {
		return isAuditEnabled;
	}

	/**
	 * @param isAuditEnabled the isAuditEnabled to set
	 */
	public void setIsAuditEnabled(int isAuditEnabled) {
		this.isAuditEnabled = isAuditEnabled;
	}
	
	
	
	
	
	
	
	

}
