package net.atos.motorrepairmgmt.repository;
import java.util.List;

import net.atos.motorrepairmgmt.dto.SearchByParameterDTO;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
public interface SearchFieldRepository {

	List<SearchByParameterDTO> searchByParameter(SearchByParameterDTO searchByParameterDTO);
}
