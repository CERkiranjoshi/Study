package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a603981
 *
 */
public interface MotorVoltageDetailRepository extends JpaRepository<MotorVoltageDetail, Long> {
}
