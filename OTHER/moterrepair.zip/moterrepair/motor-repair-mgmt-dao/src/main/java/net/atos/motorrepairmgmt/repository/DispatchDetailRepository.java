package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.DispatchDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DispatchDetailRepository extends JpaRepository<DispatchDetail, Long>  {

}

