package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a603981
 *
 */
public interface MotorNamePlateDetailRepository extends JpaRepository<MotorNamePlateDetail, Long> {
}
