 /**
 * 
 */
package net.atos.motorrepairmgmt.repository.impl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import net.atos.motorrepairmgmt.repository.MotorAttachmentsRepository;

import org.springframework.stereotype.Repository;

/**
 * @author Anand Ved
 *
 */
@Repository
public class MotorAttachmentsRepositoryImpl implements MotorAttachmentsRepository {

	@PersistenceUnit(unitName = "programMgmtPersistenceUnit")
	private EntityManagerFactory emf;
	
	private static final String All_ATTACHMENTS_COUNT="select count (*) from rmt_motor_attachments where subprocess_id=:subprocessId and is_deleted=0 and solution_category_id=:solnCategoryId and tenant_id=:tenantId";
	private static final String EXTERNAL_ATTACHMENTS_COUNT="select count (*) from rmt_motor_attachments where subprocess_id=:subprocessId and is_deleted=0 and is_internal=0 and uploaded_by=:uploadedBy and solution_category_id=:solnCategoryId and tenant_id=:tenantId";

	/* (non-Javadoc)
	 * @see net.atos.motorrepairmgmt.repository.MotorAttachmentsRepository#getMotorAttachmentsCount(java.lang.Long, boolean, java.lang.String, java.lang.String)
	 */
	@Override
	public Long getMotorAttachmentsCount(Long subprocessId, boolean externalAttachments, String solnCategoryId,
			String tenantId, String uploadedBy) {
		EntityManager em = emf.createEntityManager();
		

		Object returnVal= null;
		if(externalAttachments)
			returnVal  = em.createNativeQuery(EXTERNAL_ATTACHMENTS_COUNT).setParameter("subprocessId", subprocessId).setParameter("solnCategoryId", solnCategoryId).setParameter("tenantId", tenantId).setParameter("uploadedBy", uploadedBy).getSingleResult();
		else
			returnVal = em.createNativeQuery(All_ATTACHMENTS_COUNT).setParameter("subprocessId", subprocessId).setParameter("solnCategoryId", solnCategoryId).setParameter("tenantId", tenantId).getSingleResult();
			
		Long count = Long.parseLong(returnVal.toString());
		
		return  count;
	}

}
