package net.atos.motorrepairmgmt.entity;

import java.util.Date;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Sweety Kothari
 *
 */
@Entity
@Table(name="rmt_subprocess_group_detail")
public class SubProcessGroupDetail extends BasicEntity implements Serializable{

	
	private static final long serialVersionUID = 7858944746465902833L;
	
    @Id
    @Column(name="group_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long groupId;
	
	@Column(name = "groupName",length=50)
	private String groupName;
	
	@Column(name = "batch_process_id",length=255)
	private String batchProcessId;
	
	@Column(name = "tenant_id",length=50)
	private String tenantId;

	@Column(name = "solution_category_id",length=25)
	private String solutionCategoryId;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	
	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return the batchProcessId
	 */
	public String getBatchProcessId() {
		return batchProcessId;
	}

	/**
	 * @param batchProcessId the batchProcessId to set
	 */
	public void setBatchProcessId(String batchProcessId) {
		this.batchProcessId = batchProcessId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

}
