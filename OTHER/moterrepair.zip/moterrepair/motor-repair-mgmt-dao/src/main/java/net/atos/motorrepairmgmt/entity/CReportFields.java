/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a610051
 *
 */
@Entity
@Table(name="rmt_motor_c_report_fields")
public class CReportFields extends RMTBasicEntity implements Serializable {
  
	 /**
	 * 
	 */
	 private static final long serialVersionUID = -5858327219920315048L;

	 @Id
	 @Column(name="motor_c_report_field_id")
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long motorCReportFieldId;
     
	 @Column(name="polarity_check")
	 private String polarityCheck ;
	 
	 @Column(name="locked_rotor_volts")
	 private Float lockedRotorVolts;
	 
	 @Column(name="hv_winding")
	 private String hvWinding;
	 
	 @Column(name="hv_acHeater")
	 private String hvAcHeater;
	 
	 @Column(name="bearing_drive_end_no")
	 private String bearingDriveEndNo;
	 
	 @Column(name="bearing_nondrive_end_no")
	 private String bearingNondriveEndNo;
	 
	 @Column(name="bearing_noise_state")
	 private Boolean bearingNoiseState;
	 
	 @Column(name="vibration_noLoad", length=300)
	 private String vibrationNoLoad;
	 
	 @Column(name="repairs_completed_on")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date repairsCompletedOn;
	 
	 @Column(name="complaint_detail")
	 private String complaintDetail;
	 
	 @Column(name="bearing_DE_replaced")
	 private Integer bearingDeReplaced;
	 
	 @Column(name="bearing_NDE_replaced")
	 private Integer bearingNdeReplaced;
	 
	 @Column(name="de_make")
	 private String deMake;
	 
	 @Column(name="nde_make")
	 private String ndeMake;
	 
	 @Column(name="ac_heater_resistance")
	 private Float acHeaterResistance;
	 
	 @Column(name="motor_dispatch_detail", length=300)
	 private String motorDispatchDetail;
	 
	 @Column(name="remarks", length=300)
	 private String remarks;
	 
	 @Column(name="current_speed")
	 private String currentSpeed;
	 
	 @Column(name="rotor_rebalanced")
	 private Integer rotorRebalanced;
	 
	 @Column(name="created_on")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date createdOn;
	 
	 @Column(name="created_by_ref_id",length=20)
	 private String createdByRefId;
	 
	 @Column(name="referred_for_review_on")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date referredForReviewOn;
	 
	 @Column(name="referred_for_review_by_ref_id",length=20)
	 private String referredForReviewByRefId;
	 
	 @Column(name="status_updated_on")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date statusUpdatedOn;
	 
	 @Column(name="status_updated_by_ref_id",length=20)
	 private String statusUpdatedByRefId;
	 
	 @Column(name="approval_status")
	 private Integer approvalStatus;
	 
	 @Column(name="repaired_or_rewound")
	 private Integer repairedOrRewound;
	 
	 @Column(name="no_load")
	 private String noLoad;
	 
	 @Column(name="arc_approved_on")
	 @Temporal(TemporalType.TIMESTAMP)
	 private Date arcApprovedOn;
		 
	 @Column(name="arc_reviewed_by",length=20)
	 private String arcReviewedBy;
	 
	 @Column(name="comments")
	 private String comments;
	 
	 @Column(name="de_horizontal")
	 private String deHorizontal;
	 
	 @Column(name="de_vertical")
	 private String deVertical;
	 
	 @Column(name="de_axial")
	 private String deAxial;
	 
	 @Column(name="nde_horizontal")
	 private String ndeHorizontal;
	 
	 @Column(name="nde_vertical")
	 private String ndeVertical;
	 
	 @Column(name="nde_axial")
	 private String ndeAxial;
	 
	 @OneToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	 private MotorVoltageDetail motorVoltageDetail;

	 @OneToOne(fetch=FetchType.LAZY,cascade = CascadeType.MERGE)
	 private MotorNamePlateDetail motorNamePlateDetail;
	 
	 @OneToMany(fetch=FetchType.EAGER, cascade = { CascadeType.MERGE,
				CascadeType.REMOVE, CascadeType.PERSIST, CascadeType.REFRESH }, orphanRemoval = true)
	 @JoinColumn(name="motor_c_report_field_id")
	 private List<MotorSpeedDetail> motorSpeedDetail;
	 
	 @OneToOne(fetch=FetchType.LAZY,cascade = CascadeType.MERGE)
	 @JoinColumn(name="subprocess_id",insertable=true,updatable=true)
	 private SubProcessFields subProcessFields;
	 
	 @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	 @JoinColumn(name = "motor_elec_obs_id")
	 private ElectricalObservation electricalObservation;
	 
	/**
	 * @return the motorCReportFieldId
	 */
	public Long getMotorCReportFieldId() {
		return motorCReportFieldId;
	}

	/**
	 * @param motorCReportFieldId the motorCReportFieldId to set
	 */
	public void setMotorCReportFieldId(Long motorCReportFieldId) {
		this.motorCReportFieldId = motorCReportFieldId;
	}

	/**
	 * @return the polarityCheck
	 */
	public String getPolarityCheck() {
		return polarityCheck;
	}

	/**
	 * @param polarityCheck the polarityCheck to set
	 */
	public void setPolarityCheck(String polarityCheck) {
		this.polarityCheck = polarityCheck;
	}

	/**
	 * @return lockedRotorVolts 
	 */
	public Float getLockedRotorVolts() {
		return lockedRotorVolts;
	}

	/**
	 * @param lockedRotorVolts the lockedRotorVolts to set
	 */
	public void setLockedRotorVolts(Float lockedRotorVolts) {
		this.lockedRotorVolts = lockedRotorVolts;
	}

	/**
	 * @return the hvWinding
	 */
	public String getHvWinding() {
		return hvWinding;
	}

	/**
	 * @param hvWinding the hvWinding to set
	 */
	public void setHvWinding(String hvWinding) {
		this.hvWinding = hvWinding;
	}

	/**
	 * @return the hvAcHeater
	 */
	public String getHvAcHeater() {
		return hvAcHeater;
	}

	/**
	 * @param hvAcHeater the hvAcHeater to set
	 */
	public void setHvAcHeater(String hvAcHeater) {
		this.hvAcHeater = hvAcHeater;
	}

	/**
	 * @return the bearingDriveEndNo
	 */
	public String getBearingDriveEndNo() {
		return bearingDriveEndNo;
	}

	/**
	 * @param bearingDriveEndNo the bearingDriveEndNo to set
	 */
	public void setBearingDriveEndNo(String bearingDriveEndNo) {
		this.bearingDriveEndNo = bearingDriveEndNo;
	}

	/**
	 * @return the bearingNondriveEndNo
	 */
	public String getBearingNondriveEndNo() {
		return bearingNondriveEndNo;
	}

	/**
	 * @param bearingNondriveEndNo the bearingNondriveEndNo to set
	 */
	public void setBearingNondriveEndNo(String bearingNondriveEndNo) {
		this.bearingNondriveEndNo = bearingNondriveEndNo;
	}

	/**
	 * @return the bearingNoiseState
	 */
	public Boolean getBearingNoiseState() {
		return bearingNoiseState;
	}

	/**
	 * @param bearingNoiseState the bearingNoiseState to set
	 */
	public void setBearingNoiseState(Boolean bearingNoiseState) {
		this.bearingNoiseState = bearingNoiseState;
	}

	/**
	 * @return the vibrationNoLoad
	 */
	public String getVibrationNoLoad() {
		return vibrationNoLoad;
	}

	/**
	 * @param vibrationNoLoad the vibrationNoLoad to set
	 */
	public void setVibrationNoLoad(String vibrationNoLoad) {
		this.vibrationNoLoad = vibrationNoLoad;
	}

	/**
	 * @return the repairsCompletedOn
	 */
	public Date getRepairsCompletedOn() {
		return repairsCompletedOn;
	}

	/**
	 * @param repairsCompletedOn the repairsCompletedOn to set
	 */
	public void setRepairsCompletedOn(Date repairsCompletedOn) {
		this.repairsCompletedOn = repairsCompletedOn;
	}

	/**
	 * @return the complaintDetail
	 */
	public String getComplaintDetail() {
		return complaintDetail;
	}

	/**
	 * @param complaintDetail the complaintDetail to set
	 */
	public void setComplaintDetail(String complaintDetail) {
		this.complaintDetail = complaintDetail;
	}

	/**
	 * @return the bearingDeReplaced
	 */
	public Integer getBearingDeReplaced() {
		return bearingDeReplaced;
	}

	/**
	 * @param bearingDeReplaced the bearingDeReplaced to set
	 */
	public void setBearingDeReplaced(Integer bearingDeReplaced) {
		this.bearingDeReplaced = bearingDeReplaced;
	}

	/**
	 * @return the bearingNdeReplaced
	 */
	public Integer getBearingNdeReplaced() {
		return bearingNdeReplaced;
	}

	/**
	 * @param bearingNdeReplaced the bearingNdeReplaced to set
	 */
	public void setBearingNdeReplaced(Integer bearingNdeReplaced) {
		this.bearingNdeReplaced = bearingNdeReplaced;
	}

	/**
	 * @return the deMake
	 */
	public String getDeMake() {
		return deMake;
	}

	/**
	 * @param deMake the deMake to set
	 */
	public void setDeMake(String deMake) {
		this.deMake = deMake;
	}

	/**
	 * @return the ndeMake
	 */
	public String getNdeMake() {
		return ndeMake;
	}

	/**
	 * @param ndeMake the ndeMake to set
	 */
	public void setNdeMake(String ndeMake) {
		this.ndeMake = ndeMake;
	}

	/**
	 * @return the acHeaterResistance
	 */
	public Float getAcHeaterResistance() {
		return acHeaterResistance;
	}

	/**
	 * @param acHeaterResistance the acHeaterResistance to set
	 */
	public void setAcHeaterResistance(Float acHeaterResistance) {
		this.acHeaterResistance = acHeaterResistance;
	}

	/**
	 * @return the motorDispatchDetail
	 */
	public String getMotorDispatchDetail() {
		return motorDispatchDetail;
	}

	/**
	 * @param motorDispatchDetail the motorDispatchDetail to set
	 */
	public void setMotorDispatchDetail(String motorDispatchDetail) {
		this.motorDispatchDetail = motorDispatchDetail;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the currentSpeed
	 */
	public String getCurrentSpeed() {
		return currentSpeed;
	}

	/**
	 * @param currentSpeed the currentSpeed to set
	 */
	public void setCurrentSpeed(String currentSpeed) {
		this.currentSpeed = currentSpeed;
	}

	/**
	 * @return the rotorRebalanced
	 */
	public Integer getRotorRebalanced() {
		return rotorRebalanced;
	}

	/**
	 * @param rotorRebalanced the rotorRebalanced to set
	 * 	0:No,1:yes
	 */
	public void setRotorRebalanced(Integer rotorRebalanced) {
		this.rotorRebalanced = rotorRebalanced;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the referredForReviewOn
	 */
	public Date getReferredForReviewOn() {
		return referredForReviewOn;
	}

	/**
	 * @param referredForReviewOn the referredForReviewOn to set
	 */
	public void setReferredForReviewOn(Date referredForReviewOn) {
		this.referredForReviewOn = referredForReviewOn;
	}

	/**
	 * @return the referredForReviewByRefId
	 */
	public String getReferredForReviewByRefId() {
		return referredForReviewByRefId;
	}

	/**
	 * @param referredForReviewByRefId the referredForReviewByRefId to set
	 */
	public void setReferredForReviewByRefId(String referredForReviewByRefId) {
		this.referredForReviewByRefId = referredForReviewByRefId;
	}

	/**
	 * @return the approvedOn
	 */
	public Date getApprovedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param approvedOn the approvedOn to set
	 */
	public void setApprovedOn(Date approvedOn) {
		this.statusUpdatedOn = approvedOn;
	}

	/**
	 * @return the statusUpdatedOn
	 */
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param statusUpdatedOn the statusUpdatedOn to set
	 */
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}

	
	/**
	 * @return the statusUpdatedByRefId
	 */
	public String getStatusUpdatedByRefId() {
		return statusUpdatedByRefId;
	}

	/**
	 * @param statusUpdatedByRefId the statusUpdatedByRefId to set
	 */
	public void setStatusUpdatedByRefId(String statusUpdatedByRefId) {
		this.statusUpdatedByRefId = statusUpdatedByRefId;
	}

	/**
	 * @return the approvalStatus
	 */
	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvedStatus the approvedStatus to set
	 * 	0: Not Approved; 1: Approved; 
	 * 	2: Referred to TS; 3: Approved by TS
	 */
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	/**
	 * @return the repairedOrRewound
	 */
	public Integer getRepairedOrRewound() {
		return repairedOrRewound;
	}

	/**
	 * @param repairedOrRewound the repairedOrRewound to set
	 * 1:Repair; 2:Rewound;
	 *  
	 */
	public void setRepairedOrRewound(Integer repairedOrRewound) {
		this.repairedOrRewound = repairedOrRewound;
	}

	/**
	 * @return the noLoad
	 */
	public String getNoLoad() {
		return noLoad;
	}

	/**
	 * @param noLoad the noLoad to set
	 */
	public void setNoLoad(String noLoad) {
		this.noLoad = noLoad;
	}
	
	/**
	 * @return the arcApprovedOn
	 */
	public Date getArcApprovedOn() {
		return arcApprovedOn;
	}

	/**
	 * @param arcApprovedOn the arcApprovedOn to set
	 */
	public void setArcApprovedOn(Date arcApprovedOn) {
		this.arcApprovedOn = arcApprovedOn;
	}

	/**
	 * @return the arcReviewedBy
	 */
	public String getArcReviewedBy() {
		return arcReviewedBy;
	}

	/**
	 * @param arcReviewedBy the arcReviewedBy to set
	 */
	public void setArcReviewedBy(String arcReviewedBy) {
		this.arcReviewedBy = arcReviewedBy;
	}
	
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/**
	 * @return the deHorizontal
	 */
	public String getDeHorizontal() {
		return deHorizontal;
	}

	/**
	 * @param deHorizontal the deHorizontal to set
	 */
	public void setDeHorizontal(String deHorizontal) {
		this.deHorizontal = deHorizontal;
	}

	/**
	 * @return the deVertical
	 */
	public String getDeVertical() {
		return deVertical;
	}

	/**
	 * @param deVertical the deVertical to set
	 */
	public void setDeVertical(String deVertical) {
		this.deVertical = deVertical;
	}

	/**
	 * @return the deAxial
	 */
	public String getDeAxial() {
		return deAxial;
	}

	/**
	 * @param deAxial the deAxial to set
	 */
	public void setDeAxial(String deAxial) {
		this.deAxial = deAxial;
	}

	/**
	 * @return the ndeHorizontal
	 */
	public String getNdeHorizontal() {
		return ndeHorizontal;
	}

	/**
	 * @param ndeHorizontal the ndeHorizontal to set
	 */
	public void setNdeHorizontal(String ndeHorizontal) {
		this.ndeHorizontal = ndeHorizontal;
	}

	/**
	 * @return the ndeVertical
	 */
	public String getNdeVertical() {
		return ndeVertical;
	}

	/**
	 * @param ndeVertical the ndeVertical to set
	 */
	public void setNdeVertical(String ndeVertical) {
		this.ndeVertical = ndeVertical;
	}

	/**
	 * @return the ndeAxial
	 */
	public String getNdeAxial() {
		return ndeAxial;
	}

	/**
	 * @param ndeAxial the ndeAxial to set
	 */
	public void setNdeAxial(String ndeAxial) {
		this.ndeAxial = ndeAxial;
	}

	/**
	 * @return the motorVoltageDetail
	 */
	public MotorVoltageDetail getMotorVoltageDetail() {
		return motorVoltageDetail;
	}

	/**
	 * @param motorVoltageDetail the motorVoltageDetail to set
	 */
	public void setMotorVoltageDetail(MotorVoltageDetail motorVoltageDetail) {
		this.motorVoltageDetail = motorVoltageDetail;
	}

	/**
	 * @return the motorNamePlateDetail
	 */
	public MotorNamePlateDetail getMotorNamePlateDetail() {
		return motorNamePlateDetail;
	}

	/**
	 * @param motorNamePlateDetail the motorNamePlateDetail to set
	 */
	public void setMotorNamePlateDetail(MotorNamePlateDetail motorNamePlateDetail) {
		this.motorNamePlateDetail = motorNamePlateDetail;
	}

	/**
	 * @return the motorSpeedDetail
	 */
	public List<MotorSpeedDetail> getMotorSpeedDetail() {
		return motorSpeedDetail;
	}

	/**
	 * @param motorSpeedDetail the motorSpeedDetail to set
	 */
	public void setMotorSpeedDetail(List<MotorSpeedDetail> motorSpeedDetail) {
		this.motorSpeedDetail = motorSpeedDetail;
	}

	/**
	 * @return the subProcessFields
	 */
	public SubProcessFields getSubProcessFields() {
		return subProcessFields;
	}

	/**
	 * @param subProcessFields the subProcessFields to set
	 */
	public void setSubProcessFields(SubProcessFields subProcessFields) {
		this.subProcessFields = subProcessFields;
	}

	/**
	 * @return the electricalObservation
	 */
	public ElectricalObservation getElectricalObservation() {
		return electricalObservation;
	}

	/**
	 * @param electricalObservation the electricalObservation to set
	 */
	public void setElectricalObservation(ElectricalObservation electricalObservation) {
		this.electricalObservation = electricalObservation;
	}
}
