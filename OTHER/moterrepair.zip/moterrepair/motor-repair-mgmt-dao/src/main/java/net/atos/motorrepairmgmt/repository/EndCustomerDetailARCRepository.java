package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.EndCustomerDetailsArc;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EndCustomerDetailARCRepository extends JpaRepository<EndCustomerDetailsArc, Long>{

}
