package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.SubProcessGroupDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SubProcessGroupDetailRepository extends JpaRepository<SubProcessGroupDetail, Long> {

	@Query("SELECT spg from SubProcessGroupDetail spg where spg.masterWorkflowFieldId=:masterWorkFlowId")
	List<SubProcessGroupDetail> findAllGroupByMasterWorkFlowId(@Param("masterWorkFlowId") Long masterWorkFlowId);
	
	@Query("SELECT spg from SubProcessGroupDetail spg where spg.masterWorkflowFieldId=:masterWorkFlowId and spg.groupName=:groupName")
	SubProcessGroupDetail findByGroupAndMasterWorkFlowId(@Param("masterWorkFlowId") Long masterWorkFlowId,@Param("groupName") String groupName);
}
