package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;

/**
 * @author a610051
 * 
 */
@Entity
@Table(name = "rmt_motor_d_report_fields")
public class DReportFields extends RMTBasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8535006980889967412L;

	@Id
	@Column(name = "motor_d_report_field_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorDReportFieldId;

	@Column(name = "a_foot_breakage")
	private Integer aFootBreakage;

	@Column(name = "a_fins_breakage")
	private Integer aFinsBreakage;

	@Column(name = "b_housing")
	private Integer bHousing;

	@Column(name = "b_fan_cowl")
	private Integer bFanCowl;

	@Column(name = "b_fan_endshield")
	private Integer bFanEndshield;

	@Column(name = "b_terminal_box_breakage")
	private Integer bTerminalBoxBreakage;

	@Column(name = "c_fan_melting")
	private Integer cFanMelting;

	@Column(name = "d_brush_block_damage")
	private Integer dBrushBlockDamage;

	@Column(name = "e_short_circuit_ring_broken")
	private Integer eShortCircuitRingBroken;

	@Column(name = "f_vibration_too_high")
	private Integer fVibrationTooHigh;

	@Column(name = "g_bearing_loose_in_endshield")
	private Integer gBearingLooseInEndshield;

	@Column(name = "g_shaft")
	private Integer gShaft;

	@Column(name = "h_bearing_failure")
	private Integer hBearingFailure;

	@Column(name = "h_noisy")
	private Integer hNoisy;

	@Column(name = "h_seize")
	private Integer hSeize;

	@Column(name = "i_shaft_breakage")
	private Integer iShaftBreakage;

	@Column(name = "j_ingress_of_water")
	private Integer jIngressOfWater;

	@Column(name = "j_chemicals")
	private Integer jChemicals;

	@Column(name = "k_motor_draws_unbalance")
	private Integer kMotorDrawsUnbalance;

	@Column(name = "k_high_current")
	private Integer kHighCurrent;

	@Column(name = "l_motor_getting_excessively_hot")
	private Integer lMotorGettingExcessivelyHot;

	@Column(name = "m_motor_not_starting")
	private Integer mMotorNotStarting;

	@Column(name = "m_not_picking_up_speed")
	private Integer mNotPickingUpSpeed;

	@Column(name = "n_hook_up_wires_defective")
	private Integer nHookUpWiresDefective;

	@Column(name = "o_winding_burnt")
	private Integer oWindingBurnt;

	@Column(name = "p_winding_interturn_short")
	private Integer pWindingInterturnShort;

	@Column(name = "q_insulation_failure")
	private Integer qInsulationFailure;

	@Column(name = "q_earth_fault")
	private Integer qEarthFault;

	@Column(name = "r_interphase_insulation_failure")
	private Integer rInterphaseInsulationFailure;

	@Column(name = "s_miscellaneous")
	private Integer sMiscellaneous;

	@Column(name = "t_axial_play")
	private Integer tAxialPlay;

	@Column(name = "u_rotor_defect")
	private Integer uRotorDefect;

	@Column(name = "v_bal_wt_falling")
	private Integer vBalWtFalling;

	@Column(name = "w_rtd")
	private Integer wRTD;

	@Column(name = "w_ptc_defect")
	private Integer wPTCDefect;

	@Column(name = "I_wrong_handling")
	private Integer iWrongHandling;

	@Column(name = "I_transport")
	private Integer iTransport;

	@Column(name = "II_improper_storage")
	private Integer iiImproperStorage;

	@Column(name = "III_wrong_installation")
	private Integer iiiWrongInstallation;

	@Column(name = "IV_defective_coupling")
	private Integer ivDefectiveCoupling;

	@Column(name = "IV_alignment")
	private Integer ivAlignment;

	@Column(name = "V_wrong_selection")
	private Integer vWrongSelection;

	@Column(name = "V_application")
	private Integer vApplication;

	@Column(name = "VI_incorrect_duty_cycle")
	private Integer viIncorrectDutyCycle;

	@Column(name = "VII_improper_ventilation")
	private Integer viiImproperVentilation;

	@Column(name = "VIII_supply_condition_voltage")
	private Integer viiiSupplyConditionVoltage;

	@Column(name = "VIII_supply_condition_frequency")
	private Integer viiiSupplyConditionFrequency;

	@Column(name = "IX_overloading")
	private Integer ixOverloading;

	@Column(name = "X_single_phasing")
	private Integer xSinglePhasing;

	@Column(name = "XI_poor_maintenance")
	private Integer xiPoorMaintenance;

	@Column(name = "XII_high_amb_temp_deg")
	private Float xiiHighAmbTempDeg;

	@Column(name = "XIII_site_condition_dusty")
	private Integer xiiiSiteConditionDusty;

	@Column(name = "XIII_site_condition_corrosive")
	private Integer xiiiSiteConditionCorrosive;

	@Column(name = "XIII_site_condition_indoor")
	private Integer xiiiSiteConditionIndoor;

	@Column(name = "XIII_site_condition_outdoor")
	private Integer xiiiSiteConditionOutdoor;

	@Column(name = "XIV_miscellaneous")
	private Integer xivMiscellaneous;

	@Column(name = "misc_comments", length = 300)
	private String miscComments;

	@Column(name = "notification_num")
	private String notificationNum;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = "created_by_ref_id", length = 20)
	private String createdByRefId;

	@Column(name = "referred_for_review_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date referredForReviewOn;

	@Column(name = "referred_for_review_by_ref_id")
	private String referredForReviewByRefId;

	@Column(name = "status_updated_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date statusUpdatedOn;

	@Column(name = "status_updated_by_ref_id", length = 20)
	private String statusUpdatedByRefId;

	@Column(name = "approval_status")
	private Integer approvalStatus;
	
	@Column(name = "arc_approved_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date arcApprovedOn;

	@Column(name = "arc_reviewed_by", length = 20)
	private String arcReviewedBy;


	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="subprocess_id",insertable=true,updatable=true)
	private SubProcessFields subProcessFields;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	private MotorNamePlateDetail motorNamePlateDetail;

	/**
	 * @return the motorDReportFieldId
	 */
	public Long getMotorDReportFieldId() {
		return motorDReportFieldId;
	}

	/**
	 * @param motorDReportFieldId
	 *            the motorDReportFieldId to set
	 */
	public void setMotorDReportFieldId(Long motorDReportFieldId) {
		this.motorDReportFieldId = motorDReportFieldId;
	}
	
		/**
	 * @return the statusUpdatedOn
	 */
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param statusUpdatedOn the statusUpdatedOn to set
	 */
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}

	/**
	 * @return the statusUpdatedByRefId
	 */
	public String getStatusUpdatedByRefId() {
		return statusUpdatedByRefId;
	}

	/**
	 * @param statusUpdatedByRefId the statusUpdatedByRefId to set
	 */
	public void setStatusUpdatedByRefId(String statusUpdatedByRefId) {
		this.statusUpdatedByRefId = statusUpdatedByRefId;
	}

	/**
	 * @return the approvalStatus
	 */
	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the aFootBreakage
	 */
	public Integer getaFootBreakage() {
		return aFootBreakage;
	}

	/**
	 * @param aFootBreakage
	 *            the aFootBreakage to set
	 */
	public void setaFootBreakage(Integer aFootBreakage) {
		this.aFootBreakage = aFootBreakage;
	}

	/**
	 * @return the aFinsBreakage
	 */
	public Integer getaFinsBreakage() {
		return aFinsBreakage;
	}

	/**
	 * @param aFinsBreakage
	 *            the aFinsBreakage to set
	 */
	public void setaFinsBreakage(Integer aFinsBreakage) {
		this.aFinsBreakage = aFinsBreakage;
	}

	/**
	 * @return the bHousing
	 */
	public Integer getbHousing() {
		return bHousing;
	}

	/**
	 * @param bHousing
	 *            the bHousing to set
	 */
	public void setbHousing(Integer bHousing) {
		this.bHousing = bHousing;
	}

	/**
	 * @return the bFanCowl
	 */
	public Integer getbFanCowl() {
		return bFanCowl;
	}

	/**
	 * @param bFanCowl
	 *            the bFanCowl to set
	 */
	public void setbFanCowl(Integer bFanCowl) {
		this.bFanCowl = bFanCowl;
	}

	/**
	 * @return the bFanEndshield
	 */
	public Integer getbFanEndshield() {
		return bFanEndshield;
	}

	/**
	 * @param bFanEndshield
	 *            the bFanEndshield to set
	 */
	public void setbFanEndshield(Integer bFanEndshield) {
		this.bFanEndshield = bFanEndshield;
	}

	/**
	 * @return the bTerminalBoxBreakage
	 */
	public Integer getbTerminalBoxBreakage() {
		return bTerminalBoxBreakage;
	}

	/**
	 * @param bTerminalBoxBreakage
	 *            the bTerminalBoxBreakage to set
	 */
	public void setbTerminalBoxBreakage(Integer bTerminalBoxBreakage) {
		this.bTerminalBoxBreakage = bTerminalBoxBreakage;
	}

	/**
	 * @return the cFanMelting
	 */
	public Integer getcFanMelting() {
		return cFanMelting;
	}

	/**
	 * @param cFanMelting
	 *            the cFanMelting to set
	 */
	public void setcFanMelting(Integer cFanMelting) {
		this.cFanMelting = cFanMelting;
	}

	/**
	 * @return the dBrushBlockDamage
	 */
	public Integer getdBrushBlockDamage() {
		return dBrushBlockDamage;
	}

	/**
	 * @param dBrushBlockDamage
	 *            the dBrushBlockDamage to set
	 */
	public void setdBrushBlockDamage(Integer dBrushBlockDamage) {
		this.dBrushBlockDamage = dBrushBlockDamage;
	}

	/**
	 * @return the eShortCircuitRingBroken
	 */
	public Integer geteShortCircuitRingBroken() {
		return eShortCircuitRingBroken;
	}

	/**
	 * @param eShortCircuitRingBroken
	 *            the eShortCircuitRingBroken to set
	 */
	public void seteShortCircuitRingBroken(Integer eShortCircuitRingBroken) {
		this.eShortCircuitRingBroken = eShortCircuitRingBroken;
	}

	/**
	 * @return the fVibrationTooHigh
	 */
	public Integer getfVibrationTooHigh() {
		return fVibrationTooHigh;
	}

	/**
	 * @param fVibrationTooHigh
	 *            the fVibrationTooHigh to set
	 */
	public void setfVibrationTooHigh(Integer fVibrationTooHigh) {
		this.fVibrationTooHigh = fVibrationTooHigh;
	}

	/**
	 * @return the gBearingLooseInEndshield
	 */
	public Integer getgBearingLooseInEndshield() {
		return gBearingLooseInEndshield;
	}

	/**
	 * @param gBearingLooseInEndshield
	 *            the gBearingLooseInEndshield to set
	 */
	public void setgBearingLooseInEndshield(Integer gBearingLooseInEndshield) {
		this.gBearingLooseInEndshield = gBearingLooseInEndshield;
	}

	/**
	 * @return the gShaft
	 */
	public Integer getgShaft() {
		return gShaft;
	}

	/**
	 * @param gShaft
	 *            the gShaft to set
	 */
	public void setgShaft(Integer gShaft) {
		this.gShaft = gShaft;
	}

	/**
	 * @return the hBearingFailure
	 */
	public Integer gethBearingFailure() {
		return hBearingFailure;
	}

	/**
	 * @param hBearingFailure
	 *            the hBearingFailure to set
	 */
	public void sethBearingFailure(Integer hBearingFailure) {
		this.hBearingFailure = hBearingFailure;
	}

	/**
	 * @return the hNoisy
	 */
	public Integer gethNoisy() {
		return hNoisy;
	}

	/**
	 * @param hNoisy
	 *            the hNoisy to set
	 */
	public void sethNoisy(Integer hNoisy) {
		this.hNoisy = hNoisy;
	}

	/**
	 * @return the hSeize
	 */
	public Integer gethSeize() {
		return hSeize;
	}

	/**
	 * @param hSeize
	 *            the hSeize to set
	 */
	public void sethSeize(Integer hSeize) {
		this.hSeize = hSeize;
	}

	/**
	 * @return the iShaftBreakage
	 */
	public Integer getiShaftBreakage() {
		return iShaftBreakage;
	}

	/**
	 * @param iShaftBreakage
	 *            the iShaftBreakage to set
	 */
	public void setiShaftBreakage(Integer iShaftBreakage) {
		this.iShaftBreakage = iShaftBreakage;
	}

	/**
	 * @return the jIngressOfWater
	 */
	public Integer getjIngressOfWater() {
		return jIngressOfWater;
	}

	/**
	 * @param jIngressOfWater
	 *            the jIngressOfWater to set
	 */
	public void setjIngressOfWater(Integer jIngressOfWater) {
		this.jIngressOfWater = jIngressOfWater;
	}

	/**
	 * @return the jChemicals
	 */
	public Integer getjChemicals() {
		return jChemicals;
	}

	/**
	 * @param jChemicals
	 *            the jChemicals to set
	 */
	public void setjChemicals(Integer jChemicals) {
		this.jChemicals = jChemicals;
	}

	/**
	 * @return the kMotorDrawsUnbalance
	 */
	public Integer getkMotorDrawsUnbalance() {
		return kMotorDrawsUnbalance;
	}

	/**
	 * @param kMotorDrawsUnbalance
	 *            the kMotorDrawsUnbalance to set
	 */
	public void setkMotorDrawsUnbalance(Integer kMotorDrawsUnbalance) {
		this.kMotorDrawsUnbalance = kMotorDrawsUnbalance;
	}

	/**
	 * @return the kHighCurrent
	 */
	public Integer getkHighCurrent() {
		return kHighCurrent;
	}

	/**
	 * @param kHighCurrent
	 *            the kHighCurrent to set
	 */
	public void setkHighCurrent(Integer kHighCurrent) {
		this.kHighCurrent = kHighCurrent;
	}

	/**
	 * @return the lMotorGettingExcessivelyHot
	 */
	public Integer getlMotorGettingExcessivelyHot() {
		return lMotorGettingExcessivelyHot;
	}

	/**
	 * @param lMotorGettingExcessivelyHot
	 *            the lMotorGettingExcessivelyHot to set
	 */
	public void setlMotorGettingExcessivelyHot(Integer lMotorGettingExcessivelyHot) {
		this.lMotorGettingExcessivelyHot = lMotorGettingExcessivelyHot;
	}

	/**
	 * @return the mMotorNotStarting
	 */
	public Integer getmMotorNotStarting() {
		return mMotorNotStarting;
	}

	/**
	 * @param mMotorNotStarting
	 *            the mMotorNotStarting to set
	 */
	public void setmMotorNotStarting(Integer mMotorNotStarting) {
		this.mMotorNotStarting = mMotorNotStarting;
	}

	/**
	 * @return the mNotPickingUpSpeed
	 */
	public Integer getmNotPickingUpSpeed() {
		return mNotPickingUpSpeed;
	}

	/**
	 * @param mNotPickingUpSpeed
	 *            the mNotPickingUpSpeed to set
	 */
	public void setmNotPickingUpSpeed(Integer mNotPickingUpSpeed) {
		this.mNotPickingUpSpeed = mNotPickingUpSpeed;
	}

	/**
	 * @return the nHookUpWiresDefective
	 */
	public Integer getnHookUpWiresDefective() {
		return nHookUpWiresDefective;
	}

	/**
	 * @param nHookUpWiresDefective
	 *            the nHookUpWiresDefective to set
	 */
	public void setnHookUpWiresDefective(Integer nHookUpWiresDefective) {
		this.nHookUpWiresDefective = nHookUpWiresDefective;
	}

	/**
	 * @return the oWindingBurnt
	 */
	public Integer getoWindingBurnt() {
		return oWindingBurnt;
	}

	/**
	 * @param oWindingBurnt
	 *            the oWindingBurnt to set
	 */
	public void setoWindingBurnt(Integer oWindingBurnt) {
		this.oWindingBurnt = oWindingBurnt;
	}

	/**
	 * @return the pWindingInterturnShort
	 */
	public Integer getpWindingInterturnShort() {
		return pWindingInterturnShort;
	}

	/**
	 * @param pWindingInterturnShort
	 *            the pWindingInterturnShort to set
	 */
	public void setpWindingInterturnShort(Integer pWindingInterturnShort) {
		this.pWindingInterturnShort = pWindingInterturnShort;
	}

	/**
	 * @return the qInsulationFailure
	 */
	public Integer getqInsulationFailure() {
		return qInsulationFailure;
	}

	/**
	 * @param qInsulationFailure
	 *            the qInsulationFailure to set
	 */
	public void setqInsulationFailure(Integer qInsulationFailure) {
		this.qInsulationFailure = qInsulationFailure;
	}

	/**
	 * @return the qEarthFault
	 */
	public Integer getqEarthFault() {
		return qEarthFault;
	}

	/**
	 * @param qEarthFault
	 *            the qEarthFault to set
	 */
	public void setqEarthFault(Integer qEarthFault) {
		this.qEarthFault = qEarthFault;
	}

	/**
	 * @return the rInterphaseInsulationFailure
	 */
	public Integer getrInterphaseInsulationFailure() {
		return rInterphaseInsulationFailure;
	}

	/**
	 * @param rInterphaseInsulationFailure
	 *            the rInterphaseInsulationFailure to set
	 */
	public void setrInterphaseInsulationFailure(Integer rInterphaseInsulationFailure) {
		this.rInterphaseInsulationFailure = rInterphaseInsulationFailure;
	}

	/**
	 * @return the sMiscellaneous
	 */
	public Integer getsMiscellaneous() {
		return sMiscellaneous;
	}

	/**
	 * @param sMiscellaneous
	 *            the sMiscellaneous to set
	 */
	public void setsMiscellaneous(Integer sMiscellaneous) {
		this.sMiscellaneous = sMiscellaneous;
	}

	/**
	 * @return the tAxialPlay
	 */
	public Integer gettAxialPlay() {
		return tAxialPlay;
	}

	/**
	 * @param tAxialPlay
	 *            the tAxialPlay to set
	 */
	public void settAxialPlay(Integer tAxialPlay) {
		this.tAxialPlay = tAxialPlay;
	}

	/**
	 * @return the uRotorDefect
	 */
	public Integer getuRotorDefect() {
		return uRotorDefect;
	}

	/**
	 * @param uRotorDefect
	 *            the uRotorDefect to set
	 */
	public void setuRotorDefect(Integer uRotorDefect) {
		this.uRotorDefect = uRotorDefect;
	}

	/**
	 * @return the vBalWtFalling
	 */
	public Integer getvBalWtFalling() {
		return vBalWtFalling;
	}

	/**
	 * @param vBalWtFalling
	 *            the vBalWtFalling to set
	 */
	public void setvBalWtFalling(Integer vBalWtFalling) {
		this.vBalWtFalling = vBalWtFalling;
	}

	/**
	 * @return the wRTD
	 */
	public Integer getwRTD() {
		return wRTD;
	}

	/**
	 * @param wRTD
	 *            the wRTD to set
	 */
	public void setwRTD(Integer wRTD) {
		this.wRTD = wRTD;
	}

	/**
	 * @return the wPTCDefect
	 */
	public Integer getwPTCDefect() {
		return wPTCDefect;
	}

	/**
	 * @param wPTCDefect
	 *            the wPTCDefect to set
	 */
	public void setwPTCDefect(Integer wPTCDefect) {
		this.wPTCDefect = wPTCDefect;
	}

	/**
	 * @return the iWrongHandling
	 */
	public Integer getiWrongHandling() {
		return iWrongHandling;
	}

	/**
	 * @param iWrongHandling
	 *            the iWrongHandling to set
	 */
	public void setiWrongHandling(Integer iWrongHandling) {
		this.iWrongHandling = iWrongHandling;
	}

	/**
	 * @return the iTransport
	 */
	public Integer getiTransport() {
		return iTransport;
	}

	/**
	 * @param iTransport
	 *            the iTransport to set
	 */
	public void setiTransport(Integer iTransport) {
		this.iTransport = iTransport;
	}

	/**
	 * @return the iiImproperStorage
	 */
	public Integer getIiImproperStorage() {
		return iiImproperStorage;
	}

	/**
	 * @param iiImproperStorage
	 *            the iiImproperStorage to set
	 */
	public void setIiImproperStorage(Integer iiImproperStorage) {
		this.iiImproperStorage = iiImproperStorage;
	}

	/**
	 * @return the iiiWrongInstallation
	 */
	public Integer getIiiWrongInstallation() {
		return iiiWrongInstallation;
	}

	/**
	 * @param iiiWrongInstallation
	 *            the iiiWrongInstallation to set
	 */
	public void setIiiWrongInstallation(Integer iiiWrongInstallation) {
		this.iiiWrongInstallation = iiiWrongInstallation;
	}

	/**
	 * @return the ivDefectiveCoupling
	 */
	public Integer getIvDefectiveCoupling() {
		return ivDefectiveCoupling;
	}

	/**
	 * @param ivDefectiveCoupling
	 *            the ivDefectiveCoupling to set
	 */
	public void setIvDefectiveCoupling(Integer ivDefectiveCoupling) {
		this.ivDefectiveCoupling = ivDefectiveCoupling;
	}

	/**
	 * @return the ivAlignment
	 */
	public Integer getIvAlignment() {
		return ivAlignment;
	}

	/**
	 * @param ivAlignment
	 *            the ivAlignment to set
	 */
	public void setIvAlignment(Integer ivAlignment) {
		this.ivAlignment = ivAlignment;
	}

	/**
	 * @return the vWrongSelection
	 */
	public Integer getvWrongSelection() {
		return vWrongSelection;
	}

	/**
	 * @param vWrongSelection
	 *            the vWrongSelection to set
	 */
	public void setvWrongSelection(Integer vWrongSelection) {
		this.vWrongSelection = vWrongSelection;
	}

	/**
	 * @return the vApplication
	 */
	public Integer getvApplication() {
		return vApplication;
	}

	/**
	 * @param vApplication
	 *            the vApplication to set
	 */
	public void setvApplication(Integer vApplication) {
		this.vApplication = vApplication;
	}

	/**
	 * @return the viIncorrectDutyCycle
	 */
	public Integer getViIncorrectDutyCycle() {
		return viIncorrectDutyCycle;
	}

	/**
	 * @param viIncorrectDutyCycle
	 *            the viIncorrectDutyCycle to set
	 */
	public void setViIncorrectDutyCycle(Integer viIncorrectDutyCycle) {
		this.viIncorrectDutyCycle = viIncorrectDutyCycle;
	}

	/**
	 * @return the viiImproperVentilation
	 */
	public Integer getViiImproperVentilation() {
		return viiImproperVentilation;
	}

	/**
	 * @param viiImproperVentilation
	 *            the viiImproperVentilation to set
	 */
	public void setViiImproperVentilation(Integer viiImproperVentilation) {
		this.viiImproperVentilation = viiImproperVentilation;
	}

	/**
	 * @return the viiiSupplyConditionVoltage
	 */
	public Integer getViiiSupplyConditionVoltage() {
		return viiiSupplyConditionVoltage;
	}

	/**
	 * @param viiiSupplyConditionVoltage
	 *            the viiiSupplyConditionVoltage to set
	 */
	public void setViiiSupplyConditionVoltage(Integer viiiSupplyConditionVoltage) {
		this.viiiSupplyConditionVoltage = viiiSupplyConditionVoltage;
	}

	/**
	 * @return the viiiSupplyConditionFrequency
	 */
	public Integer getViiiSupplyConditionFrequency() {
		return viiiSupplyConditionFrequency;
	}

	/**
	 * @param viiiSupplyConditionFrequency
	 *            the viiiSupplyConditionFrequency to set
	 */
	public void setViiiSupplyConditionFrequency(Integer viiiSupplyConditionFrequency) {
		this.viiiSupplyConditionFrequency = viiiSupplyConditionFrequency;
	}

	/**
	 * @return the ixOverloading
	 */
	public Integer getIxOverloading() {
		return ixOverloading;
	}

	/**
	 * @param ixOverloading
	 *            the ixOverloading to set
	 */
	public void setIxOverloading(Integer ixOverloading) {
		this.ixOverloading = ixOverloading;
	}

	/**
	 * @return the xSinglePhasing
	 */
	public Integer getxSinglePhasing() {
		return xSinglePhasing;
	}

	/**
	 * @param xSinglePhasing
	 *            the xSinglePhasing to set
	 */
	public void setxSinglePhasing(Integer xSinglePhasing) {
		this.xSinglePhasing = xSinglePhasing;
	}

	/**
	 * @return the xiPoorMaintenance
	 */
	public Integer getXiPoorMaintenance() {
		return xiPoorMaintenance;
	}

	/**
	 * @param xiPoorMaintenance
	 *            the xiPoorMaintenance to set
	 */
	public void setXiPoorMaintenance(Integer xiPoorMaintenance) {
		this.xiPoorMaintenance = xiPoorMaintenance;
	}

	/**
	 * @return the xiiHighAmbTempDeg
	 */
	public Float getXiiHighAmbTempDeg() {
		return xiiHighAmbTempDeg;
	}

	/**
	 * @param xiiHighAmbTempDeg
	 *            the xiiHighAmbTempDeg to set
	 */
	public void setXiiHighAmbTempDeg(Float xiiHighAmbTempDeg) {
		this.xiiHighAmbTempDeg = xiiHighAmbTempDeg;
	}

	/**
	 * @return the xiiiSiteConditionDusty
	 */
	public Integer getXiiiSiteConditionDusty() {
		return xiiiSiteConditionDusty;
	}

	/**
	 * @param xiiiSiteConditionDusty
	 *            the xiiiSiteConditionDusty to set
	 */
	public void setXiiiSiteConditionDusty(Integer xiiiSiteConditionDusty) {
		this.xiiiSiteConditionDusty = xiiiSiteConditionDusty;
	}

	/**
	 * @return the xiiiSiteConditionCorrosive
	 */
	public Integer getXiiiSiteConditionCorrosive() {
		return xiiiSiteConditionCorrosive;
	}

	/**
	 * @param xiiiSiteConditionCorrosive
	 *            the xiiiSiteConditionCorrosive to set
	 */
	public void setXiiiSiteConditionCorrosive(Integer xiiiSiteConditionCorrosive) {
		this.xiiiSiteConditionCorrosive = xiiiSiteConditionCorrosive;
	}

	/**
	 * @return the xiiiSiteConditionIndoor
	 */
	public Integer getXiiiSiteConditionIndoor() {
		return xiiiSiteConditionIndoor;
	}

	/**
	 * @param xiiiSiteConditionIndoor
	 *            the xiiiSiteConditionIndoor to set
	 */
	public void setXiiiSiteConditionIndoor(Integer xiiiSiteConditionIndoor) {
		this.xiiiSiteConditionIndoor = xiiiSiteConditionIndoor;
	}

	/**
	 * @return the xiiiSiteConditionOutdoor
	 */
	public Integer getXiiiSiteConditionOutdoor() {
		return xiiiSiteConditionOutdoor;
	}

	/**
	 * @param xiiiSiteConditionOutdoor
	 *            the xiiiSiteConditionOutdoor to set
	 */
	public void setXiiiSiteConditionOutdoor(Integer xiiiSiteConditionOutdoor) {
		this.xiiiSiteConditionOutdoor = xiiiSiteConditionOutdoor;
	}

	/**
	 * @return the xivMiscellaneous
	 */
	public Integer getXivMiscellaneous() {
		return xivMiscellaneous;
	}

	/**
	 * @param xivMiscellaneous
	 *            the xivMiscellaneous to set
	 */
	public void setXivMiscellaneous(Integer xivMiscellaneous) {
		this.xivMiscellaneous = xivMiscellaneous;
	}

	/**
	 * @return the miscComments
	 */
	public String getMiscComments() {
		return miscComments;
	}

	/**
	 * @param miscComments
	 *            the miscComments to set
	 */
	public void setMiscComments(String miscComments) {
		this.miscComments = miscComments;
	}

	/**
	 * @return the notificationNum
	 */
	public String getNotificationNum() {
		return notificationNum;
	}

	/**
	 * @param notificationNum
	 *            the notificationNum to set
	 */
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the referredForReviewOn
	 */
	public Date getReferredForReviewOn() {
		return referredForReviewOn;
	}

	/**
	 * @param referredForReviewOn
	 *            the referredForReviewOn to set
	 */
	public void setReferredForReviewOn(Date referredForReviewOn) {
		this.referredForReviewOn = referredForReviewOn;
	}

	/**
	 * @return the referredForReviewByRefId
	 */
	public String getReferredForReviewByRefId() {
		return referredForReviewByRefId;
	}

	/**
	 * @param referredForReviewByRefId
	 *            the referredForReviewByRefId to set
	 */
	public void setReferredForReviewByRefId(String referredForReviewByRefId) {
		this.referredForReviewByRefId = referredForReviewByRefId;
	}


   /**
	 * @return the subProcessFields
	 */
	public SubProcessFields getSubProcessFields() {
		return subProcessFields;
	}

	/**
	 * @param subProcessFields
	 *            the subProcessFields to set
	 */
	public void setSubProcessFields(SubProcessFields subProcessFields) {
		this.subProcessFields = subProcessFields;
	}

	/**
	 * @return the motorNamePlateDetail
	 */
	public MotorNamePlateDetail getMotorNamePlateDetail() {
		return motorNamePlateDetail;
	}

	/**
	 * @param motorNamePlateDetail
	 *            the motorNamePlateDetail to set
	 */
	public void setMotorNamePlateDetail(MotorNamePlateDetail motorNamePlateDetail) {
		this.motorNamePlateDetail = motorNamePlateDetail;
	}

	/**
	 * @return the arcApprovedOn
	 */
	public Date getArcApprovedOn() {
		return arcApprovedOn;
	}

	/**
	 * @param arcApprovedOn
	 *            the arcApprovedOn to set
	 */
	public void setArcApprovedOn(Date arcApprovedOn) {
		this.arcApprovedOn = arcApprovedOn;
	}

	/**
	 * @return the arcReviewedBy
	 */
	public String getArcReviewedBy() {
		return arcReviewedBy;
	}

	/**
	 * @param arcReviewedBy
	 *            the arcReviewedBy to set
	 */
	public void setArcReviewedBy(String arcReviewedBy) {
		this.arcReviewedBy = arcReviewedBy;
	}

}
