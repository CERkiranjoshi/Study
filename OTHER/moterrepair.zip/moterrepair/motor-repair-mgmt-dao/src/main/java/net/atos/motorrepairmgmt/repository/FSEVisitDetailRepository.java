package net.atos.motorrepairmgmt.repository;

import java.util.List;
import net.atos.motorrepairmgmt.entity.FSEVisitDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603981
 *
 */
public interface FSEVisitDetailRepository extends JpaRepository<FSEVisitDetail, Long> {
	@Query("SELECT e from FSEVisitDetail e where e.fseName=:fseName ")
	List<FSEVisitDetail> findFSEVisitByName(@Param("fseName") String fseName);
}
