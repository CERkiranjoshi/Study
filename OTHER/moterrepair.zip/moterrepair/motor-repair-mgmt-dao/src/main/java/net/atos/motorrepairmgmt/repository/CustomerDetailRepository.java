package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.CustomerDetail;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerDetailRepository extends JpaRepository<CustomerDetail, Long> {

}
