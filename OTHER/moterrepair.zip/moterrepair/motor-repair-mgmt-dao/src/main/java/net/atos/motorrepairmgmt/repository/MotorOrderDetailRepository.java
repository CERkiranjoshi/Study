/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.MotorOrderDetail;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a603981
 *
 */
public interface MotorOrderDetailRepository extends JpaRepository<MotorOrderDetail, Long> {
}
