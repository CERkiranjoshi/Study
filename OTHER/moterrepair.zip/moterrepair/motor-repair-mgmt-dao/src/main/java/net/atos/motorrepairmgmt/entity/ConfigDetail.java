/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Sweety Kothari
 * This entity represents all config parameter info required for system
 */

@Entity
@Table(name="rmt_config_detail")
public class ConfigDetail implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6241253066055856235L;
	
	@Id
	@Column(name = "config_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long configId;
	  
	@Column(name = "tenant_id",length=50)
    private String tenantId;
	
	@Column(name = "config_type",length=50)
	private String configType;
	
	@Column(name = "solution_category_id",length=50)
	private String solutionCategoryId;
  
	@Column(name = "config_sub_type",length=50)
    private String configSubType;
	
	@Column(name = "config_key",length=50)
    private String configKey;
	
	@Column(name = "config_alias",length=50)
    private String configAlias;
	
	@Column(name = "config_str_val",length=200)
    private String configStrVal;
	
	@Column(name = "config_desc",length=255)
    private String configDesc;
	
	@Column(name = "config_int_val")
    private Integer configIntVal;
	
	@Column(name = "config_double_val")
    private Double configDoubleVal;
	
	@Column(name = "config_dateTime_val")
    private Date configDateTimeVal;
	
	@Column(name = "config_boolean_val")
    private Boolean configBooleanValue;
	
	//Config Type - 1: String value; 2: Integer; 3: Float; 4: Date Time; 5: Boolean
    @Column(name = "config_data_type")
    private Integer cofigDataType;
	
	@Column(name = "config_enabled")
    private Integer configEnabled;
	
	@Column(name = "config_visiblity")
    private Integer configVisiblity;
	
	@Column(name = "config_editable")
    private Integer configEditable;
	
	@Column(name = "created_on")
    private Date createdOn;
	
	@Column(name = "created_by_refid")
    private String createdByRefId;
	
	@Column(name = "modified_on")
    private Date modifiedOn;
	
	@Column(name = "modified_by_refid")
    private String modifiedByRefId;
	
	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the configId
	 */
	public Long getConfigId() {
		return configId;
	}

	/**
	 * @param configId the configId to set
	 */
	public void setConfigId(Long configId) {
		this.configId = configId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the configType
	 */
	public String getConfigType() {
		return configType;
	}

	/**
	 * @param configType the configType to set
	 */
	public void setConfigType(String configType) {
		this.configType = configType;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the configSubType
	 */
	public String getConfigSubType() {
		return configSubType;
	}

	/**
	 * @param configSubType the configSubType to set
	 */
	public void setConfigSubType(String configSubType) {
		this.configSubType = configSubType;
	}

	/**
	 * @return the configKey
	 */
	public String getConfigKey() {
		return configKey;
	}

	/**
	 * @param configKey the configKey to set
	 */
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	/**
	 * @return the configAlias
	 */
	public String getConfigAlias() {
		return configAlias;
	}

	/**
	 * @param configAlias the configAlias to set
	 */
	public void setConfigAlias(String configAlias) {
		this.configAlias = configAlias;
	}

	/**
	 * @return the configStrVal
	 */
	public String getConfigStrVal() {
		return configStrVal;
	}

	/**
	 * @param configStrVal the configStrVal to set
	 */
	public void setConfigStrVal(String configStrVal) {
		this.configStrVal = configStrVal;
	}

	/**
	 * @return the configIntVal
	 */
	public Integer getConfigIntVal() {
		return configIntVal;
	}

	/**
	 * @param configIntVal the configIntVal to set
	 */
	public void setConfigIntVal(Integer configIntVal) {
		this.configIntVal = configIntVal;
	}

	/**
	 * @return the configDoubleVal
	 */
	public Double getConfigDoubleVal() {
		return configDoubleVal;
	}

	/**
	 * @param configDoubleVal the configDoubleVal to set
	 */
	public void setConfigDoubleVal(Double configDoubleVal) {
		this.configDoubleVal = configDoubleVal;
	}

	/**
	 * @return the configDateTimeVal
	 */
	public Date getConfigDateTimeVal() {
		return configDateTimeVal;
	}

	/**
	 * @param configDateTimeVal the configDateTimeVal to set
	 */
	public void setConfigDateTimeVal(Date configDateTimeVal) {
		this.configDateTimeVal = configDateTimeVal;
	}



	/**
	 * @return the configBooleanValue
	 */
	public Boolean getConfigBooleanValue() {
		return configBooleanValue;
	}

	/**
	 * @param configBooleanValue the configBooleanValue to set
	 */
	public void setConfigBooleanValue(Boolean configBooleanValue) {
		this.configBooleanValue = configBooleanValue;
	}

	/**
	 * @return the cofigDataType
	 */
	public Integer getCofigDataType() {
		return cofigDataType;
	}

	/**
	 * @param cofigDataType the cofigDataType to set
	 */
	public void setCofigDataType(Integer cofigDataType) {
		this.cofigDataType = cofigDataType;
	}

	/**
	 * @return the configEnabled
	 */
	public Integer getConfigEnabled() {
		return configEnabled;
	}

	/**
	 * @param configEnabled the configEnabled to set
	 */
	public void setConfigEnabled(Integer configEnabled) {
		this.configEnabled = configEnabled;
	}

	/**
	 * @return the configVisiblity
	 */
	public Integer getConfigVisiblity() {
		return configVisiblity;
	}

	/**
	 * @param configVisiblity the configVisiblity to set
	 */
	public void setConfigVisiblity(Integer configVisiblity) {
		this.configVisiblity = configVisiblity;
	}

	/**
	 * @return the configEditable
	 */
	public Integer getConfigEditable() {
		return configEditable;
	}

	/**
	 * @param configEditable the configEditable to set
	 */
	public void setConfigEditable(Integer configEditable) {
		this.configEditable = configEditable;
	}

	/**
	 * @return the configDesc
	 */
	public String getConfigDesc() {
		return configDesc;
	}

	/**
	 * @param configDesc the configDesc to set
	 */
	public void setConfigDesc(String configDesc) {
		this.configDesc = configDesc;
	}
	
}
