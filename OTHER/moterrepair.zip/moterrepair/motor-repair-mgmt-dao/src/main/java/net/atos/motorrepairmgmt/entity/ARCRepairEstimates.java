/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a610051
 * 
 */
@Entity
@Table(name = "rmt_arc_repair_estimates")
public class ARCRepairEstimates extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1693422889552590467L;

	@Id
	@Column(name = "arc_repair_estimate_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long arcRepairEstimateId;

	@Column(name = "scope_of_work")
	private String scopeOfWork;

	@Column(name = "unit_cost")
	private Float unitCost;

	@Column(name = "qty")
	private Integer qty;

	@Column(name = "item_unit")
	private String itemUnit;

	@Column(name = "total_cost")
	private Float totalCost;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "created_by_ref_id", length = 20)
	private String createdByRefId;
	
	/**
	 * @return the arcRepairEstimateId
	 */
	public Long getArcRepairEstimateId() {
		return arcRepairEstimateId;
	}

	/**
	 * @param arcRepairEstimateId
	 *            the arcRepairEstimateId to set
	 */
	public void setArcRepairEstimateId(Long arcRepairEstimateId) {
		this.arcRepairEstimateId = arcRepairEstimateId;
	}

	/**
	 * @return the scopeOfWork
	 */
	public String getScopeOfWork() {
		return scopeOfWork;
	}

	/**
	 * @param scopeOfWork
	 *            the scopeOfWork to set Free Text for Job Details
	 */
	public void setScopeOfWork(String scopeOfWork) {
		this.scopeOfWork = scopeOfWork;
	}

	/**
	 * @return the qty
	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set No. of jobs / spares
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit
	 *            the itemUnit to set unit of item as 1 job or 5 mts.
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the unitCost
	 */
	public Float getUnitCost() {
		return unitCost;
	}

	/**
	 * @param unitCost
	 *            the unitCost to set Per Unit cost
	 */
	public void setUnitCost(Float unitCost) {
		this.unitCost = unitCost;
	}

	/**
	 * @return the totalCost
	 */
	public Float getTotalCost() {
		return totalCost;
	}

	/**
	 * @param totalCost
	 *            the totalCost to set Auto calculated field qty * unit_cost
	 */
	public void setTotalCost(Float totalCost) {
		this.totalCost = totalCost;
	}

}
