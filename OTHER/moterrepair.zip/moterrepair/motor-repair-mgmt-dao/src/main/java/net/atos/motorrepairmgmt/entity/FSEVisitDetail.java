package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775 entity to store FSE Visit Detail
 */
@Entity
@Table(name = "rmt_fse_details")
public class FSEVisitDetail extends BasicEntity implements Serializable {

	private static final long serialVersionUID = 13434345657676544L;

	@Id
	@Column(name = "fse_visit_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long fseVisitDetailId;

	@Column(name = "arc_code", length = 20)
	private String arcCode;

	@Column(name = "arc_ref_id", length = 20)
	private String arcRefId;

	@Column(name = "fse_name", length = 30)
	private String fseName;

	@Column(name = "fse_mobile_num", length = 20)
	private String fseMobileNum;

	@Column(name = "fse_visit_planned_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fseVisitPlannedDate;

	@Column(name = "fse_visit_actual_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fseVisitActualDate;

	@Column(name = "fse_visit_type")
	private Integer fseVisitType;
	
	@Column(name="fse_confirm_cts_approval")
	private Integer fseConfirmCtsApproval;
	
	@Column(name="visit_status")
	private Integer visitStatus;
	
	
	/**
	 * @return the fseVisitDetailId
	 */
	public Long getFseVisitDetailId() {
		return fseVisitDetailId;
	}

	/**
	 * @param fseVisitDetailId
	 *            the fseVisitDetailId to set
	 */
	public void setFseVisitDetailId(Long fseVisitDetailId) {
		this.fseVisitDetailId = fseVisitDetailId;
	}

	/**
	 * @return the arcCode
	 */
	public String getArcCode() {
		return arcCode;
	}

	/**
	 * @param arcCode
	 *            the arcCode to set
	 */
	public void setArcCode(String arcCode) {
		this.arcCode = arcCode;
	}

	/**
	 * @return the arcRefId
	 */
	public String getArcRefId() {
		return arcRefId;
	}

	/**
	 * @param arcRefId
	 *            the arcRefId to set
	 */
	public void setArcRefId(String arcRefId) {
		this.arcRefId = arcRefId;
	}

	/**
	 * @return the fseName
	 */
	public String getFseName() {
		return fseName;
	}

	/**
	 * @param fseName
	 *            the fseName to set
	 */
	public void setFseName(String fseName) {
		this.fseName = fseName;
	}

	/**
	 * @return the fseMobileNum
	 */
	public String getFseMobileNum() {
		return fseMobileNum;
	}

	/**
	 * @param fseMobileNum
	 *            the fseMobileNum to set
	 */
	public void setFseMobileNum(String fseMobileNum) {
		this.fseMobileNum = fseMobileNum;
	}

	/**
	 * @return the fseVisitPlannedDate
	 */
	public Date getFseVisitPlannedDate() {
		return fseVisitPlannedDate;
	}

	/**
	 * @param fseVisitPlannedDate
	 *            the fseVisitPlannedDate to set
	 */
	public void setFseVisitPlannedDate(Date fseVisitPlannedDate) {
		this.fseVisitPlannedDate = fseVisitPlannedDate;
	}

	/**
	 * @return the fseVisitActualDate
	 */
	public Date getFseVisitActualDate() {
		return fseVisitActualDate;
	}

	/**
	 * @param fseVisitActualDate
	 *            the fseVisitActualDate to set
	 */
	public void setFseVisitActualDate(Date fseVisitActualDate) {
		this.fseVisitActualDate = fseVisitActualDate;
	}

	/**
	 * @return the fseVisitType
	 */
	public Integer getFseVisitType() {
		return fseVisitType;
	}

	/**
	 * @param fseVisitType
	 *            the fseVisitType to set 1: Initial Inspection; 2: Revisit; 3:
	 *            With Materials
	 */
	public void setFseVisitType(Integer fseVisitType) {
		this.fseVisitType = fseVisitType;
	}

	/**
	 * @return the fseConfirmCtsApproval
	 */
	public Integer getFseConfirmCtsApproval() {
		return fseConfirmCtsApproval;
	}

	/**
	 * @param fseConfirmCtsApproval the fseConfirmCtsApproval to set
	 */
	public void setFseConfirmCtsApproval(Integer fseConfirmCtsApproval) {
		this.fseConfirmCtsApproval = fseConfirmCtsApproval;
	}

	/**
	 * @return the visitStatus
	 */
	public Integer getVisitStatus() {
		return visitStatus;
	}

	/**
	 * @param visitStatus the visitStatus to set
	 */
	public void setVisitStatus(Integer visitStatus) {
		this.visitStatus = visitStatus;
	}
	
	
	
}
