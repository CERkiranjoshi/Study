package net.atos.motorrepairmgmt.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rmt_arc_motor_detail")
public class MotorDetailsArc {

	@Id
	@Column(name = "motor_order_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorOrderDetailId;

	@Column(name = "motor_sr_numbr")
	private String motorSnNum;

	@Column(name = "mlfb_spiridon")
	private String mlfbSpiridon;

	@Column(name = "motorspiridon_material_Code")
	private String motorSpiridonMaterialCode;

	@Column(name = "motor_ibasenum")
	private String motorIBaseNum;

	@Column(name = "motor_materialspe")
	private String motorMaterialSpec;

	@Column(name = "frame_size")
	private int frameSize;

	@Column(name = "product_grp")
	private String productGrp;

	@Column(name = "fault_desc")
	private String faultDesc;

	@Column(name = "initial_warranty_claim")
	private Integer initialWarrantyClaim;

	@Column(name = "initial_warranty_claim_byreffid")
	private String initialWarrantyClaimSetByRefId;

	@Column(name = "sales_div_refid")
	private String salesDivRefId;

	@Column(name = "sales_office_refid")
	private String salesOfficeRefId;

	@Column(name = "sales_org_refId")
	private String salesOrgRefId;

	@Column(name = "sales_grp_refid")
	private String salesGrpRefId;

	@Column(name = "region_id")
	private String regionId;

	@Column(name = "sub_process_id")
	private Long subProcessId;

	@Column(name = "service_type")
	private Integer serviceType;

	@Column(name = "order_type")
	private Integer orderType;

	@Column(name = "order_no", length = 50)
	private String orderNo;

	@Column(name = "created_on")
	private Date createdOn;

	@Column(name = "created_by", length = 20)
	private String createdBy;

	@Column(name = "order_statuss")
	private Integer orderStatus;

	@Column(name = "closed_on")
	private Date closedOn;

	@Column(name = "closed_by", length = 20)
	private String closedBy;
	
	@Column(name = "tenant_id")
	private Integer tenantId;

	@Column(name = "solution_category_id")
	private Integer solutionCategoryId;

	@Column(name = "sub_warranty_type")
	private Integer subWarrantyType;

	public Integer getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(Integer solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}


	

	public Long getMotorOrderDetailId() {
		return motorOrderDetailId;
	}

	public void setMotorOrderDetailId(Long motorOrderDetailId) {
		this.motorOrderDetailId = motorOrderDetailId;
	}

	public String getMotorSnNum() {
		return motorSnNum;
	}

	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}

	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}

	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}

	public String getMotorSpiridonMaterialCode() {
		return motorSpiridonMaterialCode;
	}

	public void setMotorSpiridonMaterialCode(String motorSpiridonMaterialCode) {
		this.motorSpiridonMaterialCode = motorSpiridonMaterialCode;
	}

	public String getMotorIBaseNum() {
		return motorIBaseNum;
	}

	public void setMotorIBaseNum(String motorIBaseNum) {
		this.motorIBaseNum = motorIBaseNum;
	}

	public String getMotorMaterialSpec() {
		return motorMaterialSpec;
	}

	public void setMotorMaterialSpec(String motorMaterialSpec) {
		this.motorMaterialSpec = motorMaterialSpec;
	}

	public int getFrameSize() {
		return frameSize;
	}

	public void setFrameSize(int frameSize) {
		this.frameSize = frameSize;
	}

	public String getProductGrp() {
		return productGrp;
	}

	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	public String getFaultDesc() {
		return faultDesc;
	}

	public void setFaultDesc(String faultDesc) {
		this.faultDesc = faultDesc;
	}

	public Integer getInitialWarrantyClaim() {
		return initialWarrantyClaim;
	}

	public void setInitialWarrantyClaim(Integer initialWarrantyClaim) {
		this.initialWarrantyClaim = initialWarrantyClaim;
	}

	public String getInitialWarrantyClaimSetByRefId() {
		return initialWarrantyClaimSetByRefId;
	}

	public void setInitialWarrantyClaimSetByRefId(
			String initialWarrantyClaimSetByRefId) {
		this.initialWarrantyClaimSetByRefId = initialWarrantyClaimSetByRefId;
	}

	public String getSalesDivRefId() {
		return salesDivRefId;
	}

	public void setSalesDivRefId(String salesDivRefId) {
		this.salesDivRefId = salesDivRefId;
	}

	public String getSalesOfficeRefId() {
		return salesOfficeRefId;
	}

	public void setSalesOfficeRefId(String salesOfficeRefId) {
		this.salesOfficeRefId = salesOfficeRefId;
	}

	public String getSalesOrgRefId() {
		return salesOrgRefId;
	}

	public void setSalesOrgRefId(String salesOrgRefId) {
		this.salesOrgRefId = salesOrgRefId;
	}

	public String getSalesGrpRefId() {
		return salesGrpRefId;
	}

	public void setSalesGrpRefId(String salesGrpRefId) {
		this.salesGrpRefId = salesGrpRefId;
	}

	public String getRegionId() {
		return regionId;
	}

	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	public Long getSubProcessId() {
		return subProcessId;
	}

	public void setSubProcessId(Long subProcessId) {
		this.subProcessId = subProcessId;
	}

	public Integer getServiceType() {
		return serviceType;
	}

	public void setServiceType(Integer serviceType) {
		this.serviceType = serviceType;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Date getClosedOn() {
		return closedOn;
	}

	public void setClosedOn(Date closedOn) {
		this.closedOn = closedOn;
	}

	public String getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}
	
	public Integer getSubWarrantyType() {
		return subWarrantyType;
	}

	/**
	 * @param subWarrantyType
	 *            the subWarrantyType to set 1: Paid; 2:Void;3-Product Warranty;
	 *            4:Repair Warranty; 5: CTS & contract
	 */
	public void setSubWarrantyType(Integer subWarrantyType) {
		this.subWarrantyType = subWarrantyType;
	}

	
	

}
