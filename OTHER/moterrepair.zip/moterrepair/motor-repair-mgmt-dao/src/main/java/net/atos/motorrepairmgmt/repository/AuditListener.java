/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import net.atos.motorrepairmgmt.entity.BasicEntity;
import net.atos.motorrepairmgmt.entity.RMTBasicEntity;

import org.springframework.beans.factory.annotation.Autowired;



/**
 * @author a545466
 *
 */
public class AuditListener {

	@Autowired
	private ClusterNodeRepository nodeRepo;
	
	/**
	 * @return the nodeId
	 */
	public String getNodeId() {
		AutowireHelper.autowire(this, nodeRepo);
		return this.nodeRepo.getNodeId();
	}

	/**
	 * This method is used to set Audit information in entity.
	 * 
	 * @param object
	 * 
	 */
	@PrePersist
	public void prePersist(final Object object) {
		if (object instanceof BasicEntity) {
			final BasicEntity basicEntity = (BasicEntity) object;	
			basicEntity.setNodeId(getNodeId());
			basicEntity.setModifiedOn(new Date());
			
		}
		else if (object instanceof RMTBasicEntity) {
			final RMTBasicEntity basicEntity = (RMTBasicEntity) object;			
			basicEntity.setNodeId(getNodeId());
			basicEntity.setModifiedOn(new Date());
			
		}

	}

	/**
	 * This method is used to set audit information in entity.
	 * 
	 * @param object
	 * 
	 */
	@PreUpdate
	public void preUpdate(final Object object) {
		if (object instanceof BasicEntity) {
			final BasicEntity basicEntity = (BasicEntity) object;	
			basicEntity.setNodeId(getNodeId());		
			basicEntity.setModifiedOn(new Date());
		}
		else if (object instanceof RMTBasicEntity) {
			final RMTBasicEntity basicEntity = (RMTBasicEntity) object;			
			basicEntity.setNodeId(getNodeId());
			basicEntity.setModifiedOn(new Date());
			
		}
	}

}