/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.BReportFields;
import net.atos.motorrepairmgmt.entity.CReportFields;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603327
 * 
 */
public interface BReportFieldsRepository extends JpaRepository<BReportFields, Long> {

	@Query("Select e.motorVoltageDetail from BReportFields e where e.bReportFieldId=:bReportFieldId")
	List<MotorVoltageDetail> findMotorVoltageDetailListByBReportField(@Param("bReportFieldId") Long bReportFieldId);

	@Query("Select e.motorSpeedDetailList from BReportFields e where e.bReportFieldId=:bReportFieldId")
	List<MotorSpeedDetail> findMotorSpeedDetailListByBReportField(@Param("bReportFieldId") Long bReportFieldId);

	@Query("Select e.motorNamePlateDetail from BReportFields e where e.bReportFieldId=:bReportFieldId")
	List<MotorNamePlateDetail> findMotorNamePlateDetailListByBReportField(@Param("bReportFieldId") Long bReportFieldId);

	@Query("select e from BReportFields e inner join e.subProcessFields subProcess where subProcess.wlfwSubProcessId = :wlfwSubProcessId")
	BReportFields findBReportFieldsBySubProcessId(@Param("wlfwSubProcessId") Long wlfwSubProcessId);

	@Query("Select brf.bReportFieldId,brf.approvalStatus,brf.statusUpdatedOn,brf.statusUpdatedByRefId from BReportFields brf where brf.subProcessFields.wlfwSubProcessId=:wlfwSubProcessId")
	Object[] findBReportFieldsApprovedStatusSubProcessID(@Param("wlfwSubProcessId") Long wlfwSubProcessId);
}