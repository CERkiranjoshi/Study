/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a593775 entity to store Motor Speed Detail
 *
 */
@Entity
@Table(name = "rmt_motor_speed_detail")
public class MotorSpeedDetail extends BasicEntity implements Serializable {

	private static final long serialVersionUID = 123236767531L;

	@Id
	@Column(name = "rmt_motor_speed_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorSpeedDetailId;

	@Column(name = "R_amp")
	private Float rAmp;

	@Column(name = "Y_amp")
	private Float yAmp;

	@Column(name = "B_amp")
	private Float bAmp;

	@Column(name = "rpm")
	private Integer rpm;

	@Column(name = "load_type")
	private Integer loadType;

	/**
	 * @return the motorSpeedDetailId
	 */
	public Long getMotorSpeedDetailId() {
		return motorSpeedDetailId;
	}

	/**
	 * @param motorSpeedDetailId
	 *            the motorSpeedDetailId to set
	 */
	public void setMotorSpeedDetailId(Long motorSpeedDetailId) {
		this.motorSpeedDetailId = motorSpeedDetailId;
	}

	/**
	 * @return the rAmp
	 */
	public Float getrAmp() {
		return rAmp;
	}

	/**
	 * @param rAmp
	 *            the rAmp to set
	 */
	public void setrAmp(Float rAmp) {
		this.rAmp = rAmp;
	}

	/**
	 * @return the yAmp
	 */
	public Float getyAmp() {
		return yAmp;
	}

	/**
	 * @param yAmp
	 *            the yAmp to set
	 */
	public void setyAmp(Float yAmp) {
		this.yAmp = yAmp;
	}

	/**
	 * @return the bAmp
	 */
	public Float getbAmp() {
		return bAmp;
	}

	/**
	 * @param bAmp
	 *            the bAmp to set
	 */
	public void setbAmp(Float bAmp) {
		this.bAmp = bAmp;
	}

	/**
	 * @return the rpm
	 */
	public Integer getRpm() {
		return rpm;
	}

	/**
	 * @param rpm
	 *            the rpm to set
	 */
	public void setRpm(Integer rpm) {
		this.rpm = rpm;
	}

	/**
	 * @return the loadType
	 */
	public Integer getLoadType() {
		return loadType;
	}

	/**
	 * @param loadType
	 *            the loadType to set 0: No Load; 1: Full Load
	 */
	public void setLoadType(Integer loadType) {
		this.loadType = loadType;
	}

}
