package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a610039
 * 
 */
@Entity
@Table(name = "rmt_motor_sales_detail")
public class MotorSalesDetail extends BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6407863939118313524L;

	@Id
	@Column(name = "motor_sales_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorSalesDetailId;

	@Column(name = "name",length=100)
	private String name;

	@Column(name = "code",length=50)
	private String code;

	@Column(name = "sales_type")
	private Integer salesType;

	@Column(name = "parent_id")
	private Long parentId;
	
	@Column(name = "region_id")
	private Long regionId;

	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;

	/**
	 * @return the motorSalesDetailId
	 */
	public Long getMotorSalesDetailId() {
		return motorSalesDetailId;
	}

	/**
	 * @param motorSalesDetailId
	 *            the motorSalesDetailId to set
	 */
	public void setMotorSalesDetailId(Long motorSalesDetailId) {
		this.motorSalesDetailId = motorSalesDetailId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the salesType
	 */
	public Integer getSalesType() {
		return salesType;
	}

	/**
	 * @param salesType
	 *            the salesType to set
	 */
	public void setSalesType(Integer salesType) {
		this.salesType = salesType;
	}

	/**
	 * @return the parentId
	 */
	public Long getParentId() {
		return parentId;
	}

	/**
	 * @param parentId
	 *            the parentId to set
	 */
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	
	/**
	 * @return the regionId
	 */
	public Long getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}
}
