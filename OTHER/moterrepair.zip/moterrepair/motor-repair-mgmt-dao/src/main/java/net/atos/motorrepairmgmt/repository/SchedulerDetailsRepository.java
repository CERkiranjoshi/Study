/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.SchedulerDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 * 
 */
public interface SchedulerDetailsRepository extends JpaRepository<SchedulerDetails, String> {

	@Query("SELECT sd from SchedulerDetails sd where sd.schedulerId =:schedulerDetailId AND sd.tenantId=:tenantId AND sd.solutionCategoryId=:solutionCategoryId")
	SchedulerDetails findSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(
			@Param("schedulerDetailId") String schedulerDetailId, @Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);

	@Query("SELECT sd from SchedulerDetails sd where sd.subprocessId =:subprocessId AND sd.tenantId=:tenantId AND sd.solutionCategoryId=:solutionCategoryId")
	List<SchedulerDetails> findSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId(
			@Param("subprocessId") Long subprocessId, @Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);

	@Query("SELECT sd from SchedulerDetails sd where sd.tenantId=:tenantId AND sd.solutionCategoryId=:solutionCategoryId")
	List<SchedulerDetails> findSchedulerDetailsByTenantIdAndSolCatId(@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);

	@Query("SELECT sd from SchedulerDetails sd where sd.hasExecuted=0 AND sd.postRestartRun=1 AND sd.tenantId=:tenantId AND sd.solutionCategoryId=:solutionCategoryId")
	List<SchedulerDetails> findPendingSchedulerDetailsByTenantIdAndSolCatId(@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
	
}
