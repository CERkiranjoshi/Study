/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.MotorAttachmentDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a603327
 *
 */
public interface MotorAttachmentDetailRepository extends JpaRepository<MotorAttachmentDetail, Long> {
	@Query("SELECT m from MotorAttachmentDetail m where m.motorAttachmentsId=:motorAttachmentsId AND m.tenantId=:tenantId AND m.solutionCategoryId=:solutionCategoryId  ")
	MotorAttachmentDetail findMotorAttachmentDetailByMotorAttachmentsIdAndTenantIdAndSolCatId(
			@Param("motorAttachmentsId") Long motorAttachmentsId,
			@Param("tenantId") String tenantId,
			@Param("solutionCategoryId") String solutionCategoryId);
	
	@Query("SELECT m from MotorAttachmentDetail m where m.attachmentUrl=:attachmentUrl")
	List<MotorAttachmentDetail> findAllMotorAttachmentDetailBasedOnFileName(@Param("attachmentUrl") String attachmentUrl);
}
