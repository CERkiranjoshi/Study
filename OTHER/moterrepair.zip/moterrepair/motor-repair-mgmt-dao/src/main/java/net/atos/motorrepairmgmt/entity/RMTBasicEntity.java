/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import net.atos.motorrepairmgmt.repository.AuditListener;

/**
 * @author a545466
 *
 */
@MappedSuperclass
@EntityListeners(value = { AuditListener.class })
public abstract class RMTBasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1884093700934281588L;


	@Column(name = "adt_task_code")
	private String functionCode;
	
	@Column(name = "subprocess_id",insertable=false,updatable=false)
	private Long wlfwSubProcessId;
	
	@Column(name = "master_workflow_id",insertable=false,updatable=false)
	private Long masterWorkflowFieldId;
	
	@Column(name = "adt_modified_on")
	private Date modifiedOn;

	@Column(name = "adt_modified_by_ref_id", length = 20)
	private String modifiedByRefId;

	@Column(name="node_id")
	private String nodeId;
	

	

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the wlfwSubProcessId
	 */
	public Long getWlfwSubProcessId() {
		return wlfwSubProcessId;
	}

	/**
	 * @param wlfwSubProcessId the wlfwSubProcessId to set
	 */
	public void setWlfwSubProcessId(Long wlfwSubProcessId) {
		this.wlfwSubProcessId = wlfwSubProcessId;
	}

	/**
	 * @return the masterWorkflowFieldId
	 */
	public Long getMasterWorkflowFieldId() {
		return masterWorkflowFieldId;
	}

	/**
	 * @param masterWorkflowFieldId the masterWorkflowFieldId to set
	 */
	public void setMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		this.masterWorkflowFieldId = masterWorkflowFieldId;
	}

	/**
	 * @return the nodeId
	 */
	public String getNodeId() {
		return nodeId;
	}

	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	
	
}
