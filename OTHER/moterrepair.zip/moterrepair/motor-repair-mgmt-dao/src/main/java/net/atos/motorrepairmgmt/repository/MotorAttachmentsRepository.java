/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

/**
 * @author Anand Ved
 * Class to handle direct jdbc query calls
 */
public interface MotorAttachmentsRepository {

	public Long getMotorAttachmentsCount(Long subprocessId, boolean externalAttachments, String solnCategoryId, String tenantId, String uploadedBy);
}
