/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.TemplateInfo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 *
 */
public interface TemplateInfoRepository extends JpaRepository<TemplateInfo, Long>{
	
	@Query("Select e from TemplateInfo e where e.functionCode=:functionCode and e.templateCode IN (:templateCode) and e.enabled=1")
    public List<TemplateInfo> getTemplateInfoByFunCodeNEmailCode(@Param("functionCode") String functionCode,@Param("templateCode") List<String> templateCode);

	@Query("Select e from TemplateInfo e where e.functionCode=:functionCode and e.enabled=1")
	public List<TemplateInfo> getTemplateInfoByFunctionCode(@Param("functionCode") String functionCode);

	@Query("Select e from TemplateInfo e where e.functionCode=:functionCode and e.notificationType=:notificationType and e.enabled=1")
	public List<TemplateInfo> getTemplateInfoByFunCodeNNotificationType(@Param("functionCode") String functionCode,@Param("notificationType") Integer notificationType);
}
