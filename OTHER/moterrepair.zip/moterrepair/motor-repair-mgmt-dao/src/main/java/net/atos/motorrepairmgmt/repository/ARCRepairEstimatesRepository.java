package net.atos.motorrepairmgmt.repository;

import net.atos.motorrepairmgmt.entity.ARCRepairEstimates;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author a610051
 * 
 */
public interface ARCRepairEstimatesRepository extends JpaRepository<ARCRepairEstimates, Long> {

}
