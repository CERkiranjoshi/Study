package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.CReportFields;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author a610051
 * 
 */
public interface CReportFieldsRepository extends JpaRepository<CReportFields, Long> {

	@Query("Select crf.motorVoltageDetail from CReportFields crf where crf.motorCReportFieldId=:motorCReportFieldId")
	MotorVoltageDetail findVoltageDetailByCReportId(@Param("motorCReportFieldId") Long motorCReportFieldId);

	@Query("Select crf.motorNamePlateDetail from CReportFields crf where crf.motorCReportFieldId=:motorCReportFieldId")
	MotorNamePlateDetail findNamePlateByCReportId(@Param("motorCReportFieldId") Long motorCReportFieldId);

	@Query("Select crf.motorSpeedDetail from CReportFields crf where crf.motorCReportFieldId=:motorCReportFieldId")
	List<MotorSpeedDetail> findSpeedDetailByCReportId(@Param("motorCReportFieldId") Long motorCReportFieldId);

	@Query("Select crf from CReportFields crf where crf.subProcessFields.wlfwSubProcessId=:wlfwSubProcessId")
	CReportFields findCReportFieldsBySubProcessID(@Param("wlfwSubProcessId") Long wlfwSubProcessId);
	
	@Query("Select crf.motorCReportFieldId,crf.approvalStatus,crf.statusUpdatedOn,crf.statusUpdatedByRefId from CReportFields crf where crf.subProcessFields.wlfwSubProcessId=:wlfwSubProcessId")
	Object[] findCReportFieldsApprovedStatusSubProcessID(@Param("wlfwSubProcessId") Long wlfwSubProcessId);
}
