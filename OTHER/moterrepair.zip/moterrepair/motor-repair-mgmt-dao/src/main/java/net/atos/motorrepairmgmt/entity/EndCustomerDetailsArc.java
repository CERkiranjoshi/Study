package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rmt_end_customer_detail")
public class EndCustomerDetailsArc  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6588396478132570029L;

	@Id
	@Column(name = "customer_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "customer_contact_name")
	private String customerContactName;

	@Column(name = "cust_contact_num")
	private String custContactNum;

	@Column(name = "office_contact_num")
	private String officeContactNum;

	@Column(name = "cust_email_id")
	private String custEmailId;

	@Column(name = "cust_type")
	private String custType;

	@Column(name = "gsp_ref_code")
	private String gspRefCode;

	@Column(name = "spiridon_ref_code")
	private String spiridonRefCode;

	@Column(name = "notification_type")
	private Integer notificationType;

	@Column(name = "customer_address")
	private String customerAddress;

	@Column(name = "shipping_to_address")
	private String shipingToAddress;

	@Column(name = "is_ship_to_party")
	private Integer isShipToParty;

	@Column(name = "is_sold_to_party")
	private Integer isSoldToParty;

	@Column(name = "country_code", length = 10)
	private String countyCode;

	// for storing partner type for channel partner ,like OEM ,etc
	
	
	@Column(name = "partner_type")
	private Integer partnerType;
	
	@Column(name = "solution_category_id")
	private Integer solutionCategoryId;
	

	@Column(name = "tenant_id")
	private Integer tenantId;
	

	@Column(name = "created_by")
	private String createdBy;
	
	public Integer getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(Integer solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	




	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCustomerContactName() {
		return customerContactName;
	}

	public void setCustomerContactName(String customerContactName) {
		this.customerContactName = customerContactName;
	}

	public String getCustContactNum() {
		return custContactNum;
	}

	public void setCustContactNum(String custContactNum) {
		this.custContactNum = custContactNum;
	}

	public String getOfficeContactNum() {
		return officeContactNum;
	}

	public void setOfficeContactNum(String officeContactNum) {
		this.officeContactNum = officeContactNum;
	}

	public String getCustEmailId() {
		return custEmailId;
	}

	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getGspRefCode() {
		return gspRefCode;
	}

	public void setGspRefCode(String gspRefCode) {
		this.gspRefCode = gspRefCode;
	}

	public String getSpiridonRefCode() {
		return spiridonRefCode;
	}

	public void setSpiridonRefCode(String spiridonRefCode) {
		this.spiridonRefCode = spiridonRefCode;
	}

	public Integer getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getShipingToAddress() {
		return shipingToAddress;
	}

	public void setShipingToAddress(String shipingToAddress) {
		this.shipingToAddress = shipingToAddress;
	}

	public Integer getIsShipToParty() {
		return isShipToParty;
	}

	public void setIsShipToParty(Integer isShipToParty) {
		this.isShipToParty = isShipToParty;
	}

	public Integer getIsSoldToParty() {
		return isSoldToParty;
	}

	public void setIsSoldToParty(Integer isSoldToParty) {
		this.isSoldToParty = isSoldToParty;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public Integer getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(Integer partnerType) {
		this.partnerType = partnerType;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}


	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
