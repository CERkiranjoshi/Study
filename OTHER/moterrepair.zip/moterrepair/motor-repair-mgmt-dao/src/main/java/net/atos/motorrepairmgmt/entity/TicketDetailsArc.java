package net.atos.motorrepairmgmt.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "rmt_ticket_details")
public class TicketDetailsArc {

	@Id
	@Column(name = "ticket_details_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ticketdetailsId;

	@Column(name = "arc_jobRef_nmuber")
	private String arcJobRefNmuber;
	
	@Column(name = "internal_comments")
	private String internalComments;
	
	@Column(name = "tenant_id")
	private String tenantId;

	@Column(name = "solution_category_id")
	private String solutionCategoryId;

	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "reference_id")
	private Long refId;
	
	@Column(name = "ticket_status")
	private Integer ticketStatus; 
	
	@Column(name = "created_on")
	private Date createdOn;  // createdOn
	
	@Column(name = "modified_on")
	private Date modifiedOn;  // modifiedOn
	
	@Column(name = "modified_by")
	private String modifiedBy;  // modifiedOn
	
	// ARC
	@Column(name = "submitted_by")
	private String submittedBy; // submittedBy
	
	@Column(name = "submitted_on")
	private Date submittedOn; // submittedOn
	
	// CCC
	@Column(name = "ticket_created_by")
	private String ticketCreatedBy; // ticketCreatedBy
	
	@Column(name = "ticket_created_on")
	private Date ticketCreatedOn; // ticketCreatedOn
	
	@Column(name = "gsp_ticket_referencenum")
	private Integer gspTicketReferenceNum ;// gspTicketReferenceNum

	@Column(name = "claim_reference_id")
	private String claimRefId ;// claimReferenceId

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "motor_order_detail_id")
	private MotorDetailsArc motorDetailsArc;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private EndCustomerDetailsArc endCustomerDetailsArc;

	public Long getTicketdetailsId() {
		return ticketdetailsId;
	}

	public void setTicketdetailsId(Long ticketdetailsId) {
		this.ticketdetailsId = ticketdetailsId;
	}

	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public String getArcJobRefNmuber() {
		return arcJobRefNmuber;
	}

	public void setArcJobRefNmuber(String arcJobRefNmuber) {
		this.arcJobRefNmuber = arcJobRefNmuber;
	}

	public String getInternalComments() {
		return internalComments;
	}

	public void setInternalComments(String internalComments) {
		this.internalComments = internalComments;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the motorDetailsArc
	 */
	public MotorDetailsArc getMotorDetailsArc() {
		return motorDetailsArc;
	}

	/**
	 * @param motorDetailsArc
	 *            the motorDetailsArc to set
	 */
	public void setMotorDetailsArc(MotorDetailsArc motorDetailsArc) {
		this.motorDetailsArc = motorDetailsArc;
	}

	/**
	 * @return the endCustomerDetailsArc
	 */
	public EndCustomerDetailsArc getEndCustomerDetailsArc() {
		return endCustomerDetailsArc;
	}

	/**
	 * @param endCustomerDetailsArc
	 *            the endCustomerDetailsArc to set
	 */
	public void setEndCustomerDetailsArc(EndCustomerDetailsArc endCustomerDetailsArc) {
		this.endCustomerDetailsArc = endCustomerDetailsArc;
	}

	public Integer getTicketStatus() {
		return ticketStatus;
	}
	// 0 - ARC is creating Motor Details; 1 - ARC has submitted the Details; CCC is able to view it;
	// 2 - CCC user has claimed this Motor for initiation of Workflow ,3 - CCC user has initiated workflows,
	// 4 - Workflow has been created
	public void setTicketStatus(Integer ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getRefId() {
		return refId;
	}

	public void setRefId(Long refId) {
		this.refId = refId;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getSubmittedBy() {
		return submittedBy;
	}

	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	public Date getSubmittedOn() {
		return submittedOn;
	}

	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}

	public String getTicketCreatedBy() {
		return ticketCreatedBy;
	}

	public void setTicketCreatedBy(String ticketCreatedBy) {
		this.ticketCreatedBy = ticketCreatedBy;
	}

	public Date getTicketCreatedOn() {
		return ticketCreatedOn;
	}

	public void setTicketCreatedOn(Date ticketCreatedOn) {
		this.ticketCreatedOn = ticketCreatedOn;
	}

	public Integer getGspTicketReferenceNum() {
		return gspTicketReferenceNum;
	}

	public void setGspTicketReferenceNum(Integer gspTicketReferenceNum) {
		this.gspTicketReferenceNum = gspTicketReferenceNum;
	}

	/**
	 * @return the claimRefId
	 */
	public String getClaimRefId() {
		return claimRefId;
	}

	/**
	 * @param claimRefId the claimRefId to set
	 */
	public void setClaimRefId(String claimRefId) {
		this.claimRefId = claimRefId;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
}
