package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author a593775
 *
 */
// removed as of now
// @Entity(name="rmt_motor_insp_report_fields")
public class InspReportFields implements Serializable {

	private static final long serialVersionUID = 1345873458998L;

	@Id
	@Column(name = "motor_insp_report_id")
	private String motorInspReportId;

	@Column(name = "arc_job_ref_no")
	private String arcJobRefNo;

	@Column(name = "created_on")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;

	@Column(name = "frame_size")
	private Integer frameSize;

	@Column(name = "motor_type")
	private String motorType;

	@Column(name = "machine_no")
	private String machineNo;

	@Column(name = "hz")
	private String hz;

	@Column(name = "volts")
	private float volts;

	@Column(name = "amp")
	private float amp;

	@Column(name = "rpm")
	private float rpm;

	@Column(name = "kw_per_hp")
	private float kwPerHp;

	@Column(name = "ins_class")
	private String insClass;

	@Column(name = "duty")
	private String duty;

	@Column(name = "mfg_Date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date mfgDate;

	@Column(name = "notifcation_no")
	private String notificationNo;

	@Column(name = "job_ref_no")
	private String jobRefNo;

	public String getMotorInspReportId() {
		return motorInspReportId;
	}

	public void setMotorInspReportId(String motorInspReportId) {
		this.motorInspReportId = motorInspReportId;
	}

	public String getArcJobRefNo() {
		return arcJobRefNo;
	}

	public void setArcJobRefNo(String arcJobRefNo) {
		this.arcJobRefNo = arcJobRefNo;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getFrameSize() {
		return frameSize;
	}

	public void setFrameSize(Integer frameSize) {
		this.frameSize = frameSize;
	}

	public String getMotorType() {
		return motorType;
	}

	public void setMotorType(String motorType) {
		this.motorType = motorType;
	}

	public String getMachineNo() {
		return machineNo;
	}

	public void setMachineNo(String machineNo) {
		this.machineNo = machineNo;
	}

	public String getHz() {
		return hz;
	}

	public void setHz(String hz) {
		this.hz = hz;
	}

	public float getVolts() {
		return volts;
	}

	public void setVolts(float volts) {
		this.volts = volts;
	}

	public float getAmp() {
		return amp;
	}

	public void setAmp(float amp) {
		this.amp = amp;
	}

	public float getRpm() {
		return rpm;
	}

	public void setRpm(float rpm) {
		this.rpm = rpm;
	}

	public float getKwPerHp() {
		return kwPerHp;
	}

	public void setKwPerHp(float kwPerHp) {
		this.kwPerHp = kwPerHp;
	}

	public String getInsClass() {
		return insClass;
	}

	public void setInsClass(String insClass) {
		this.insClass = insClass;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	public Date getMfgDate() {
		return mfgDate;
	}

	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

}
