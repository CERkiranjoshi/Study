/**
 * 
 */
package net.atos.motorrepairmgmt.repository;

import java.util.List;

import net.atos.motorrepairmgmt.entity.SparesMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 *
 */
public interface SparesMasterRepository extends JpaRepository<SparesMaster, Long> {

	@Query("select sm from SparesMaster sm where  sm.tenantId=:tenantId and sm.solutionCategoryId=:solutionCategoryId")
	List<SparesMaster> findSparesByTenantIdNSolutionCategory(
			@Param("tenantId") String tenantId, @Param("solutionCategoryId") String solnCategory);
}
