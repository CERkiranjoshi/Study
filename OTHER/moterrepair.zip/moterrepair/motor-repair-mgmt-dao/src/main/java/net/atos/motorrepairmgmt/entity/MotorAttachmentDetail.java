/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a593775
 * 
 */
@Entity
@Table(name = "rmt_motor_attachments")
public class MotorAttachmentDetail extends BasicEntity implements Serializable {

	private static final long serialVersionUID = 1344551212L;

	@Id
	@Column(name = "motor_attachments_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long motorAttachmentsId;

	@Column(name = "file_name", length = 100)
	private String fileName;

	@Column(name = "file_size")
	private float fileSize;

	@Column(name = "dms_ref_id", length = 20)
	private String dmsRefId;

	@Column(name = "attachment_url", length = 100)
	private String attachmentUrl;

	@Column(name = "attachment_type")
	private Integer attachmentType;

	@Column(name = "base_folder", length = 100)
	private String baseFolder;

	@Column(name = "is_deleted")
	private Integer isDeleted;

	@Column(name = "uploaded_on")
	private Date uploadedOn;

	@Column(name = "uploaded_by", length = 20)
	private String uploadedBy;

	@Column(name = "deleted_by", length = 20)
	private String deletedBy;

	@Column(name = "deleted_on")
	private Date deletedOn;

	@Column(name = "description", length = 100)
	private String description;

	@Column(name = "is_Internal")
	private Integer isInternal;
	
	@Column(name = "tenant_id",length=50)
	private String tenantId;

	@Column(name = "solution_category_id",length=25)
	private String solutionCategoryId;
	
	

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the motorAttachmentsId
	 */
	public Long getMotorAttachmentsId() {
		return motorAttachmentsId;
	}

	/**
	 * @param motorAttachmentsId
	 *            the motorAttachmentsId to set
	 */
	public void setMotorAttachmentsId(Long motorAttachmentsId) {
		this.motorAttachmentsId = motorAttachmentsId;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the fileSize
	 */
	public float getFileSize() {
		return fileSize;
	}

	/**
	 * @param fileSize
	 *            the fileSize to set
	 */
	public void setFileSize(float fileSize) {
		this.fileSize = fileSize;
	}

	/**
	 * @return the dmsRefId
	 */
	public String getDmsRefId() {
		return dmsRefId;
	}

	/**
	 * @param dmsRefId
	 *            the dmsRefId to set
	 */
	public void setDmsRefId(String dmsRefId) {
		this.dmsRefId = dmsRefId;
	}

	/**
	 * @return the attachmentUrl
	 */
	public String getAttachmentUrl() {
		return attachmentUrl;
	}

	/**
	 * @param attachmentUrl
	 *            the attachmentUrl to set
	 */
	public void setAttachmentUrl(String attachmentUrl) {
		this.attachmentUrl = attachmentUrl;
	}

	/**
	 * @return the attachmentType
	 */
	public Integer getAttachmentType() {
		return attachmentType;
	}

	/**
	 * @param attachmentType
	 *            the attachmentType to set 0: Others; 1: A Report Attachments;
	 *            2: B Report Attachments;
	 */
	public void setAttachmentType(Integer attachmentType) {
		this.attachmentType = attachmentType;
	}

	/**
	 * @return the baseFolder
	 */
	public String getBaseFolder() {
		return baseFolder;
	}

	/**
	 * @param baseFolder
	 *            the baseFolder to set
	 */
	public void setBaseFolder(String baseFolder) {
		this.baseFolder = baseFolder;
	}

	/**
	 * @return the isDeleted
	 */
	public Integer getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted
	 *            the isDeleted to set
	 */
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the uploadedOn
	 */
	public Date getUploadedOn() {
		return uploadedOn;
	}

	/**
	 * @param uploadedOn
	 *            the uploadedOn to set
	 */
	public void setUploadedOn(Date uploadedOn) {
		this.uploadedOn = uploadedOn;
	}

	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return uploadedBy;
	}

	/**
	 * @param uploadedBy
	 *            the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	/**
	 * @return the deletedBy
	 */
	public String getDeletedBy() {
		return deletedBy;
	}

	/**
	 * @param deletedBy
	 *            the deletedBy to set
	 */
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}

	/**
	 * @return the deletedOn
	 */
	public Date getDeletedOn() {
		return deletedOn;
	}

	/**
	 * @param deletedOn
	 *            the deletedOn to set
	 */
	public void setDeletedOn(Date deletedOn) {
		this.deletedOn = deletedOn;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the isInternal
	 */
	public Integer getIsInternal() {
		return isInternal;
	}

	/**
	 * @param isInternal
	 *            the isInternal to set
	 */
	public void setIsInternal(Integer isInternal) {
		this.isInternal = isInternal;
	}

}
