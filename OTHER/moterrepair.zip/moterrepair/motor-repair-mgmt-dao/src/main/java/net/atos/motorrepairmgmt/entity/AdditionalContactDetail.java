/**
 * 
 */
package net.atos.motorrepairmgmt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author a593775 entity to store additional contact list for notification
 */
@Entity
@Table(name = "rmt_additional_contact_detail")
public class AdditionalContactDetail extends BasicEntity implements Serializable {

	private static final long serialVersionUID = -6984089407163545828L;

	@Id
	@Column(name = "additional_contact_detail_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long additionalContactDetailId;

	@Column(name = "email_address", length = 40)
	private String emailAddress;

	@Column(name = "mobile_no", length = 20)
	private String mobileNo;
	
	@Column(name="country_code",length=10)
	private String countyCode;
	
	@Column(name = "notification_type")
	private Integer notificationType;
	
	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}
	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * @return the additionalContactDetailId
	 */
	public Long getAdditionalContactDetailId() {
		return additionalContactDetailId;
	}

	/**
	 * @param additionalContactDetailId
	 *            the additionalContactDetailId to set
	 */
	public void setAdditionalContactDetailId(Long additionalContactDetailId) {
		this.additionalContactDetailId = additionalContactDetailId;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo
	 *            the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

}
