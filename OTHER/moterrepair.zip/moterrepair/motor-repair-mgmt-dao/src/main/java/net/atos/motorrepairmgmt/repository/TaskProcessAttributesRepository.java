/**
 * 
 */
package net.atos.motorrepairmgmt.repository;


import net.atos.motorrepairmgmt.entity.TaskProcessAttributes;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * @author Sweety Kothari
 *
 */
public interface TaskProcessAttributesRepository extends JpaRepository<TaskProcessAttributes, Long>{

	@Query("select tpd from TaskProcessAttributes tpd where tpd.activitiTaskId=:activitiTaskId")
	public TaskProcessAttributes getTaskParameterDetailsByActivitiTaskId(@Param("activitiTaskId") String taskId);
}
