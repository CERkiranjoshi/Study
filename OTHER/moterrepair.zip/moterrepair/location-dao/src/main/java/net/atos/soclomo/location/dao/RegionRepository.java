package net.atos.soclomo.location.dao;

import java.util.List;

import net.atos.soclomo.location.dao.entity.Region;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface RegionRepository extends JpaRepository<Region, String>{

	
	@Query("select r from Region r")
	List<Region> getAllRegions();

	Region findByRegionCode(String regionCode);
	
	
}