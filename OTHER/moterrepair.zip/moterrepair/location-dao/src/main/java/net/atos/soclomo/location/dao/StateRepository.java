package net.atos.soclomo.location.dao;

import java.util.List;

import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.entity.State;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface StateRepository extends JpaRepository<State, String>{

	
	@Query("select s from State s")
	List<State> getAllStates();

	State findByStateCode(String stateCode);

	
}