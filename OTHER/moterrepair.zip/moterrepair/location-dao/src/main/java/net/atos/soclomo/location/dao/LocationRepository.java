package net.atos.soclomo.location.dao;

import java.util.List;

import net.atos.soclomo.location.dao.entity.Location;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface LocationRepository extends JpaRepository<Location, Long>{

	@Query("Select e from Location e")
	List<Location> getAllLocation();
	
	Location findByLocCode(String locationCode);

	List<Location> findAllByLocSubtype(String locSubtype);

	//Location findByBranchCode(String branchCode);	
}
