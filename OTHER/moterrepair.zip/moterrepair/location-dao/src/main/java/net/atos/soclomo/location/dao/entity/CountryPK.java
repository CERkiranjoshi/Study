package net.atos.soclomo.location.dao.entity;

import java.io.Serializable;
import javax.persistence.*;

@Embeddable
public class CountryPK implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//default serial version id, required for serializable classes.

	@Column(name="tenant_id")
	private String tenantId;

	@Column(name="country_code")
	private String countryCode;

	public CountryPK() {
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}
	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CountryPK)) {
			return false;
		}
		CountryPK castOther = (CountryPK)other;
		return 
			this.tenantId.equals(castOther.tenantId)
			&& this.countryCode.equals(castOther.countryCode);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.tenantId.hashCode();
		hash = hash * prime + this.countryCode.hashCode();
		
		return hash;
	}
}