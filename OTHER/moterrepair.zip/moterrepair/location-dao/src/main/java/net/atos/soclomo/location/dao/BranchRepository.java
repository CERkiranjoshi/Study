package net.atos.soclomo.location.dao;

import java.util.Collection;
import java.util.List;

import net.atos.soclomo.location.dao.entity.Branch;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BranchRepository extends JpaRepository<Branch, String>{
	
	@Query("select b from Branch b")
	List<Branch> getAllBranches();
	List<Branch> findAllBranchesByLongitudeIsNotNullAndLatitudeIsNotNullAndBranchTypeIn(Collection<String> branchType);
	Branch findByBranchCode(String branchCode);
}
