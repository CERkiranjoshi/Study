package net.atos.soclomo.location.dao;

import java.util.List;

import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.CountryPK;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface CountryRepository extends JpaRepository<Country, CountryPK>{
	
	@Query(value="select c from Country c")
	List<Country> getAllCountries();
	
	
	@Query(value="select c from Country c" , countQuery="select count(c) from Country c")
	List<Country> getAllCountries(Pageable pageable);


	Country findById(CountryPK countrypk);
	
	
	
}
