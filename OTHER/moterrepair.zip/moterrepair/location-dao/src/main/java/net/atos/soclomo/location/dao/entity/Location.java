package net.atos.soclomo.location.dao.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="location")
public class Location implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	private String active;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Date createdDate;

	@Column(name="loc_code")
	private String locCode;

	@Column(name="loc_name")
	private String locName;

	@Column(name="loc_subtype")
	private String locSubtype;

	@Column(name="loc_type")
	private String locType;
	
	@Column(name="loc_code_cust")
	private String locCodeCust;
	
	@Column(name="loc_info1")
	private String locInfo1;

	@Column(name="loc_info2")
	private String locInfo2;

	@Column(name="loc_info3")
	private String locInfo3;

	@Column(name="loc_info4")
	private String locInfo4;

	@Column(name="modified_by")
	private String modifiedBy;
	
	private String address1;

	private String address2;

	private String address3;
	
	private Double longitude;
	
	private Double latitude;

	@Column(name="modified_date")
	private Date modifiedDate;
	
	//bi-directional many-to-one association to Branch
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="branch_code",referencedColumnName="branch_code")
	private Branch branch;

	public Location() {
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the active
	 */
	public String getActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the locCode
	 */
	public String getLocCode() {
		return locCode;
	}

	/**
	 * @param locCode the locCode to set
	 */
	public void setLocCode(String locCode) {
		this.locCode = locCode;
	}

	/**
	 * @return the locName
	 */
	public String getLocName() {
		return locName;
	}

	/**
	 * @param locName the locName to set
	 */
	public void setLocName(String locName) {
		this.locName = locName;
	}

	/**
	 * @return the locSubtype
	 */
	public String getLocSubtype() {
		return locSubtype;
	}

	/**
	 * @param locSubtype the locSubtype to set
	 */
	public void setLocSubtype(String locSubtype) {
		this.locSubtype = locSubtype;
	}

	/**
	 * @return the locType
	 */
	public String getLocType() {
		return locType;
	}

	/**
	 * @param locType the locType to set
	 */
	public void setLocType(String locType) {
		this.locType = locType;
	}

	/**
	 * @return the locCodeCust
	 */
	public String getLocCodeCust() {
		return locCodeCust;
	}

	/**
	 * @param locCodeCust the locCodeCust to set
	 */
	public void setLocCodeCust(String locCodeCust) {
		this.locCodeCust = locCodeCust;
	}

	/**
	 * @return the locInfo1
	 */
	public String getLocInfo1() {
		return locInfo1;
	}

	/**
	 * @param locInfo1 the locInfo1 to set
	 */
	public void setLocInfo1(String locInfo1) {
		this.locInfo1 = locInfo1;
	}

	/**
	 * @return the locInfo2
	 */
	public String getLocInfo2() {
		return locInfo2;
	}

	/**
	 * @param locInfo2 the locInfo2 to set
	 */
	public void setLocInfo2(String locInfo2) {
		this.locInfo2 = locInfo2;
	}

	/**
	 * @return the locInfo3
	 */
	public String getLocInfo3() {
		return locInfo3;
	}

	/**
	 * @param locInfo3 the locInfo3 to set
	 */
	public void setLocInfo3(String locInfo3) {
		this.locInfo3 = locInfo3;
	}

	/**
	 * @return the locInfo4
	 */
	public String getLocInfo4() {
		return locInfo4;
	}

	/**
	 * @param locInfo4 the locInfo4 to set
	 */
	public void setLocInfo4(String locInfo4) {
		this.locInfo4 = locInfo4;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * @param address3 the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * @return the longitude
	 */
	public Double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the latitude
	 */
	public Double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the branch
	 */
	public Branch getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	
}