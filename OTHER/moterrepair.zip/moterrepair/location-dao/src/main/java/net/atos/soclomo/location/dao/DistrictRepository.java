package net.atos.soclomo.location.dao;

import java.util.List;

import net.atos.soclomo.location.dao.entity.District;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface DistrictRepository extends JpaRepository<District, String>{

	
	@Query("select d from District d")
	List<District> getAllDistricts();

	
	District findByDistrictCode(String districtCode);
	
}