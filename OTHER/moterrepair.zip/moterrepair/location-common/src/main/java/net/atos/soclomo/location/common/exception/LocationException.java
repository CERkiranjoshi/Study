package net.atos.soclomo.location.common.exception;

public class LocationException extends Exception {

	/**
	 *  Serial Version Id
	 */
	private static final long serialVersionUID = 1L;

	public LocationException() {
		super();
	}
	
	public LocationException(final String causeMessage){
		super(causeMessage);
	}
	
	public LocationException( Throwable e) {
		super(e);
	}
	
	public LocationException(final String causeMessage, Throwable e) {
		super(causeMessage,e);
	}
}
