package net.atos.soclomo.location.common.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class PropertiesUtil extends PropertyPlaceholderConfigurer{

	 /** The properties map. */
    private static Map<String, String> propertiesMap;

    /**
     * This method return property value
     * 
     * @param name
     *            the name
     * @return the property
     */
    public static String getProperty(final String name) {
        return propertiesMap.get(name);
    }

    /**
     * This method is responsible for loading properties file from context.
     * 
     * @param beanFactory
     * @param props
     * @throws BeansException
     */
    @Override
    public void processProperties(final ConfigurableListableBeanFactory beanFactory, final Properties props)
        throws BeansException {
        super.processProperties(beanFactory, props);
        propertiesMap = new HashMap<String, String>();
        for (final Object key : props.keySet()) {
            final String keyStr = key.toString();
            propertiesMap.put(keyStr, props.getProperty(keyStr));
        }

    }
}
