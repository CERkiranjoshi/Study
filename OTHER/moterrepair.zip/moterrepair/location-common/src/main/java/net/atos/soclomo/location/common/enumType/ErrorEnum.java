/**
 * 
 */
package net.atos.soclomo.location.common.enumType;

/**
 * This enum is used to handle the error code and error message
 * 
 * @author A569702
 * 
 */
public enum ErrorEnum {

	_30001("30001", "The branch code should not null"), _20002("20002",
			"JsonProcessingException occured"), _20003("20003",
			"UnsupportedEncodingException occured"), _20004("20004",
			"MqttException occured in sender."),_20005("20005",
					"MqttException occured in listener."), _20015("20015",
			"No values informed!"), _20016("20016", "Folder is not created"), _20017(
			"20017",
			"doFilter() called on a request or response that was not an HttpServletRequest or response."), _20018(
			"20018", "Authenication Filter protects only HTTP resources");

	private final String errorCode;
	private final String errorDescription;

	/**
	 * Constructor for enum
	 * 
	 * @param errorCode
	 * @param errorDescription
	 */
	private ErrorEnum(String errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	/**
	 * Get the errorCode
	 * 
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Get the errorDescription
	 * 
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	@Override
	public String toString() {
		return errorCode + ": " + errorDescription;
	}
}
