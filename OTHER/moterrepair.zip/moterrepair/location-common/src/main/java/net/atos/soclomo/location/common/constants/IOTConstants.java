package net.atos.soclomo.location.common.constants;

public  class IOTConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
}
