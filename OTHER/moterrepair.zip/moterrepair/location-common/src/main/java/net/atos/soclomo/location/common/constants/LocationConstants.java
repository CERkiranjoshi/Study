package net.atos.soclomo.location.common.constants;

public class LocationConstants {

	public static final String SUCCESS = "SUCCESS";
	public static final String N = "N";
}
