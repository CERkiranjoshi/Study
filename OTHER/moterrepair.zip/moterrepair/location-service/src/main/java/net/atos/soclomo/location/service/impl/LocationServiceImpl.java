package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.BranchDTO;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.DistrictDTO;
import net.atos.soclomo.location.common.dto.LocationDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.BranchRepository;
import net.atos.soclomo.location.dao.LocationRepository;
import net.atos.soclomo.location.dao.entity.Branch;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.District;
import net.atos.soclomo.location.dao.entity.Location;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.dao.entity.State;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.LocationService;

@Component("locationServiceImpl")
public class LocationServiceImpl implements LocationService {
	
	private static final Logger LOGGER=Logger.getLogger(LocationServiceImpl.class);

	@Autowired
	LocationRepository locationRepository;
	
	@Autowired 
	BranchRepository branchRepository;
	
	@Autowired
	LocationMapper mapper;
	
	@Autowired
	Mapper dMapper;

	@Override
	public List<LocationDTO> getAllLocation() {
		List<Location> locations = null;
		List<LocationDTO> locationDtos = null;
		
		try {
			locations=locationRepository.findAll();
			if(locations!=null && !locations.isEmpty()) {
				locationDtos=new ArrayList<LocationDTO>();
				for(Location location:locations) {
					LocationDTO  locationDTO=dMapper.map(location, LocationDTO.class);
					
					Branch branch=location.getBranch();
					BranchDTO branchDTO=dMapper.map(branch, BranchDTO.class);
					
					District district=branch.getDistrict();
					DistrictDTO districtDTO = dMapper.map(district, DistrictDTO.class);
					
					State state=district.getState();
					StateDTO stateDTO=dMapper.map(state, StateDTO.class);
					
					Region region=state.getRegion();
					RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
					Country country=region.getCountry();
					CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
					countryDTO.setTenantId(country.getId().getTenantId());
					
					countryDTO.setCountryCode(country.getId().getCountryCode());
					regionDTO.setCountry(countryDTO);
					stateDTO.setRegion(regionDTO);
					districtDTO.setState(stateDTO);
					branchDTO.setDistrict(districtDTO);
					
					locationDTO.setBranch(branchDTO);
					
					locationDtos.add(locationDTO);
				}
				return locationDtos;
			}
		}
		catch(Exception e) {
			LOGGER.info(e);
		}

		return locationDtos;	
	}
	
	@Override
	public String saveLocation(LocationDTO locationDTO) {
		Location location=null;
		Branch branch=null;
		try {
			System.out.println("Enter into saveLocation(-) "+locationDTO);
			
			location=locationRepository.findByLocCode(locationDTO.getLocCode());
			if(null==location) {
				System.out.println("No location exist - "+location);
				location=dMapper.map(locationDTO, Location.class);
				location.setCreatedDate(new Date());
				location.setModifiedDate(new Date());
				String id=locationDTO.getBranch().getBranchCode();
				System.out.println(" Id----------------- "+id);
				branch=branchRepository.findByBranchCode(id);
				System.out.println("Parent table Branch Code - "+branch.getBranchCode());
				location.setBranch(branch);
				
				location=locationRepository.save(location);
				System.out.println("Sucess to save - "+location);
			} else {
				System.out.println("location exist - "+location);
				location.setActive(locationDTO.getActive());
				location.setLocCode(locationDTO.getLocCode());
				location.setLocCodeCust(locationDTO.getLocCodeCust());
				location.setLocName(locationDTO.getLocName());
				location.setLocType(locationDTO.getLocType());
				location.setLocSubtype(locationDTO.getLocSubType());
				location.setLocInfo1(locationDTO.getLocInfo1());
				location.setLocInfo2(locationDTO.getLocInfo2());
				location.setLocInfo3(locationDTO.getLocInfo3());
				location.setLocInfo4(locationDTO.getLocInfo4());
				location.setModifiedBy(locationDTO.getModifiedBy());
				location.setModifiedDate(new Date());
				location.setAddress1(locationDTO.getAddress1());
				location.setAddress2(locationDTO.getAddress2());
				location.setAddress3(locationDTO.getAddress3());
				location.setLatitude(locationDTO.getLatitude());
				location.setLongitude(locationDTO.getLongitude());
				String id=locationDTO.getBranch().getBranchCode();
				branch=branchRepository.findByBranchCode(id);
				System.out.println("Parent branch code - "+branch.getBranchCode());
				
				location.setBranch(branch);
				
				location=locationRepository.save(location);
				System.out.println("Updated Location - "+location);
			}
			
			if(null == location){
			
				return FAILURE;
			}
			
					
		}
		catch(Exception e) {
			LOGGER.info(e);
		}
	
		return SUCCESS;
	}

	@Override
	public String deleteLocation(LocationDTO locationDto) {
		Location location=locationRepository.findByLocCode(locationDto.getLocCode());
		if(location!=null) {
			location.setActive(LocationConstants.N);
			locationRepository.save(location);
			
			return SUCCESS;
		}

		return FAILURE;
	}

	@Override
	public List<LocationDTO> getAllLocationByLocSubtype(String locSubtype) {
		List<Location> alLocations=null;
		List<LocationDTO> alLocationDTOs=null;
		if(StringUtils.isNotBlank(locSubtype)) {
			alLocations=locationRepository.findAllByLocSubtype(locSubtype);
			if(null!=alLocations && !alLocations.isEmpty()) {
				alLocationDTOs=new ArrayList<LocationDTO>();
				for(Location location : alLocations) {
					alLocationDTOs.add(dMapper.map(location, LocationDTO.class));
				}
			}
		}
		return alLocationDTOs;
	}

	@Override
	public LocationDTO getLocationByLocCode(String locCode) {
		LocationDTO locationDTO=null;
		if(StringUtils.isNotBlank(locCode)) {
			Location location=locationRepository.findByLocCode(locCode);
			
			if(null!=location) {
				locationDTO=dMapper.map(location, LocationDTO.class);
				
				Branch branch=location.getBranch();
				BranchDTO branchDTO=dMapper.map(branch, BranchDTO.class);
				
				District district=branch.getDistrict();
				DistrictDTO districtDTO = dMapper.map(district, DistrictDTO.class);
				
				State state=district.getState();
				StateDTO stateDTO=dMapper.map(state, StateDTO.class);
				
				Region region=state.getRegion();
				RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
				Country country=region.getCountry();
				CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());
				
				countryDTO.setCountryCode(country.getId().getCountryCode());
				regionDTO.setCountry(countryDTO);
				stateDTO.setRegion(regionDTO);
				districtDTO.setState(stateDTO);
				branchDTO.setDistrict(districtDTO);
				
				locationDTO.setBranch(branchDTO);
			}
		}
		return locationDTO;
	}
	
}
