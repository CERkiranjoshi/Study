package net.atos.soclomo.location.service;

import java.util.List;

import net.atos.soclomo.location.common.dto.BranchDTO;

/**
 * This is a service interface used for Branch operations.
 * @author a602834
 *
 */
public interface BranchService {

	/**
	 * This method is used to get Branch list.
	 * @return list Branch dto.
	 */
	List<BranchDTO> getBranches();
	
	/**
	 * This method is used to save the Branch.
	 * @param branch
	 * @return saved Branch.
	 */
	String savebranches(BranchDTO branch) ;
	
	/**
	 * This method is used to delete branch.
	 * @param branch
	 * @return deleted Branch
	 */
	String deleteBranch(BranchDTO branch) ;

	BranchDTO getBranchByBranchCode(String  branchCode); 
}
