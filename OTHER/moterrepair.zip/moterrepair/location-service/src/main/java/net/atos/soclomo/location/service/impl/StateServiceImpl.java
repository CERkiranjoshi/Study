package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.RegionRepository;
import net.atos.soclomo.location.dao.StateRepository;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.dao.entity.State;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.StateService;

import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for State operations.
 * @author a602834
 *
 */
@Component("stateServiceImpl")
public class StateServiceImpl implements StateService {

	@Autowired
	private StateRepository stateRepository;


	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private LocationMapper mapper;
	
	@Autowired
	Mapper dMapper;


	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.StateService#getStates()
	 */
	@Transactional
	public List<StateDTO> getStates() {
		List<State> states = null;
		List<StateDTO> stateDtos = null;
		try {
			states = stateRepository.findAll();
			if(states != null && !states.isEmpty()){
				stateDtos = new ArrayList<StateDTO>();
				try {
					for (State state : states) {
						StateDTO stateDTO=dMapper.map(state, StateDTO.class);
						
						Region region=state.getRegion();
						RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
						Country country=region.getCountry();
						CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
						countryDTO.setTenantId(country.getId().getTenantId());
						countryDTO.setCountryCode(country.getId().getCountryCode());
						regionDTO.setCountry(countryDTO);
						stateDTO.setRegion(regionDTO);
						
						stateDtos.add(stateDTO);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return stateDtos;
			}
			System.out.println(states);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("arti "+states);
		return stateDtos;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.StateService#saveStates(net.atos.soclomo.location.common.dto.StateDTO)
	 */
	@Transactional
	public String saveStates(StateDTO stateDTO) {
		System.out.println("StateServiceImpl start ");
		State state = null;
		Region region = null;
		try {
			state = stateRepository.findOne(stateDTO.getStateCode());
			if(null == state) {
				state=dMapper.map(stateDTO, State.class);
				state.setCreatedDate(new Date());
				state.setModifiedDate(new Date());
				String id=stateDTO.getRegion().getRegionCode();
				region=regionRepository.findOne(id);
				state.setRegion(region);
				state = stateRepository.save(state);
			}
			else {
				state.setStateCode(stateDTO.getStateCode());
				state.setStateName(stateDTO.getStateName());
				state.setActive(stateDTO.getActive());
				state.setModifiedBy(stateDTO.getModifiedBy());
				state.setModifiedDate(new Date());
				String id=stateDTO.getRegion().getRegionCode();
				region=regionRepository.findOne(id);
				state.setRegion(region);
				state = stateRepository.save(state);
			}
			/*state = mapper.convertStateDTOToStateEntity(stateDTO,state);
			String id=stateDTO.getRegionDTO().getRegionCode();
			region=regionRepository.findOne(id);
			state.setRegion(region);
				
			
			state.setCreatedDate(new Date());
			state.setModifiedDate(new Date());
			state = stateRepository.save(state);*/
			
			if(null ==  state){

			
				return FAILURE;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("stateService "+state);
	
		return SUCCESS;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.StateService#deleteState(net.atos.soclomo.location.common.dto.StateDTO)
	 */
	@Override
	@Transactional
	public String deleteState(StateDTO stateDto) {
		// TODO Auto-generated method stub
		State state=stateRepository.findByStateCode(stateDto.getStateCode());
		if(state!=null) {
			state.setActive(LocationConstants.N);
			stateRepository.save(state);
	
			return SUCCESS;
		}

		return FAILURE;
	}

	@Override
	public StateDTO getStateByStateCode(String stateCode) {
		StateDTO stateDTO=null;
		if(StringUtils.isNotBlank(stateCode)) {
			State state=stateRepository.findByStateCode(stateCode);
			if(state!=null) {
				stateDTO=dMapper.map(state, StateDTO.class);
				
				Region region=state.getRegion();
				RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
				Country country=region.getCountry();
				CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());
				countryDTO.setCountryCode(country.getId().getCountryCode());
				regionDTO.setCountry(countryDTO);
				stateDTO.setRegion(regionDTO);
			}
		}
		return stateDTO;
	}
	
}
