package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.dao.CountryRepository;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.CountryPK;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.CountryService;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for Country operations.
 * @author a602834
 *
 */
@Component("countryServiceImpl")
public class CountryServiceImpl implements CountryService {

	private static final Logger LOGGER=Logger.getLogger(CountryServiceImpl.class);

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private LocationMapper locationMapper;

	@Autowired
	private Mapper mapper;


	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.CountryService#getCountries()
	 */
	@Override
	@Transactional
	public List<CountryDTO> getCountries() {

		LOGGER.info("Start getCountries ");
		List<Country> countries = null;
		List<CountryDTO> countryDtos = null;

		try {
			countries = countryRepository.getAllCountries();
			if(countries != null && !countries.isEmpty()){
				countryDtos = new ArrayList<CountryDTO>();
				try {
					for (Country country : countries) {

						CountryDTO countryDto=mapper.map(country, CountryDTO.class);
						countryDto.setTenantId(country.getId().getTenantId());
						countryDto.setCountryCode(country.getId().getCountryCode());
						countryDto.setCountryName(country.getCountryName());
						countryDtos.add(countryDto);
					}
				} catch (Exception e) {
					LOGGER.error(e);
				}
				return countryDtos;
			}

			LOGGER.info(countries);

		} catch (Exception e) {
			LOGGER.error(e);
		}
		LOGGER.info("Country end "+countries);
		return countryDtos;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.CountryService#saveCountries(net.atos.soclomo.location.common.dto.CountryDTO)
	 */
	@Transactional
	public String saveCountries(final CountryDTO countryDTO) {
		LOGGER.info("CountryServiceImpl start ");
		Country country = null;
		try {
			LOGGER.info(countryDTO);
			CountryPK countrypk = new CountryPK();
			countrypk.setCountryCode(countryDTO.getCountryCode());
			countrypk.setTenantId(countryDTO.getTenantId());
			country = countryRepository.findOne(countrypk);
			if(null==country) {
				country=mapper.map(countryDTO, Country.class);
				CountryPK countryPK = new CountryPK();
				countryPK.setCountryCode(countryDTO.getCountryCode());
				countryPK.setTenantId(countryDTO.getTenantId());
				country.setId(countryPK);
				country.setCreatedDate(new Date());
				country.setModifiedDate(new Date());
				country=countryRepository.save(country);
			}
			else {
				CountryPK countryPK = new CountryPK();
				countryPK.setCountryCode(countryDTO.getCountryCode());
				countryPK.setTenantId(countryDTO.getTenantId());
				country.setId(countryPK);
				country.setCountryName(countryDTO.getCountryName());
				country.setActive(countryDTO.getActive());
				country.setModifiedBy(countryDTO.getModifiedBy());
				country.setModifiedDate(new Date());
				country=countryRepository.save(country);
			}
			if(null == country){
				return FAILURE;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("CountryService "+country);
		return SUCCESS;
	}

	/**
	 * This method is used to save country.
	 * @param country
	 * @return saved Country.
	 */
	/*public Country savecountries(CountryDTO country) {
		// TODO Auto-generated method stub
		return null;
	}*/

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.CountryService#deleteCountry(net.atos.soclomo.location.common.dto.CountryDTO)
	 */
	@Override
	public String deleteCountry(CountryDTO countryDto) {
		CountryPK countryPK = new CountryPK();
		countryPK.setCountryCode(countryDto.getCountryCode());
		countryPK.setTenantId(countryDto.getTenantId());
		Country country=countryRepository.findOne(countryPK);
		if(country!=null) {
			country.setActive(LocationConstants.N);
			countryRepository.save(country);
			
			return SUCCESS;
		}
	
		return FAILURE;
	}

	/**
	 * Pagenation of getAllCountries
	 */
	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.CountryService#getCountries(org.springframework.data.domain.Pageable)
	 */
	@Override
	public List<CountryDTO> getCountries(Pageable pageable) {


		List<Country> countries = null;
		List<CountryDTO> countryDtos = null;
		countries=countryRepository.getAllCountries(pageable);
		if(countries != null && !countries.isEmpty()){
			countryDtos = new ArrayList<CountryDTO>();
			try {
				for (Country country : countries) {
					CountryDTO countryDto = new CountryDTO();
					countryDto.setActive(country.getActive());
					countryDto.setCountryCode(country.getId().getCountryCode());
					countryDto.setCountryName(country.getCountryName());
					countryDto.setTenantId(country.getId().getTenantId());
					countryDtos.add(countryDto);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return countryDtos;
	}

	@Override
	public CountryDTO getCountryByTenantIdAndCountryCode(String tenantId,String countryCode) {
		CountryDTO countryDTO=null;
		Country country=null;
		if(StringUtils.isNotBlank(tenantId) && StringUtils.isNotBlank(countryCode)) {
			CountryPK countrypk = new CountryPK();
			countrypk.setTenantId(tenantId);
			countrypk.setCountryCode(countryCode);
			country=countryRepository.findById(countrypk);
			if(null!=country) {
				countryDTO=mapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());
				countryDTO.setCountryCode(country.getId().getCountryCode());
			}

		}
		return countryDTO;
	}

	@Override
	public List<String> getTenantList() {
		List<Country> alCountries=null;
		List<String> alTenants=null;
		alCountries=countryRepository.findAll();
		if(null!=alCountries && !alCountries.isEmpty()) {
			alTenants= new ArrayList<String>();
			for(Country country : alCountries) {
				String tenant=country.getId().getTenantId();
				if(StringUtils.isNotBlank(tenant)) {
					alTenants.add(tenant);
				}
			}
		}
		return alTenants;
	}

	@Override
	public String updateByTenantIdAndCountryCode(CountryDTO countryDTO) {
		if(null!=countryDTO) {
			String tenantId=countryDTO.getTenantId();
			String countryCode=countryDTO.getCountryCode();
			if(StringUtils.isNotBlank(tenantId) && StringUtils.isNotBlank(countryCode)) {
				CountryPK countryPK=new CountryPK();
				countryPK.setTenantId(tenantId);
				countryPK.setCountryCode(countryCode);

				Country country=countryRepository.findById(countryPK);

				if(null!=country) {
					country.setModifiedDate(new Date());
					country.setCountryName(countryDTO.getCountryName());
					country.setActive(countryDTO.getActive());
					Country savedConCountry=countryRepository.save(country);
					if(null!=savedConCountry) {
					
						return SUCCESS;
					}
				}
			}
		}

		return FAILURE;
	}

}




