package net.atos.soclomo.location.service;

import java.util.List;
import org.springframework.data.domain.Pageable;
import net.atos.soclomo.location.common.dto.CountryDTO;


/**
 * This is a service interface used for Country operations.
 * @author a602834
 * 
 */
public interface CountryService {

	/**
	 * This method is used to get Country list.
	 * @return list of Country dto.
	 */
	List<CountryDTO> getCountries();

	/**
	 * This method is used to save Country.
	 * @param country
	 * @return saved Country.
	 */
	String saveCountries(CountryDTO country);

	/**
	 * This method is used to delete Country.
	 * @param countryDto
	 * @return deleted Country.
	 */
	String deleteCountry(CountryDTO countryDto);

	/**
	 * This method is used to get country list based on pagination.
	 * @param pageable
	 * @return list of CountryDTO
	 */
	List<CountryDTO> getCountries(Pageable pageable);

	CountryDTO getCountryByTenantIdAndCountryCode(String tenant_id,
			String country_code);

	List<String> getTenantList();

	String updateByTenantIdAndCountryCode(CountryDTO countryDTO);

}
