package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.dao.CountryRepository;
import net.atos.soclomo.location.dao.RegionRepository;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.CountryPK;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.RegionService;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for Region operations.
 * @author a602834
 *
 */
@Component("regionServiceImpl")
public class RegionServiceImpl implements RegionService {
	
	private static final Logger logger=Logger.getLogger(RegionServiceImpl.class);

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private CountryRepository countryRepository;
	
	@Autowired
	LocationMapper locationMapper;
	
	@Autowired
	private Mapper mapper;
	
	
	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.RegionService#getregions()
	 */
	@Transactional
	public  List<RegionDTO> getregions() {
		List<Region> alRegions = null;
		List<RegionDTO> alRegionDTOs = null;
 		try {
 			alRegions = regionRepository.findAll();
			if(alRegions != null && !alRegions.isEmpty()){
				alRegionDTOs = new ArrayList<RegionDTO>();
				try {
					for (Region region : alRegions) {
						
						RegionDTO regionDto = new RegionDTO();
						Country country=region.getCountry();
						CountryDTO countryDTO=mapper.map(country, CountryDTO.class);
						countryDTO.setCountryCode(country.getId().getCountryCode());
						countryDTO.setTenantId(country.getId().getTenantId());
						
						regionDto=mapper.map(region, RegionDTO.class);
						regionDto.setCountry(countryDTO);
						
						alRegionDTOs.add(regionDto);
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return alRegionDTOs;
			}
		} catch (Exception e) {
			logger.error(e);
		}
		return alRegionDTOs;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.RegionService#saveRegions(net.atos.soclomo.location.common.dto.RegionDTO)
	 */
	
	@Transactional
	public String saveRegions(RegionDTO regionDTO) {
		logger.info("RegionServiceImpl start ");
		Region region = null;
		Country country = null;
		try {
			logger.info(regionDTO);
			region=regionRepository.findByRegionCode(regionDTO.getRegionCode());
			if(null==region) {
				region=mapper.map(regionDTO, Region.class);
				CountryPK id = new CountryPK();
				id.setCountryCode(regionDTO.getCountry().getCountryCode());
				id.setTenantId(regionDTO.getCountry().getTenantId());
				country = countryRepository.findOne(id);
				region.setCountry(country);
				region.setCreatedDate(new Date());
				region.setModifiedDate(new Date());
				
				region = regionRepository.save(region);
			}else {
				region.setRegionCode(regionDTO.getRegionCode());
				region.setRegionName(regionDTO.getRegionName());
				region.setModifiedBy(regionDTO.getModifiedBy());
				region.setModifiedDate(new Date());
				region.setActive(regionDTO.getActive());
				CountryPK id = new CountryPK();
				id.setCountryCode(regionDTO.getCountry().getCountryCode());
				id.setTenantId(regionDTO.getCountry().getTenantId());
				country = countryRepository.findOne(id);
				region.setCountry(country);
				
				region = regionRepository.save(region);
			}
			
			/*CountryPK id = new CountryPK();
			id.setCountryCode(regionDTO.getCountryDTO().getCountryCode());
			id.setTenantId(regionDTO.getCountryDTO().getTenantId());
			country = countryRepository.findOne(id);
			
			region.setCountry(country);
			region.setModifiedDate(new Date());
			logger.info(country);
			
			region = regionRepository.save(region);*/
			
			if(null == region){
			
				return FAILURE;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e);
		}
		logger.info("regionService "+region);

		return SUCCESS;
	}
	
	@Override
	public String deleteRegion(RegionDTO regionDto) {
		Region region=regionRepository.findByRegionCode(regionDto.getRegionCode());
		if(region!=null) {
			region.setActive(LocationConstants.N);
			regionRepository.save(region);
			
			return SUCCESS;
		}
	
		return FAILURE;
	}

	@Override
	public RegionDTO getRegionByRegionCode(String regionCode) {
		RegionDTO regionDTO=null;
		if(StringUtils.isNotBlank(regionCode)) {
			Region region=regionRepository.findByRegionCode(regionCode);
			if(null!=region) {
				regionDTO=mapper.map(region, RegionDTO.class);
				Country country=region.getCountry();
				CountryDTO countryDTO=mapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());
				System.out.println("Tenant - "+country.getId().getTenantId());
				countryDTO.setCountryCode(country.getId().getCountryCode());
				System.out.println("Country - "+country.getId().getCountryCode());
				regionDTO.setCountry(countryDTO);
			}
		}
		return regionDTO;
	}
	
}
			