package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.DistrictDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.DistrictRepository;
import net.atos.soclomo.location.dao.StateRepository;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.District;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.dao.entity.State;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.DistrictService;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


/**
 * This is a service class used for District operations.
 * @author a602834
 *
 */
@Component("districtServiceImpl")
public class DistrictServiceImpl implements DistrictService {
	
	private static final Logger logger=Logger.getLogger(DistrictServiceImpl.class);

	@Autowired
	private DistrictRepository districtRepository;

	@Autowired
	private StateRepository stateRepository;
	
	@Autowired
	private LocationMapper mapper;
	
	@Autowired
	private Mapper dMapper;

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.DistrictService#getDistricts()
	 */
	@Transactional
	public List<DistrictDTO> getDistricts() {
		logger.info("Enterd into getDistricts");
		List<District> districts = null;
		List<DistrictDTO> districtDtos = null;
		try {
			districts = districtRepository.findAll();
			if(districts != null && !districts.isEmpty()){
				districtDtos = new ArrayList<DistrictDTO>();
				try {
					for (District district : districts) {
						DistrictDTO districtDTO = dMapper.map(district, DistrictDTO.class);
						
						//for hierachy
						State state=district.getState();
						StateDTO stateDTO=dMapper.map(state, StateDTO.class);
						
						Region region=state.getRegion();
						RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
						Country country=region.getCountry();
						CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
						countryDTO.setTenantId(country.getId().getTenantId());
						countryDTO.setCountryCode(country.getId().getCountryCode());
						regionDTO.setCountry(countryDTO);
						stateDTO.setRegion(regionDTO);
						
						districtDTO.setState(stateDTO);
						
						districtDtos.add(districtDTO);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return districtDtos;
			}
			logger.info(districts);
		} catch (Exception e) {
			logger.error(e);
		}
		logger.info("District "+districts);
		return districtDtos;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.DistrictService#saveDistricts(net.atos.soclomo.location.common.dto.DistrictDTO)
	 */
	@Override
	@Transactional
	public String saveDistricts(DistrictDTO districtDTO) {
		logger.info("DistrictServiceImpl start ");
		District district = null;
		State state = null;

		try {
			district=districtRepository.findByDistrictCode(districtDTO.getDistrictCode());
			if(null==district) {
				district=dMapper.map(districtDTO, District.class);
				district.setCreatedDate(new Date());
				district.setModifiedDate(new Date());
				String id=districtDTO.getState().getStateCode();
				state=stateRepository.findOne(id);
				district.setState(state);
				
				district = districtRepository.save(district);
			}else {
				district.setDistrictCode(districtDTO.getDistrictCode());
				district.setDistrictName(districtDTO.getDistrictName());
				district.setActive(districtDTO.getActive());
				district.setModifiedBy(districtDTO.getModifiedBy());
				district.setModifiedDate(new Date());
				String id=districtDTO.getState().getStateCode();
				state=stateRepository.findOne(id);
				district.setState(state);
				
				district = districtRepository.save(district);
				
			}
			
			/*district=mapper.convertDistrictDTOToDistrictEntity(districtDTO,district);
			String id=districtDTO.getStateDTO().getStateCode();
			state=stateRepository.findOne(id);
			
			logger.info(state);
			district.setState(state);
			
			district.setModifiedDate(new Timestamp(new Date().getTime()));

			logger.info(districtDTO);

			district = districtRepository.save(district);*/
			
			
			if(null == district){
				
				return FAILURE;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e);
		}
		logger.info("districtService "+district);
		
		return SUCCESS;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.DistrictService#deleteDistrict(net.atos.soclomo.location.common.dto.DistrictDTO)
	 */
	@Override
	public String deleteDistrict(DistrictDTO districtDto) {
		District district=districtRepository.findByDistrictCode(districtDto.getDistrictCode());
		if(district!=null) {
			district.setActive(LocationConstants.N);
			districtRepository.save(district);
			
			return SUCCESS;
		}
	
		return FAILURE;
		
	}

	@Override
	public DistrictDTO getDistrictByDistrictCode(String districtCode) {
		DistrictDTO districtDTO=null;
		if(StringUtils.isNotBlank(districtCode)) {
			District district=districtRepository.findByDistrictCode(districtCode);
			if(null!=district) {
				districtDTO=dMapper.map(district, DistrictDTO.class);
				State state=district.getState();
				StateDTO stateDTO=dMapper.map(state, StateDTO.class);
				
				Region region=state.getRegion();
				RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
				Country country=region.getCountry();
				CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());
				countryDTO.setCountryCode(country.getId().getCountryCode());
				regionDTO.setCountry(countryDTO);
				stateDTO.setRegion(regionDTO);
				
				districtDTO.setState(stateDTO);
				
			}
		}
		return districtDTO;
	}

}
