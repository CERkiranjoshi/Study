package net.atos.soclomo.location.service.impl;

import static net.atos.soclomo.location.common.constants.IOTConstants.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.soclomo.location.common.constants.LocationConstants;
import net.atos.soclomo.location.common.dto.BranchDTO;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.DistrictDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.BranchRepository;
import net.atos.soclomo.location.dao.DistrictRepository;
import net.atos.soclomo.location.dao.entity.Branch;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.District;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.dao.entity.State;
import net.atos.soclomo.location.mapper.LocationMapper;
import net.atos.soclomo.location.service.BranchService;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for branch operations.
 * @author a602834
 *
 */
@Service
public class BranchServiceImpl implements BranchService {

	private final static Logger logger=Logger.getLogger(BranchServiceImpl.class);

	@Autowired
	private BranchRepository branchRepository;
	@Autowired
	private DistrictRepository districtRepository;
	@Autowired 
	LocationMapper mapper;

	@Autowired
	Mapper dMapper;

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.BranchService#getBranches()
	 */
	@Transactional
	public List<BranchDTO> getBranches() {
		List<Branch> branches = null;
		List<BranchDTO> branchDtos = null;

		try {
			branches = branchRepository.findAll();
			if (branches != null && !branches.isEmpty()) {
				branchDtos = new ArrayList<BranchDTO>();
				try {
					for (Branch branch : branches) {

						BranchDTO branchDTO=dMapper.map(branch, BranchDTO.class);
						//branchDto.setDistrictDTO(dMapper.map(branch.getDistrict(),DistrictDTO.class));

						District district=branch.getDistrict();
						DistrictDTO districtDTO = dMapper.map(district, DistrictDTO.class);

						State state=district.getState();
						StateDTO stateDTO=dMapper.map(state, StateDTO.class);

						Region region=state.getRegion();
						RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
						Country country=region.getCountry();
						CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
						countryDTO.setTenantId(country.getId().getTenantId());

						countryDTO.setCountryCode(country.getId().getCountryCode());
						regionDTO.setCountry(countryDTO);
						stateDTO.setRegion(regionDTO);
						districtDTO.setState(stateDTO);
						branchDTO.setDistrict(districtDTO);

						branchDtos.add(branchDTO);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return branchDtos;
			}
			
			logger.info(branches);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e);
		}
		logger.info("arti " + branches);
		return branchDtos;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.BranchService#savebranches(net.atos.soclomo.location.common.dto.BranchDTO)
	 */
	@Override
	public String savebranches(BranchDTO branchDTO) {
		Branch branch = null;
		District district = null;
		
		branch=branchRepository.findByBranchCode(branchDTO.getBranchCode());
		if(null==branch) {
			branch=dMapper.map(branchDTO, Branch.class);
			branch.setCreatedDate(new Timestamp(new Date().getTime()));
			branch.setModifiedDate(new Timestamp(new Date().getTime()));
			String id=branchDTO.getDistrict().getDistrictCode();
			district=districtRepository.findByDistrictCode(id);
			branch.setDistrict(district);
			
			branch = branchRepository.save(branch);
		}else {
			branch.setActive(branchDTO.getActive());
			branch.setAddress1(branchDTO.getAddress1());
			branch.setAddress2(branchDTO.getAddress2());
			branch.setAddress3(branchDTO.getAddress3());
			branch.setBranchCode(branchDTO.getBranchCode());
			branch.setBranchCodeCust(branchDTO.getBranchCodeCust());
			branch.setBranchName(branchDTO.getBranchName());
			branch.setBranchType(branchDTO.getBranchType());
			branch.setBranchSubtype(branchDTO.getBranchSubType());
			branch.setModifiedBy(branchDTO.getModifiedBy());
			branch.setModifiedDate(new Timestamp(new Date().getTime()));
			branch.setLatitude(branchDTO.getLatitude());
			branch.setLongitude(branchDTO.getLongitude());
			String id=branchDTO.getDistrict().getDistrictCode();
			district=districtRepository.findByDistrictCode(id);
			branch.setDistrict(district);
			
			branch = branchRepository.save(branch);
		}
		
		if(null == branch){
			return FAILURE;
		}
		return SUCCESS;
	}

	/* (non-Javadoc)
	 * @see net.atos.soclomo.location.service.BranchService#deleteBranch(net.atos.soclomo.location.common.dto.BranchDTO)
	 */
	@Override
	public String deleteBranch(BranchDTO branchDto) {
		Branch branch=branchRepository.findByBranchCode(branchDto.getBranchCode());
		if(null != branch) {
			branch.setActive(LocationConstants.N);
			branchRepository.save(branch);
		
			return SUCCESS;
		}
		return FAILURE;
	
	}

	@Override
	public BranchDTO getBranchByBranchCode(String  branchCode) {
		BranchDTO branchDTO=null;
		if(StringUtils.isNotBlank(branchCode)) {
			Branch branch=branchRepository.findByBranchCode(branchCode);
			if(null!=branch) {
				branchDTO=dMapper.map(branch, BranchDTO.class);
				District district=branch.getDistrict();
				DistrictDTO districtDTO = dMapper.map(district, DistrictDTO.class);

				State state=district.getState();
				StateDTO stateDTO=dMapper.map(state, StateDTO.class);

				Region region=state.getRegion();
				RegionDTO regionDTO = dMapper.map(region, RegionDTO.class);
				Country country=region.getCountry();
				CountryDTO countryDTO=dMapper.map(country, CountryDTO.class);
				countryDTO.setTenantId(country.getId().getTenantId());

				countryDTO.setCountryCode(country.getId().getCountryCode());
				regionDTO.setCountry(countryDTO);
				stateDTO.setRegion(regionDTO);
				districtDTO.setState(stateDTO);

				branchDTO.setDistrict(districtDTO);

			}
		}
		return branchDTO;
	}

}
