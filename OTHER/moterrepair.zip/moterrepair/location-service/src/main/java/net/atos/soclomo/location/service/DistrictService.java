package net.atos.soclomo.location.service;

import java.util.List;

import net.atos.soclomo.location.common.dto.DistrictDTO;

/**
 * This is a service interface used for District service operations.
 * @author a602834
 *
 */
public interface DistrictService {

	/**
	 * This method is used to get District list.
	 * @return list of DistrictDTO
	 */
	List<DistrictDTO> getDistricts();

	/**
	 * This method is used to delete District.
	 * @param districtDto
	 * @return deleted District.
	 */
	String deleteDistrict(DistrictDTO districtDto);

	/**
	 * This method is used to save District.
	 * @param districtDto
	 * @return saved District.
	 */
	String saveDistricts(DistrictDTO districtDto);

	DistrictDTO getDistrictByDistrictCode(String districtCode);

}