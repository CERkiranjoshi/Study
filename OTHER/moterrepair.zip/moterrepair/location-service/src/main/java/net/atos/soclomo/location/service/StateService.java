package net.atos.soclomo.location.service;

import java.util.List;
import net.atos.soclomo.location.common.dto.StateDTO;


/**
 * This is a service interface used for State service operations.
 * @author a602834
 *
 */
public interface StateService {

	String saveStates(StateDTO state);

	/**
	 * This method is used to get State list.
	 * @return list of StateDto.
	 */
	List<StateDTO> getStates();
	
	/**
	 * This method is used to delete State.
	 * @param stateDto
	 * @return deleted State.
	 */
	String deleteState(StateDTO stateDto) ;

	StateDTO getStateByStateCode(String stateCode);

}