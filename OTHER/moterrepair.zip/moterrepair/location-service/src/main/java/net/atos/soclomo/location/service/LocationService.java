package net.atos.soclomo.location.service;

import java.util.List;
import net.atos.soclomo.location.common.dto.LocationDTO;

public interface LocationService {
	
	public List<LocationDTO> getAllLocation();
	
	public String saveLocation(LocationDTO locationDto);
	
	public String deleteLocation(LocationDTO locationDto);

	public List<LocationDTO> getAllLocationByLocSubtype(String locSubtype);

	public LocationDTO getLocationByLocCode(String locCode);
	
}
