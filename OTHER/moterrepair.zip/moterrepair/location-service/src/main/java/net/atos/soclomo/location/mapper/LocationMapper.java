package net.atos.soclomo.location.mapper;

import net.atos.soclomo.location.common.dto.BranchDTO;
import net.atos.soclomo.location.common.dto.CountryDTO;
import net.atos.soclomo.location.common.dto.DistrictDTO;
import net.atos.soclomo.location.common.dto.LocationDTO;
import net.atos.soclomo.location.common.dto.RegionDTO;
import net.atos.soclomo.location.common.dto.StateDTO;
import net.atos.soclomo.location.dao.entity.Branch;
import net.atos.soclomo.location.dao.entity.Country;
import net.atos.soclomo.location.dao.entity.CountryPK;
import net.atos.soclomo.location.dao.entity.District;
import net.atos.soclomo.location.dao.entity.Location;
import net.atos.soclomo.location.dao.entity.Region;
import net.atos.soclomo.location.dao.entity.State;

import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class LocationMapper {

	final ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private Mapper mapper;

	public Country convertCountryToCountryDto(final CountryDTO countryDto, Country country) {
		if(null == country){
			country = new Country();

		}

		country = mapper.map(countryDto, Country.class);
		if(null == country.getId()){
			CountryPK countrypk = new CountryPK();
			countrypk.setCountryCode(countryDto.getCountryCode());
			countrypk.setTenantId(countryDto.getTenantId());
			country.setId(countrypk);
		}
		return country;

	}

	public Branch convertBranchDTOToBranchEntity(final BranchDTO branchDto,Branch branch) {
		if(branch==null) {
			branch=new Branch();
		}
		branch=mapper.map(branchDto, Branch.class);
		return branch;
	}

	public State convertStateDTOToStateEntity(StateDTO stateDto, State stateSave) {
		if(null == stateSave){
			stateSave = new State();
		}
		stateSave = mapper.map(stateDto, State.class);
		return stateSave;
	}

	public BranchDTO convertBranchEntityToBranchDTO(BranchDTO branchDto, Branch branch) {
		if(branchDto==null) {
			branchDto=new BranchDTO();
		}
		branchDto=mapper.map(branch, BranchDTO.class);
		return branchDto;
	}

	public StateDTO convertStateEntityToStateDTO(StateDTO stateDto, State state) {
		if(stateDto==null) {
			stateDto= new StateDTO();
		}
		stateDto=mapper.map(state, StateDTO.class);
		return stateDto;
	}

	public RegionDTO convertRegionEntityToRegionDTO(RegionDTO regionDto,Region regionSave) {
		if(regionDto==null) {
			regionDto=new RegionDTO();
		}
		regionDto=mapper.map(regionSave, RegionDTO.class);
		return regionDto;
	}

	public District convertDistrictDTOToDistrictEntity(DistrictDTO districtDto,
			District districtSave) {
		if(null==districtSave) {
			districtSave=new District();
		}
		districtSave=mapper.map(districtDto, District.class);
		return districtSave;
	}

	public LocationDTO convertLocationEntityToLocationDTO(
			LocationDTO locationDto, Location location) {
		if(null==locationDto) {
			locationDto=new LocationDTO();
		}
		locationDto=mapper.map(location, LocationDTO.class);
		return locationDto;
	}

	public Location convertLocationDTOToLocationEntity(LocationDTO locationDto, Location location) {
		if(null==location) {
			location=new Location();
		}
		location=mapper.map(locationDto, Location.class);
		return location;
	}

	public Region convertRegionDTOToRegioEntity(RegionDTO regionDto, Region regionSave) {
		if(null==regionSave) {
			regionSave=new Region();
		}
		regionSave=mapper.map(regionDto, Region.class);
		return regionSave;
	}
}
