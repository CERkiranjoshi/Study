package net.atos.soclomo.location.service;

import java.util.List;

import net.atos.soclomo.location.common.dto.RegionDTO;


/**
 * This is a service interface used for Region service operations.
 * @author a602834
 *
 */
public interface RegionService {

	/**
	 * This method is used to get Region list.
	 * @return list of Region dto.
	 */
	List<RegionDTO> getregions();

	/**
	 * This method is used to save region.
	 * @param region
	 * @return saved Region.
	 */
	String saveRegions(RegionDTO region);

	/** This method is used to delete Region.
	 * @param regionDto
	 * @return deleted Region.
	 */
	String deleteRegion(RegionDTO regionDto);

	RegionDTO getRegionByRegionCode(String regionCode);

}