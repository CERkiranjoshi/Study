package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorNamePlateDetailDTO implements Serializable {

	private static final long serialVersionUID = 14265476788887L;

	private Long motorNamePlateFieldsId;

	private Date createdOn;

	private Integer frameSize;

	private String motorType;

	private String machineNum;

	private Float statorFreqHz;

	private Float statorVolts;

	private Float statorKWPerHp;

	private Float statorAmp;

	private Integer statorRpm;

	private String insClaim;

	private String duty;

	private Date mfgDate;
	
	private String rotor;

	/**
	 * @return the motorNamePlateFieldsId
	 */
	public Long getMotorNamePlateFieldsId() {
		return motorNamePlateFieldsId;
	}

	/**
	 * @param motorNamePlateFieldsId the motorNamePlateFieldsId to set
	 */
	public void setMotorNamePlateFieldsId(Long motorNamePlateFieldsId) {
		this.motorNamePlateFieldsId = motorNamePlateFieldsId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the frameSize
	 */
	public Integer getFrameSize() {
		return frameSize;
	}

	/**
	 * @param frameSize the frameSize to set
	 */
	public void setFrameSize(Integer frameSize) {
		this.frameSize = frameSize;
	}

	/**
	 * @return the motorType
	 */
	public String getMotorType() {
		return motorType;
	}

	/**
	 * @param motorType the motorType to set
	 */
	public void setMotorType(String motorType) {
		this.motorType = motorType;
	}

	/**
	 * @return the machineNum
	 */
	public String getMachineNum() {
		return machineNum;
	}

	/**
	 * @param machineNum the machineNum to set
	 */
	public void setMachineNum(String machineNum) {
		this.machineNum = machineNum;
	}

	/**
	 * @return the statorFreqHz
	 */
	public Float getStatorFreqHz() {
		return statorFreqHz;
	}

	/**
	 * @param statorFreqHz the statorFreqHz to set
	 */
	public void setStatorFreqHz(Float statorFreqHz) {
		this.statorFreqHz = statorFreqHz;
	}

	/**
	 * @return the statorVolts
	 */
	public Float getStatorVolts() {
		return statorVolts;
	}

	/**
	 * @param statorVolts the statorVolts to set
	 */
	public void setStatorVolts(Float statorVolts) {
		this.statorVolts = statorVolts;
	}

	/**
	 * @return the statorKWPerHp
	 */
	public Float getStatorKWPerHp() {
		return statorKWPerHp;
	}

	/**
	 * @param statorKWPerHp the statorKWPerHp to set
	 */
	public void setStatorKWPerHp(Float statorKWPerHp) {
		this.statorKWPerHp = statorKWPerHp;
	}

	/**
	 * @return the statorAmp
	 */
	public Float getStatorAmp() {
		return statorAmp;
	}

	/**
	 * @param statorAmp the statorAmp to set
	 */
	public void setStatorAmp(Float statorAmp) {
		this.statorAmp = statorAmp;
	}

	/**
	 * @return the statorRpm
	 */
	public Integer getStatorRpm() {
		return statorRpm;
	}

	/**
	 * @param statorRpm the statorRpm to set
	 */
	public void setStatorRpm(Integer statorRpm) {
		this.statorRpm = statorRpm;
	}

	/**
	 * @return the insClaim
	 */
	public String getInsClaim() {
		return insClaim;
	}

	/**
	 * @param insClaim the insClaim to set
	 */
	public void setInsClaim(String insClaim) {
		this.insClaim = insClaim;
	}

	/**
	 * @return the duty
	 */
	public String getDuty() {
		return duty;
	}

	/**
	 * @param duty the duty to set
	 */
	public void setDuty(String duty) {
		this.duty = duty;
	}

	/**
	 * @return the mfgDate
	 */
	public Date getMfgDate() {
		return mfgDate;
	}

	/**
	 * @param mfgDate the mfgDate to set
	 */
	public void setMfgDate(Date mfgDate) {
		this.mfgDate = mfgDate;
	}

	/**
	 * @return the rotor
	 */
	public String getRotor() {
		return rotor;
	}

	/**
	 * @param rotor the rotor to set
	 */
	public void setRotor(String rotor) {
		this.rotor = rotor;
	}
}
