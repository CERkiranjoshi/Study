package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610039
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MasterWorkflowFieldsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4091414412841314530L;

	private Long masterWorkflowFieldId;
	private String gspRefNo;
	private String batchProcessId;
	private Date createdOn;
	private String companyId;
	private Integer quantity;
	private String tenantId;
	private String location;
	private String solutionCategoryId;
	private List<CustomerDetailDTO> customerDetails;
	private List<AdditionalContactDetailDTO> additionalContactDetails;
	private WorkflowStateDTO workflowState;

	/**
	 * @return the masterWorkflowFieldId
	 */
	public Long getMasterWorkflowFieldId() {
		return masterWorkflowFieldId;
	}

	/**
	 * @param masterWorkflowFieldId
	 *            the masterWorkflowFieldId to set
	 */
	public void setMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		this.masterWorkflowFieldId = masterWorkflowFieldId;
	}

	/**
	 * @return the gspRefNo
	 */
	public String getGspRefNo() {
		return gspRefNo;
	}

	/**
	 * @param gspRefNo
	 *            the gspRefNo to set GSP customer code
	 */
	public void setGspRefNo(String gspRefNo) {
		this.gspRefNo = gspRefNo;
	}

	/**
	 * @return the batchProcessId
	 */
	public String getBatchProcessId() {
		return batchProcessId;
	}

	/**
	 * @param batchProcessId
	 *            the batchProcessId to set
	 */
	public void setBatchProcessId(String batchProcessId) {
		this.batchProcessId = batchProcessId;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId
	 *            the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set Number of motors sent for repairs
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set plant location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the customerDetails
	 */
	public List<CustomerDetailDTO> getCustomerDetails() {
		return customerDetails;
	}

	/**
	 * @param customerDetails
	 *            the customerDetails to set
	 */
	public void setCustomerDetails(List<CustomerDetailDTO> customerDetails) {
		this.customerDetails = customerDetails;
	}

	/**
	 * @return the additionalContactDetails
	 */
	public List<AdditionalContactDetailDTO> getAdditionalContactDetails() {
		return additionalContactDetails;
	}

	/**
	 * @param additionalContactDetails
	 *            the additionalContactDetails to set
	 */
	public void setAdditionalContactDetails(List<AdditionalContactDetailDTO> additionalContactDetails) {
		this.additionalContactDetails = additionalContactDetails;
	}

	/**
	 * @return the workflowState
	 */
	public WorkflowStateDTO getWorkflowState() {
		return workflowState;
	}

	/**
	 * @param workflowState
	 *            the workflowState to set
	 */
	public void setWorkflowState(WorkflowStateDTO workflowState) {
		this.workflowState = workflowState;
	}

}
