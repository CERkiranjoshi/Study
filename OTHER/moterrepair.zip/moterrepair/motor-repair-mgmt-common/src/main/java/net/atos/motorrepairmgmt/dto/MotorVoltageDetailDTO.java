package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorVoltageDetailDTO {

	private Long motorVoltageDetailId;

	private Float ry;

	private Float yb;

	private Float br;

	private Float freqHz;

	/**
	 * @return the motorVoltageDetailId
	 */
	public Long getMotorVoltageDetailId() {
		return motorVoltageDetailId;
	}

	/**
	 * @param motorVoltageDetailId
	 *            the motorVoltageDetailId to set
	 */
	public void setMotorVoltageDetailId(Long motorVoltageDetailId) {
		this.motorVoltageDetailId = motorVoltageDetailId;
	}

	/**
	 * @return the ry
	 */
	public Float getRy() {
		return ry;
	}

	/**
	 * @param ry
	 *            the ry to set
	 */
	public void setRy(Float ry) {
		this.ry = ry;
	}

	/**
	 * @return the yb
	 */
	public Float getYb() {
		return yb;
	}

	/**
	 * @param yb
	 *            the yb to set
	 */
	public void setYb(Float yb) {
		this.yb = yb;
	}

	/**
	 * @return the br
	 */
	public Float getBr() {
		return br;
	}

	/**
	 * @param br
	 *            the br to set
	 */
	public void setBr(Float br) {
		this.br = br;
	}

	/**
	 * @return the freqHz
	 */
	public Float getFreqHz() {
		return freqHz;
	}

	/**
	 * @param freqHz
	 *            the freqHz to set
	 */
	public void setFreqHz(Float freqHz) {
		this.freqHz = freqHz;
	}
}
