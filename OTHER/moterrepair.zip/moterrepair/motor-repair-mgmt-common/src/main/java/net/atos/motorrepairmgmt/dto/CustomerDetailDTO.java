package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDetailDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4729660129211272593L;

	private Long customerId;
	private String customerName;
	private String custContactName;
	private String mobileContactNum;
	private String officeContactNum;
	private String emailId;
	private String custType;
	private String custAddress;
	private String gspRefCode;
	private String spiridonRefCode;
	private Integer notificationType;
	private String shipToAddress;
	private Integer isShipToParty;
	private Integer isSoldToParty;
    private String countyCode;
    private Integer partnerType;
   	private String custState;
   	private String custCity;
   	private Integer custPinCode;
    
    /**
	 * @return the partnerType
	 */
	public Integer getPartnerType() {
		return partnerType;
	}

	/**
	 * @param partnerType the partnerType to set
	 */
	public void setPartnerType(Integer partnerType) {
		this.partnerType = partnerType;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	/**
	 * @return the customerId
	 */
	public Long getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the custContactName
	 */
	public String getCustContactName() {
		return custContactName;
	}
	/**
	 * @param custContactName the custContactName to set
	 */
	public void setCustContactName(String custContactName) {
		this.custContactName = custContactName;
	}
	/**
	 * @return the mobileContactNum
	 */
	public String getMobileContactNum() {
		return mobileContactNum;
	}
	/**
	 * @param mobileContactNum the mobileContactNum to set
	 */
	public void setMobileContactNum(String mobileContactNum) {
		this.mobileContactNum = mobileContactNum;
	}
	/**
	 * @return the officeContactNum
	 */
	public String getOfficeContactNum() {
		return officeContactNum;
	}
	/**
	 * @param officeContactNum the officeContactNum to set
	 */
	public void setOfficeContactNum(String officeContactNum) {
		this.officeContactNum = officeContactNum;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the custType
	 */
	public String getCustType() {
		return custType;
	}
	/**
	 * @param custType the custType to set
	 */
	public void setCustType(String custType) {
		this.custType = custType;
	}
	/**
	 * @return the custAddress
	 */
	public String getCustAddress() {
		return custAddress;
	}
	/**
	 * @param custAddress the custAddress to set
	 */
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	/**
	 * @return the gspRefCode
	 */
	public String getGspRefCode() {
		return gspRefCode;
	}
	/**
	 * @param gspRefCode the gspRefCode to set
	 */
	public void setGspRefCode(String gspRefCode) {
		this.gspRefCode = gspRefCode;
	}
	/**
	 * @return the spiridonRefCode
	 */
	public String getSpiridonRefCode() {
		return spiridonRefCode;
	}
	/**
	 * @param spiridonRefCode the spiridonRefCode to set
	 */
	public void setSpiridonRefCode(String spiridonRefCode) {
		this.spiridonRefCode = spiridonRefCode;
	}
	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}
	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}
	/**
	 * @return the shipToAddress
	 */
	public String getShipToAddress() {
		return shipToAddress;
	}
	/**
	 * @param shipToAddress the shipToAddress to set
	 */
	public void setShipToAddress(String shipToAddress) {
		this.shipToAddress = shipToAddress;
	}
	/**
	 * @return the isShipToParty
	 */
	public Integer getIsShipToParty() {
		return isShipToParty;
	}
	/**
	 * @param isShipToParty the isShipToParty to set
	 */
	public void setIsShipToParty(Integer isShipToParty) {
		this.isShipToParty = isShipToParty;
	}
	/**
	 * @return the isSoldToParty
	 */
	public Integer getIsSoldToParty() {
		return isSoldToParty;
	}
	/**
	 * @param isSoldToParty the isSoldToParty to set
	 */
	public void setIsSoldToParty(Integer isSoldToParty) {
		this.isSoldToParty = isSoldToParty;
	}
	
	
	public String getCustState() {
		return custState;
	}

	public void setCustState(String custState) {
		this.custState = custState;
	}

	public String getCustCity() {
		return custCity;
	}

	public void setCustCity(String custCity) {
		this.custCity = custCity;
	}

	public Integer getCustPinCode() {
		return custPinCode;
	}

	public void setCustPinCode(Integer custPinCode) {
		this.custPinCode = custPinCode;
	}
}
