/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorAReportFieldsDTO {

}
