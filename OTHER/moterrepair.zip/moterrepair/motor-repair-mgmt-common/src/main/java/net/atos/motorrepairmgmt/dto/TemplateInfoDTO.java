/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Sweety Kothari
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateInfoDTO {

	private Long id;

	private String functionCode;

	private String templateCode;

	private String templateName;

	private Integer enabled;

	private Integer notificationType;

	private Integer templateType;

	private Integer templateVisibility;

	private Integer templateEditable;

	private String subjectLine;
	
	private Integer receipientType;
	
	private String statusText;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode
	 *            the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	/**
	 * @return the enabled
	 */
	public Integer getEnabled() {
		return enabled;
	}

	/**
	 * @param enabled
	 *            the enabled to set
	 */
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return the templateCode
	 */
	public String getTemplateCode() {
		return templateCode;
	}

	/**
	 * @param templateCode
	 *            the templateCode to set
	 */
	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 *            the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the templateType
	 */
	public Integer getTemplateType() {
		return templateType;
	}

	/**
	 * @param templateType
	 *            the templateType to set
	 */
	public void setTemplateType(Integer templateType) {
		this.templateType = templateType;
	}

	/**
	 * @return the subjectLine
	 */
	public String getSubjectLine() {
		return subjectLine;
	}

	/**
	 * @param subjectLine
	 *            the subjectLine to set
	 */
	public void setSubjectLine(String subjectLine) {
		this.subjectLine = subjectLine;
	}

	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType
	 *            the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the templateVisibility
	 */
	public Integer getTemplateVisibility() {
		return templateVisibility;
	}

	/**
	 * @param templateVisibility
	 *            the templateVisibility to set
	 */
	public void setTemplateVisibility(Integer templateVisibility) {
		this.templateVisibility = templateVisibility;
	}

	/**
	 * @return the templateEditable
	 */
	public Integer getTemplateEditable() {
		return templateEditable;
	}

	/**
	 * @param templateEditable
	 *            the templateEditable to set
	 */
	public void setTemplateEditable(Integer templateEditable) {
		this.templateEditable = templateEditable;
	}

	/**
	 * @return the receipientType
	 */
	public Integer getReceipientType() {
		return receipientType;
	}

	/**
	 * @param receipientType the receipientType to set
	 */
	public void setReceipientType(Integer receipientType) {
		this.receipientType = receipientType;
	}

	/**
	 * @return the statusText
	 */
	public String getStatusText() {
		return statusText;
	}

	/**
	 * @param statusText the statusText to set
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

}
