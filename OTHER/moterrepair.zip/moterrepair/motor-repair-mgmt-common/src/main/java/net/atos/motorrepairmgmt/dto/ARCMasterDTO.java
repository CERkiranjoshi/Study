package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ARCMasterDTO {

	private Long arcId;

	private String arcName;

	private String arcVCode;

	private String arcAddress;

	private String arcCity;

	private String arcZipCode;

	private String arcContactPerson;

	private String arcContactEmail;

	private String arcContactMobile;

	private Integer arcEnabled;

	private String arcBranchCity;

	private String arcContactOffice;

	private Integer arcType;

	private String arcCategory;

	private String arcClientCode;

	private String arcProductType;

	private RegionMasterDTO regionMaster;

	/**
	 * @return the arcId
	 */
	public Long getArcId() {
		return arcId;
	}

	/**
	 * @param arcId
	 *            the arcId to set
	 */
	public void setArcId(Long arcId) {
		this.arcId = arcId;
	}

	/**
	 * @return the arcName
	 */
	public String getArcName() {
		return arcName;
	}

	/**
	 * @param arcName
	 *            the arcName to set
	 */
	public void setArcName(String arcName) {
		this.arcName = arcName;
	}

	/**
	 * @return the arcVCode
	 */
	public String getArcVCode() {
		return arcVCode;
	}

	/**
	 * @param arcVCode
	 *            the arcVCode to set
	 */
	public void setArcVCode(String arcVCode) {
		this.arcVCode = arcVCode;
	}

	/**
	 * @return the arcBranchCity
	 */
	public String getArcBranchCity() {
		return arcBranchCity;
	}

	/**
	 * @param arcBranchCity
	 *            the arcBranchCity to set
	 */
	public void setArcBranchCity(String arcBranchCity) {
		this.arcBranchCity = arcBranchCity;
	}

	/**
	 * @return the arcContactOffice
	 */
	public String getArcContactOffice() {
		return arcContactOffice;
	}

	/**
	 * @param arcContactOffice
	 *            the arcContactOffice to set
	 */
	public void setArcContactOffice(String arcContactOffice) {
		this.arcContactOffice = arcContactOffice;
	}

	/**
	 * @return the arcType
	 */
	public Integer getArcType() {
		return arcType;
	}

	/**
	 * @param arcType
	 *            the arcType to set
	 */
	public void setArcType(Integer arcType) {
		this.arcType = arcType;
	}

	/**
	 * @return the arcCategory
	 */
	public String getArcCategory() {
		return arcCategory;
	}

	/**
	 * @param arcCategory
	 *            the arcCategory to set
	 */
	public void setArcCategory(String arcCategory) {
		this.arcCategory = arcCategory;
	}

	/**
	 * @return the arcClientCode
	 */
	public String getArcClientCode() {
		return arcClientCode;
	}

	/**
	 * @param arcClientCode
	 *            the arcClientCode to set
	 */
	public void setArcClientCode(String arcClientCode) {
		this.arcClientCode = arcClientCode;
	}

	/**
	 * @return the arcProductType
	 */
	public String getArcProductType() {
		return arcProductType;
	}

	/**
	 * @param arcProductType
	 *            the arcProductType to set
	 */
	public void setArcProductType(String arcProductType) {
		this.arcProductType = arcProductType;
	}

	/**
	 * @return the arcAddress
	 */
	public String getArcAddress() {
		return arcAddress;
	}

	/**
	 * @param arcAddress
	 *            the arcAddress to set
	 */
	public void setArcAddress(String arcAddress) {
		this.arcAddress = arcAddress;
	}

	/**
	 * @return the arcCity
	 */
	public String getArcCity() {
		return arcCity;
	}

	/**
	 * @param arcCity
	 *            the arcCity to set
	 */
	public void setArcCity(String arcCity) {
		this.arcCity = arcCity;
	}

	/**
	 * @return the arcZipCode
	 */
	public String getArcZipCode() {
		return arcZipCode;
	}

	/**
	 * @param arcZipCode
	 *            the arcZipCode to set
	 */
	public void setArcZipCode(String arcZipCode) {
		this.arcZipCode = arcZipCode;
	}

	/**
	 * @return the arcContactPerson
	 */
	public String getArcContactPerson() {
		return arcContactPerson;
	}

	/**
	 * @param arcContactPerson
	 *            the arcContactPerson to set
	 */
	public void setArcContactPerson(String arcContactPerson) {
		this.arcContactPerson = arcContactPerson;
	}

	/**
	 * @return the arcContactEmail
	 */
	public String getArcContactEmail() {
		return arcContactEmail;
	}

	/**
	 * @param arcContactEmail
	 *            the arcContactEmail to set
	 */
	public void setArcContactEmail(String arcContactEmail) {
		this.arcContactEmail = arcContactEmail;
	}

	/**
	 * @return the arcEnabled
	 */
	public Integer getArcEnabled() {
		return arcEnabled;
	}

	/**
	 * @param arcEnabled
	 *            the arcEnabled to set
	 */
	public void setArcEnabled(Integer arcEnabled) {
		this.arcEnabled = arcEnabled;
	}

	/**
	 * @return the arcContactMobile
	 */
	public String getArcContactMobile() {
		return arcContactMobile;
	}

	/**
	 * @param arcContactMobile
	 *            the arcContactMobile to set
	 */
	public void setArcContactMobile(String arcContactMobile) {
		this.arcContactMobile = arcContactMobile;
	}

	/**
	 * @return the regionMaster
	 */
	public RegionMasterDTO getRegionMaster() {
		return regionMaster;
	}

	/**
	 * @param regionMaster
	 *            the regionMaster to set
	 */
	public void setRegionMaster(RegionMasterDTO regionMaster) {
		this.regionMaster = regionMaster;
	}

}
