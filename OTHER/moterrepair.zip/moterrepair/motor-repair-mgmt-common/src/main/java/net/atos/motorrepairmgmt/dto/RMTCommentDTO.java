/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

/**
 * @author a545466
 *
 */
public class RMTCommentDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7319137884669335291L;

	private String type;
	
	private String description;
	
	private String commentedOn;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the commentedOn
	 */
	public String getCommentedOn() {
		return commentedOn;
	}

	/**
	 * @param commentedOn the commentedOn to set
	 */
	public void setCommentedOn(String commentedOn) {
		this.commentedOn = commentedOn;
	}
	
	
}
