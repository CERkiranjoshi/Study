package net.atos.motorrepairmgmt.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FSEVisitDetailDTO {

	private Long fseVisitDetailId;

	private String arcCode;

	private String arcRefId;

	private String fseName;

	private String fseMobileNum;

	private Date fseVisitPlannedDate;

	private Date fseVisitActualDate;

	private Integer fseVisitType;
	
	private Integer fseConfirmCtsApproval;
	
	private Integer visitStatus;

	/**
	 * @return the fseVisitDetailId
	 */
	public Long getFseVisitDetailId() {
		return fseVisitDetailId;
	}

	/**
	 * @param fseVisitDetailId
	 *            the fseVisitDetailId to set
	 */
	public void setFseVisitDetailId(Long fseVisitDetailId) {
		this.fseVisitDetailId = fseVisitDetailId;
	}

	/**
	 * @return the arcCode
	 */
	public String getArcCode() {
		return arcCode;
	}

	/**
	 * @param arcCode
	 *            the arcCode to set
	 */
	public void setArcCode(String arcCode) {
		this.arcCode = arcCode;
	}

	/**
	 * @return the arcRefId
	 */
	public String getArcRefId() {
		return arcRefId;
	}

	/**
	 * @param arcRefId
	 *            the arcRefId to set
	 */
	public void setArcRefId(String arcRefId) {
		this.arcRefId = arcRefId;
	}

	/**
	 * @return the fseName
	 */
	public String getFseName() {
		return fseName;
	}

	/**
	 * @param fseName
	 *            the fseName to set
	 */
	public void setFseName(String fseName) {
		this.fseName = fseName;
	}

	/**
	 * @return the fseMobileNum
	 */
	public String getFseMobileNum() {
		return fseMobileNum;
	}

	/**
	 * @param fseMobileNum
	 *            the fseMobileNum to set
	 */
	public void setFseMobileNum(String fseMobileNum) {
		this.fseMobileNum = fseMobileNum;
	}

	/**
	 * @return the fseVisitPlannedDate
	 */
	public Date getFseVisitPlannedDate() {
		return fseVisitPlannedDate;
	}

	/**
	 * @param fseVisitPlannedDate
	 *            the fseVisitPlannedDate to set
	 */
	public void setFseVisitPlannedDate(Date fseVisitPlannedDate) {
		this.fseVisitPlannedDate = fseVisitPlannedDate;
	}

	/**
	 * @return the fseVisitActualDate
	 */
	public Date getFseVisitActualDate() {
		return fseVisitActualDate;
	}

	/**
	 * @param fseVisitActualDate
	 *            the fseVisitActualDate to set
	 */
	public void setFseVisitActualDate(Date fseVisitActualDate) {
		this.fseVisitActualDate = fseVisitActualDate;
	}

	/**
	 * @return the fseVisitType
	 */
	public Integer getFseVisitType() {
		return fseVisitType;
	}

	/**
	 * @param fseVisitType
	 *            the fseVisitType to set 1: Initial Inspection; 2: Revisit; 3:
	 *            With Materials
	 */
	public void setFseVisitType(Integer fseVisitType) {
		this.fseVisitType = fseVisitType;
	}

	/**
	 * @return the fseConfirmCtsApproval
	 */
	public Integer getFseConfirmCtsApproval() {
		return fseConfirmCtsApproval;
	}

	/**
	 * @param fseConfirmCtsApproval the fseConfirmCtsApproval to set
	 */
	public void setFseConfirmCtsApproval(Integer fseConfirmCtsApproval) {
		this.fseConfirmCtsApproval = fseConfirmCtsApproval;
	}

	/**
	 * @return the visitStatus
	 */
	public Integer getVisitStatus() {
		return visitStatus;
	}

	/**
	 * @param visitStatus the visitStatus to set
	 */
	public void setVisitStatus(Integer visitStatus) {
		this.visitStatus = visitStatus;
	}
	
	
}
