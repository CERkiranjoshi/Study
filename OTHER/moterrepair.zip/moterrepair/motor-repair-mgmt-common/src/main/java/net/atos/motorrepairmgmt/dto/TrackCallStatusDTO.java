package net.atos.motorrepairmgmt.dto;

import java.util.Collection;
import java.util.List;

public class TrackCallStatusDTO 
{
	private Long wlfwSubProcessId;
	
	private String motorSnNum;
	
	private String mlfbSpiridon;
	
	private String finalWarrantyState;
	
	private String materialSpecification;
	
	private Integer frameSize;
	
	private String subWarrantyType;
	
	private List<MilestoneListDTO>mileStoneList;

	
	 

	/**
	 * @return the frameSize
	 */
	public Integer getFrameSize() {
		return frameSize;
	}

	/**
	 * @param frameSize the frameSize to set
	 */
	public void setFrameSize(Integer frameSize) {
		this.frameSize = frameSize;
	}

	/**
	 * @return the subWarrantyType
	 */
	public String getSubWarrantyType() {
		return subWarrantyType;
	}

	/**
	 * @param subWarrantyType the subWarrantyType to set
	 */
	public void setSubWarrantyType(String subWarrantyType) {
		this.subWarrantyType = subWarrantyType;
	}

	/**
	 * @return the materialSpecification
	 */
	public String getMaterialSpecification() {
		return materialSpecification;
	}

	/**
	 * @param materialSpecification the materialSpecification to set
	 */
	public void setMaterialSpecification(String materialSpecification) {
		this.materialSpecification = materialSpecification;
	}

	/**
	 * @return the wlfwSubProcessId
	 */
	public Long getWlfwSubProcessId() {
		return wlfwSubProcessId;
	}

	/**
	 * @param wlfwSubProcessId the wlfwSubProcessId to set
	 */
	public void setWlfwSubProcessId(Long wlfwSubProcessId) {
		this.wlfwSubProcessId = wlfwSubProcessId;
	}

	/**
	 * @return the motorSnNum
	 */
	public String getMotorSnNum() {
		return motorSnNum;
	}

	/**
	 * @param motorSnNum the motorSnNum to set
	 */
	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}

	/**
	 * @return the mlfbSpiridon
	 */
	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}

	/**
	 * @param mlfbSpiridon the mlfbSpiridon to set
	 */
	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}

	/**
	 * @return the finalWarrantyState
	 */
	public String getFinalWarrantyState() {
		return finalWarrantyState;
	}

	/**
	 * @param finalWarrantyState the finalWarrantyState to set
	 */
	public void setFinalWarrantyState(String finalWarrantyState) {
		this.finalWarrantyState = finalWarrantyState;
	}

	/**
	 * @return the mileStoneList
	 */
	public List<MilestoneListDTO> getMileStoneList() {
		return mileStoneList;
	}

	/**
	 * @param mileStoneList the mileStoneList to set
	 */
	public void setMileStoneList(List<MilestoneListDTO> mileStoneList) {
		this.mileStoneList = mileStoneList;
	}

	

}
