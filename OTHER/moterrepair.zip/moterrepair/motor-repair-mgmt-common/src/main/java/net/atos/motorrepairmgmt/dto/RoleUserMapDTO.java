/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.util.Date;

/**
 * @author Sweety Kothari
 *
 */
public class RoleUserMapDTO {

	    private Long roleUserMapId;
	
		private String userName;
	
		private int enabled;
		
		private String createdBy;
		
		private String modifiedBy;
		
		private String deletedBy;
		
		private Date createdOn;
		
		private Date modifiedOn;
		
		private Date deletedOn;
		
		private Long referenceId;
		
		//1:ARC ,2: PARAS
		private Integer type;

		/**
		 * @return the referenceId
		 */
		public Long getReferenceId() {
			return referenceId;
		}

		/**
		 * @param referenceId the referenceId to set
		 */
		public void setReferenceId(Long referenceId) {
			this.referenceId = referenceId;
		}

		/**
		 * @return the userName
		 */
		public String getUserName() {
			return userName;
		}

		/**
		 * @param userName the userName to set
		 */
		public void setUserName(String userName) {
			this.userName = userName;
		}

		/**
		 * @return the enabled
		 */
		public int getEnabled() {
			return enabled;
		}

		/**
		 * @param enabled the enabled to set
		 */
		public void setEnabled(int enabled) {
			this.enabled = enabled;
		}

		/**
		 * @return the createdBy
		 */
		public String getCreatedBy() {
			return createdBy;
		}

		/**
		 * @param createdBy the createdBy to set
		 */
		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		/**
		 * @return the modifiedBy
		 */
		public String getModifiedBy() {
			return modifiedBy;
		}

		/**
		 * @param modifiedBy the modifiedBy to set
		 */
		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		/**
		 * @return the deletedBy
		 */
		public String getDeletedBy() {
			return deletedBy;
		}

		/**
		 * @param deletedBy the deletedBy to set
		 */
		public void setDeletedBy(String deletedBy) {
			this.deletedBy = deletedBy;
		}

		/**
		 * @return the createdOn
		 */
		public Date getCreatedOn() {
			return createdOn;
		}

		/**
		 * @param createdOn the createdOn to set
		 */
		public void setCreatedOn(Date createdOn) {
			this.createdOn = createdOn;
		}

		/**
		 * @return the modifiedOn
		 */
		public Date getModifiedOn() {
			return modifiedOn;
		}

		/**
		 * @param modifiedOn the modifiedOn to set
		 */
		public void setModifiedOn(Date modifiedOn) {
			this.modifiedOn = modifiedOn;
		}

		/**
		 * @return the deletedOn
		 */
		public Date getDeletedOn() {
			return deletedOn;
		}

		/**
		 * @param deletedOn the deletedOn to set
		 */
		public void setDeletedOn(Date deletedOn) {
			this.deletedOn = deletedOn;
		}

		/**
		 * @return the roleUserMapId
		 */
		public Long getRoleUserMapId() {
			return roleUserMapId;
		}

		/**
		 * @param roleUserMapId the roleUserMapId to set
		 */
		public void setRoleUserMapId(Long roleUserMapId) {
			this.roleUserMapId = roleUserMapId;
		}

		/**
		 * @return the type
		 */
		public Integer getType() {
			return type;
		}

		/**
		 * @param type the type to set
		 */
		public void setType(Integer type) {
			this.type = type;
		}

		
	}

