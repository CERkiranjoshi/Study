package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ElectricalObservationDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4880283304854224498L;

	private Long motorElecObsId;
	private Float meggerVolt;
	private Float phaseNEarthUE;
	private Float phaseNEarthVE;
	private Float phaseNEarthWE;
	private Float btwnPhasesUV;
	private Float btwnPhasesVW;
	private Float btwnPhasesWU;
	private Float windingResTemp;
	private Float windingResPhaseU;
	private Float windingResPhaseV;
	private Float windingResPhasew;

	/**
	 * @return the motorElecObsId
	 */
	public Long getMotorElecObsId() {
		return motorElecObsId;
	}

	/**
	 * @param motorElecObsId
	 *            the motorElecObsId to set
	 */
	public void setMotorElecObsId(Long motorElecObsId) {
		this.motorElecObsId = motorElecObsId;
	}

	/**
	 * @return the meggerVolt
	 */
	public Float getMeggerVolt() {
		return meggerVolt;
	}

	/**
	 * @param meggerVolt
	 *            the meggerVolt to set
	 */
	public void setMeggerVolt(Float meggerVolt) {
		this.meggerVolt = meggerVolt;
	}

	/**
	 * @return the phaseNEarthUE
	 */
	public Float getPhaseNEarthUE() {
		return phaseNEarthUE;
	}

	/**
	 * @param phaseNEarthUE
	 *            the phaseNEarthUE to set
	 */
	public void setPhaseNEarthUE(Float phaseNEarthUE) {
		this.phaseNEarthUE = phaseNEarthUE;
	}

	/**
	 * @return the phaseNEarthVE
	 */
	public Float getPhaseNEarthVE() {
		return phaseNEarthVE;
	}

	/**
	 * @param phaseNEarthVE
	 *            the phaseNEarthVE to set
	 */
	public void setPhaseNEarthVE(Float phaseNEarthVE) {
		this.phaseNEarthVE = phaseNEarthVE;
	}

	/**
	 * @return the phaseNEarthWE
	 */
	public Float getPhaseNEarthWE() {
		return phaseNEarthWE;
	}

	/**
	 * @param phaseNEarthWE
	 *            the phaseNEarthWE to set
	 */
	public void setPhaseNEarthWE(Float phaseNEarthWE) {
		this.phaseNEarthWE = phaseNEarthWE;
	}

	/**
	 * @return the btwnPhasesUV
	 */
	public Float getBtwnPhasesUV() {
		return btwnPhasesUV;
	}

	/**
	 * @param btwnPhasesUV
	 *            the btwnPhasesUV to set
	 */
	public void setBtwnPhasesUV(Float btwnPhasesUV) {
		this.btwnPhasesUV = btwnPhasesUV;
	}

	/**
	 * @return the btwnPhasesVW
	 */
	public Float getBtwnPhasesVW() {
		return btwnPhasesVW;
	}

	/**
	 * @param btwnPhasesVW
	 *            the btwnPhasesVW to set
	 */
	public void setBtwnPhasesVW(Float btwnPhasesVW) {
		this.btwnPhasesVW = btwnPhasesVW;
	}

	/**
	 * @return the btwnPhasesWU
	 */
	public Float getBtwnPhasesWU() {
		return btwnPhasesWU;
	}

	/**
	 * @param btwnPhasesWU
	 *            the btwnPhasesWU to set
	 */
	public void setBtwnPhasesWU(Float btwnPhasesWU) {
		this.btwnPhasesWU = btwnPhasesWU;
	}

	/**
	 * @return the windingResTemp
	 */
	public Float getWindingResTemp() {
		return windingResTemp;
	}

	/**
	 * @param windingResTemp
	 *            the windingResTemp to set
	 */
	public void setWindingResTemp(Float windingResTemp) {
		this.windingResTemp = windingResTemp;
	}

	/**
	 * @return the windingResPhaseU
	 */
	public Float getWindingResPhaseU() {
		return windingResPhaseU;
	}

	/**
	 * @param windingResPhaseU
	 *            the windingResPhaseU to set
	 */
	public void setWindingResPhaseU(Float windingResPhaseU) {
		this.windingResPhaseU = windingResPhaseU;
	}

	/**
	 * @return the windingResPhaseV
	 */
	public Float getWindingResPhaseV() {
		return windingResPhaseV;
	}

	/**
	 * @param windingResPhaseV
	 *            the windingResPhaseV to set
	 */
	public void setWindingResPhaseV(Float windingResPhaseV) {
		this.windingResPhaseV = windingResPhaseV;
	}

	/**
	 * @return the windingResPhasew
	 */
	public Float getWindingResPhasew() {
		return windingResPhasew;
	}

	/**
	 * @param windingResPhasew
	 *            the windingResPhasew to set
	 */
	public void setWindingResPhasew(Float windingResPhasew) {
		this.windingResPhasew = windingResPhasew;
	}

}
