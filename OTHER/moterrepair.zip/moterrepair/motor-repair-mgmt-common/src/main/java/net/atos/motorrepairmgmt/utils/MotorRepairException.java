/**
 * 
 */
package net.atos.motorrepairmgmt.utils;

/**
 * @author a529421
 *
 */
public class MotorRepairException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 404486716464264025L;
	
	public static final String INPUT_ERR = "INPUT_ERR";
	public static final String PROCESS_ERR = "PROCESS_ERR";
	public static final String EXCEPTION_ERR = "EXCEPTION_ERR";
	// public static final String INPUT_ERR = "INPUT_ERR";

	private String errCode;
	private String errMsg;
	private String errCause;

	public MotorRepairException(String errCode, String errMsg, String errCause) {
		super();
		this.errCode = errCode;
		this.errMsg = errMsg;
		this.errCause = errCause;
	}

	@Override
	public String toString() {
		return "MotorRepairException [errCode=" + errCode + ", errMsg=" + errMsg + ", errCause=" + errCause + "]";
	}

}
