/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author a545466
 *
 */
public class RMTTaskLogDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2779991436650594557L;

	private String taskCode;
	
	private String taskName;
	
	private String userName;
	
	private List<RMTCommentDTO> comments; 
	
	private List<RMTAuditDTO> auditLogs;
	
	private String milestone;
	
	private String assignedOn;
	
	private String ownedOn;
	
	private String closedOn;
	
	private Integer escalationLevel;
	
	private String assignedPriority;
	
	private String ownedPriority;
	
	private String closedPriority;
	
	private Long parallelProcessId;
	
	private String group;
	
	private String taskId;
	
	private boolean isCustomerNotified;
	
	

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the comments
	 */
	public List<RMTCommentDTO> getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(List<RMTCommentDTO> comments) {
		this.comments = comments;
	}

	/**
	 * @return the auditLogs
	 */
	public List<RMTAuditDTO> getAuditLogs() {
		return auditLogs;
	}

	/**
	 * @param auditLogs the auditLogs to set
	 */
	public void setAuditLogs(List<RMTAuditDTO> auditLogs) {
		this.auditLogs = auditLogs;
	}

	/**
	 * @return the milestone
	 */
	public String getMilestone() {
		return milestone;
	}

	/**
	 * @param milestone the milestone to set
	 */
	public void setMilestone(String milestone) {
		this.milestone = milestone;
	}

	/**
	 * @return the assignedOn
	 */
	public String getAssignedOn() {
		return assignedOn;
	}

	/**
	 * @param assignedOn the assignedOn to set
	 */
	public void setAssignedOn(String assignedOn) {
		this.assignedOn = assignedOn;
	}

	/**
	 * @return the ownedOn
	 */
	public String getOwnedOn() {
		return ownedOn;
	}

	/**
	 * @param ownedOn the ownedOn to set
	 */
	public void setOwnedOn(String ownedOn) {
		this.ownedOn = ownedOn;
	}

	/**
	 * @return the closedOn
	 */
	public String getClosedOn() {
		return closedOn;
	}

	/**
	 * @param closedOn the closedOn to set
	 */
	public void setClosedOn(String closedOn) {
		this.closedOn = closedOn;
	}

	/**
	 * @return the escalationLevel
	 */
	public Integer getEscalationLevel() {
		return escalationLevel;
	}

	/**
	 * @param escalationLevel the escalationLevel to set
	 */
	public void setEscalationLevel(Integer escalationLevel) {
		this.escalationLevel = escalationLevel;
	}

	/**
	 * @return the taskCode
	 */
	public String getTaskCode() {
		return taskCode;
	}

	/**
	 * @param taskCode the taskCode to set
	 */
	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}

	/**
	 * @return the assignedPriority
	 */
	public String getAssignedPriority() {
		return assignedPriority;
	}

	/**
	 * @param assignedPriority the assignedPriority to set
	 */
	public void setAssignedPriority(String assignedPriority) {
		this.assignedPriority = assignedPriority;
	}

	/**
	 * @return the ownedPriority
	 */
	public String getOwnedPriority() {
		return ownedPriority;
	}

	/**
	 * @param ownedPriority the ownedPriority to set
	 */
	public void setOwnedPriority(String ownedPriority) {
		this.ownedPriority = ownedPriority;
	}

	/**
	 * @return the closedPriority
	 */
	public String getClosedPriority() {
		return closedPriority;
	}

	/**
	 * @param closedPriority the closedPriority to set
	 */
	public void setClosedPriority(String closedPriority) {
		this.closedPriority = closedPriority;
	}

	/**
	 * @return the parallelProcessId
	 */
	public Long getParallelProcessId() {
		return parallelProcessId;
	}

	/**
	 * @param parallelProcessId the parallelProcessId to set
	 */
	public void setParallelProcessId(Long parallelProcessId) {
		this.parallelProcessId = parallelProcessId;
	}

	/**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the isCustomerNotifed
	 */
	public boolean getIsCustomerNotified() {
		return isCustomerNotified;
	}

	/**
	 * @param isCustomerNotifed the isCustomerNotifed to set
	 */
	public void setIsCustomerNotified(boolean isCustomerNotified) {
		this.isCustomerNotified = isCustomerNotified;
	}
	
	
}
