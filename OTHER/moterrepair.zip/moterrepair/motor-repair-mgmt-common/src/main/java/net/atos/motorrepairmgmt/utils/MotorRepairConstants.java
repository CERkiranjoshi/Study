/**
 * 
 */
package net.atos.motorrepairmgmt.utils;

/**
 * @author a593775
 * 
 */
public class MotorRepairConstants {

	public static enum SUBPROC_STATE {
		SUBPROC_STATE_INITIAL(1);
		private int value;
		

		SUBPROC_STATE(int value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

	};

	public static enum BENCHMARK_STATE {

		// START & END for notification only
		ASSIGNED(1), OWNED(2), COMPLETED(3), RECALLED(4), RECLAIMED(5), RECLAIMED_WORKFLOW(6), REASSIGNED(7), REJECTED(
				8), START(9), END(10), CLOSE_WORKFLOW(11),CUSTOMER_NOTIFICATION(12);
		// ASSIGNED: ASSIGNED TO GROUP ,OWNED:CLAIMED
		private int value;

		BENCHMARK_STATE(int value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

	};
	
	public static enum SEVERITY {

		// START & END for notification only
		HIGH(2), MEDIUM(1), NORMAL(0);
		// ASSIGNED: ASSIGNED TO GROUP ,OWNED:CLAIMED
		private int value;

		SEVERITY(int value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

	};

	public static enum NOTIFICATION_TYPE {
		EMAIL(1), SMS(2), EMAILNSMS(3);
		// ASSIGNED: ASSIGNED TO GROUP ,OWNED:CLAIMED
		private int value;

		NOTIFICATION_TYPE(int value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

	};

	/**
	 * Flags indicating Milestone enabled state
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum FUNCTION_MILESTONE_FLAG {
		TRUE(1), FALSE(0);

		private int value;

		private FUNCTION_MILESTONE_FLAG(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

	}

	/**
	 * Flags indicating function enabled state
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum FUNCTION_ENABLED_FLAG {
		TRUE(1), FALSE(0);

		private int value;

		private FUNCTION_ENABLED_FLAG(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

	}

	/**
	 * Flags indicating function sla state. State of SLA - 0: within SLA; 1: Warning State; 2: Escalated
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum FUNCTION_SLA_STATE {
		IN_SLA(0), WARN_SLA(1), ESCALACTED_SLA(2);

		private int value;

		private FUNCTION_SLA_STATE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

	}

	/**
	 * 
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum SCHEDULER_TYPES {
		TTO(1), TTR(2), TTH(3), RECEIVE_MOTOR(4);

		private int value;

		private SCHEDULER_TYPES(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return Based on enum value
		 */
		public int getValue() {
			return value;
		}
		
		
		public static SCHEDULER_TYPES getSchedulerType(int type) {
			switch (type) {
				case 1:
					return TTO;
				case 2:
					return TTR;
				case 3:
					return TTH;
				case 4:
					return RECEIVE_MOTOR;

				default:
					break;
			}
			return null;
		}

	}

	/**
	 * Flags indicating function sla state. State of SLA - 0: within SLA; 1: Warning State; 2: Escalated
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum CHECK_ACCEPT_STATE {
		ACCEPT("ACCEPT"), REJECT("REJECT"), RECALLED("RECALLED"), RECLAIM_WORKFLOW("RECLAIM_WORKFLOW");

		private String value;

		private CHECK_ACCEPT_STATE(String value) {
			this.value = value;
		}

		/**
		 * 
		 * @return based on enum value
		 */
		public String getValue() {
			return value;
		}

	}

	public static enum ORDER_STATUS {
		OPEN(1), CLOSE(0);
		// ASSIGNED: ASSIGNED TO GROUP ,OWNED:CLAIMED
		private int value;

		ORDER_STATUS(int value) {
			this.value = value;
		}

		/**
		 * @return the value
		 */
		public int getValue() {
			return value;
		}

	};

	/**
	 * Flags indicating function escalation state. State of Escalation - 1: TTO; 2: TTR; 3: TTH etc
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum ESCALATION_STATE {
		TTO(1), TTR(2), TTH(3);

		private int value;

		private ESCALATION_STATE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}
	}
	
	

	/**
	 * Flags for warranty sub type
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum WARRANTY_SUB_TYPE {
		VOID(2),CTS(3), PRODUCT_WARRANTY(4), REPAIR_WARRANTY(5), COST_TO_SALES(6),  COMPREHENSIVE_CONTRACT(7), NON_COMPREHENSIVE_CONTRACT(8),PAID(9);

		private int value;

		private WARRANTY_SUB_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static WARRANTY_SUB_TYPE of(int value) {

			switch (value) {
				case 2:
					return VOID;
				case 3:
					return CTS;
				case 4:
					return PRODUCT_WARRANTY;
				case 5:
					return REPAIR_WARRANTY;
				case 6:
					return COST_TO_SALES;
				case 7:
					return COMPREHENSIVE_CONTRACT;
				case 8:
					return NON_COMPREHENSIVE_CONTRACT;
				case 9:
					return PAID;
				default:
					return null;

			}
		}
	}
	
	/**
	 * Flags for TS support decision
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum TS_SUPPORT_DECISION {

		DEFAULT(0),CALL_CLOSURE_POST_CUST_CALL(1),DISPATCH_ONLY_SPARES(2),FS_VISIT_WITH_SPARES(3),ASSIGN_ARC(4),ASSIGN_FSE(5),FSE_REVISIT(6);
		private int value;

		private TS_SUPPORT_DECISION(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static TS_SUPPORT_DECISION of(int value) {

			switch (value) {
				case 0:
					return DEFAULT;
				case 1:
					return CALL_CLOSURE_POST_CUST_CALL;
				case 2:
					return DISPATCH_ONLY_SPARES;
				case 3:
					return FS_VISIT_WITH_SPARES;
				case 4:
					return ASSIGN_ARC;
				case 5:
					return ASSIGN_FSE;
				case 6:
					return FSE_REVISIT;
				default:
					return null;

			}
		}
	}
	

	/**
	 * Flags for Flow type
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum FLOW_TYPE {

		FS("FS"),REPAIRS("REPAIRS"),REPLACEMENT("REPLACEMENT");
		private String value;

		private FLOW_TYPE(String value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public String getValue() {
			return value;
		}

	}
	
	/**
	 * Flags for FS VISIT TYPE
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum FS_VISIT_TYPE {

		INITIAL_INSPECTION(0),FS_VISIT_WITH_SPARES(1),FS_VISIT_WITHOUT_SPARES(2);
		private int value;

		private FS_VISIT_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

	}

	
	/**
	 * Flags for warranty sub type
	 * 
	 * @author Sweety Kothari
	 * 	 0:Completed,1:IN-EXEC; 2:
	 *   RESOLVED_CLOSURE; 3: CUSTOMER_DECLINED; 4: SHORT_CLOSED; 5:
	 *   DUPLICATED; 6: WRONGLY_CREATED
	 */
	public static enum SUBPROCESS_STATE {
		COMPLETED(0),IN_EXEC(1), RESOLVED_CLOSURE(2), CUST_DECLINED(3), SHORT_CLOSED(4),  DUPLICATED(5), WRONGLY_CREATED(6);
	
		private int value;

		private SUBPROCESS_STATE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static SUBPROCESS_STATE of(int value) {

			switch (value) {
				case 0:
					return COMPLETED;
				case 1:
					return IN_EXEC;
				case 2:
					return RESOLVED_CLOSURE;
				case 3:
					return CUST_DECLINED;
				case 4:
					return SHORT_CLOSED;
				case 5:
					return DUPLICATED;
				case 6:
					return WRONGLY_CREATED;
				
				default:
					return null;

			}
		}
	}
	
	

	/**
	 * Flags for WORKFLOW_CLOSURE_TYPE	 * 
	 * @author Sweety Kothari
	 * 	 0:Completed,1:IN-EXEC; 2:
	 *   RESOLVED_CLOSURE; 3: CUSTOMER_DECLINED; 4: SHORT_CLOSED; 5:
	 *   DUPLICATED; 6: WRONGLY_CREATED
	 */
	public static enum WORKFLOW_CLOSURE_TYPE {
		COMPLETED(0),IN_EXEC(1), RESOLVED_CLOSURE(2), CUST_DECLINED(3), SHORT_CLOSED(4),  DUPLICATED(5), WRONGLY_CREATED(6);
	
		private int value;

		private WORKFLOW_CLOSURE_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or o based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static WORKFLOW_CLOSURE_TYPE of(int value) {

			switch (value) {
				case 0:
					return COMPLETED;
				case 1:
					return IN_EXEC;
				case 2:
					return RESOLVED_CLOSURE;
				case 3:
					return CUST_DECLINED;
				case 4:
					return SHORT_CLOSED;
				case 5:
					return DUPLICATED;
				case 6:
					return WRONGLY_CREATED;
				
				default:
					return null;

			}
		}
	}
	
	/**
	 * Flags for comment type
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum COMMENT_TYPE {
		INTERNAL(0), EXTERNAL(1), APPROVE_COMMENT(2), REJECTION_COMMENT(3), RECOMMENDATION_TO_ARC(4), REASSIGNMENT_COMMENT(
				5), COMMENT_FOR_CUST(6), COMMENT_FOR_ARC(7),CUST_VISIT_COMMENT(8),NEGOITIATE_WITH_CUST(9);

		private int value;

		private COMMENT_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or 0 based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static COMMENT_TYPE of(int value) {
			switch (value) {
				case 0:
					return INTERNAL;
				case 1:
					return EXTERNAL;
				case 2:
					return APPROVE_COMMENT;
				case 3:
					return REJECTION_COMMENT;
				case 4:
					return RECOMMENDATION_TO_ARC;
				case 5:
					return REASSIGNMENT_COMMENT;
				case 6:
					return COMMENT_FOR_CUST;
				case 7:
					return COMMENT_FOR_ARC;
				case 8:
					return CUST_VISIT_COMMENT;
				case 9:
					return NEGOITIATE_WITH_CUST;
				default:
					return null;

			}
		}
	}

	/**
	 * Flags for warranty type
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum WARRANTY_TYPE {
		IN_WARRANTY(1), WARRANTY_VOID(0);

		private int value;

		private WARRANTY_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or 0 based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static WARRANTY_TYPE of(int value) {
			switch (value) {
				case 1:
					return IN_WARRANTY;
				case 0:
					return WARRANTY_VOID;

				default:
					return null;

			}
		}
	}

	public static enum ORDER_TYPE {
		SERVICES(1), SALES(2);

		private int value;

		private ORDER_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or 0 based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static ORDER_TYPE of(int value) {
			switch (value) {
				case 1:
					return SALES;
				case 0:
					return SALES;

				default:
					return null;

			}
		}
	}

	public static enum SERVICE_TYPE {
		FS(1), REPAIRS(2),REPAIRS_REPLACEMENT(3);

		private int value;

		private SERVICE_TYPE(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or 0 based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static SERVICE_TYPE of(int value) {
			switch (value) {
				case 1:
					return FS;
				case 2:
					return REPAIRS;
				case 3:
					return REPAIRS_REPLACEMENT;

				default:
					return null;

			}
		}
	}

	/**
	 * Flags for customer type
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum CUST_TYPE {
		END_CUSTOMER("1"), CHANNEL_PARTNER("2"), DEALER_DETAIL("3");

		private String value;

		private CUST_TYPE(String value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either 1 or 0 based on enum value
		 */
		public String getValue() {
			return value;
		}

	}

	/**
	 * Flags for report status
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum REPORT_STATUS {
		
		
		
//		0;"UNDER_REVIEW"
//		1;"APPROVED"
//		2;"REJECTED"
//		3;"REFERRED_TO_TS"
//		3;"UNDER_REVIEW"
//		4;"APPROVED"
//		5;"REJECTED"

		UNDER_REVIEW("UNDER_REVIEW"), APPROVE("APPROVE"), REJECT("REJECT"), TSREVIEW("TSREVIEW"),REFER_TO_PARAS("REFER_TO_PARAS");

		private String value;

		private REPORT_STATUS(String value) {
			this.value = value;
		}

		/**
		 * 
		 * @return value based on enum value
		 */
		public String getValue() {
			return value;
		}

		public static REPORT_STATUS of(int value) {
			switch (value) {
				case 0:
					return UNDER_REVIEW;
				case 1:
					return APPROVE;
				case 2:
					return REJECT;
				case 3:
					return TSREVIEW;
				case 4:
					return APPROVE;
				case 5:
					return REJECT;
				case 6:
					return REFER_TO_PARAS;
				case 7:
					return REFER_TO_PARAS;
				default:
					return null;

			}
		}
	}

	/**
	 * Values for Parallel Process Types: A: Parallel Process A; B: Parallel Process B
	 * 
	 * @author Anand Ved
	 * 
	 */
	public static enum PARALLEL_PROCESS_TYPES {
		A("A"), B("B"), C("C"), D("D");

		private String value;

		private PARALLEL_PROCESS_TYPES(String value) {
			this.value = value;
		}

		/**
		 * 
		 * @return either "A" or "B" based on value
		 */
		public String getValue() {
			return value;
		}
	}

	/**
	 * Flags for CUSTOMER STATUS VISIBLITY
	 * 
	 * @author Sweety Kothari
	 * 
	 */
	public static enum CUSTOMER_STATUS_VISIBLITY {
		INTIAL_DEFAULT_VISIBLE_STATE(1), IN_WARRANTY_FS(2), IN_WARRANTY_REPAIRS(4), WARRANTY_VOID_FS(8),

		WARRANTY_VOID_REPAIRS(16), IN_WARRANTY_FS_REPAIRS(32), WARRANTY_VOID_FS_REPAIRS(64),IN_WARRANTY_REPLACEMENT(128);

		private int value;

		private CUSTOMER_STATUS_VISIBLITY(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return value based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static CUSTOMER_STATUS_VISIBLITY of(String value) {
			if (value.equals(INTIAL_DEFAULT_VISIBLE_STATE.toString())) {
				return INTIAL_DEFAULT_VISIBLE_STATE;
			} else if (value.equals(IN_WARRANTY_FS.toString())) {
				return IN_WARRANTY_FS;
			} else if (value.equals(IN_WARRANTY_REPAIRS.toString())) {
				return IN_WARRANTY_REPAIRS;
			} else if (value.equals(WARRANTY_VOID_FS.toString())) {
				return WARRANTY_VOID_FS;
			} else if (value.equals(WARRANTY_VOID_REPAIRS.toString())) {
				return WARRANTY_VOID_REPAIRS;
			} else if (value.equals(IN_WARRANTY_FS_REPAIRS.toString())) {
				return IN_WARRANTY_FS_REPAIRS;
			} else  if (value.equals(WARRANTY_VOID_FS_REPAIRS.toString())) {
				return WARRANTY_VOID_FS_REPAIRS;

			}
			else{
				return IN_WARRANTY_REPLACEMENT;
			}
		}
	}

	public static enum TASK_PRIORITY {
		HIGH("1"), MEDIUM("2"), LOW("3");

		private String value;

		private TASK_PRIORITY(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	public static enum SALES_TYPE {
		DIV(2), GROUP(3), OFFICE(4), ORG(1);

		private int value;

		private SALES_TYPE(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
	}

	/**
	 * Notification types used in EmailTemplates
	 * @author Anand Ved
	 * 
	 */
	public static enum TASK_NOTIFY_TYPE {
		NEW_TASK(1), TASK_WARN(2), TASK_ESCALATION(3), OTHER(4), NOTIFY(5), MOTOR_NOT_RECEIVED(6), PO_NOT_RECEIVED(7), CCL_NOT_RECEIVED(8);

		private int value;

		private TASK_NOTIFY_TYPE(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
		
		public static TASK_NOTIFY_TYPE of(int value) {

			switch (value) {
				case 1:
					return NEW_TASK;
				case 2:
					return TASK_WARN;
				case 3:
					return TASK_ESCALATION;
				case 4:
					return OTHER;
				case 5:
					return NOTIFY;
				case 6:
					return MOTOR_NOT_RECEIVED;
				case 7:
					return PO_NOT_RECEIVED;
				case 8:
					return CCL_NOT_RECEIVED;
				
				default:
					return null;

			}
	}
	}

	/**
	 * Notification Template Types
	 * @author Anand Ved
	 *
	 */
	public static enum TEMPLATE_TYPE {
		EMAIL(1), SMS(2);
		
		private int value;
		
		private TEMPLATE_TYPE(int value) {
			this.value = value;
		}
		
		public int getValue() {
			return value;
		}
	}
	
	public static enum CUSTOMER_STATUS_VISIBLITY_SET {

		IN_WARRANTY_REPAIRS_FS(32), WARRANTY_VOID_REPAIRS_FS(64);

		private int value;

		private CUSTOMER_STATUS_VISIBLITY_SET(int value) {
			this.value = value;
		}

		/**
		 * 
		 * @return value based on enum value
		 */
		public int getValue() {
			return value;
		}

		public static CUSTOMER_STATUS_VISIBLITY_SET of(String value) {
			if (value.equals(IN_WARRANTY_REPAIRS_FS.toString())) {
				return IN_WARRANTY_REPAIRS_FS;
			} else {
				return WARRANTY_VOID_REPAIRS_FS;
			}

		}
	}

	public static final String IN_EXEC = "IN_EXEC";
	public static final String COMPLETED = "COMPLETED";

	// workflow code
	public static final String ARC_ASSIGNMENT_CODE = "CCC_UC_R1_007";
	public static final String CCCRECLAIM_CODE = "CCC_RECLAIM";

	public static final String CCC_NEW_SERVICE_FOR_MOTOR = "CCC_UC_R1_004";
	public static final String CCC_NEW_SERVICE_REC_MOTOR = "CCC_UC_R1_005";
	public static final String SYS_MULTIPLE_WORKFLOW = "SYS_UC_R1_075";

	public static final String TECH_SUPPORT_WORKFLOW = "TECH_SUPPORT_WORKFLOW";
	public static final String TICKET_REF_NO = "ticketReferenceNumber";
	public static final String STATUS = "status";
	public static final String MOTOR_SN_NO = "motorSerialNumber";
	public static final String DATE_EMAIL = "date";
	public static final String EMAIL_CODE = "EMAIL";
	public static final String SMS_CODE = "SMS";
	public static final String CUST_NAME = "customerName";
	public static final int ENABLE = 1;
	public static final int VISIBLE = 1;
	
	// ------------------------------------ FUNCTION CODES -----------------------------------------
	
	public static final String CCC_B_N_D_REPORT_APPROVAL = "CCC_UC_R1_009";
	public static final String CCC_SITE_INSPECTION_N_A_REPORT_APPROVAL = "CCC_UC_R2_008";
	public static final String CCC_PREPARES_SPARES = "CCC_UC_R1_010";
	public static final String CCC_LINK_ORDER_INT_SPARES = "CCC_UC_R1_011";
	public static final String CCC_CS_SALES_ORDER = "CCC_UC_R1_012";
	public static final String CCC_CTS_CLERANCE = "CCC_UC_R2_013";
	public static final String CCC_C_REPORT_APPROVAL = "CCC_UC_R1_014";
	public static final String CCC_CLEARANCE_TO_ARC_DISPATCH = "CCC_UC_R1_015";
	public static final String CCC_CLEARANCE_TO_LC_DISPATCH = "CCC_UC_R1_016";
	public static final String CCC_CONFIRM_SPARES_RECEIPT = "CCC_UC_R2_017";
	public static final String CCC_CREATE_DI_OUTBOUND_SALES_ORDER = "CCC_UC_R1_018";
	public static final String CCC_LINKED_ORDER_CLOSURE = "CCC_UC_R1_019";
	public static final String CCC_CLOSURE_VERIFY_CUST = "CCC_UC_R1_020";
	public static final String CCC_MOTOR_NOT_RECEIVED_MUL_NOTIFY = "CCC_UC_R2_022";
	public static final String CCC_RECLAIMED_TASK = "CCC_UC_R1_023";
	//public static final String CCC_MOTOR_REPLACEMENT_DECISION = "CCC_UC_R1_070";
	//public static final String CCC_MARK_WARRANTY_VOID_REPLACEMENT="CCC_UC_R1_063";
	
	public static final String TS_CUST_SUPPORT = "TS_UC_R1_025";
	public static final String TS_REVIEW_SITE_INSPECTION_N_A_REPORT_APPROVAL = "TS_UC_R2_026";
	public static final String TS_REVIEW_B_N_D_REPORT = "TS_UC_R1_027";
	public static final String TS_REVIEW_N_UPDATE_SPARES = "TS_UC_R1_028";
	public static final String TS_REVIEW_C_REPORT = "TS_UC_R1_029";
	//public static final String TS_REVIEW_MOTOR_REPLACEMENT_DECISION = "TS_UC_R1_029";
	//public static final String TS_MARK_WARRANTY_VOID_REPLACEMENT ="TS_UC_R1_064";
	
	//public static final String ARC_DISPATCH_MOTOR_FOR_REPLACEMENT="ARC_UC_R1_065";
	public static final String ARC_CHK_CUST_AVAIL = "ARC_UC_R2_031";
	public static final String ARC_SITE_A_REPORT_UPLOAD = "ARC_UC_R2_032";
	public static final String ARC_RECEIVE_MOTOR_WITH_GSP = "ARC_UC_R1_033";
	public static final String ARC_RECEIVE_MOTOR_WITHOUT_GSP = "ARC_UC_R1_034";
	public static final String ARC_BEGIN_INSPECTION = "ARC_UC_R1_035";
	public static final String ARC_BEGIN_REPAIRS_N_CONFIRM_SPARES_RECEIPT = "ARC_UC_R1_036";
	public static final String ARC_SUBMIT_C_REPORT = "ARC_UC_R1_037";
	public static final String ARC_DISPATCH_MOTOR = "ARC_UC_R1_038";
	
	public static final String QC_SEND_QUOTE = "QC_UC_R2_040";
	
	public static final String RCS_NEGOTIATE_CUST = "RCSBA_UC_R2_042";
	public static final String RCS_RECEIVE_CUST_PO = "RCSBA_UC_R2_043";
	public static final String RCS_PROVIDE_CCL = "RCSBA_UC_R2_044";
	public static final String RCS_PERFORMA_INVOICE = "RCSBA_UC_R2_045";
	public static final String RCS_RECEIVE_PAYMENT = "RCSBA_UC_R2_046";
	
	public static final String OEC_PROCESS_SPARES_PROCURMENT = "OEC_UC_R1_048";
	
	public static final String LC_RECEIVE_SPARES = "LC_UC_R1_050";
	public static final String LC_DISPATCH_SPARES = "LC_UC_R1_051";
	public static final String LC_RECEIVE_N_DISPATCH_SPARES = "LC_UC_R1_074";
	
	public static final String SYS_ESCALATION = "SYS_UC_R2_058";
	public static final String SYS_CONSOLIDATION = "SYS_UC_R2_059";
	public static final String SYS_BEGIN_PARALLEL_PROCESS = "SYS_UC_R1_060";
	public static final String SYS_END_PARALLEL_PROCESS = "SYS_UC_R1_061";
	public static final String SYS_NOTIFICATION = "SYS_UC_R1_062";
	
	public static final String SYSTEM_USER = "SYSTEM_USER";
	public static final String SYSTEM_CONSOLIDATION = "SYSTEM_CONSOLIDATION";
	
	//PARAS RELATED FUNCTION CODE
	//public static final String PARAS_CONFIRM_MOTOR_RECEIPT = "PARAS_UC_R1_066";
	public static final String ARC_VIEW_MOTOR_DETAIL_N_PROCESS_REPLACEMENT = "ARC_UC_R1_067";
	//public static final String PARAS_DISPATCH_REPLACED_MOTOR = "PARAS_UC_R1_068";
	//public static final String PARAS_REVIEW_B_N_D_REPORT_N_PROCESS_FOR_REPLACEMENT = "PARAS_UC_R1_068";
	
	public static final String TENANT_ID = "SIEMENS";
	public static final String PROGRAM_ID = "1";
	public static final String SMTP_SERVER = "SMTP_SERVER";
	public static final String SMTP_HOST = "HOST";
	public static final String SMTP_PORT = "PORT";
	public static final String IS_SECURED = "IS_SECURED";
	public static final String PROXY_ENABLED = "PROXY_ENABLED";
	public static final String PROXY_HOST = "PROXY_HOST";
	public static final String PROXY_PORT = "PROXY_PORT";
	public static final String USER_CREDS_REQ = "USER_CREDS_REQ";
	public static final String SMTP_USER = "SMTP_USER";
	public static final String SMTP_PASSWORD = "SMTP_PASSWORD";
	
	public static final String TEMPLATE_CODE = "templateCode";
    public static final String NOTIFY_TYPE = "NOTIFY_TYPE";
    public static final String ATTACHMENT_TYPE = "ATTACHMENT_TYPE";
	public static final String ARC = "ARC";
	public static final String FS_ASSIGNMENT = "CCC_UC_R2_006";

	public static final String ASSIGNMENT_EMAIL_CONFIG_TYPE = "NOTIFICATIONS";
	public static final String ASSIGNMENT_EMAIL_CONFIG_SUBTYPE = "TASK_ASSIGN_EMAILS";
	public static final String CCC_USER = "CCC";
	
	public static final String FRAME_SIZE_1 = "FRAME_SIZE_1";
	public static final String FRAME_SIZE_2 = "FRAME_SIZE_2";
	public static final String PARAS_ARC_TYPE = "PARAS_ARC_TYPE";
	public static final String FRAME_SIZE_LIMIT = "FRAME_SIZE_LIMIT";
	
	public static final String SYSTEM_CONFIG = "SYSTEM_CONFIG";
	public static final String NOTIFICATIONS = "NOTIFICATIONS";
	public static final String MAIL_NOTIFICATIONS_ENABLED="EMAIL_NOTIFICATIONS_ENABLED";
	public static final String SMS_NOTIFICATIONS_ENABLED="SMS_NOTIFICATIONS_ENABLED";

	public static final String REPLY_TO_ADDRESS ="REPLY_TO_ADDRESS";
	public static final String GSP_REFERNCE_TEXT="#$GSP_REFERENCE$#"; 
	public static final String USER_NAME="userName";
    public static final String SMS_SERVER_DETAIL="SMS_SERVER_DETAIL";
    
	public static final String SEND_FOR_APPROVAL_FLAG = "SEND_FOR_APPROVAL_FLAG";
    public static final String PRE_APPROVAL_FUNC_CODE="PRE_APPROVAL_FUNC_CODE";
    public static final String POST_APPROVAL_FUNC_CODE="POST_APPROVAL_FUNC_CODE";
    
    
    
    //SMS server configuration
	public static enum SMS_SERVER_CONFIG {
		SMS_URL("SMS_URL"), SMS_JSON("SMS_JSON"),SMS_USER_NAME("SMS_USER_NAME"),SMS_USER_PASSWORD("SMS_USER_PASSWORD"),SMS_FEED_ID("SMS_FEED_ID"),PHONE_NO("PHONE_NO"),DESCRIPTION("DESCRIPTION");
	    private String value;
		private SMS_SERVER_CONFIG(String value) {
			this.value = value;
		}
		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}
	}
	public static final String BASE_LOCATION="BASE_LOCATION";
	public static final String CSV_DOWNLOAD="CSV_DOWNLOAD";
	public static final String ARC_BEGIN_REPAIRS = "ARC_UC_R1_076";
	//public static final String ARC_BEGIN_REPAIRS = "ARC_UC_R1_036";
	public static final String ARC_CONFIRM_SPARES_RECEIPT = "ARC_UC_R1_077";
	
	public static final Integer MAX_QTY = 10;
	//Management Related Function Code
	public static final String MGMT_View_Ticket_Status_Based_On_GSP_Reference = "MGMT_UC_R1_053";

	//Approvers Related Function Code
	public static final String APP_APPROVAL_CLEARANCE = "APP_UC_R2_054";
	
	//Super Admin Related Function Code
	public static final String SUPADM_View_Ticket_Status_Based_On_GSP_Reference = "SUPADM_UC_R1_055";
	public static final String SUPADM_View_Workflow_Data_From_View_Ticket_Status_Screen = "SUPADM_UC_R2_056";
	public static final String SUPADM_Configuration_Screens = "SUPADM_UC_R2_057";
	public static final String SUPADM_SLA_And_Escalation = "SUPADM_UC_R1_078";
	
	//Customer Related Function Code
	public static final String CUST_Track_Service_Call_Status = "CUST_UC_R1_002";
	public static final String ATTACHMENT = "ATTACHMENT";
	public static final int TRUE = 1;
	public static final int FALSE = 0;
	public static final String HELPLINE_NUMBER = "HELPLINE_NUMBER";
	public static final String HELPLINE_EMAIL = "HELPLINE_EMAIL";
	/**
	 * Notification Template Types
	 * @author Anand Ved
	 *
	 */
	public static enum RECEIPIENT_TYPE {
		CUSTOMER(1), ARC(2),SIEMENS(3);
		
		private int value;
		
		private RECEIPIENT_TYPE(int value) {
			this.value = value;
		}
		
		public int getValue() {
			return value;
		}
	}
	
	public static final String ASSIGNED_TO_GROUP="ASSIGNED_TO_GROUP";
	public static final String ASSIGNED_TO = "ASSIGNED_TO";
	public static final String ASSIGNED_TO_EMAIL = "ASSIGNED_TO_EMAIL";
	public static final String ARC_NAME = "arcName";
	public static final String ARC_ADDRESS = "arcAddress";
	public static final String ARC_CITY = "arcCity";
	public static final String ARC_ZIP = "arcZip";
	public static final String HOST_URL = "HOST_URL";
	public static final String LOGO_URL = "logoUrl";
	public static final String TRACKING_URL = "trackingUrl";
	public static final String STATUS_TRACKING = "STATUS_TRACKING";
	public static final String TASK_ID = ":trackId";
	public static final String ARC_REF_ID = "ARC_REF_ID";
	public static final String CLOSURE_REF_TO_TS="CLOSURE_REF_TO_TS" ;
	public static final String CHECK_FLOW_TYPE="CHECK_FLOW_TYPE" ;
	public static final String DEV = "1";
	public static final String HELPLINE_URL = "HELPLINE_URL";
	public static final String SHIP_TO_PARTY_ADDRESS = "shipToPartyAddress";
	public static final String SHIP_TO_PARTY_NAME = "shipToPartyName";
	

}
