/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author a593775
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorSparesDetailDTO implements Serializable {
	private static final long serialVersionUID = 3279171422940689361L;

	private Long materialId;

	private String materialCode;

	private String materialNumber;

	private String materialDesc;

	private Integer qty;

	private float materialRatePerUnit;

	private String materialDispatchToAddress;

	private Integer isCts;

	private Date receivedByLcOn;

	private Integer receivedByLcStatus;

	private String receivedByLcRefId;

	private Date dispatchedOn;

	private String dispatchedByRefId;

	private String dispatchDocketNum;

	private Integer dispatchStatus;

	private Date receivedByArcOn;

	private String receivedByArcRefId;

	private Integer receivedByArcStatus;

	private Integer sparesDispatchRpReq;

	private Date sparesDispatchRpRequestedOn;

	private Integer sparesDispatchRpReceived;

	private Date sparesDispatchRpReceivedOn;

	private float externalCost;

	private String sparesComment;

	private String itemUnit;
	
	private Integer shipToPartyType;
	
	private Date createdOn;

	private String createdByRefId;
	
	private Date modifiedOn;

	private String modifiedByRefId;
	
	//get updated on review spares list
	private Date reviewdOn;

	private String reviewedOn;
	
    private Integer spareStatus;
	
    private String sparePONumber;
	
	private Date spareEstDeliveryDate; 
	
	private String tenantId;
		
    private String solutionCategoryId; 
		
    private Date receivedByCCCOn;
    
	private String receivedByCCCRefId;	
	
	private Integer receivedByCCCStatus;	

	private String repairStatus;

	/**
	 * @return the receivedByCCCOn
	 */
	public Date getReceivedByCCCOn() {
		return receivedByCCCOn;
	}

	/**
	 * @param receivedByCCCOn the receivedByCCCOn to set
	 */
	public void setReceivedByCCCOn(Date receivedByCCCOn) {
		this.receivedByCCCOn = receivedByCCCOn;
	}

	/**
	 * @return the receivedByCCCRefId
	 */
	public String getReceivedByCCCRefId() {
		return receivedByCCCRefId;
	}

	/**
	 * @param receivedByCCCRefId the receivedByCCCRefId to set
	 */
	public void setReceivedByCCCRefId(String receivedByCCCRefId) {
		this.receivedByCCCRefId = receivedByCCCRefId;
	}

	/**
	 * @return the receivedByCCCStatus
	 */
	public Integer getReceivedByCCCStatus() {
		return receivedByCCCStatus;
	}

	/**
	 * @param receivedByCCCStatus the receivedByCCCStatus to set
	 */
	public void setReceivedByCCCStatus(Integer receivedByCCCStatus) {
		this.receivedByCCCStatus = receivedByCCCStatus;
	}

		/**
		 * @return the tenantId
		 */
		public String getTenantId() {
			return tenantId;
		}

		/**
		 * @param tenantId the tenantId to set
		 */
		public void setTenantId(String tenantId) {
			this.tenantId = tenantId;
		}

		/**
		 * @return the solutionCategoryId
		 */
		public String getSolutionCategoryId() {
			return solutionCategoryId;
		}

		/**
		 * @param solutionCategoryId the solutionCategoryId to set
		 */
		public void setSolutionCategoryId(String solutionCategoryId) {
			this.solutionCategoryId = solutionCategoryId;
		}


	/**
	 * @return the shipToPartyType
	 */
	public Integer getShipToPartyType() {
		return shipToPartyType;
	}

	/**
	 * @param shipToPartyType the shipToPartyType to set
	 */
	public void setShipToPartyType(Integer shipToPartyType) {
		this.shipToPartyType = shipToPartyType;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the reviewdOn
	 */
	public Date getReviewdOn() {
		return reviewdOn;
	}

	/**
	 * @param reviewdOn the reviewdOn to set
	 */
	public void setReviewdOn(Date reviewdOn) {
		this.reviewdOn = reviewdOn;
	}

	/**
	 * @return the reviewedOn
	 */
	public String getReviewedOn() {
		return reviewedOn;
	}

	/**
	 * @param reviewedOn the reviewedOn to set
	 */
	public void setReviewedOn(String reviewedOn) {
		this.reviewedOn = reviewedOn;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit
	 *            the itemUnit to set
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the materialId
	 */
	public Long getMaterialId() {
		return materialId;
	}

	/**
	 * @param materialId
	 *            the materialId to set
	 */
	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}

	/**
	 * @return the materialCode
	 */
	public String getMaterialCode() {
		return materialCode;
	}

	/**
	 * @param materialCode
	 *            the materialCode to set
	 */
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	/**
	 * @return the materialNumber
	 */
	public String getMaterialNumber() {
		return materialNumber;
	}

	/**
	 * @param materialNumber
	 *            the materialNumber to set
	 */
	public void setMaterialNumber(String materialNumber) {
		this.materialNumber = materialNumber;
	}

	/**
	 * @return the materialDesc
	 */
	public String getMaterialDesc() {
		return materialDesc;
	}

	/**
	 * @param materialDesc
	 *            the materialDesc to set
	 */
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	
	/**
	 * @return the qty
	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the materialRatePerUnit
	 */
	public float getMaterialRatePerUnit() {
		return materialRatePerUnit;
	}

	/**
	 * @param materialRatePerUnit
	 *            the materialRatePerUnit to set
	 */
	public void setMaterialRatePerUnit(float materialRatePerUnit) {
		this.materialRatePerUnit = materialRatePerUnit;
	}

	/**
	 * @return the materialDispatchToAddress
	 */
	public String getMaterialDispatchToAddress() {
		return materialDispatchToAddress;
	}

	/**
	 * @param materialDispatchToAddress
	 *            the materialDispatchToAddress to set
	 */
	public void setMaterialDispatchToAddress(String materialDispatchToAddress) {
		this.materialDispatchToAddress = materialDispatchToAddress;
	}

	/**
	 * @return the isCts
	 */
	public Integer getIsCts() {
		return isCts;
	}

	/**
	 * @param isCts
	 *            the isCts to set
	 */
	public void setIsCts(Integer isCts) {
		this.isCts = isCts;
	}

	/**
	 * @return the receivedByLcOn
	 */
	public Date getReceivedByLcOn() {
		return receivedByLcOn;
	}

	/**
	 * @param receivedByLcOn
	 *            the receivedByLcOn to set
	 */
	public void setReceivedByLcOn(Date receivedByLcOn) {
		this.receivedByLcOn = receivedByLcOn;
	}

	/**
	 * @return the receivedByLcStatus
	 */
	public Integer getReceivedByLcStatus() {
		return receivedByLcStatus;
	}

	/**
	 * @param receivedByLcStatus
	 *            the receivedByLcStatus to set
	 */
	public void setReceivedByLcStatus(Integer receivedByLcStatus) {
		this.receivedByLcStatus = receivedByLcStatus;
	}

	/**
	 * @return the receivedByLcRefId
	 */
	public String getReceivedByLcRefId() {
		return receivedByLcRefId;
	}

	/**
	 * @param receivedByLcRefId
	 *            the receivedByLcRefId to set
	 */
	public void setReceivedByLcRefId(String receivedByLcRefId) {
		this.receivedByLcRefId = receivedByLcRefId;
	}

	/**
	 * @return the dispatchedOn
	 */
	public Date getDispatchedOn() {
		return dispatchedOn;
	}

	/**
	 * @param dispatchedOn
	 *            the dispatchedOn to set
	 */
	public void setDispatchedOn(Date dispatchedOn) {
		this.dispatchedOn = dispatchedOn;
	}

	/**
	 * @return the dispatchedByRefId
	 */
	public String getDispatchedByRefId() {
		return dispatchedByRefId;
	}

	/**
	 * @param dispatchedByRefId
	 *            the dispatchedByRefId to set
	 */
	public void setDispatchedByRefId(String dispatchedByRefId) {
		this.dispatchedByRefId = dispatchedByRefId;
	}

	/**
	 * @return the dispatchDocketNum
	 */
	public String getDispatchDocketNum() {
		return dispatchDocketNum;
	}

	/**
	 * @param dispatchDocketNum
	 *            the dispatchDocketNum to set
	 */
	public void setDispatchDocketNum(String dispatchDocketNum) {
		this.dispatchDocketNum = dispatchDocketNum;
	}

	/**
	 * @return the dispatchStatus
	 */
	public Integer getDispatchStatus() {
		return dispatchStatus;
	}

	/**
	 * @param dispatchStatus
	 *            the dispatchStatus to set
	 */
	public void setDispatchStatus(Integer dispatchStatus) {
		this.dispatchStatus = dispatchStatus;
	}

	/**
	 * @return the receivedByArcOn
	 */
	public Date getReceivedByArcOn() {
		return receivedByArcOn;
	}

	/**
	 * @param receivedByArcOn
	 *            the receivedByArcOn to set
	 */
	public void setReceivedByArcOn(Date receivedByArcOn) {
		this.receivedByArcOn = receivedByArcOn;
	}

	/**
	 * @return the receivedByArcRefId
	 */
	public String getReceivedByArcRefId() {
		return receivedByArcRefId;
	}

	/**
	 * @param receivedByArcRefId
	 *            the receivedByArcRefId to set
	 */
	public void setReceivedByArcRefId(String receivedByArcRefId) {
		this.receivedByArcRefId = receivedByArcRefId;
	}

	/**
	 * @return the receivedByArcStatus
	 */
	public Integer getReceivedByArcStatus() {
		return receivedByArcStatus;
	}

	/**
	 * @param receivedByArcStatus
	 *            the receivedByArcStatus to set
	 */
	public void setReceivedByArcStatus(Integer receivedByArcStatus) {
		this.receivedByArcStatus = receivedByArcStatus;
	}

	/**
	 * @return the sparesDispatchRpReq
	 */
	public Integer getSparesDispatchRpReq() {
		return sparesDispatchRpReq;
	}

	/**
	 * @param sparesDispatchRpReq
	 *            the sparesDispatchRpReq to set
	 */
	public void setSparesDispatchRpReq(Integer sparesDispatchRpReq) {
		this.sparesDispatchRpReq = sparesDispatchRpReq;
	}

	/**
	 * @return the sparesDispatchRpRequestedOn
	 */
	public Date getSparesDispatchRpRequestedOn() {
		return sparesDispatchRpRequestedOn;
	}

	/**
	 * @param sparesDispatchRpRequestedOn
	 *            the sparesDispatchRpRequestedOn to set
	 */
	public void setSparesDispatchRpRequestedOn(Date sparesDispatchRpRequestedOn) {
		this.sparesDispatchRpRequestedOn = sparesDispatchRpRequestedOn;
	}

	/**
	 * @return the sparesDispatchRpReceived
	 */
	public Integer getSparesDispatchRpReceived() {
		return sparesDispatchRpReceived;
	}

	/**
	 * @param sparesDispatchRpReceived
	 *            the sparesDispatchRpReceived to set
	 */
	public void setSparesDispatchRpReceived(Integer sparesDispatchRpReceived) {
		this.sparesDispatchRpReceived = sparesDispatchRpReceived;
	}

	/**
	 * @return the sparesDispatchRpReceivedOn
	 */
	public Date getSparesDispatchRpReceivedOn() {
		return sparesDispatchRpReceivedOn;
	}

	/**
	 * @param sparesDispatchRpReceivedOn
	 *            the sparesDispatchRpReceivedOn to set
	 */
	public void setSparesDispatchRpReceivedOn(Date sparesDispatchRpReceivedOn) {
		this.sparesDispatchRpReceivedOn = sparesDispatchRpReceivedOn;
	}

	/**
	 * @return the externalCost
	 */
	public float getExternalCost() {
		return externalCost;
	}

	/**
	 * @param externalCost
	 *            the externalCost to set
	 */
	public void setExternalCost(float externalCost) {
		this.externalCost = externalCost;
	}

	/**
	 * @return the sparesComment
	 */
	public String getSparesComment() {
		return sparesComment;
	}

	/**
	 * @param sparesComment
	 *            the sparesComment to set
	 */
	public void setSparesComment(String sparesComment) {
		this.sparesComment = sparesComment;
	}

	public Integer getSpareStatus() {
		return spareStatus;
	}

	public void setSpareStatus(Integer spareStatus) {
		this.spareStatus = spareStatus;
	}

	public String getSparePONumber() {
		return sparePONumber;
	}

	public void setSparePONumber(String sparePONumber) {
		this.sparePONumber = sparePONumber;
	}

	public Date getSpareEstDeliveryDate() {
		return spareEstDeliveryDate;
	}

	public void setSpareEstDeliveryDate(Date spareEstDeliveryDate) {
		this.spareEstDeliveryDate = spareEstDeliveryDate;
	}

	/**
	 * @return the repairStatus
	 */
	public String getRepairStatus() {
		return repairStatus;
	}

	/**
	 * @param repairStatus the repairStatus to set
	 */
	public void setRepairStatus(String repairStatus) {
		this.repairStatus = repairStatus;
	}

}
