/**
 * 
 */
package net.atos.motorrepairmgmt.utils;

import java.util.Random;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component
public class UniqueIdGenerator {

	/* *
	 * This method generates unique String of 16 digit
	 */
	public String generateUniqueId() {
		Random random = new Random();
		long seed = (long) (Math.random() * 10000000);
		random.setSeed(seed);
		Long val = random.nextLong();
		String data = Long.toHexString(val);
		return data.toUpperCase();
	}

	/* *
	 * This method generates unique String of 16 digit
	 */
	public long generateLongUniqueId() {
		Random random = new Random();
		long seed = (long) (Math.random() * 10000000);
		random.setSeed(seed);
		long val = random.nextLong();
		System.out.println("Generated: " + val);
		if(val < 0)
			val = -val;
		return val;
	}
	
}
