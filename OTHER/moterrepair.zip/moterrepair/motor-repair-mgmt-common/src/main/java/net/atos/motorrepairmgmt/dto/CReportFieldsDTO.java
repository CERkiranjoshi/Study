/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CReportFieldsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2991310019897962647L;

	private Long motorCReportFieldId;
	private String polarityCheck;
	private Float lockedRotorVolts;
	private String hvWinding;
	private String hvAcHeater;
	private String bearingDriveEndNo;
	private String bearingNondriveEndNo;
	private Boolean bearingNoiseState;
	private String vibrationNoLoad;
	private Date repairsCompletedOn;
	private String complaintDetail;
	private Integer bearingDeReplaced;
	private Integer bearingNdeReplaced;
	private String deMake;
	private String ndeMake;
	private Float acHeaterResistance;
	private String motorDispatchDetail;
	private String remarks;
	private String currentSpeed;
	private Integer rotorRebalanced;
	private Date createdOn;
	private String createdByRefId;
	private Date modifiedOn;
	private String modifiedByRefId;
	private Date referredForReviewOn;
	private String referredForReviewByRefId;
	private Date statusUpdatedOn;
	private String statusUpdatedByRefId;
	private Integer approvalStatus;
	private Integer repairedOrRewound;
	private String noLoad;
	private Date arcApprovedOn;
	private String arcReviewedBy;
	private String comments;
	private String deHorizontal;
	private String deVertical;
    private String deAxial;
	private String ndeHorizontal;
	private String ndeVertical;
	private String ndeAxial;
	private MotorVoltageDetailDTO motorVoltageDetail;
	private List<MotorSpeedDetailDTO> motorSpeedDetail;
	private MotorNamePlateDetailDTO motorNamePlateDetail;
	private SubProcessFieldsDTO subProcessFields;
	private ElectricalObservationDTO electricalObservation;
	private String functionCode;
	/**
	 * @return the motorCReportFieldId
	 */
	public Long getMotorCReportFieldId() {
		return motorCReportFieldId;
	}

	/**
	 * @param motorCReportFieldId
	 *            the motorCReportFieldId to set
	 */
	public void setMotorCReportFieldId(Long motorCReportFieldId) {
		this.motorCReportFieldId = motorCReportFieldId;
	}

	/**
	 * @return the polarityCheck
	 */
	public String getPolarityCheck() {
		return polarityCheck;
	}

	/**
	 * @param polarityCheck
	 *            the polarityCheck to set
	 */
	public void setPolarityCheck(String polarityCheck) {
		this.polarityCheck = polarityCheck;
	}

	/**
	 * @return lockedRotorVolts
	 */
	public Float getLockedRotorVolts() {
		return lockedRotorVolts;
	}

	/**
	 * @param lockedRotorVolts
	 *            the lockedRotorVolts to set
	 */
	public void setLockedRotorVolts(Float lockedRotorVolts) {
		this.lockedRotorVolts = lockedRotorVolts;
	}

	/**
	 * @return the hvWinding
	 */
	public String getHvWinding() {
		return hvWinding;
	}

	/**
	 * @param hvWinding
	 *            the hvWinding to set
	 */
	public void setHvWinding(String hvWinding) {
		this.hvWinding = hvWinding;
	}

	/**
	 * @return the hvAcHeater
	 */
	public String getHvAcHeater() {
		return hvAcHeater;
	}

	/**
	 * @param hvAcHeater
	 *            the hvAcHeater to set
	 */
	public void setHvAcHeater(String hvAcHeater) {
		this.hvAcHeater = hvAcHeater;
	}

	/**
	 * @return the bearingDriveEndNo
	 */
	public String getBearingDriveEndNo() {
		return bearingDriveEndNo;
	}

	/**
	 * @param bearingDriveEndNo
	 *            the bearingDriveEndNo to set
	 */
	public void setBearingDriveEndNo(String bearingDriveEndNo) {
		this.bearingDriveEndNo = bearingDriveEndNo;
	}

	/**
	 * @return the bearingNondriveEndNo
	 */
	public String getBearingNondriveEndNo() {
		return bearingNondriveEndNo;
	}

	/**
	 * @param bearingNondriveEndNo
	 *            the bearingNondriveEndNo to set
	 */
	public void setBearingNondriveEndNo(String bearingNondriveEndNo) {
		this.bearingNondriveEndNo = bearingNondriveEndNo;
	}

	/**
	 * @return the bearingNoiseState
	 */
	public Boolean getBearingNoiseState() {
		return bearingNoiseState;
	}

	/**
	 * @param bearingNoiseState
	 *            the bearingNoiseState to set
	 */
	public void setBearingNoiseState(Boolean bearingNoiseState) {
		this.bearingNoiseState = bearingNoiseState;
	}

	/**
	 * @return the vibrationNoLoad
	 */
	public String getVibrationNoLoad() {
		return vibrationNoLoad;
	}

	/**
	 * @param vibrationNoLoad
	 *            the vibrationNoLoad to set
	 */
	public void setVibrationNoLoad(String vibrationNoLoad) {
		this.vibrationNoLoad = vibrationNoLoad;
	}

	/**
	 * @return the repairsCompletedOn
	 */
	public Date getRepairsCompletedOn() {
		return repairsCompletedOn;
	}

	/**
	 * @param repairsCompletedOn
	 *            the repairsCompletedOn to set
	 */
	public void setRepairsCompletedOn(Date repairsCompletedOn) {
		this.repairsCompletedOn = repairsCompletedOn;
	}

	/**
	 * @return the complaintDetail
	 */
	public String getComplaintDetail() {
		return complaintDetail;
	}

	/**
	 * @param complaintDetail
	 *            the complaintDetail to set
	 */
	public void setComplaintDetail(String complaintDetail) {
		this.complaintDetail = complaintDetail;
	}

	/**
	 * @return the bearingDeReplaced
	 */
	public Integer getBearingDeReplaced() {
		return bearingDeReplaced;
	}

	/**
	 * @param bearingDeReplaced
	 *            the bearingDeReplaced to set
	 */
	public void setBearingDeReplaced(Integer bearingDeReplaced) {
		this.bearingDeReplaced = bearingDeReplaced;
	}

	/**
	 * @return the bearingNdeReplaced
	 */
	public Integer getBearingNdeReplaced() {
		return bearingNdeReplaced;
	}

	/**
	 * @param bearingNdeReplaced
	 *            the bearingNdeReplaced to set
	 */
	public void setBearingNdeReplaced(Integer bearingNdeReplaced) {
		this.bearingNdeReplaced = bearingNdeReplaced;
	}

	/**
	 * @return the deMake
	 */
	public String getDeMake() {
		return deMake;
	}

	/**
	 * @param deMake
	 *            the deMake to set
	 */
	public void setDeMake(String deMake) {
		this.deMake = deMake;
	}

	/**
	 * @return the ndeMake
	 */
	public String getNdeMake() {
		return ndeMake;
	}

	/**
	 * @param ndeMake
	 *            the ndeMake to set
	 */
	public void setNdeMake(String ndeMake) {
		this.ndeMake = ndeMake;
	}

	/**
	 * @return the acHeaterResistance
	 */
	public Float getAcHeaterResistance() {
		return acHeaterResistance;
	}

	/**
	 * @param acHeaterResistance
	 *            the acHeaterResistance to set
	 */
	public void setAcHeaterResistance(Float acHeaterResistance) {
		this.acHeaterResistance = acHeaterResistance;
	}

	/**
	 * @return the motorDispatchDetail
	 */
	public String getMotorDispatchDetail() {
		return motorDispatchDetail;
	}

	/**
	 * @param motorDispatchDetail
	 *            the motorDispatchDetail to set
	 */
	public void setMotorDispatchDetail(String motorDispatchDetail) {
		this.motorDispatchDetail = motorDispatchDetail;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks
	 *            the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the currentSpeed
	 */
	public String getCurrentSpeed() {
		return currentSpeed;
	}

	/**
	 * @param currentSpeed
	 *            the currentSpeed to set
	 */
	public void setCurrentSpeed(String currentSpeed) {
		this.currentSpeed = currentSpeed;
	}

	/**
	 * @return the rotorRebalanced
	 */
	public Integer getRotorRebalanced() {
		return rotorRebalanced;
	}

	/**
	 * @param rotorRebalanced
	 *            the rotorRebalanced to set 0:No,1:yes
	 */
	public void setRotorRebalanced(Integer rotorRebalanced) {
		this.rotorRebalanced = rotorRebalanced;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn
	 *            the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId
	 *            the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the referredForReviewOn
	 */
	public Date getReferredForReviewOn() {
		return referredForReviewOn;
	}

	/**
	 * @param referredForReviewOn
	 *            the referredForReviewOn to set
	 */
	public void setReferredForReviewOn(Date referredForReviewOn) {
		this.referredForReviewOn = referredForReviewOn;
	}

	/**
	 * @return the referredForReviewByRefId
	 */
	public String getReferredForReviewByRefId() {
		return referredForReviewByRefId;
	}

	/**
	 * @param referredForReviewByRefId
	 *            the referredForReviewByRefId to set
	 */
	public void setReferredForReviewByRefId(String referredForReviewByRefId) {
		this.referredForReviewByRefId = referredForReviewByRefId;
	}

	
	/**
	 * @return the statusUpdatedOn
	 */
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param statusUpdatedOn the statusUpdatedOn to set
	 */
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}

	/**
	 * @return the statusUpdatedByRefId
	 */
	public String getStatusUpdatedByRefId() {
		return statusUpdatedByRefId;
	}

	/**
	 * @param statusUpdatedByRefId the statusUpdatedByRefId to set
	 */
	public void setStatusUpdatedByRefId(String statusUpdatedByRefId) {
		this.statusUpdatedByRefId = statusUpdatedByRefId;
	}

	/**
	 * @return the approvalStatus
	 */
	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the repairedOrRewound
	 */
	public Integer getRepairedOrRewound() {
		return repairedOrRewound;
	}

	/**
	 * @param repairedOrRewound
	 *            the repairedOrRewound to set 1:Repair; 2:Rewound;
	 */
	public void setRepairedOrRewound(Integer repairedOrRewound) {
		this.repairedOrRewound = repairedOrRewound;
	}

	/**
	 * @return the noLoad
	 */
	public String getNoLoad() {
		return noLoad;
	}

	/**
	 * @param noLoad
	 *            the noLoad to set
	 */
	public void setNoLoad(String noLoad) {
		this.noLoad = noLoad;
	}

	/**
	 * @return the arcApprovedOn
	 */
	public Date getArcApprovedOn() {
		return arcApprovedOn;
	}

	/**
	 * @param arcApprovedOn
	 *            the arcApprovedOn to set
	 */
	public void setArcApprovedOn(Date arcApprovedOn) {
		this.arcApprovedOn = arcApprovedOn;
	}

	/**
	 * @return the arcReviewedBy
	 */
	public String getArcReviewedBy() {
		return arcReviewedBy;
	}

	/**
	 * @param arcReviewedBy
	 *            the arcReviewedBy to set
	 */
	public void setArcReviewedBy(String arcReviewedBy) {
		this.arcReviewedBy = arcReviewedBy;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
		
	/**
	 * @return the deHorizontal
	 */
	public String getDeHorizontal() {
		return deHorizontal;
	}

	/**
	 * @param deHorizontal the deHorizontal to set
	 */
	public void setDeHorizontal(String deHorizontal) {
		this.deHorizontal = deHorizontal;
	}

	/**
	 * @return the deVertical
	 */
	public String getDeVertical() {
		return deVertical;
	}

	/**
	 * @param deVertical the deVertical to set
	 */
	public void setDeVertical(String deVertical) {
		this.deVertical = deVertical;
	}

	/**
	 * @return the deAxial
	 */
	public String getDeAxial() {
		return deAxial;
	}

	/**
	 * @param deAxial the deAxial to set
	 */
	public void setDeAxial(String deAxial) {
		this.deAxial = deAxial;
	}

	/**
	 * @return the ndeHorizontal
	 */
	public String getNdeHorizontal() {
		return ndeHorizontal;
	}

	/**
	 * @param ndeHorizontal the ndeHorizontal to set
	 */
	public void setNdeHorizontal(String ndeHorizontal) {
		this.ndeHorizontal = ndeHorizontal;
	}

	/**
	 * @return the ndeVertical
	 */
	public String getNdeVertical() {
		return ndeVertical;
	}

	/**
	 * @param ndeVertical the ndeVertical to set
	 */
	public void setNdeVertical(String ndeVertical) {
		this.ndeVertical = ndeVertical;
	}

	/**
	 * @return the ndeAxial
	 */
	public String getNdeAxial() {
		return ndeAxial;
	}

	/**
	 * @param ndeAxial the ndeAxial to set
	 */
	public void setNdeAxial(String ndeAxial) {
		this.ndeAxial = ndeAxial;
	}

	/**
	 * @return the motorVoltageDetail
	 */
	public MotorVoltageDetailDTO getMotorVoltageDetail() {
		return motorVoltageDetail;
	}

	/**
	 * @param motorVoltageDetail
	 *            the motorVoltageDetail to set
	 */
	public void setMotorVoltageDetail(MotorVoltageDetailDTO motorVoltageDetail) {
		this.motorVoltageDetail = motorVoltageDetail;
	}

	/**
	 * @return the motorSpeedDetail
	 */
	public List<MotorSpeedDetailDTO> getMotorSpeedDetail() {
		return motorSpeedDetail;
	}

	/**
	 * @param motorSpeedDetail
	 *            the motorSpeedDetail to set
	 */
	public void setMotorSpeedDetail(List<MotorSpeedDetailDTO> motorSpeedDetail) {
		this.motorSpeedDetail = motorSpeedDetail;
	}

	/**
	 * @return the motorNamePlateDetail
	 */
	public MotorNamePlateDetailDTO getMotorNamePlateDetail() {
		return motorNamePlateDetail;
	}

	/**
	 * @param motorNamePlateDetail
	 *            the motorNamePlateDetail to set
	 */
	public void setMotorNamePlateDetail(
			MotorNamePlateDetailDTO motorNamePlateDetail) {
		this.motorNamePlateDetail = motorNamePlateDetail;
	}

	/**
	 * @return the subProcessFields
	 */
	public SubProcessFieldsDTO getSubProcessFields() {
		return subProcessFields;
	}

	/**
	 * @param subProcessFields
	 *            the subProcessFields to set
	 */
	public void setSubProcessFields(SubProcessFieldsDTO subProcessFields) {
		this.subProcessFields = subProcessFields;
	}

	/**
	 * @return the electricalObservation
	 */
	public ElectricalObservationDTO getElectricalObservation() {
		return electricalObservation;
	}

	/**
	 * @param electricalObservation
	 *            the electricalObservation to set
	 */
	public void setElectricalObservation(
			ElectricalObservationDTO electricalObservation) {
		this.electricalObservation = electricalObservation;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}
}
