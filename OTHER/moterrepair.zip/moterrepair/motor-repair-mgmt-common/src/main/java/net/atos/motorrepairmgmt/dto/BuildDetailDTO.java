/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.util.Date;
/**
 * @author Sweety Kothari
 *
 */
public class BuildDetailDTO {
	
	private Long id;
	
	private String buildVersion;
	
	private Date buildDate;
	
	//1: means current build
	private Integer isCurrent;
	
	private String tenantId;

	private String solutionCategoryId;
	
	private String releaseNotes;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the buildVersion
	 */
	public String getBuildVersion() {
		return buildVersion;
	}

	/**
	 * @param buildVersion the buildVersion to set
	 */
	public void setBuildVersion(String buildVersion) {
		this.buildVersion = buildVersion;
	}

	/**
	 * @return the buildDate
	 */
	public Date getBuildDate() {
		return buildDate;
	}

	/**
	 * @param buildDate the buildDate to set
	 */
	public void setBuildDate(Date buildDate) {
		this.buildDate = buildDate;
	}

	/**
	 * @return the isCurrent
	 */
	public Integer getIsCurrent() {
		return isCurrent;
	}

	/**
	 * @param isCurrent the isCurrent to set
	 */
	public void setIsCurrent(Integer isCurrent) {
		this.isCurrent = isCurrent;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the releaseNotes
	 */
	public String getReleaseNotes() {
		return releaseNotes;
	}

	/**
	 * @param releaseNotes the releaseNotes to set
	 */
	public void setReleaseNotes(String releaseNotes) {
		this.releaseNotes = releaseNotes;
	}
	
	


}
