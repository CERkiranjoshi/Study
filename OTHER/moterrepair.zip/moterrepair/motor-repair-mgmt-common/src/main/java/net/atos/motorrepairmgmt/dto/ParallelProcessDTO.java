package net.atos.motorrepairmgmt.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a603975
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParallelProcessDTO {
	private Long parallelProcessThreadId;

	private String parallelProcessType;

	private String parallelProcessId;

	private String masterWorkflowFieldId;

	private String ppBatchProcessId;

	private String parallelProcessState;

	private Date createdOn;

	private String createdByRefId;

	private String taskId;

	private String initTaskId;

	private String initProcessInsId;

	private String processInstancId;

	private String taskCode;

	private String closedByRefId;

	private Date closedOn;

	private String initTaskCode;
	
    private String tenantId;
	
	private String solutionCategoryId;
	
	

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public String getInitTaskCode() {
		return initTaskCode;
	}

	public void setInitTaskCode(String initTaskCode) {
		this.initTaskCode = initTaskCode;
	}

	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId
	 *            the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the initTaskId
	 */
	public String getInitTaskId() {
		return initTaskId;
	}

	/**
	 * @param initTaskId
	 *            the initTaskId to set
	 */
	public void setInitTaskId(String initTaskId) {
		this.initTaskId = initTaskId;
	}

	/**
	 * @return the initProcessInsId
	 */
	public String getInitProcessInsId() {
		return initProcessInsId;
	}

	/**
	 * @param initProcessInsId
	 *            the initProcessInsId to set
	 */
	public void setInitProcessInsId(String initProcessInsId) {
		this.initProcessInsId = initProcessInsId;
	}

	/**
	 * @return the processInstancId
	 */
	public String getProcessInstancId() {
		return processInstancId;
	}

	/**
	 * @param processInstancId
	 *            the processInstancId to set
	 */
	public void setProcessInstancId(String processInstancId) {
		this.processInstancId = processInstancId;
	}

	/**
	 * @return the taskCode
	 */
	public String getTaskCode() {
		return taskCode;
	}

	/**
	 * @param taskCode
	 *            the taskCode to set
	 */
	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}

	/**
	 * @return the closedByRefId
	 */
	public String getClosedByRefId() {
		return closedByRefId;
	}

	/**
	 * @param closedByRefId
	 *            the closedByRefId to set
	 */
	public void setClosedByRefId(String closedByRefId) {
		this.closedByRefId = closedByRefId;
	}

	/**
	 * @return the closedOn
	 */
	public Date getClosedOn() {
		return closedOn;
	}

	/**
	 * @param closedOn
	 *            the closedOn to set
	 */
	public void setClosedOn(Date closedOn) {
		this.closedOn = closedOn;
	}

	/**
	 * @return the parallelProcessThreadId
	 */
	public Long getParallelProcessThreadId() {
		return parallelProcessThreadId;
	}

	/**
	 * @param parallelProcessThreadId
	 *            the parallelProcessThreadId to set
	 */
	public void setParallelProcessThreadId(Long parallelProcessThreadId) {
		this.parallelProcessThreadId = parallelProcessThreadId;
	}

	/**
	 * @return the parallelProcessType
	 */
	public String getParallelProcessType() {
		return parallelProcessType;
	}

	/**
	 * @param parallelProcessType
	 *            the parallelProcessType to set
	 */
	public void setParallelProcessType(String parallelProcessType) {
		this.parallelProcessType = parallelProcessType;
	}

	/**
	 * @return the parallelProcessId
	 */
	public String getParallelProcessId() {
		return parallelProcessId;
	}

	/**
	 * @param parallelProcessId
	 *            the parallelProcessId to set
	 */
	public void setParallelProcessId(String parallelProcessId) {
		this.parallelProcessId = parallelProcessId;
	}

	/**
	 * @return the masterWorkflowFieldId
	 */
	public String getMasterWorkflowFieldId() {
		return masterWorkflowFieldId;
	}

	/**
	 * @param masterWorkflowFieldId
	 *            the masterWorkflowFieldId to set
	 */
	public void setMasterWorkflowFieldId(String masterWorkflowFieldId) {
		this.masterWorkflowFieldId = masterWorkflowFieldId;
	}

	/**
	 * @return the ppBatchProcessId Parallel Process batch process Id
	 */
	public String getPpBatchProcessId() {
		return ppBatchProcessId;
	}

	/**
	 * @param ppBatchProcessId
	 *            the ppBatchProcessId to set Parallel Process batch process Id
	 */
	public void setPpBatchProcessId(String ppBatchProcessId) {
		this.ppBatchProcessId = ppBatchProcessId;
	}

	/**
	 * @return the parallelProcessState
	 */
	public String getParallelProcessState() {
		return parallelProcessState;
	}

	/**
	 * @param parallelProcessState
	 *            the parallelProcessState to set
	 * 
	 *            0:COMPLETED,1: IN_EXEC
	 */
	public void setParallelProcessState(String parallelProcessState) {
		this.parallelProcessState = parallelProcessState;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

}
