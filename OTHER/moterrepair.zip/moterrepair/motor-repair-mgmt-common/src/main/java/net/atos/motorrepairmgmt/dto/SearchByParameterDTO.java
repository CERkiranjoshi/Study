package net.atos.motorrepairmgmt.dto;

public class SearchByParameterDTO
{
	private Long wlfwSubProcessId;
	
	private String customerName; 
	
	private String gspRefNo;
	
	private String motorSnNum;
	
	private String mlfbSpiridon;

	private String value;
	
	private String mobileContactNum;
	
	private String subjectTitle;
	
	
	/**
	 * @return the wlfwSubProcessId
	 */
	public Long getWlfwSubProcessId() {
		return wlfwSubProcessId;
	}

	/**
	 * @param wlfwSubProcessId the wlfwSubProcessId to set
	 */
	public void setWlfwSubProcessId(Long wlfwSubProcessId) {
		this.wlfwSubProcessId = wlfwSubProcessId;
	}

	/**
	 * @return the subjectTitle
	 */
	public String getSubjectTitle() {
		return subjectTitle;
	}

	/**
	 * @param subjectTitle the subjectTitle to set
	 */
	public void setSubjectTitle(String subjectTitle) {
		this.subjectTitle = subjectTitle;
	}

	/**
	 * @return the mobileContactNum
	 */
	public String getMobileContactNum() {
		return mobileContactNum;
	}

	/**
	 * @param mobileContactNum the mobileContactNum to set
	 */
	public void setMobileContactNum(String mobileContactNum) {
		this.mobileContactNum = mobileContactNum;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the gspRefNo
	 */
	public String getGspRefNo() {
		return gspRefNo;
	}

	/**
	 * @param gspRefNo the gspRefNo to set
	 */
	public void setGspRefNo(String gspRefNo) {
		this.gspRefNo = gspRefNo;
	}

	/**
	 * @return the motorSnNum
	 */
	public String getMotorSnNum() {
		return motorSnNum;
	}

	/**
	 * @param motorSnNum the motorSnNum to set
	 */
	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}

	/**
	 * @return the mlfbSpiridon
	 */
	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}

	/**
	 * @param mlfbSpiridon the mlfbSpiridon to set
	 */
	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	

}
