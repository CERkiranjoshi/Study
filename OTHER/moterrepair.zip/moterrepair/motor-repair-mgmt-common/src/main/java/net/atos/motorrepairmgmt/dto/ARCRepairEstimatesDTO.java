package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ARCRepairEstimatesDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8558046626855534509L;

	private Long arcRepairEstimateId;
	private String scopeOfWork;
	private Float unitCost;
	private Integer qty;
	private String itemUnit;
	private Float totalCost;
	private Date createdDate;
	private String createdByRefId;
	private Date modifiedDate;
	private String modifiedByRefId;

	/**
	 * @return the arcRepairEstimateId
	 */
	public Long getArcRepairEstimateId() {
		return arcRepairEstimateId;
	}

	/**
	 * @param arcRepairEstimateId
	 *            the arcRepairEstimateId to set
	 */
	public void setArcRepairEstimateId(Long arcRepairEstimateId) {
		this.arcRepairEstimateId = arcRepairEstimateId;
	}

	/**
	 * @return the scopeOfWork
	 */
	public String getScopeOfWork() {
		return scopeOfWork;
	}

	/**
	 * @param scopeOfWork
	 *            the scopeOfWork to set Free Text for Job Details
	 */
	public void setScopeOfWork(String scopeOfWork) {
		this.scopeOfWork = scopeOfWork;
	}

	/**
	 * @return the qty
	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set No. of jobs / spares
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit
	 *            the itemUnit to set unit of item as 1 job or 5 mts.
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedDate
	 */
	public Date getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate
	 *            the modifiedDate to set
	 */
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId
	 *            the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the unitCost
	 */
	public Float getUnitCost() {
		return unitCost;
	}

	/**
	 * @param unitCost
	 *            the unitCost to set
	 */
	public void setUnitCost(Float unitCost) {
		this.unitCost = unitCost;
	}

	/**
	 * @return the totalCost
	 */
	public Float getTotalCost() {
		return totalCost;
	}

	/**
	 * @param totalCost
	 *            the totalCost to set
	 */
	public void setTotalCost(Float totalCost) {
		this.totalCost = totalCost;
	}

}
