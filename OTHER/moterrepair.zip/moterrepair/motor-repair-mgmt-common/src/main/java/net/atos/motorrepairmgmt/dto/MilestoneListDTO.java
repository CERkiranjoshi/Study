package net.atos.motorrepairmgmt.dto;

import java.util.Date;
import java.util.List;

public class MilestoneListDTO
{
	private String matricesName;
	private String matricesAliasName;
	private List<Date> milestoneTimeStamp;
	/**
	 * @return the matricesName
	 */
	public String getMatricesName() {
		return matricesName;
	}
	/**
	 * @param matricesName the matricesName to set
	 */
	public void setMatricesName(String matricesName) {
		this.matricesName = matricesName;
	}
	/**
	 * @return the matricesAliasName
	 */
	public String getMatricesAliasName() {
		return matricesAliasName;
	}
	/**
	 * @param matricesAliasName the matricesAliasName to set
	 */
	public void setMatricesAliasName(String matricesAliasName) {
		this.matricesAliasName = matricesAliasName;
	}
	/**
	 * @return the milestoneTimeStamp
	 */
	public List<Date> getMilestoneTimeStamp() {
		return milestoneTimeStamp;
	}
	/**
	 * @param milestoneTimeStamp the milestoneTimeStamp to set
	 */
	public void setMilestoneTimeStamp(List<Date> milestoneTimeStamp) {
		this.milestoneTimeStamp = milestoneTimeStamp;
	}
	 

}
