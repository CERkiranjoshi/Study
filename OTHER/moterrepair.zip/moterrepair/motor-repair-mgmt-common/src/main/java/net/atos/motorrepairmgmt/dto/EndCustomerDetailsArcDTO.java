package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EndCustomerDetailsArcDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8558046626855534509L;

	private Long customerId;

	private String companyName;

	private String customerContactName;

	private String custContactNum;

	private String officeContactNum;

	private String custEmailId;

	private String custType;

	private String gspRefCode;

	private String spiridonRefCode;

	private Integer notificationType;

	private String customerAddress;

	private String shipingToAddress;

	private Integer isShipToParty;

	private Integer isSoldToParty;

	private String countyCode;
	

	private Integer tenantId;

	private Integer solutionCategoryId;

	private String createdBy;


	// for storing partner type for channel partner ,like OEM ,etc

	private Integer partnerType;

	public Long getCustomerId() {
		return customerId;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	public Integer getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(Integer solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCustomerContactName() {
		return customerContactName;
	}

	public void setCustomerContactName(String customerContactName) {
		this.customerContactName = customerContactName;
	}

	public String getCustContactNum() {
		return custContactNum;
	}

	public void setCustContactNum(String custContactNum) {
		this.custContactNum = custContactNum;
	}

	public String getOfficeContactNum() {
		return officeContactNum;
	}

	public void setOfficeContactNum(String officeContactNum) {
		this.officeContactNum = officeContactNum;
	}

	public String getCustEmailId() {
		return custEmailId;
	}

	public void setCustEmailId(String custEmailId) {
		this.custEmailId = custEmailId;
	}

	public String getCustType() {
		return custType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getGspRefCode() {
		return gspRefCode;
	}

	public void setGspRefCode(String gspRefCode) {
		this.gspRefCode = gspRefCode;
	}

	public String getSpiridonRefCode() {
		return spiridonRefCode;
	}

	public void setSpiridonRefCode(String spiridonRefCode) {
		this.spiridonRefCode = spiridonRefCode;
	}

	public Integer getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getShipingToAddress() {
		return shipingToAddress;
	}

	public void setShipingToAddress(String shipingToAddress) {
		this.shipingToAddress = shipingToAddress;
	}

	public Integer getIsShipToParty() {
		return isShipToParty;
	}

	public void setIsShipToParty(Integer isShipToParty) {
		this.isShipToParty = isShipToParty;
	}

	public Integer getIsSoldToParty() {
		return isSoldToParty;
	}

	public void setIsSoldToParty(Integer isSoldToParty) {
		this.isSoldToParty = isSoldToParty;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public Integer getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(Integer partnerType) {
		this.partnerType = partnerType;
	}

}
