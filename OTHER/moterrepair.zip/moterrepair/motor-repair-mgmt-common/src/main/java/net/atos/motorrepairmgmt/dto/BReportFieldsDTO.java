package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BReportFieldsDTO implements Serializable {

	private static final long serialVersionUID = -4230063210251214326L;

	private Long bReportFieldId;

	private String contactPersonName;

	private String contactNumber;

	private String contactEmail;

	private String notificationNum;

	private String fseNotificationNum;

	private String windingCondition;

	private String missingPart;

	private String brokenPart;

	private String bearingDriveEndNo;

	private String bearingNondriveEndNo;

	private String bearingConDriveEndNo;

	private String bearingConNondriveEndNo;

	private String otherObs;

	private String remarks;

	private String complaintDetail;

	private String hVTestVolt;

	private String iRAfterHVTest;

	private Float repairsTimeEstimate;

	private Float repairEstimateCost;

	private Float materialEstimateCost;

	private Float totalEstimateCost;

	private Float noLoadVolts;

	private Float rAmp;

	private Float yAmp;

	private Float bAmp;

	private Date createdOn;

	private String createdByRefId;

	private Date modifiedOn;

	private String modifiedByRefId;

	private Date referredForReviewOn;

	private String referredForReviewByRefId;

	private Date statusUpdatedOn;
    
	private String statusUpdatedByRefId;

	private Integer approvalStatus;

	private String wornOutPart;

	private String scopeOfWork;

	private Date arcApprovedOn;

	private String arcReviewedBy;

	private SubProcessFieldsDTO subProcessFields;

	private MotorVoltageDetailDTO motorVoltageDetail;

	private MotorNamePlateDetailDTO motorNamePlateDetail;

	private ElectricalObservationDTO electricalObservation;

	private List<ARCRepairEstimatesDTO> arcRepairEstimateList;

	private List<ARCSparesEstimatesDTO> arcSpareEstimateList;

	private List<MotorSpeedDetailDTO> motorSpeedDetailList;
	
	private String functionCode;

	/**
	 * @return the bReportFieldId
	 */
	public Long getbReportFieldId() {
		return bReportFieldId;
	}

	/**
	 * @param bReportFieldId
	 *            the bReportFieldId to set
	 */
	public void setbReportFieldId(Long bReportFieldId) {
		this.bReportFieldId = bReportFieldId;
	}

	/**
	 * @return the contactPersonName
	 */
	public String getContactPersonName() {
		return contactPersonName;
	}

	/**
	 * @param contactPersonName
	 *            the contactPersonName to set
	 */
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	/**
	 * @return the contactNumber
	 */
	public String getContactNumber() {
		return contactNumber;
	}

	/**
	 * @param contactNumber
	 *            the contactNumber to set
	 */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/**
	 * @return the contactEmail
	 */
	public String getContactEmail() {
		return contactEmail;
	}

	/**
	 * @param contactEmail
	 *            the contactEmail to set
	 */
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	/**
	 * @return the notificationNum
	 */
	public String getNotificationNum() {
		return notificationNum;
	}

	/**
	 * @param notificationNum
	 *            the notificationNum to set
	 */
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}

	/**
	 * @return the fseNotificationNum
	 */
	public String getFseNotificationNum() {
		return fseNotificationNum;
	}

	/**
	 * @param fseNotificationNum
	 *            the fseNotificationNum to set
	 */
	public void setFseNotificationNum(String fseNotificationNum) {
		this.fseNotificationNum = fseNotificationNum;
	}

	/**
	 * @return the windingCondition
	 */
	public String getWindingCondition() {
		return windingCondition;
	}

	/**
	 * @param windingCondition
	 *            the windingCondition to set
	 */
	public void setWindingCondition(String windingCondition) {
		this.windingCondition = windingCondition;
	}

	/**
	 * @return the missingPart
	 */
	public String getMissingPart() {
		return missingPart;
	}

	/**
	 * @param missingPart
	 *            the missingPart to set
	 */
	public void setMissingPart(String missingPart) {
		this.missingPart = missingPart;
	}

	/**
	 * @return the brokenPart
	 */
	public String getBrokenPart() {
		return brokenPart;
	}

	/**
	 * @param brokenPart
	 *            the brokenPart to set
	 */
	public void setBrokenPart(String brokenPart) {
		this.brokenPart = brokenPart;
	}

	/**
	 * @return the bearingDriveEndNo
	 */
	public String getBearingDriveEndNo() {
		return bearingDriveEndNo;
	}

	/**
	 * @param bearingDriveEndNo
	 *            the bearingDriveEndNo to set
	 */
	public void setBearingDriveEndNo(String bearingDriveEndNo) {
		this.bearingDriveEndNo = bearingDriveEndNo;
	}

	/**
	 * @return the bearingNondriveEndNo
	 */
	public String getBearingNondriveEndNo() {
		return bearingNondriveEndNo;
	}

	/**
	 * @param bearingNondriveEndNo
	 *            the bearingNondriveEndNo to set
	 */
	public void setBearingNondriveEndNo(String bearingNondriveEndNo) {
		this.bearingNondriveEndNo = bearingNondriveEndNo;
	}

	/**
	 * @return the bearingConDriveEndNo
	 */
	public String getBearingConDriveEndNo() {
		return bearingConDriveEndNo;
	}

	/**
	 * @param bearingConDriveEndNo
	 *            the bearingConDriveEndNo to set
	 */
	public void setBearingConDriveEndNo(String bearingConDriveEndNo) {
		this.bearingConDriveEndNo = bearingConDriveEndNo;
	}

	/**
	 * @return the bearingConNondriveEndNo
	 */
	public String getBearingConNondriveEndNo() {
		return bearingConNondriveEndNo;
	}

	/**
	 * @param bearingConNondriveEndNo
	 *            the bearingConNondriveEndNo to set
	 */
	public void setBearingConNondriveEndNo(String bearingConNondriveEndNo) {
		this.bearingConNondriveEndNo = bearingConNondriveEndNo;
	}

	/**
	 * @return the otherObs
	 */
	public String getOtherObs() {
		return otherObs;
	}

	/**
	 * @param otherObs
	 *            the otherObs to set
	 */
	public void setOtherObs(String otherObs) {
		this.otherObs = otherObs;
	}

	/**
	 * @return the remarks
	 */
	public String getRemarks() {
		return remarks;
	}

	/**
	 * @param remarks
	 *            the remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/**
	 * @return the complaintDetail
	 */
	public String getComplaintDetail() {
		return complaintDetail;
	}

	/**
	 * @param complaintDetail
	 *            the complaintDetail to set
	 */
	public void setComplaintDetail(String complaintDetail) {
		this.complaintDetail = complaintDetail;
	}

	/**
	 * @return the hVTestVolt
	 */
	public String gethVTestVolt() {
		return hVTestVolt;
	}

	/**
	 * @param hVTestVolt
	 *            the hVTestVolt to set
	 */
	public void sethVTestVolt(String hVTestVolt) {
		this.hVTestVolt = hVTestVolt;
	}

	/**
	 * @return the iRAfterHVTest
	 */
	public String getiRAfterHVTest() {
		return iRAfterHVTest;
	}

	/**
	 * @param iRAfterHVTest
	 *            the iRAfterHVTest to set
	 */
	public void setiRAfterHVTest(String iRAfterHVTest) {
		this.iRAfterHVTest = iRAfterHVTest;
	}

	/**
	 * @return the repairsTimeEstimate
	 */
	public Float getRepairsTimeEstimate() {
		return repairsTimeEstimate;
	}

	/**
	 * @param repairsTimeEstimate
	 *            the repairsTimeEstimate to set
	 */
	public void setRepairsTimeEstimate(Float repairsTimeEstimate) {
		this.repairsTimeEstimate = repairsTimeEstimate;
	}

	/**
	 * @return the repairEstimateCost
	 */
	public Float getRepairEstimateCost() {
		return repairEstimateCost;
	}

	/**
	 * @param repairEstimateCost
	 *            the repairEstimateCost to set
	 */
	public void setRepairEstimateCost(Float repairEstimateCost) {
		this.repairEstimateCost = repairEstimateCost;
	}

	/**
	 * @return the materialEstimateCost
	 */
	public Float getMaterialEstimateCost() {
		return materialEstimateCost;
	}

	/**
	 * @param materialEstimateCost
	 *            the materialEstimateCost to set
	 */
	public void setMaterialEstimateCost(Float materialEstimateCost) {
		this.materialEstimateCost = materialEstimateCost;
	}

	/**
	 * @return the totalEstimateCost
	 */
	public Float getTotalEstimateCost() {
		return totalEstimateCost;
	}

	/**
	 * @param totalEstimateCost
	 *            the totalEstimateCost to set
	 */
	public void setTotalEstimateCost(Float totalEstimateCost) {
		this.totalEstimateCost = totalEstimateCost;
	}

	/**
	 * @return the noLoadVolts
	 */
	public Float getNoLoadVolts() {
		return noLoadVolts;
	}

	/**
	 * @param noLoadVolts
	 *            the noLoadVolts to set
	 */
	public void setNoLoadVolts(Float noLoadVolts) {
		this.noLoadVolts = noLoadVolts;
	}

	/**
	 * @return the rAmp
	 */
	public Float getrAmp() {
		return rAmp;
	}

	/**
	 * @param rAmp
	 *            the rAmp to set
	 */
	public void setrAmp(Float rAmp) {
		this.rAmp = rAmp;
	}

	/**
	 * @return the yAmp
	 */
	public Float getyAmp() {
		return yAmp;
	}

	/**
	 * @param yAmp
	 *            the yAmp to set
	 */
	public void setyAmp(Float yAmp) {
		this.yAmp = yAmp;
	}

	/**
	 * @return the bAmp
	 */
	public Float getbAmp() {
		return bAmp;
	}

	/**
	 * @param bAmp
	 *            the bAmp to set
	 */
	public void setbAmp(Float bAmp) {
		this.bAmp = bAmp;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn
	 *            the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId
	 *            the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the referredForReviewOn
	 */
	public Date getReferredForReviewOn() {
		return referredForReviewOn;
	}

	/**
	 * @param referredForReviewOn
	 *            the referredForReviewOn to set
	 */
	public void setReferredForReviewOn(Date referredForReviewOn) {
		this.referredForReviewOn = referredForReviewOn;
	}

	/**
	 * @return the referredForReviewByRefId
	 */
	public String getReferredForReviewByRefId() {
		return referredForReviewByRefId;
	}

	/**
	 * @param referredForReviewByRefId
	 *            the referredForReviewByRefId to set
	 */
	public void setReferredForReviewByRefId(String referredForReviewByRefId) {
		this.referredForReviewByRefId = referredForReviewByRefId;
	}

	
	

	/**
	 * @return the statusUpdatedOn
	 */
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param statusUpdatedOn the statusUpdatedOn to set
	 */
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}

	/**
	 * @return the statusUpdatedByRefId
	 */
	public String getStatusUpdatedByRefId() {
		return statusUpdatedByRefId;
	}

	/**
	 * @param statusUpdatedByRefId the statusUpdatedByRefId to set
	 */
	public void setStatusUpdatedByRefId(String statusUpdatedByRefId) {
		this.statusUpdatedByRefId = statusUpdatedByRefId;
	}

	/**
	 * @return the approvalStatus
	 */
	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the wornOutPart
	 */
	public String getWornOutPart() {
		return wornOutPart;
	}

	/**
	 * @param wornOutPart
	 *            the wornOutPart to set
	 */
	public void setWornOutPart(String wornOutPart) {
		this.wornOutPart = wornOutPart;
	}

	/**
	 * @return the scopeOfWork
	 */
	public String getScopeOfWork() {
		return scopeOfWork;
	}

	/**
	 * @param scopeOfWork
	 *            the scopeOfWork to set
	 */
	public void setScopeOfWork(String scopeOfWork) {
		this.scopeOfWork = scopeOfWork;
	}

	/**
	 * @return the subProcessFields
	 */
	public SubProcessFieldsDTO getSubProcessFields() {
		return subProcessFields;
	}

	/**
	 * @param subProcessFields
	 *            the subProcessFields to set
	 */
	public void setSubProcessFields(SubProcessFieldsDTO subProcessFields) {
		this.subProcessFields = subProcessFields;
	}

	/**
	 * @return the motorVoltageDetail
	 */
	public MotorVoltageDetailDTO getMotorVoltageDetail() {
		return motorVoltageDetail;
	}

	/**
	 * @param motorVoltageDetail
	 *            the motorVoltageDetail to set
	 */
	public void setMotorVoltageDetail(MotorVoltageDetailDTO motorVoltageDetail) {
		this.motorVoltageDetail = motorVoltageDetail;
	}

	/**
	 * @return the motorNamePlateDetail
	 */
	public MotorNamePlateDetailDTO getMotorNamePlateDetail() {
		return motorNamePlateDetail;
	}

	/**
	 * @param motorNamePlateDetail
	 *            the motorNamePlateDetail to set
	 */
	public void setMotorNamePlateDetail(MotorNamePlateDetailDTO motorNamePlateDetail) {
		this.motorNamePlateDetail = motorNamePlateDetail;
	}

	/**
	 * @return the electricalObservation
	 */
	public ElectricalObservationDTO getElectricalObservation() {
		return electricalObservation;
	}

	/**
	 * @param electricalObservation
	 *            the electricalObservation to set
	 */
	public void setElectricalObservation(ElectricalObservationDTO electricalObservation) {
		this.electricalObservation = electricalObservation;
	}

	/**
	 * @return the arcRepairEstimateList
	 */
	public List<ARCRepairEstimatesDTO> getArcRepairEstimateList() {
		return arcRepairEstimateList;
	}

	/**
	 * @param arcRepairEstimateList
	 *            the arcRepairEstimateList to set
	 */
	public void setArcRepairEstimateList(List<ARCRepairEstimatesDTO> arcRepairEstimateList) {
		this.arcRepairEstimateList = arcRepairEstimateList;
	}

	/**
	 * @return the arcSpareEstimateList
	 */
	public List<ARCSparesEstimatesDTO> getArcSpareEstimateList() {
		return arcSpareEstimateList;
	}

	/**
	 * @param arcSpareEstimateList
	 *            the arcSpareEstimateList to set
	 */
	public void setArcSpareEstimateList(List<ARCSparesEstimatesDTO> arcSpareEstimateList) {
		this.arcSpareEstimateList = arcSpareEstimateList;
	}

	/**
	 * @return the motorSpeedDetailList
	 */
	public List<MotorSpeedDetailDTO> getMotorSpeedDetailList() {
		return motorSpeedDetailList;
	}

	/**
	 * @param motorSpeedDetailList
	 *            the motorSpeedDetailList to set
	 */
	public void setMotorSpeedDetailList(List<MotorSpeedDetailDTO> motorSpeedDetailList) {
		this.motorSpeedDetailList = motorSpeedDetailList;
	}

	/**
	 * @return the arcApprovedOn
	 */
	public Date getArcApprovedOn() {
		return arcApprovedOn;
	}

	/**
	 * @param arcApprovedOn the arcApprovedOn to set
	 */
	public void setArcApprovedOn(Date arcApprovedOn) {
		this.arcApprovedOn = arcApprovedOn;
	}

	/**
	 * @return the arcReviewedBy
	 */
	public String getArcReviewedBy() {
		return arcReviewedBy;
	}

	/**
	 * @param arcReviewedBy the arcReviewedBy to set
	 */
	public void setArcReviewedBy(String arcReviewedBy) {
		this.arcReviewedBy = arcReviewedBy;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

}
