package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a603981
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalContactDetailDTO {
	private Long additionalContactDetailId;

	private String emailAddress;

	private String mobileNo;
	
	private String countyCode;
	
	private Integer notificationType;
	
	/**
	 * @return the notificationType
	 */
	public Integer getNotificationType() {
		return notificationType;
	}

	/**
	 * @param notificationType the notificationType to set
	 */
	public void setNotificationType(Integer notificationType) {
		this.notificationType = notificationType;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * @return the additionalContactDetailId
	 */
	public Long getAdditionalContactDetailId() {
		return additionalContactDetailId;
	}

	/**
	 * @param additionalContactDetailId
	 *            the additionalContactDetailId to set
	 */
	public void setAdditionalContactDetailId(Long additionalContactDetailId) {
		this.additionalContactDetailId = additionalContactDetailId;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the mobileNo
	 */
	public String getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo
	 *            the mobileNo to set
	 */
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
}
