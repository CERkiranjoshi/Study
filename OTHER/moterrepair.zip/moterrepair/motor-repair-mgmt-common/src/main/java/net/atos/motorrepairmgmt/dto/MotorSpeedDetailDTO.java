/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a593775
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorSpeedDetailDTO {

	private Long motorSpeedDetailId;

	private Float rAmp;

	private Float yAmp;

	private Float bAmp;

	private Integer rpm;

	private Integer loadType;

	/**
	 * @return the motorSpeedDetailId
	 */
	public Long getMotorSpeedDetailId() {
		return motorSpeedDetailId;
	}

	/**
	 * @param motorSpeedDetailId
	 *            the motorSpeedDetailId to set
	 */
	public void setMotorSpeedDetailId(Long motorSpeedDetailId) {
		this.motorSpeedDetailId = motorSpeedDetailId;
	}

	/**
	 * @return the rAmp
	 */
	public Float getrAmp() {
		return rAmp;
	}

	/**
	 * @param rAmp
	 *            the rAmp to set
	 */
	public void setrAmp(Float rAmp) {
		this.rAmp = rAmp;
	}

	/**
	 * @return the yAmp
	 */
	public Float getyAmp() {
		return yAmp;
	}

	/**
	 * @param yAmp
	 *            the yAmp to set
	 */
	public void setyAmp(Float yAmp) {
		this.yAmp = yAmp;
	}

	/**
	 * @return the bAmp
	 */
	public Float getbAmp() {
		return bAmp;
	}

	/**
	 * @param bAmp
	 *            the bAmp to set
	 */
	public void setbAmp(Float bAmp) {
		this.bAmp = bAmp;
	}

	/**
	 * @return the rpm
	 */
	public Integer getRpm() {
		return rpm;
	}

	/**
	 * @param rpm
	 *            the rpm to set
	 */
	public void setRpm(Integer rpm) {
		this.rpm = rpm;
	}

	/**
	 * @return the loadType
	 */
	public Integer getLoadType() {
		return loadType;
	}

	/**
	 * @param loadType
	 *            the loadType to set 0: No Load; 1: Full Load
	 */
	public void setLoadType(Integer loadType) {
		this.loadType = loadType;
	}
}
