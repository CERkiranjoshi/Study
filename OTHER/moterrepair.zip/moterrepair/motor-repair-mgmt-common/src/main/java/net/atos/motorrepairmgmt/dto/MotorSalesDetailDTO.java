package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610039
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorSalesDetailDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5146371874477048913L;

	private Long motorSalesDetailId;
	private String name;
	private String code;
	private Integer salesType;
	private Long parentId;
	//primary key for RegionMaster entity
	private Long regionId;
	private String tenantId;
	private String solutionCategoryId;
	
	/**
	 * @return the regionId
	 */
	public Long getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the motorSalesDetailId
	 */
	public Long getMotorSalesDetailId() {
		return motorSalesDetailId;
	}

	/**
	 * @param motorSalesDetailId
	 *            the motorSalesDetailId to set
	 */
	public void setMotorSalesDetailId(Long motorSalesDetailId) {
		this.motorSalesDetailId = motorSalesDetailId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the salesType
	 */
	public Integer getSalesType() {
		return salesType;
	}

	/**
	 * @param salesType
	 *            the salesType to set
	 */
	public void setSalesType(Integer salesType) {
		this.salesType = salesType;
	}

	/**
	 * @return the parentId
	 */
	public Long getParentId() {
		return parentId;
	}

	/**
	 * @param parentId
	 *            the parentId to set
	 */
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}
}
