/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Sweety Kothari
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorDetailsDTO {
	
	private String motorSnNum;
	private String mlfbSpiridon;
	private String motorSpiridonMaterialCode;
	private String motorIBaseNum;
	private String motorMaterialSpec;
	private int frameSize;
	private String productGrp;
	private String faultDesc;
	private Integer initialWarrantyClaim;
	private String initialWarrantyClaimSetByRefId;
	private String  salesDivRefId;
	private String  salesOfficeRefId;
	private String  salesOrgRefId;
	private String salesGrpRefId;
	private String  regionId;
	private Long subProcessId;
	private String groupName;
	
	/**
	 * @return the subProcessId
	 */
	public Long getSubProcessId() {
		return subProcessId;
	}
	/**
	 * @param subProcessId the subProcessId to set
	 */
	public void setSubProcessId(Long subProcessId) {
		this.subProcessId = subProcessId;
	}
	/**
	 * @return the motorSnNum
	 */
	public String getMotorSnNum() {
		return motorSnNum;
	}
	/**
	 * @param motorSnNum the motorSnNum to set
	 */
	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}
	/**
	 * @return the mlfbSpiridon
	 */
	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}
	/**
	 * @param mlfbSpiridon the mlfbSpiridon to set
	 */
	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}
	/**
	 * @return the motorSpiridonMaterialCode
	 */
	public String getMotorSpiridonMaterialCode() {
		return motorSpiridonMaterialCode;
	}
	/**
	 * @param motorSpiridonMaterialCode the motorSpiridonMaterialCode to set
	 */
	public void setMotorSpiridonMaterialCode(String motorSpiridonMaterialCode) {
		this.motorSpiridonMaterialCode = motorSpiridonMaterialCode;
	}
	/**
	 * @return the motorIBaseNum
	 */
	public String getMotorIBaseNum() {
		return motorIBaseNum;
	}
	/**
	 * @param motorIBaseNum the motorIBaseNum to set
	 */
	public void setMotorIBaseNum(String motorIBaseNum) {
		this.motorIBaseNum = motorIBaseNum;
	}
	/**
	 * @return the motorMaterialSpec
	 */
	public String getMotorMaterialSpec() {
		return motorMaterialSpec;
	}
	/**
	 * @param motorMaterialSpec the motorMaterialSpec to set
	 */
	public void setMotorMaterialSpec(String motorMaterialSpec) {
		this.motorMaterialSpec = motorMaterialSpec;
	}
	/**
	 * @return the frameSize
	 */
	public int getFrameSize() {
		return frameSize;
	}
	/**
	 * @param frameSize the frameSize to set
	 */
	public void setFrameSize(int frameSize) {
		this.frameSize = frameSize;
	}
	/**
	 * @return the productGrp
	 */
	public String getProductGrp() {
		return productGrp;
	}
	/**
	 * @param productGrp the productGrp to set
	 */
	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}
	/**
	 * @return the faultDesc
	 */
	public String getFaultDesc() {
		return faultDesc;
	}
	/**
	 * @param faultDesc the faultDesc to set
	 */
	public void setFaultDesc(String faultDesc) {
		this.faultDesc = faultDesc;
	}
	/**
	 * @return the initialWarrantyClaim
	 */
	public Integer getInitialWarrantyClaim() {
		return initialWarrantyClaim;
	}
	/**
	 * @param initialWarrantyClaim the initialWarrantyClaim to set
	 */
	public void setInitialWarrantyClaim(Integer initialWarrantyClaim) {
		this.initialWarrantyClaim = initialWarrantyClaim;
	}
	/**
	 * @return the initialWarrantyClaimSetByRefId
	 */
	public String getInitialWarrantyClaimSetByRefId() {
		return initialWarrantyClaimSetByRefId;
	}
	/**
	 * @param initialWarrantyClaimSetByRefId the initialWarrantyClaimSetByRefId to set
	 */
	public void setInitialWarrantyClaimSetByRefId(String initialWarrantyClaimSetByRefId) {
		this.initialWarrantyClaimSetByRefId = initialWarrantyClaimSetByRefId;
	}
	/**
	 * @return the salesDivRefId
	 */
	public String getSalesDivRefId() {
		return salesDivRefId;
	}
	/**
	 * @param salesDivRefId the salesDivRefId to set
	 */
	public void setSalesDivRefId(String salesDivRefId) {
		this.salesDivRefId = salesDivRefId;
	}
	/**
	 * @return the salesOfficeRefId
	 */
	public String getSalesOfficeRefId() {
		return salesOfficeRefId;
	}
	/**
	 * @param salesOfficeRefId the salesOfficeRefId to set
	 */
	public void setSalesOfficeRefId(String salesOfficeRefId) {
		this.salesOfficeRefId = salesOfficeRefId;
	}
	/**
	 * @return the salesOrgRefId
	 */
	public String getSalesOrgRefId() {
		return salesOrgRefId;
	}
	/**
	 * @param salesOrgRefId the salesOrgRefId to set
	 */
	public void setSalesOrgRefId(String salesOrgRefId) {
		this.salesOrgRefId = salesOrgRefId;
	}
	/**
	 * @return the regionId
	 */
	public String getRegionId() {
		return regionId;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	/**
	 * @return the salesGrpRefId
	 */
	public String getSalesGrpRefId() {
		return salesGrpRefId;
	}
	/**
	 * @param salesGrpRefId the salesGrpRefId to set
	 */
	public void setSalesGrpRefId(String salesGrpRefId) {
		this.salesGrpRefId = salesGrpRefId;
	}
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	
}