/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author Sweety Kothari
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigDetailDTO {
	
	private Long configId;
	  
    private String tenantId;
	
	private String configType;
	
	private String solutionCategoryId;
  
    private String configSubType;
	
    private String configKey;
	
    private String configAlias;
	
    private String configStrVal;
	
    private Integer configIntVal;
	
    private Double configDoubleVal;
	
    private Date configDateTimeVal;
	
    private Boolean configBooleanValue;
	
	//Config Type - 1: String value; 2: Integer; 3: Float; 4: Date Time; 5: Boolean
    private Integer cofigDataType;
	
    private Integer configEnabled;
	
    private Integer configVisiblity;
	
    private Integer configEditable;
    
    private Date createdOn;
    
   	private String createdByRefId;
   	
    private Date modifiedOn;
    
    private String modifiedByRefId;
       
    private String configDesc;
    
       
    public String getConfigDesc() {
		return configDesc;
	}

	public void setConfigDesc(String configDesc) {
		this.configDesc = configDesc;
	}

	/**
   	 * @return the createdOn
   	 */
   	public Date getCreatedOn() {
   		return createdOn;
   	}

   	/**
   	 * @param createdOn the createdOn to set
   	 */
   	public void setCreatedOn(Date createdOn) {
   		this.createdOn = createdOn;
   	}

   

   	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
   	 * @return the modifiedOn
   	 */
   	public Date getModifiedOn() {
   		return modifiedOn;
   	}

   	/**
   	 * @param modifiedOn the modifiedOn to set
   	 */
   	public void setModifiedOn(Date modifiedOn) {
   		this.modifiedOn = modifiedOn;
   	}

	/**
	 * @return the configId
	 */
	public Long getConfigId() {
		return configId;
	}

	/**
	 * @param configId the configId to set
	 */
	public void setConfigId(Long configId) {
		this.configId = configId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the configType
	 */
	public String getConfigType() {
		return configType;
	}

	/**
	 * @param configType the configType to set
	 */
	public void setConfigType(String configType) {
		this.configType = configType;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the configSubType
	 */
	public String getConfigSubType() {
		return configSubType;
	}

	/**
	 * @param configSubType the configSubType to set
	 */
	public void setConfigSubType(String configSubType) {
		this.configSubType = configSubType;
	}

	/**
	 * @return the configKey
	 */
	public String getConfigKey() {
		return configKey;
	}

	/**
	 * @param configKey the configKey to set
	 */
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	/**
	 * @return the configAlias
	 */
	public String getConfigAlias() {
		return configAlias;
	}

	/**
	 * @param configAlias the configAlias to set
	 */
	public void setConfigAlias(String configAlias) {
		this.configAlias = configAlias;
	}

	/**
	 * @return the configStrVal
	 */
	public String getConfigStrVal() {
		return configStrVal;
	}

	/**
	 * @param configStrVal the configStrVal to set
	 */
	public void setConfigStrVal(String configStrVal) {
		this.configStrVal = configStrVal;
	}

	/**
	 * @return the configIntVal
	 */
	public Integer getConfigIntVal() {
		return configIntVal;
	}

	/**
	 * @param configIntVal the configIntVal to set
	 */
	public void setConfigIntVal(Integer configIntVal) {
		this.configIntVal = configIntVal;
	}

	/**
	 * @return the configDoubleVal
	 */
	public Double getConfigDoubleVal() {
		return configDoubleVal;
	}

	/**
	 * @param configDoubleVal the configDoubleVal to set
	 */
	public void setConfigDoubleVal(Double configDoubleVal) {
		this.configDoubleVal = configDoubleVal;
	}

	/**
	 * @return the configDateTimeVal
	 */
	public Date getConfigDateTimeVal() {
		return configDateTimeVal;
	}

	/**
	 * @param configDateTimeVal the configDateTimeVal to set
	 */
	public void setConfigDateTimeVal(Date configDateTimeVal) {
		this.configDateTimeVal = configDateTimeVal;
	}

	

	/**
	 * @return the configBooleanValue
	 */
	public Boolean getConfigBooleanValue() {
		return configBooleanValue;
	}

	/**
	 * @param configBooleanValue the configBooleanValue to set
	 */
	public void setConfigBooleanValue(Boolean configBooleanValue) {
		this.configBooleanValue = configBooleanValue;
	}

	/**
	 * @return the cofigDataType
	 */
	public Integer getCofigDataType() {
		return cofigDataType;
	}

	/**
	 * @param cofigDataType the cofigDataType to set
	 */
	public void setCofigDataType(Integer cofigDataType) {
		this.cofigDataType = cofigDataType;
	}

	/**
	 * @return the configEnabled
	 */
	public Integer getConfigEnabled() {
		return configEnabled;
	}

	/**
	 * @param configEnabled the configEnabled to set
	 */
	public void setConfigEnabled(Integer configEnabled) {
		this.configEnabled = configEnabled;
	}

	/**
	 * @return the configVisiblity
	 */
	public Integer getConfigVisiblity() {
		return configVisiblity;
	}

	/**
	 * @param configVisiblity the configVisiblity to set
	 */
	public void setConfigVisiblity(Integer configVisiblity) {
		this.configVisiblity = configVisiblity;
	}

	/**
	 * @return the configEditable
	 */
	public Integer getConfigEditable() {
		return configEditable;
	}

	/**
	 * @param configEditable the configEditable to set
	 */
	public void setConfigEditable(Integer configEditable) {
		this.configEditable = configEditable;
	}
    
    

}
