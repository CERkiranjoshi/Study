package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;







import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorDetailsArcDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8558046626855534509L;

	private Long motorOrderDetailId;

	private String motorSnNum;

	private String mlfbSpiridon;

	private String motorSpiridonMaterialCode;

	private String motorIBaseNum;

	private String motorMaterialSpec;

	private int frameSize;

	private String productGrp;

	private String faultDesc;

	private Integer initialWarrantyClaim;

	private String initialWarrantyClaimSetByRefId;
	
	
	private Integer subWarrantyType;

	private String salesDivRefId;

	private String salesOfficeRefId;

	private String salesOrgRefId;

	private String salesGrpRefId;

	private String regionId;

	private Long subProcessId;

	private Integer tenantId;

	private Integer solutionCategoryId;
	private String createdBy;

	public Integer getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(Integer solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}




	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Long getMotorOrderDetailId() {
		return motorOrderDetailId;
	}

	public void setMotorOrderDetailId(Long motorOrderDetailId) {
		this.motorOrderDetailId = motorOrderDetailId;
	}

	public String getMotorSnNum() {
		return motorSnNum;
	}

	public void setMotorSnNum(String motorSnNum) {
		this.motorSnNum = motorSnNum;
	}

	public String getMlfbSpiridon() {
		return mlfbSpiridon;
	}

	public void setMlfbSpiridon(String mlfbSpiridon) {
		this.mlfbSpiridon = mlfbSpiridon;
	}

	public String getMotorSpiridonMaterialCode() {
		return motorSpiridonMaterialCode;
	}

	public void setMotorSpiridonMaterialCode(String motorSpiridonMaterialCode) {
		this.motorSpiridonMaterialCode = motorSpiridonMaterialCode;
	}

	public String getMotorIBaseNum() {
		return motorIBaseNum;
	}

	public void setMotorIBaseNum(String motorIBaseNum) {
		this.motorIBaseNum = motorIBaseNum;
	}

	public String getMotorMaterialSpec() {
		return motorMaterialSpec;
	}

	public void setMotorMaterialSpec(String motorMaterialSpec) {
		this.motorMaterialSpec = motorMaterialSpec;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getFrameSize() {
		return frameSize;
	}

	public void setFrameSize(int frameSize) {
		this.frameSize = frameSize;
	}

	public String getProductGrp() {
		return productGrp;
	}

	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	public String getFaultDesc() {
		return faultDesc;
	}

	public void setFaultDesc(String faultDesc) {
		this.faultDesc = faultDesc;
	}

	public Integer getInitialWarrantyClaim() {
		return initialWarrantyClaim;
	}

	public void setInitialWarrantyClaim(Integer initialWarrantyClaim) {
		this.initialWarrantyClaim = initialWarrantyClaim;
	}

	public String getInitialWarrantyClaimSetByRefId() {
		return initialWarrantyClaimSetByRefId;
	}

	public void setInitialWarrantyClaimSetByRefId(
			String initialWarrantyClaimSetByRefId) {
		this.initialWarrantyClaimSetByRefId = initialWarrantyClaimSetByRefId;
	}

	public String getSalesDivRefId() {
		return salesDivRefId;
	}

	public void setSalesDivRefId(String salesDivRefId) {
		this.salesDivRefId = salesDivRefId;
	}

	public String getSalesOfficeRefId() {
		return salesOfficeRefId;
	}

	public void setSalesOfficeRefId(String salesOfficeRefId) {
		this.salesOfficeRefId = salesOfficeRefId;
	}

	public String getSalesOrgRefId() {
		return salesOrgRefId;
	}

	public void setSalesOrgRefId(String salesOrgRefId) {
		this.salesOrgRefId = salesOrgRefId;
	}

	public String getSalesGrpRefId() {
		return salesGrpRefId;
	}

	public void setSalesGrpRefId(String salesGrpRefId) {
		this.salesGrpRefId = salesGrpRefId;
	}

	public String getRegionId() {
		return regionId;
	}

	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	public Long getSubProcessId() {
		return subProcessId;
	}

	public void setSubProcessId(Long subProcessId) {
		this.subProcessId = subProcessId;
	}
	
	public Integer getSubWarrantyType() {
		return subWarrantyType;
	}

	/**
	 * @param subWarrantyType
	 *            the subWarrantyType to set 1: Paid; 2:Void;3-Product Warranty;
	 *            4:Repair Warranty; 5: CTS & contract
	 */
	public void setSubWarrantyType(Integer subWarrantyType) {
		this.subWarrantyType = subWarrantyType;
	}

	
	
	

}
