/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.util.Date;

/**
 * @author a545466
 *
 */
public class SubProcessGroupDetailDTO {

	private Long groupId;		
	private String groupName;
	private String batchProcessId;		
	private String tenantId;	
	private String solutionCategoryId;	
	private Date createdOn;
	private Long masterWorkflowFieldId;
	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @return the batchProcessId
	 */
	public String getBatchProcessId() {
		return batchProcessId;
	}
	/**
	 * @param batchProcessId the batchProcessId to set
	 */
	public void setBatchProcessId(String batchProcessId) {
		this.batchProcessId = batchProcessId;
	}
	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}
	/**
	 * @param tenantId the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}
	/**
	 * @param solutionCategoryId the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}
	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}
	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	/**
	 * @return the masterWorkflowFieldId
	 */
	public Long getMasterWorkflowFieldId() {
		return masterWorkflowFieldId;
	}
	/**
	 * @param masterWorkflowFieldId the masterWorkflowFieldId to set
	 */
	public void setMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		this.masterWorkflowFieldId = masterWorkflowFieldId;
	}
	
	
}
