package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TicketDetailsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8558046626855534509L;
	
	private Long ticketdetailsId;
	private String arcJobRefNmuber;
	private String internalComments;
	private String tenantId;
	private String solutionCategoryId;
	private String createdBy;
	private MotorDetailsArcDTO motorDetailsArc;
	private EndCustomerDetailsArcDTO endCustomerDetailsArc;
	private Long refId;
	private Integer ticketStatus; // 0 - Editable by by ARC; 1 - Viewable by CCC; 2 - Ticket Created for this motor.
	private Date createdOn;  // createdOn
	private Date modifiedOn;  // modifiedOn
	
	private String modifiedBy;
	// ARC
	private String submittedBy; // submittedBy
	private Date submittedOn; // submittedOn
	
	// CCC
	private String ticketCreatedBy; 	// ticketCreatedBy
	private Date ticketCreatedOn; // ticketCreatedOn
	private Integer gspTicketReferenceNum ;// gspTicketReferenceNum
	private String claimRefId ;// claimReferenceId

	public Long getTicketdetailsId() {
		return ticketdetailsId;
	}

	public void setTicketdetailsId(Long ticketdetailsId) {
		this.ticketdetailsId = ticketdetailsId;
	}
	
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	public String getArcJobRefNmuber() {
		return arcJobRefNmuber;
	}

	public void setArcJobRefNmuber(String arcJobRefNmuber) {
		this.arcJobRefNmuber = arcJobRefNmuber;
	}

	public String getInternalComments() {
		return internalComments;
	}

	public void setInternalComments(String internalComments) {
		this.internalComments = internalComments;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the motorDetailsArc
	 */
	public MotorDetailsArcDTO getMotorDetailsArc() {
		return motorDetailsArc;
	}

	/**
	 * @param motorDetailsArc the motorDetailsArc to set
	 */
	public void setMotorDetailsArc(MotorDetailsArcDTO motorDetailsArc) {
		this.motorDetailsArc = motorDetailsArc;
	}

	/**
	 * @return the endCustomerDetailsArc
	 */
	public EndCustomerDetailsArcDTO getEndCustomerDetailsArc() {
		return endCustomerDetailsArc;
	}

	/**
	 * @param endCustomerDetailsArc the endCustomerDetailsArc to set
	 */
	public void setEndCustomerDetailsArc(EndCustomerDetailsArcDTO endCustomerDetailsArc) {
		this.endCustomerDetailsArc = endCustomerDetailsArc;
	}

	public Integer getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(Integer ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getSubmittedBy() {
		return submittedBy;
	}

	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}

	public Date getSubmittedOn() {
		return submittedOn;
	}

	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}

	public String getTicketCreatedBy() {
		return ticketCreatedBy;
	}

	public void setTicketCreatedBy(String ticketCreatedBy) {
		this.ticketCreatedBy = ticketCreatedBy;
	}

	public Date getTicketCreatedOn() {
		return ticketCreatedOn;
	}

	public void setTicketCreatedOn(Date ticketCreatedOn) {
		this.ticketCreatedOn = ticketCreatedOn;
	}

	public Integer getGspTicketReferenceNum() {
		return gspTicketReferenceNum;
	}

	public void setGspTicketReferenceNum(Integer gspTicketReferenceNum) {
		this.gspTicketReferenceNum = gspTicketReferenceNum;
	}
	public Long getRefId() {
		return refId;
	}

	public void setRefId(Long refId) {
		this.refId = refId;
	}

	/**
	 * @return the claimRefId
	 */
	public String getClaimRefId() {
		return claimRefId;
	}

	/**
	 * @param claimRefId the claimRefId to set
	 */
	public void setClaimRefId(String claimRefId) {
		this.claimRefId = claimRefId;
	}
	

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
}
