package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ARCSparesEstimatesDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7481306718117677433L;

	private Long arcSparesEstimateId;
	private String materialCode;
	private String materialDesc;
	private Integer qty;
	private String itemUnit;
	private Double totalCost;

	/**
	 * @return the arcSparesEstimateId
	 */
	public Long getArcSparesEstimateId() {
		return arcSparesEstimateId;
	}

	/**
	 * @param arcSparesEstimateId
	 *            the arcSparesEstimateId to set
	 */
	public void setArcSparesEstimateId(Long arcSparesEstimateId) {
		this.arcSparesEstimateId = arcSparesEstimateId;
	}

	/**
	 * @return the materialCode
	 */
	public String getMaterialCode() {
		return materialCode;
	}

	/**
	 * @param materialCode
	 *            the materialCode to set
	 */
	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	/**
	 * @return the materialDesc
	 */
	public String getMaterialDesc() {
		return materialDesc;
	}

	/**
	 * @param materialDesc
	 *            the materialDesc to set
	 */
	public void setMaterialDesc(String materialDesc) {
		this.materialDesc = materialDesc;
	}

	/**
	 * @return the qty
	 */
	public Integer getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set
	 */
	public void setQty(Integer qty) {
		this.qty = qty;
	}

	/**
	 * @return the itemUnit
	 */
	public String getItemUnit() {
		return itemUnit;
	}

	/**
	 * @param itemUnit the itemUnit to set
	 */
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	/**
	 * @return the totalCost
	 */
	public Double getTotalCost() {
		return totalCost;
	}

	/**
	 * @param totalCost
	 *            the totalCost to set
	 */
	public void setTotalCost(Double totalCost) {
		this.totalCost = totalCost;
	}

}
