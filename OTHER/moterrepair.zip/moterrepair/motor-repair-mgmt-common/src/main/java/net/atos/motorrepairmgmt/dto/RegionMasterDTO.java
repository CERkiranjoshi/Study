/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;

/**
 * @author a593775
 *
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class RegionMasterDTO {

	private Long regionId;

	private String regionName;

	private Integer regionEnabled;

	private String tenantId;

	private String solutionCategoryId;

	private List<ARCMasterDTO> arcMasterList;

	/**
	 * @return the regionId
	 */
	public Long getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId
	 *            the regionId to set
	 */
	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}

	/**
	 * @param regionName
	 *            the regionName to set
	 * 
	 *            region can be East, North, West, South etc, based on business
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	/**
	 * @return the regionEnabled
	 */
	public Integer getRegionEnabled() {
		return regionEnabled;
	}

	/**
	 * @param regionEnabled
	 *            the regionEnabled to set
	 */
	public void setRegionEnabled(Integer regionEnabled) {
		this.regionEnabled = regionEnabled;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	/**
	 * @return the arcMasterList
	 */
	public List<ARCMasterDTO> getArcMasterList() {
		return arcMasterList;
	}

	/**
	 * @param arcMasterList
	 *            the arcMasterList to set
	 */
	public void setArcMasterList(List<ARCMasterDTO> arcMasterList) {
		this.arcMasterList = arcMasterList;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public String getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(String solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

}
