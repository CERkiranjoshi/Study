package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DReportFieldsDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2266092295698265984L;

	private Long motorDReportFieldId;
	private Integer aFootBreakage;
	private Integer aFinsBreakage;
	private Integer bHousing;
	private Integer bFanCowl;
	private Integer bFanEndshield;
	private Integer bTerminalBoxBreakage;
	private Integer cFanMelting;
	private Integer dBrushBlockDamage;
	private Integer eShortCircuitRingBroken;
	private Integer fVibrationTooHigh;
	private Integer gBearingLooseInEndshield;
	private Integer gShaft;
	private Integer hBearingFailure;
	private Integer hNoisy;
	private Integer hSeize;
	private Integer iShaftBreakage;
	private Integer jIngressOfWater;
	private Integer jChemicals;
	private Integer kMotorDrawsUnbalance;
	private Integer kHighCurrent;
	private Integer lMotorGettingExcessivelyHot;
	private Integer mMotorNotStarting;
	private Integer mNotPickingUpSpeed;
	private Integer nHookUpWiresDefective;
	private Integer oWindingBurnt;
	private Integer pWindingInterturnShort;
	private Integer qInsulationFailure;
	private Integer qEarthFault;
	private Integer rInterphaseInsulationFailure;
	private Integer sMiscellaneous;
	private Integer tAxialPlay;
	private Integer uRotorDefect;
	private Integer vBalWtFalling;
	private Integer wRTD;
	private Integer wPTCDefect;
	private Integer iWrongHandling;
	private Integer iTransport;
	private Integer iiImproperStorage;
	private Integer iiiWrongInstallation;
	private Integer ivDefectiveCoupling;
	private Integer ivAlignment;
	private Integer vWrongSelection;
	private Integer vApplication;
	private Integer viIncorrectDutyCycle;
	private Integer viiImproperVentilation;
	private Integer viiiSupplyConditionVoltage;
	private Integer viiiSupplyConditionFrequency;
	private Integer ixOverloading;
	private Integer xSinglePhasing;
	private Integer xiPoorMaintenance;
	private Float xiiHighAmbTempDeg;
	private Integer xiiiSiteConditionDusty;
	private Integer xiiiSiteConditionCorrosive;
	private Integer xiiiSiteConditionIndoor;
	private Integer xiiiSiteConditionOutdoor;
	private Integer xivMiscellaneous;
	private String miscComments;
	private String notificationNum;
	private Date createdOn;
	private String createdByRefId;
	private Date modifiedOn;
	private String modifiedByRefId;
	private Date referredForReviewOn;
	private String referredForReviewByRefId;
	private Date approvedOn;
	private String approvedByRefId;
	private Integer approvalStatus;
	private Date arcApprovedOn;
	private String arcReviewedBy;
	private Date statusUpdatedOn;
	private String statusUpdatedByRefId;
	private SubProcessFieldsDTO subProcessFields;
	private MotorNamePlateDetailDTO motorNamePlateDetail;
	private String functionCode;

	/**
	 * @return the motorDReportFieldId
	 */
	public Long getMotorDReportFieldId() {
		return motorDReportFieldId;
	}

	/**
	 * @param motorDReportFieldId
	 *            the motorDReportFieldId to set
	 */
	public void setMotorDReportFieldId(Long motorDReportFieldId) {
		this.motorDReportFieldId = motorDReportFieldId;
	}

	/**
	 * @return the aFootBreakage
	 */
	public Integer getaFootBreakage() {
		return aFootBreakage;
	}

	/**
	 * @param aFootBreakage
	 *            the aFootBreakage to set
	 */
	public void setaFootBreakage(Integer aFootBreakage) {
		this.aFootBreakage = aFootBreakage;
	}

	/**
	 * @return the aFinsBreakage
	 */
	public Integer getaFinsBreakage() {
		return aFinsBreakage;
	}

	/**
	 * @param aFinsBreakage
	 *            the aFinsBreakage to set
	 */
	public void setaFinsBreakage(Integer aFinsBreakage) {
		this.aFinsBreakage = aFinsBreakage;
	}

	/**
	 * @return the bHousing
	 */
	public Integer getbHousing() {
		return bHousing;
	}

	/**
	 * @param bHousing
	 *            the bHousing to set
	 */
	public void setbHousing(Integer bHousing) {
		this.bHousing = bHousing;
	}

	/**
	 * @return the bFanCowl
	 */
	public Integer getbFanCowl() {
		return bFanCowl;
	}

	/**
	 * @param bFanCowl
	 *            the bFanCowl to set
	 */
	public void setbFanCowl(Integer bFanCowl) {
		this.bFanCowl = bFanCowl;
	}

	/**
	 * @return the bFanEndshield
	 */
	public Integer getbFanEndshield() {
		return bFanEndshield;
	}

	/**
	 * @param bFanEndshield
	 *            the bFanEndshield to set
	 */
	public void setbFanEndshield(Integer bFanEndshield) {
		this.bFanEndshield = bFanEndshield;
	}

	/**
	 * @return the bTerminalBoxBreakage
	 */
	public Integer getbTerminalBoxBreakage() {
		return bTerminalBoxBreakage;
	}

	/**
	 * @param bTerminalBoxBreakage
	 *            the bTerminalBoxBreakage to set
	 */
	public void setbTerminalBoxBreakage(Integer bTerminalBoxBreakage) {
		this.bTerminalBoxBreakage = bTerminalBoxBreakage;
	}

	/**
	 * @return the cFanMelting
	 */
	public Integer getcFanMelting() {
		return cFanMelting;
	}

	/**
	 * @param cFanMelting
	 *            the cFanMelting to set
	 */
	public void setcFanMelting(Integer cFanMelting) {
		this.cFanMelting = cFanMelting;
	}

	/**
	 * @return the dBrushBlockDamage
	 */
	public Integer getdBrushBlockDamage() {
		return dBrushBlockDamage;
	}

	/**
	 * @param dBrushBlockDamage
	 *            the dBrushBlockDamage to set
	 */
	public void setdBrushBlockDamage(Integer dBrushBlockDamage) {
		this.dBrushBlockDamage = dBrushBlockDamage;
	}

	/**
	 * @return the eShortCircuitRingBroken
	 */
	public Integer geteShortCircuitRingBroken() {
		return eShortCircuitRingBroken;
	}

	/**
	 * @param eShortCircuitRingBroken
	 *            the eShortCircuitRingBroken to set
	 */
	public void seteShortCircuitRingBroken(Integer eShortCircuitRingBroken) {
		this.eShortCircuitRingBroken = eShortCircuitRingBroken;
	}

	/**
	 * @return the fVibrationTooHigh
	 */
	public Integer getfVibrationTooHigh() {
		return fVibrationTooHigh;
	}

	/**
	 * @param fVibrationTooHigh
	 *            the fVibrationTooHigh to set
	 */
	public void setfVibrationTooHigh(Integer fVibrationTooHigh) {
		this.fVibrationTooHigh = fVibrationTooHigh;
	}

	/**
	 * @return the gBearingLooseInEndshield
	 */
	public Integer getgBearingLooseInEndshield() {
		return gBearingLooseInEndshield;
	}

	/**
	 * @param gBearingLooseInEndshield
	 *            the gBearingLooseInEndshield to set
	 */
	public void setgBearingLooseInEndshield(Integer gBearingLooseInEndshield) {
		this.gBearingLooseInEndshield = gBearingLooseInEndshield;
	}

	/**
	 * @return the gShaft
	 */
	public Integer getgShaft() {
		return gShaft;
	}

	/**
	 * @param gShaft
	 *            the gShaft to set
	 */
	public void setgShaft(Integer gShaft) {
		this.gShaft = gShaft;
	}

	/**
	 * @return the hBearingFailure
	 */
	public Integer gethBearingFailure() {
		return hBearingFailure;
	}

	/**
	 * @param hBearingFailure
	 *            the hBearingFailure to set
	 */
	public void sethBearingFailure(Integer hBearingFailure) {
		this.hBearingFailure = hBearingFailure;
	}

	/**
	 * @return the hNoisy
	 */
	public Integer gethNoisy() {
		return hNoisy;
	}

	/**
	 * @param hNoisy
	 *            the hNoisy to set
	 */
	public void sethNoisy(Integer hNoisy) {
		this.hNoisy = hNoisy;
	}

	/**
	 * @return the hSeize
	 */
	public Integer gethSeize() {
		return hSeize;
	}

	/**
	 * @param hSeize
	 *            the hSeize to set
	 */
	public void sethSeize(Integer hSeize) {
		this.hSeize = hSeize;
	}

	/**
	 * @return the iShaftBreakage
	 */
	public Integer getiShaftBreakage() {
		return iShaftBreakage;
	}

	/**
	 * @param iShaftBreakage
	 *            the iShaftBreakage to set
	 */
	public void setiShaftBreakage(Integer iShaftBreakage) {
		this.iShaftBreakage = iShaftBreakage;
	}

	/**
	 * @return the jIngressOfWater
	 */
	public Integer getjIngressOfWater() {
		return jIngressOfWater;
	}

	/**
	 * @param jIngressOfWater
	 *            the jIngressOfWater to set
	 */
	public void setjIngressOfWater(Integer jIngressOfWater) {
		this.jIngressOfWater = jIngressOfWater;
	}

	/**
	 * @return the jChemicals
	 */
	public Integer getjChemicals() {
		return jChemicals;
	}

	/**
	 * @param jChemicals
	 *            the jChemicals to set
	 */
	public void setjChemicals(Integer jChemicals) {
		this.jChemicals = jChemicals;
	}

	/**
	 * @return the kMotorDrawsUnbalance
	 */
	public Integer getkMotorDrawsUnbalance() {
		return kMotorDrawsUnbalance;
	}

	/**
	 * @param kMotorDrawsUnbalance
	 *            the kMotorDrawsUnbalance to set
	 */
	public void setkMotorDrawsUnbalance(Integer kMotorDrawsUnbalance) {
		this.kMotorDrawsUnbalance = kMotorDrawsUnbalance;
	}

	/**
	 * @return the kHighCurrent
	 */
	public Integer getkHighCurrent() {
		return kHighCurrent;
	}

	/**
	 * @param kHighCurrent
	 *            the kHighCurrent to set
	 */
	public void setkHighCurrent(Integer kHighCurrent) {
		this.kHighCurrent = kHighCurrent;
	}

	/**
	 * @return the lMotorGettingExcessivelyHot
	 */
	public Integer getlMotorGettingExcessivelyHot() {
		return lMotorGettingExcessivelyHot;
	}

	/**
	 * @param lMotorGettingExcessivelyHot
	 *            the lMotorGettingExcessivelyHot to set
	 */
	public void setlMotorGettingExcessivelyHot(Integer lMotorGettingExcessivelyHot) {
		this.lMotorGettingExcessivelyHot = lMotorGettingExcessivelyHot;
	}

	/**
	 * @return the mMotorNotStarting
	 */
	public Integer getmMotorNotStarting() {
		return mMotorNotStarting;
	}

	/**
	 * @param mMotorNotStarting
	 *            the mMotorNotStarting to set
	 */
	public void setmMotorNotStarting(Integer mMotorNotStarting) {
		this.mMotorNotStarting = mMotorNotStarting;
	}

	/**
	 * @return the mNotPickingUpSpeed
	 */
	public Integer getmNotPickingUpSpeed() {
		return mNotPickingUpSpeed;
	}

	/**
	 * @param mNotPickingUpSpeed
	 *            the mNotPickingUpSpeed to set
	 */
	public void setmNotPickingUpSpeed(Integer mNotPickingUpSpeed) {
		this.mNotPickingUpSpeed = mNotPickingUpSpeed;
	}

	/**
	 * @return the nHookUpWiresDefective
	 */
	public Integer getnHookUpWiresDefective() {
		return nHookUpWiresDefective;
	}

	/**
	 * @param nHookUpWiresDefective
	 *            the nHookUpWiresDefective to set
	 */
	public void setnHookUpWiresDefective(Integer nHookUpWiresDefective) {
		this.nHookUpWiresDefective = nHookUpWiresDefective;
	}

	/**
	 * @return the oWindingBurnt
	 */
	public Integer getoWindingBurnt() {
		return oWindingBurnt;
	}

	/**
	 * @param oWindingBurnt
	 *            the oWindingBurnt to set
	 */
	public void setoWindingBurnt(Integer oWindingBurnt) {
		this.oWindingBurnt = oWindingBurnt;
	}

	/**
	 * @return the pWindingInterturnShort
	 */
	public Integer getpWindingInterturnShort() {
		return pWindingInterturnShort;
	}

	/**
	 * @param pWindingInterturnShort
	 *            the pWindingInterturnShort to set
	 */
	public void setpWindingInterturnShort(Integer pWindingInterturnShort) {
		this.pWindingInterturnShort = pWindingInterturnShort;
	}

	/**
	 * @return the qInsulationFailure
	 */
	public Integer getqInsulationFailure() {
		return qInsulationFailure;
	}

	/**
	 * @param qInsulationFailure
	 *            the qInsulationFailure to set
	 */
	public void setqInsulationFailure(Integer qInsulationFailure) {
		this.qInsulationFailure = qInsulationFailure;
	}

	/**
	 * @return the qEarthFault
	 */
	public Integer getqEarthFault() {
		return qEarthFault;
	}

	/**
	 * @param qEarthFault
	 *            the qEarthFault to set
	 */
	public void setqEarthFault(Integer qEarthFault) {
		this.qEarthFault = qEarthFault;
	}

	/**
	 * @return the rInterphaseInsulationFailure
	 */
	public Integer getrInterphaseInsulationFailure() {
		return rInterphaseInsulationFailure;
	}

	/**
	 * @param rInterphaseInsulationFailure
	 *            the rInterphaseInsulationFailure to set
	 */
	public void setrInterphaseInsulationFailure(Integer rInterphaseInsulationFailure) {
		this.rInterphaseInsulationFailure = rInterphaseInsulationFailure;
	}

	/**
	 * @return the sMiscellaneous
	 */
	public Integer getsMiscellaneous() {
		return sMiscellaneous;
	}

	/**
	 * @param sMiscellaneous
	 *            the sMiscellaneous to set
	 */
	public void setsMiscellaneous(Integer sMiscellaneous) {
		this.sMiscellaneous = sMiscellaneous;
	}

	/**
	 * @return the tAxialPlay
	 */
	public Integer gettAxialPlay() {
		return tAxialPlay;
	}

	/**
	 * @param tAxialPlay
	 *            the tAxialPlay to set
	 */
	public void settAxialPlay(Integer tAxialPlay) {
		this.tAxialPlay = tAxialPlay;
	}

	/**
	 * @return the uRotorDefect
	 */
	public Integer getuRotorDefect() {
		return uRotorDefect;
	}

	/**
	 * @param uRotorDefect
	 *            the uRotorDefect to set
	 */
	public void setuRotorDefect(Integer uRotorDefect) {
		this.uRotorDefect = uRotorDefect;
	}

	/**
	 * @return the vBalWtFalling
	 */
	public Integer getvBalWtFalling() {
		return vBalWtFalling;
	}

	/**
	 * @param vBalWtFalling
	 *            the vBalWtFalling to set
	 */
	public void setvBalWtFalling(Integer vBalWtFalling) {
		this.vBalWtFalling = vBalWtFalling;
	}

	/**
	 * @return the wRTD
	 */
	public Integer getwRTD() {
		return wRTD;
	}

	/**
	 * @param wRTD
	 *            the wRTD to set
	 */
	public void setwRTD(Integer wRTD) {
		this.wRTD = wRTD;
	}

	/**
	 * @return the wPTCDefect
	 */
	public Integer getwPTCDefect() {
		return wPTCDefect;
	}

	/**
	 * @param wPTCDefect
	 *            the wPTCDefect to set
	 */
	public void setwPTCDefect(Integer wPTCDefect) {
		this.wPTCDefect = wPTCDefect;
	}

	/**
	 * @return the iWrongHandling
	 */
	public Integer getiWrongHandling() {
		return iWrongHandling;
	}

	/**
	 * @param iWrongHandling
	 *            the iWrongHandling to set
	 */
	public void setiWrongHandling(Integer iWrongHandling) {
		this.iWrongHandling = iWrongHandling;
	}

	/**
	 * @return the iTransport
	 */
	public Integer getiTransport() {
		return iTransport;
	}

	/**
	 * @param iTransport
	 *            the iTransport to set
	 */
	public void setiTransport(Integer iTransport) {
		this.iTransport = iTransport;
	}

	/**
	 * @return the iiImproperStorage
	 */
	public Integer getIiImproperStorage() {
		return iiImproperStorage;
	}

	/**
	 * @param iiImproperStorage
	 *            the iiImproperStorage to set
	 */
	public void setIiImproperStorage(Integer iiImproperStorage) {
		this.iiImproperStorage = iiImproperStorage;
	}

	/**
	 * @return the iiiWrongInstallation
	 */
	public Integer getIiiWrongInstallation() {
		return iiiWrongInstallation;
	}

	/**
	 * @param iiiWrongInstallation
	 *            the iiiWrongInstallation to set
	 */
	public void setIiiWrongInstallation(Integer iiiWrongInstallation) {
		this.iiiWrongInstallation = iiiWrongInstallation;
	}

	/**
	 * @return the ivDefectiveCoupling
	 */
	public Integer getIvDefectiveCoupling() {
		return ivDefectiveCoupling;
	}

	/**
	 * @param ivDefectiveCoupling
	 *            the ivDefectiveCoupling to set
	 */
	public void setIvDefectiveCoupling(Integer ivDefectiveCoupling) {
		this.ivDefectiveCoupling = ivDefectiveCoupling;
	}

	/**
	 * @return the ivAlignment
	 */
	public Integer getIvAlignment() {
		return ivAlignment;
	}

	/**
	 * @param ivAlignment
	 *            the ivAlignment to set
	 */
	public void setIvAlignment(Integer ivAlignment) {
		this.ivAlignment = ivAlignment;
	}

	/**
	 * @return the vWrongSelection
	 */
	public Integer getvWrongSelection() {
		return vWrongSelection;
	}

	/**
	 * @param vWrongSelection
	 *            the vWrongSelection to set
	 */
	public void setvWrongSelection(Integer vWrongSelection) {
		this.vWrongSelection = vWrongSelection;
	}

	/**
	 * @return the vApplication
	 */
	public Integer getvApplication() {
		return vApplication;
	}

	/**
	 * @param vApplication
	 *            the vApplication to set
	 */
	public void setvApplication(Integer vApplication) {
		this.vApplication = vApplication;
	}

	/**
	 * @return the viIncorrectDutyCycle
	 */
	public Integer getViIncorrectDutyCycle() {
		return viIncorrectDutyCycle;
	}

	/**
	 * @param viIncorrectDutyCycle
	 *            the viIncorrectDutyCycle to set
	 */
	public void setViIncorrectDutyCycle(Integer viIncorrectDutyCycle) {
		this.viIncorrectDutyCycle = viIncorrectDutyCycle;
	}

	/**
	 * @return the viiImproperVentilation
	 */
	public Integer getViiImproperVentilation() {
		return viiImproperVentilation;
	}

	/**
	 * @param viiImproperVentilation
	 *            the viiImproperVentilation to set
	 */
	public void setViiImproperVentilation(Integer viiImproperVentilation) {
		this.viiImproperVentilation = viiImproperVentilation;
	}

	/**
	 * @return the viiiSupplyConditionVoltage
	 */
	public Integer getViiiSupplyConditionVoltage() {
		return viiiSupplyConditionVoltage;
	}

	/**
	 * @param viiiSupplyConditionVoltage
	 *            the viiiSupplyConditionVoltage to set
	 */
	public void setViiiSupplyConditionVoltage(Integer viiiSupplyConditionVoltage) {
		this.viiiSupplyConditionVoltage = viiiSupplyConditionVoltage;
	}

	/**
	 * @return the viiiSupplyConditionFrequency
	 */
	public Integer getViiiSupplyConditionFrequency() {
		return viiiSupplyConditionFrequency;
	}

	/**
	 * @param viiiSupplyConditionFrequency
	 *            the viiiSupplyConditionFrequency to set
	 */
	public void setViiiSupplyConditionFrequency(Integer viiiSupplyConditionFrequency) {
		this.viiiSupplyConditionFrequency = viiiSupplyConditionFrequency;
	}

	/**
	 * @return the ixOverloading
	 */
	public Integer getIxOverloading() {
		return ixOverloading;
	}

	/**
	 * @param ixOverloading
	 *            the ixOverloading to set
	 */
	public void setIxOverloading(Integer ixOverloading) {
		this.ixOverloading = ixOverloading;
	}

	/**
	 * @return the xSinglePhasing
	 */
	public Integer getxSinglePhasing() {
		return xSinglePhasing;
	}

	/**
	 * @param xSinglePhasing
	 *            the xSinglePhasing to set
	 */
	public void setxSinglePhasing(Integer xSinglePhasing) {
		this.xSinglePhasing = xSinglePhasing;
	}

	/**
	 * @return the xiPoorMaintenance
	 */
	public Integer getXiPoorMaintenance() {
		return xiPoorMaintenance;
	}

	/**
	 * @param xiPoorMaintenance
	 *            the xiPoorMaintenance to set
	 */
	public void setXiPoorMaintenance(Integer xiPoorMaintenance) {
		this.xiPoorMaintenance = xiPoorMaintenance;
	}

	/**
	 * @return the xiiHighAmbTempDeg
	 */
	public Float getXiiHighAmbTempDeg() {
		return xiiHighAmbTempDeg;
	}

	/**
	 * @param xiiHighAmbTempDeg
	 *            the xiiHighAmbTempDeg to set
	 */
	public void setXiiHighAmbTempDeg(Float xiiHighAmbTempDeg) {
		this.xiiHighAmbTempDeg = xiiHighAmbTempDeg;
	}

	/**
	 * @return the xiiiSiteConditionDusty
	 */
	public Integer getXiiiSiteConditionDusty() {
		return xiiiSiteConditionDusty;
	}

	/**
	 * @param xiiiSiteConditionDusty
	 *            the xiiiSiteConditionDusty to set
	 */
	public void setXiiiSiteConditionDusty(Integer xiiiSiteConditionDusty) {
		this.xiiiSiteConditionDusty = xiiiSiteConditionDusty;
	}

	/**
	 * @return the xiiiSiteConditionCorrosive
	 */
	public Integer getXiiiSiteConditionCorrosive() {
		return xiiiSiteConditionCorrosive;
	}

	/**
	 * @param xiiiSiteConditionCorrosive
	 *            the xiiiSiteConditionCorrosive to set
	 */
	public void setXiiiSiteConditionCorrosive(Integer xiiiSiteConditionCorrosive) {
		this.xiiiSiteConditionCorrosive = xiiiSiteConditionCorrosive;
	}

	/**
	 * @return the xiiiSiteConditionIndoor
	 */
	public Integer getXiiiSiteConditionIndoor() {
		return xiiiSiteConditionIndoor;
	}

	/**
	 * @param xiiiSiteConditionIndoor
	 *            the xiiiSiteConditionIndoor to set
	 */
	public void setXiiiSiteConditionIndoor(Integer xiiiSiteConditionIndoor) {
		this.xiiiSiteConditionIndoor = xiiiSiteConditionIndoor;
	}

	/**
	 * @return the xiiiSiteConditionOutdoor
	 */
	public Integer getXiiiSiteConditionOutdoor() {
		return xiiiSiteConditionOutdoor;
	}

	/**
	 * @param xiiiSiteConditionOutdoor
	 *            the xiiiSiteConditionOutdoor to set
	 */
	public void setXiiiSiteConditionOutdoor(Integer xiiiSiteConditionOutdoor) {
		this.xiiiSiteConditionOutdoor = xiiiSiteConditionOutdoor;
	}

	/**
	 * @return the xivMiscellaneous
	 */
	public Integer getXivMiscellaneous() {
		return xivMiscellaneous;
	}

	/**
	 * @param xivMiscellaneous
	 *            the xivMiscellaneous to set
	 */
	public void setXivMiscellaneous(Integer xivMiscellaneous) {
		this.xivMiscellaneous = xivMiscellaneous;
	}

	/**
	 * @return the miscComments
	 */
	public String getMiscComments() {
		return miscComments;
	}

	/**
	 * @param miscComments
	 *            the miscComments to set
	 */
	public void setMiscComments(String miscComments) {
		this.miscComments = miscComments;
	}

	/**
	 * @return the notificationNum
	 */
	public String getNotificationNum() {
		return notificationNum;
	}

	/**
	 * @param notificationNum
	 *            the notificationNum to set
	 */
	public void setNotificationNum(String notificationNum) {
		this.notificationNum = notificationNum;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdByRefId
	 */
	public String getCreatedByRefId() {
		return createdByRefId;
	}

	/**
	 * @param createdByRefId
	 *            the createdByRefId to set
	 */
	public void setCreatedByRefId(String createdByRefId) {
		this.createdByRefId = createdByRefId;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn
	 *            the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	/**
	 * @return the modifiedByRefId
	 */
	public String getModifiedByRefId() {
		return modifiedByRefId;
	}

	/**
	 * @param modifiedByRefId
	 *            the modifiedByRefId to set
	 */
	public void setModifiedByRefId(String modifiedByRefId) {
		this.modifiedByRefId = modifiedByRefId;
	}

	/**
	 * @return the referredForReviewOn
	 */
	public Date getReferredForReviewOn() {
		return referredForReviewOn;
	}

	/**
	 * @param referredForReviewOn
	 *            the referredForReviewOn to set
	 */
	public void setReferredForReviewOn(Date referredForReviewOn) {
		this.referredForReviewOn = referredForReviewOn;
	}

	/**
	 * @return the referredForReviewByRefId
	 */
	public String getReferredForReviewByRefId() {
		return referredForReviewByRefId;
	}

	/**
	 * @param referredForReviewByRefId
	 *            the referredForReviewByRefId to set
	 */
	public void setReferredForReviewByRefId(String referredForReviewByRefId) {
		this.referredForReviewByRefId = referredForReviewByRefId;
	}

	/**
	 * @return the approvedOn
	 */
	public Date getApprovedOn() {
		return approvedOn;
	}

	/**
	 * @param approvedOn
	 *            the approvedOn to set
	 */
	public void setApprovedOn(Date approvedOn) {
		this.approvedOn = approvedOn;
	}

	/**
	 * @return the approvedByRefId
	 */
	public String getApprovedByRefId() {
		return approvedByRefId;
	}

	/**
	 * @param approvedByRefId
	 *            the approvedByRefId to set
	 */
	public void setApprovedByRefId(String approvedByRefId) {
		this.approvedByRefId = approvedByRefId;
	}


	/**
	 * @return the approvalStatus
	 */
	public Integer getApprovalStatus() {
		return approvalStatus;
	}

	/**
	 * @param approvalStatus the approvalStatus to set
	 */
	public void setApprovalStatus(Integer approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	/**
	 * @return the subProcessFields
	 */
	public SubProcessFieldsDTO getSubProcessFields() {
		return subProcessFields;
	}

	/**
	 * @param subProcessFields
	 *            the subProcessFields to set
	 */
	public void setSubProcessFields(SubProcessFieldsDTO subProcessFields) {
		this.subProcessFields = subProcessFields;
	}

	/**
	 * @return the motorNamePlateDetail
	 */
	public MotorNamePlateDetailDTO getMotorNamePlateDetail() {
		return motorNamePlateDetail;
	}

	/**
	 * @param motorNamePlateDetail
	 *            the motorNamePlateDetail to set
	 */
	public void setMotorNamePlateDetail(MotorNamePlateDetailDTO motorNamePlateDetail) {
		this.motorNamePlateDetail = motorNamePlateDetail;
	}

	/**
	 * @return the arcApprovedOn
	 */
	public Date getArcApprovedOn() {
		return arcApprovedOn;
	}

	/**
	 * @param arcApprovedOn the arcApprovedOn to set
	 */
	public void setArcApprovedOn(Date arcApprovedOn) {
		this.arcApprovedOn = arcApprovedOn;
	}

	/**
	 * @return the arcReviewedBy
	 */
	public String getArcReviewedBy() {
		return arcReviewedBy;
	}

	/**
	 * @param arcReviewedBy the arcReviewedBy to set
	 */
	public void setArcReviewedBy(String arcReviewedBy) {
		this.arcReviewedBy = arcReviewedBy;
	}

	/**
	 * @return the statusUpdatedOn
	 */
	public Date getStatusUpdatedOn() {
		return statusUpdatedOn;
	}

	/**
	 * @param statusUpdatedOn the statusUpdatedOn to set
	 */
	public void setStatusUpdatedOn(Date statusUpdatedOn) {
		this.statusUpdatedOn = statusUpdatedOn;
	}

	/**
	 * @return the statusUpdatedByRefId
	 */
	public String getStatusUpdatedByRefId() {
		return statusUpdatedByRefId;
	}

	/**
	 * @param statusUpdatedByRefId the statusUpdatedByRefId to set
	 */
	public void setStatusUpdatedByRefId(String statusUpdatedByRefId) {
		this.statusUpdatedByRefId = statusUpdatedByRefId;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

}
