package net.atos.motorrepairmgmt.dto;

import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a610051
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DispatchDetailDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4729660129211272593L;
	
	private Long dispatchId;
	private String docketNo;
	private Date dispatchDate;
	private String transporterName;
	private Integer dispatchedFrom;
	private Integer dispatchedTo;
	private String dispatchedByRefId;
	private Date createdOn;
	private String dispatchToAddress;
	private Date receivedOn;
	private String receivedByRefId;
	private Integer received;
	private Integer dispatchType;
	private Integer dispatchMode;
	private String otherModeDetails;
	private String docketDetail;
	
	/**
	 * @return the dispatchId
	 */
	public Long getDispatchId() {
		return dispatchId;
	}
	/**
	 * @param dispatchId the dispatchId to set
	 */
	public void setDispatchId(Long dispatchId) {
		this.dispatchId = dispatchId;
	}
	/**
	 * @return the docketNo
	 */
	public String getDocketNo() {
		return docketNo;
	}
	/**
	 * @param docketNo the docketNo to set
	 */
	public void setDocketNo(String docketNo) {
		this.docketNo = docketNo;
	}
	/**
	 * @return the dispatchDate
	 */
	public Date getDispatchDate() {
		return dispatchDate;
	}
	/**
	 * @param dispatchDate the dispatchDate to set
	 */
	public void setDispatchDate(Date dispatchDate) {
		this.dispatchDate = dispatchDate;
	}
	/**
	 * @return the transporterName
	 */
	public String getTransporterName() {
		return transporterName;
	}
	/**
	 * @param transporterName the transporterName to set
	 */
	public void setTransporterName(String transporterName) {
		this.transporterName = transporterName;
	}
	/**
	 * @return the dispatchedFrom
	 */
	public Integer getDispatchedFrom() {
		return dispatchedFrom;
	}
	/**
	 * @param dispatchedFrom the dispatchedFrom to set
	 */
	public void setDispatchedFrom(Integer dispatchedFrom) {
		this.dispatchedFrom = dispatchedFrom;
	}
	/**
	 * @return the dispatchedTo
	 */
	public Integer getDispatchedTo() {
		return dispatchedTo;
	}
	/**
	 * @param dispatchedTo the dispatchedTo to set
	 */
	public void setDispatchedTo(Integer dispatchedTo) {
		this.dispatchedTo = dispatchedTo;
	}
	/**
	 * @return the dispatchedByRefId
	 */
	public String getDispatchedByRefId() {
		return dispatchedByRefId;
	}
	/**
	 * @param dispatchedByRefId the dispatchedByRefId to set
	 */
	public void setDispatchedByRefId(String dispatchedByRefId) {
		this.dispatchedByRefId = dispatchedByRefId;
	}
	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}
	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	/**
	 * @return the dispatchToAddress
	 */
	public String getDispatchToAddress() {
		return dispatchToAddress;
	}
	/**
	 * @param dispatchToAddress the dispatchToAddress to set
	 */
	public void setDispatchToAddress(String dispatchToAddress) {
		this.dispatchToAddress = dispatchToAddress;
	}
	/**
	 * @return the receivedOn
	 */
	public Date getReceivedOn() {
		return receivedOn;
	}
	/**
	 * @param receivedOn the receivedOn to set
	 */
	public void setReceivedOn(Date receivedOn) {
		this.receivedOn = receivedOn;
	}
	/**
	 * @return the receivedByRefId
	 */
	public String getReceivedByRefId() {
		return receivedByRefId;
	}
	/**
	 * @param receivedByRefId the receivedByRefId to set
	 */
	public void setReceivedByRefId(String receivedByRefId) {
		this.receivedByRefId = receivedByRefId;
	}
	/**
	 * @return the received
	 */
	public Integer getReceived() {
		return received;
	}
	/**
	 * @param received the received to set
	 */
	public void setReceived(Integer received) {
		this.received = received;
	}
	/**
	 * @return the dispatchType
	 */
	public Integer getDispatchType() {
		return dispatchType;
	}
	/**
	 * @param dispatchType the dispatchType to set
	 */
	public void setDispatchType(Integer dispatchType) {
		this.dispatchType = dispatchType;
	}
	/**
	 * @return the dispatchMode
	 */
	public Integer getDispatchMode() {
		return dispatchMode;
	}
	/**
	 * @param dispatchMode the dispatchMode to set
	 */
	public void setDispatchMode(Integer dispatchMode) {
		this.dispatchMode = dispatchMode;
	}
	/**
	 * @return the otherModeDetails
	 */
	public String getOtherModeDetails() {
		return otherModeDetails;
	}
	/**
	 * @param otherModeDetails the otherModeDetails to set
	 */
	public void setOtherModeDetails(String otherModeDetails) {
		this.otherModeDetails = otherModeDetails;
	}
	/**
	 * @return the docketDetail
	 */
	public String getDocketDetail() {
		return docketDetail;
	}
	/**
	 * @param docketDetail the docketDetail to set
	 */
	public void setDocketDetail(String docketDetail) {
		this.docketDetail = docketDetail;
	}
 
}
