/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Sweety Kothari
 * 
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class SparesMasterDTO {

	private Long spareId;
	private long spareMLFB;
	private String spareName;
	private String spareDesc;
	private int spareType;
	private int spareSeriesType;
	private String spareSubType;
	private int spareFrameSize;
	private double pricePerUnit;
	private String spareUnit;
	private String productType;
	private int solutionCategoryId;
	private String tenantId;

	/**
	 * @return the spareId
	 */
	public Long getSpareId() {
		return spareId;
	}

	/**
	 * @param spareId
	 *            the spareId to set
	 */
	public void setSpareId(Long spareId) {
		this.spareId = spareId;
	}

	/**
	 * @return the spareMLFB
	 */
	public long getSpareMLFB() {
		return spareMLFB;
	}

	/**
	 * @param spareMLFB
	 *            the spareMLFB to set
	 */
	public void setSpareMLFB(long spareMLFB) {
		this.spareMLFB = spareMLFB;
	}

	/**
	 * @return the spareName
	 */
	public String getSpareName() {
		return spareName;
	}

	/**
	 * @param spareName
	 *            the spareName to set
	 */
	public void setSpareName(String spareName) {
		this.spareName = spareName;
	}

	/**
	 * @return the spareDesc
	 */
	public String getSpareDesc() {
		return spareDesc;
	}

	/**
	 * @param spareDesc
	 *            the spareDesc to set
	 */
	public void setSpareDesc(String spareDesc) {
		this.spareDesc = spareDesc;
	}

	/**
	 * @return the spareType
	 */
	public int getSpareType() {
		return spareType;
	}

	/**
	 * @param spareType
	 *            the spareType to set
	 */
	public void setSpareType(int spareType) {
		this.spareType = spareType;
	}

	/**
	 * @return the spareSeriesType
	 */
	public int getSpareSeriesType() {
		return spareSeriesType;
	}

	/**
	 * @param spareSeriesType
	 *            the spareSeriesType to set
	 */
	public void setSpareSeriesType(int spareSeriesType) {
		this.spareSeriesType = spareSeriesType;
	}

	/**
	 * @return the spareSubType
	 */
	public String getSpareSubType() {
		return spareSubType;
	}

	/**
	 * @param spareSubType
	 *            the spareSubType to set
	 */
	public void setSpareSubType(String spareSubType) {
		this.spareSubType = spareSubType;
	}

	/**
	 * @return the spareFrameSize
	 */
	public int getSpareFrameSize() {
		return spareFrameSize;
	}

	/**
	 * @param spareFrameSize
	 *            the spareFrameSize to set
	 */
	public void setSpareFrameSize(int spareFrameSize) {
		this.spareFrameSize = spareFrameSize;
	}

	/**
	 * @return the pricePerUnit
	 */
	public double getPricePerUnit() {
		return pricePerUnit;
	}

	/**
	 * @param pricePerUnit
	 *            the pricePerUnit to set
	 */
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	/**
	 * @return the spareUnit
	 */
	public String getSpareUnit() {
		return spareUnit;
	}

	/**
	 * @param spareUnit
	 *            the spareUnit to set
	 */
	public void setSpareUnit(String spareUnit) {
		this.spareUnit = spareUnit;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 *            the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the solutionCategoryId
	 */
	public int getSolutionCategoryId() {
		return solutionCategoryId;
	}

	/**
	 * @param solutionCategoryId
	 *            the solutionCategoryId to set
	 */
	public void setSolutionCategoryId(int solutionCategoryId) {
		this.solutionCategoryId = solutionCategoryId;
	}

	/**
	 * @return the tenantId
	 */
	public String getTenantId() {
		return tenantId;
	}

	/**
	 * @param tenantId
	 *            the tenantId to set
	 */
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

}
