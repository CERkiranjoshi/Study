/**
 * 
 */
package net.atos.motorrepairmgmt.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author a545466
 *
 */
public class RMTAuditDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4580725539618906408L;

	private String fieldName;
	
	private String oldValue;
	
	private String newValue;
	
	private String actionTimestamp;
	
	private String userName;	

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the oldValue
	 */
	public String getOldValue() {
		return oldValue;
	}

	/**
	 * @param oldValue the oldValue to set
	 */
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	/**
	 * @return the newValue
	 */
	public String getNewValue() {
		return newValue;
	}

	/**
	 * @param newValue the newValue to set
	 */
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	/**
	 * @return the actionTimestamp
	 */
	public String getActionTimestamp() {
		return actionTimestamp;
	}

	/**
	 * @param actionTimestamp the actionTimestamp to set
	 */
	public void setActionTimestamp(String actionTimestamp) {
		this.actionTimestamp = actionTimestamp;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
