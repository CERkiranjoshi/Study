package net.atos.motorrepairmgmt.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author a603981
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MotorOrderDetailDTO {

	private Long motorOrderDetailId;

	private Integer serviceType;

	private Integer orderType;

	private String orderNo;

	private Date createdOn;

	private String createdBy;

	private Integer orderStatus;

	private Date closedOn;

	private String closedBy;

	/**
	 * @return the motorOrderDetailId
	 */
	public Long getMotorOrderDetailId() {
		return motorOrderDetailId;
	}

	/**
	 * @param motorOrderDetailId
	 *            the motorOrderDetailId to set
	 */
	public void setMotorOrderDetailId(Long motorOrderDetailId) {
		this.motorOrderDetailId = motorOrderDetailId;
	}

	/**
	 * @return the serviceType
	 */
	public Integer getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 *            the serviceType to set 1:FS ,2:Repair
	 */
	public void setServiceType(Integer serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return the orderType
	 */
	public Integer getOrderType() {
		return orderType;
	}

	/**
	 * @param orderType
	 *            the orderType to set 1:Service ,2:Sales
	 */
	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	/**
	 * @return the orderNo
	 */
	public String getOrderNo() {
		return orderNo;
	}

	/**
	 * @param orderNo
	 *            the orderNo to set
	 */
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the orderStatus
	 */
	public Integer getOrderStatus() {
		return orderStatus;
	}

	/**
	 * @param orderStatus
	 *            the orderStatus to set 0:Closed,1:Open
	 */
	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * @return the closedOn
	 */
	public Date getClosedOn() {
		return closedOn;
	}

	/**
	 * @param closedOn
	 *            the closedOn to set
	 */
	public void setClosedOn(Date closedOn) {
		this.closedOn = closedOn;
	}

	/**
	 * @return the closedBy
	 */
	public String getClosedBy() {
		return closedBy;
	}

	/**
	 * @param closedBy
	 *            the closedBy to set
	 */
	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}
}
