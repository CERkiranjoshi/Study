--drop script for old triggers
DROP TABLE rmt_audit;
DROP TABLE rmt_audit_detail;
DROP TRIGGER audit_log_master_workflow_trigger ON rmt_master_workflow_fields;
DROP TRIGGER audit_log_sub_process_trigger ON rmt_motor_sub_proc_fields;
DROP TRIGGER audit_log_customer_detail_trigger ON rmt_customer_detail;
DROP TRIGGER audit_log_additional_contact_trigger ON rmt_additional_contact_detail;
DROP TRIGGER audit_log_b_report_trigger ON rmt_motor_b_report_fields;
DROP TRIGGER audit_log_c_report_trigger ON rmt_motor_c_report_fields;
DROP TRIGGER audit_log_d_report_trigger ON rmt_motor_d_report_fields;
DROP TRIGGER audit_log_repair_est_trigger ON rmt_arc_repair_estimates;
DROP TRIGGER audit_log_spare_est_trigger ON rmt_arc_spare_estimates;
DROP TRIGGER audit_log_elec_trigger ON rmt_motor_elec_obs;
DROP TRIGGER audit_log_nameplate_trigger ON rmt_motor_nameplate_detail;


create extension hstore;

--rmt_audit table for statement level log
CREATE TABLE rmt_audit
(
  rmt_audit_id serial NOT NULL,
  old_values hstore,
  new_values hstore,
  updated_cols text[],
  query text,
  table_name character varying,
  action_timestamp timestamp with time zone DEFAULT now(),
  action text,
  user_name text,
  task_code character varying,
  subprocess_id bigint,
  master_workflow_id bigint,
  node_id character varying,
  CONSTRAINT audit_detail_pkey PRIMARY KEY (rmt_audit_id)
);
--rmt_audit_detail table for column level log
CREATE TABLE rmt_audit_detail
(
  rmt_audit_detail_id serial NOT NULL,
  old_value character varying,
  new_value character varying,
  column_name character varying,
  rmt_audit_id integer,
  CONSTRAINT rmt_audit_detail_pkey PRIMARY KEY (rmt_audit_detail_id),
  CONSTRAINT rmt_audit_fk FOREIGN KEY (rmt_audit_id)
      REFERENCES rmt_audit (rmt_audit_id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

--rmt_audit_detail log function which gets called from trigger 
-- Function: rmt_audit_funct()

-- DROP FUNCTION rmt_audit_funct();

CREATE OR REPLACE FUNCTION rmt_audit_funct()
  RETURNS trigger AS
$BODY$
DECLARE
 k text;
 v text;
 rmt_aud_id INTEGER;
 user_name text;
 arc_ref_id bigint;
begin
	
    select nextval('rmt_audit_rmt_audit_id_seq') into rmt_aud_id;
    
    user_name=NEW.adt_modified_by_ref_id;
    if NEW.adt_task_code like 'ARC_%' AND NEW.adt_modified_by_ref_id ~ '^[0-9]+$' then 
		arc_ref_id=(NEW.adt_modified_by_ref_id)::bigint;
		SELECT username FROM rmt_role_usermap  where reference_id=arc_ref_id into user_name;
    end if;
    
    if tg_op = 'UPDATE' then
    
	insert into rmt_audit(rmt_audit_id,old_values, new_values, updated_cols, query,table_name,user_name,action,subprocess_id,task_code,master_workflow_id,node_id)
        values (rmt_aud_id,hstore(OLD.*), hstore(NEW.*),akeys(hstore(NEW.*) - hstore(OLD.*)), current_query(),
		tg_table_name::text,user_name::text,'u',OLD.subprocess_id,NEW.adt_task_code,OLD.master_workflow_id,NEW.node_id);

		FOR k,v IN select key,value from each((hstore(NEW))-(hstore(OLD))) LOOP

			insert into rmt_audit_detail (column_name,old_value,new_value,rmt_audit_id)
			values (k,hstore(OLD)->k,v,rmt_aud_id);

                END LOOP;

        return new;
    elsif tg_op = 'DELETE' then
   
         insert into rmt_audit(rmt_audit_id,old_values, query,table_name,user_name,action,subprocess_id,task_code,master_workflow_id,node_id) 
         values (rmt_aud_id,hstore(OLD.*), current_query(),
		tg_table_name::text,user_name::text,'d',OLD.subprocess_id,OLD.adt_task_code,OLD.master_workflow_id,OLD.node_id);

		FOR k,v IN select key,value from each((hstore(OLD))) LOOP
			if v is not null then
				insert into rmt_audit_detail (column_name,old_value,rmt_audit_id)
				values (k,v,rmt_aud_id);
			end if;
                END LOOP;
        return old;
    elsif tg_op = 'INSERT' then
    
        insert into rmt_audit(rmt_audit_id,new_values, query,table_name,user_name,action,subprocess_id,task_code,master_workflow_id,node_id) 
        values (rmt_aud_id,hstore(NEW.*), current_query(),
		tg_table_name::text,user_name::text,'i',NEW.subprocess_id,NEW.adt_task_code,NEW.master_workflow_id,NEW.node_id);

		FOR k,v IN select key,value from each((hstore(NEW))) LOOP

			if v is not null then
				insert into rmt_audit_detail (column_name,new_value,rmt_audit_id)
				values (k,v,rmt_aud_id);
			end if;

                END LOOP;
        return new;
    end if;
end;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;


--drop triggers already present
 DROP TRIGGER rmt_additional_contact_detail_trigger ON rmt_additional_contact_detail;
 DROP TRIGGER rmt_arc_repair_estimates_trigger ON rmt_arc_repair_estimates;
 DROP TRIGGER rmt_arc_spare_estimates_trigger ON rmt_arc_spare_estimates;
 DROP TRIGGER rmt_customer_detail_trigger ON rmt_customer_detail;
 DROP TRIGGER rmt_dispatch_detail_trigger ON rmt_dispatch_detail;
 DROP TRIGGER rmt_email_template_info_trigger ON rmt_email_template_info;
 DROP TRIGGER rmt_fse_details_trigger ON rmt_fse_details;
 DROP TRIGGER rmt_master_workflow_fields_trigger ON rmt_master_workflow_fields;
 DROP TRIGGER rmt_motor_attachments_trigger ON rmt_motor_attachments;
 DROP TRIGGER rmt_motor_b_report_fields_trigger ON rmt_motor_b_report_fields;
 DROP TRIGGER rmt_motor_c_report_fields_trigger ON rmt_motor_c_report_fields;
 DROP TRIGGER rmt_motor_d_report_fields_trigger ON rmt_motor_d_report_fields;
 DROP TRIGGER rmt_motor_elec_obs_trigger ON rmt_motor_elec_obs;
 DROP TRIGGER rmt_motor_nameplate_detail_trigger ON rmt_motor_nameplate_detail;
 DROP TRIGGER rmt_motor_order_detail_trigger ON rmt_motor_order_detail;
 DROP TRIGGER rmt_motor_sales_detail_trigger ON rmt_motor_sales_detail;
 DROP TRIGGER rmt_motor_spares_detail_trigger ON rmt_motor_spares_detail;
 DROP TRIGGER rmt_motor_speed_detail_trigger ON rmt_motor_speed_detail;
 DROP TRIGGER rmt_motor_sub_proc_fields_trigger ON rmt_motor_sub_proc_fields;
 DROP TRIGGER rmt_motor_voltage_detail_trigger ON rmt_motor_voltage_detail;
 DROP TRIGGER rmt_parallel_proc_trigger ON rmt_parallel_proc;
 DROP TRIGGER rmt_column_detail_trigger ON rmt_column_detail;

  
  
--From here, create script for trigger start for required table
 CREATE TRIGGER rmt_additional_contact_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_additional_contact_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_arc_repair_estimates_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_arc_repair_estimates  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_arc_spare_estimates_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_arc_spare_estimates  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_customer_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_customer_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_dispatch_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_dispatch_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_email_template_info_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_email_template_info  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_fse_details_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_fse_details  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_master_workflow_fields_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_master_workflow_fields  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_attachments_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_attachments  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_b_report_fields_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_b_report_fields  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_c_report_fields_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_c_report_fields  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_d_report_fields_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_d_report_fields  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_elec_obs_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_elec_obs  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_nameplate_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_nameplate_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_order_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_order_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_sales_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_sales_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_spares_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_spares_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_speed_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_speed_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_sub_proc_fields_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_sub_proc_fields  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_motor_voltage_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_motor_voltage_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_parallel_proc_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_parallel_proc  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();
 CREATE TRIGGER rmt_column_detail_trigger AFTER INSERT OR UPDATE OR DELETE ON rmt_column_detail  FOR EACH ROW EXECUTE PROCEDURE rmt_audit_funct();

 CREATE INDEX rmt_role_usermap_reference_id  ON rmt_role_usermap  USING btree (reference_id);
