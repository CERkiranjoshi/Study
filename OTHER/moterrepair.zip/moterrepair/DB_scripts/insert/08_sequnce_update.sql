﻿ALTER SEQUENCE rmt_config_detail_config_id_seq  RESTART WITH 149;  

ALTER SEQUENCE rmt_actor_cp_role_map_id_seq  RESTART WITH 13;