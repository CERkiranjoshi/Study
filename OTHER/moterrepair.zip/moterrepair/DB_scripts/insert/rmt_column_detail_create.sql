CREATE SEQUENCE rmt_column_detail_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 321
  CACHE 1;


CREATE TABLE rmt_column_detail
(
  id integer NOT NULL DEFAULT nextval('rmt_column_detail_id_seq'::regclass),
  table_name character varying(250),
  column_name character varying(250),
  alias_name character varying(250),
  is_csv_enabled integer DEFAULT 0,
  is_audit_enabled integer DEFAULT 0,
  CONSTRAINT rmt_column_alias_pkey PRIMARY KEY (id)
);