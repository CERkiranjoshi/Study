package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.map.LinkedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.MilestoneListDTO;
import net.atos.motorrepairmgmt.dto.TrackCallStatusDTO;
import net.atos.motorrepairmgmt.entity.FSEVisitDetail;
import net.atos.motorrepairmgmt.entity.MotorOrderDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.TrackcallStatusService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.entity.MatricesMaster;
import net.atos.taskmgmt.entity.Milestones;
import net.atos.taskmgmt.repository.MatricesMasterRepository;
import net.atos.taskmgmt.repository.MiletstonesRepository;

@Service
@Transactional
public class TrackcallStatusServiceImpl implements TrackcallStatusService {
	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	@Autowired
	private MatricesMasterRepository matricesMasterRepository;

	@Autowired
	private MiletstonesRepository miletstonesRepository;

	/**
	 * Steps: 1. Fetch the list of matrices from matrices table for a given
	 * actor. 2. Fetch the Subprocess for a given GSP Reference Number 3. For
	 * each subprocess, find the current flow it has taken using
	 * Motor_Order_details & final Warranty Status. 4. For each subprocess,
	 * iterate through the matrices list fetched earlier and filter based on the
	 * flow taken. This becomes your main subset of grey milestones for UI. 5.
	 * Now for each subprocess, fetch the data from milestones table and
	 * provided the details to UI.
	 **/

	@Override
	public List<TrackCallStatusDTO> getTrackcallStatusList(String gspRefNo,
			String actorId) {
		TrackCallStatusDTO trackCallStatusDTO = null;
		MilestoneListDTO mileStoneDTO = null;
		List<MilestoneListDTO> milestoneListDTO = null;
		List<SubProcessFields> subProcessFeildsList = null;
		List<TrackCallStatusDTO> trackCallStatusListDTO = new ArrayList<TrackCallStatusDTO>();
		List<TrackCallStatusDTO> trackCallStatusFinalListDTO = new ArrayList<TrackCallStatusDTO>();

		List<MatricesMaster> matricesMasterList = null;
		List<Milestones> mileStoneList = null;
		String strvalue = null;
		String binstr = null;
		String maxStr = null;
		// List<MatricesMaster> matricesMasterFilterList=null;
		int index;

		Set<String> setServiceType = new HashSet<String>();

		List<MatricesMaster> filterList = null;

		if (null != actorId) {
			matricesMasterList = matricesMasterRepository
					.findAllMatricesByActorId(actorId);
		}
		if (null != gspRefNo) {
			subProcessFeildsList = subProcessFieldsRepository
					.findSubProcessFieldsByGSPRefNo(gspRefNo);

			// serviceType=new HashSet<Integer>();
			if (null != subProcessFeildsList) {
				for (SubProcessFields subProcessField : subProcessFeildsList) {
					filterList = new ArrayList<MatricesMaster>();
					milestoneListDTO = new ArrayList<MilestoneListDTO>();
					if (null != subProcessField.getFinalWarrantyState()) {
						
						strvalue = MotorRepairConstants.WARRANTY_TYPE.of(
								subProcessField.getFinalWarrantyState())
								.toString();

						String serviceTypeEnumVal = null;

						if (null != subProcessField.getfSEVisitDetails()
								&& subProcessField.getfSEVisitDetails().size() > 0) {
							serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
									.of(1).toString();

							strvalue += "_" + serviceTypeEnumVal;

							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");

						}
						if (null != subProcessField.getMotorOrderDetails()) {
							for (MotorOrderDetail motorOrderDetail : subProcessField
									.getMotorOrderDetails()) {
								setServiceType
										.add(MotorRepairConstants.SERVICE_TYPE
												.of(motorOrderDetail
														.getServiceType())
												.toString());

								if (null != motorOrderDetail.getServiceType()) {
									if (null == serviceTypeEnumVal) {
										serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
												.of(motorOrderDetail
														.getServiceType())
												.toString();
									} else if (!serviceTypeEnumVal
											.equalsIgnoreCase(MotorRepairConstants.SERVICE_TYPE
													.of(motorOrderDetail
															.getServiceType())
													.toString())) {
										if (setServiceType
												.contains(serviceTypeEnumVal))
											serviceTypeEnumVal += "_"
													+ MotorRepairConstants.SERVICE_TYPE
															.of(motorOrderDetail
																	.getServiceType())
															.toString();

									}
								}

							}
						}
						if (null != serviceTypeEnumVal
								&& MotorRepairConstants.WARRANTY_TYPE
										.of(subProcessField
												.getFinalWarrantyState())
										.toString().equals(strvalue)) {

							strvalue += "_" + serviceTypeEnumVal;
						}

						if ((MotorRepairConstants.WARRANTY_TYPE.of(
								subProcessField.getFinalWarrantyState())
								.toString().equals(strvalue))) {
							if (null != subProcessField.getArcRefId()) {
								serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
										.of(2).toString();
								strvalue += "_" + serviceTypeEnumVal;
							}
							else if(null !=subProcessField.getRepairStatus() && strvalue==MotorRepairConstants.WARRANTY_TYPE.of(1).toString()){
								strvalue="IN_WARRANTY_REPLACEMENT";
							}
							else {
								strvalue = "INTIAL_DEFAULT_VISIBLE_STATE";

							}

						}
						if (strvalue.equals("IN_WARRANTY_REPAIRS_FS")
								|| strvalue.equals("WARRANTY_VOID_REPAIRS_FS")) {
							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY_SET
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");
						} else {
							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");
						}
					}
					/*
					 * else is when there is initial warranty claim*/
					else {
						
						strvalue = MotorRepairConstants.WARRANTY_TYPE.of(
								subProcessField.getInitialWarrantyClaim())
								.toString();

						String serviceTypeEnumVal = null;

						if (null != subProcessField.getfSEVisitDetails()
								&& subProcessField.getfSEVisitDetails().size() > 0) {
							serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
									.of(1).toString();

							strvalue += "_" + serviceTypeEnumVal;

							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");

						}

						/*
						 * else{ strvalue = "INTIAL_DEFAULT_VISIBLE_STATE";
						 * binstr = Integer
						 * .toBinaryString((MotorRepairConstants
						 * .CUSTOMER_STATUS_VISIBLITY
						 * .of(strvalue).getValue())); binstr.toCharArray();
						 * 
						 * index = String.format("%8s", binstr) .replace(' ',
						 * '0').indexOf("1"); }
						 */
						if (null != subProcessField.getMotorOrderDetails()) {
							for (MotorOrderDetail motorOrderDetail : subProcessField
									.getMotorOrderDetails()) {
								setServiceType
										.add(MotorRepairConstants.SERVICE_TYPE
												.of(motorOrderDetail
														.getServiceType())
												.toString());

								if (null != motorOrderDetail.getServiceType()) {
									if (null == serviceTypeEnumVal) {
										serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
												.of(motorOrderDetail
														.getServiceType())
												.toString();
									} else if (!serviceTypeEnumVal
											.equalsIgnoreCase(MotorRepairConstants.SERVICE_TYPE
													.of(motorOrderDetail
															.getServiceType())
													.toString())) {
										if (setServiceType
												.contains(serviceTypeEnumVal))
											serviceTypeEnumVal += "_"
													+ MotorRepairConstants.SERVICE_TYPE
															.of(motorOrderDetail
																	.getServiceType())
															.toString();

									}
								}

							}
						}
						if (null != serviceTypeEnumVal
								&& MotorRepairConstants.WARRANTY_TYPE
										.of(subProcessField
												.getInitialWarrantyClaim())
										.toString().equals(strvalue)) {

							strvalue += "_" + serviceTypeEnumVal;
						}

						if ((MotorRepairConstants.WARRANTY_TYPE.of(
								subProcessField.getInitialWarrantyClaim())
								.toString().equals(strvalue))) {
							if (null != subProcessField.getArcRefId()) {
								serviceTypeEnumVal = MotorRepairConstants.SERVICE_TYPE
										.of(2).toString();
								strvalue += "_" + serviceTypeEnumVal;
							}else if(null !=subProcessField.getRepairStatus() && strvalue==MotorRepairConstants.WARRANTY_TYPE.of(1).toString()){
								strvalue="IN_WARRANTY_REPLACEMENT";
							}else {
								strvalue = "INTIAL_DEFAULT_VISIBLE_STATE";

							}

						}
						if (strvalue.equals("IN_WARRANTY_REPAIRS_FS")
								|| strvalue.equals("WARRANTY_VOID_REPAIRS_FS")) {
							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY_SET
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");
						} else {
							binstr = Integer
									.toBinaryString((MotorRepairConstants.CUSTOMER_STATUS_VISIBLITY
											.of(strvalue).getValue()));
							binstr.toCharArray();

							index = String.format("%8s", binstr)
									.replace(' ', '0').indexOf("1");
						}

					}
					/*
					 * else { strvalue = "INTIAL_DEFAULT_VISIBLE_STATE"; binstr
					 * = Integer .toBinaryString((MotorRepairConstants.
					 * CUSTOMER_STATUS_VISIBLITY .of(strvalue).getValue()));
					 * binstr.toCharArray();
					 * 
					 * index = String.format("%8s", binstr).replace(' ', '0')
					 * .indexOf("1"); }
					 */
					for (MatricesMaster matricesMaster : matricesMasterList) {

						maxStr = Integer.toBinaryString(matricesMaster
								.getMatricesType());

						maxStr.toCharArray();
						maxStr = String.format("%8s", maxStr).replace(' ', '0');
						if (maxStr.charAt(index) == '1') {
							filterList.add(matricesMaster);
						}

					}

					mileStoneList = miletstonesRepository
							.findMilestonesBySubProcessId(Long
									.toString(subProcessField
											.getWlfwSubProcessId()));
					Map<String, MilestoneListDTO> mileStoneMap = new LinkedHashMap<String, MilestoneListDTO>();
					for (MatricesMaster matricesMasterFilter : filterList) {
						mileStoneDTO = new MilestoneListDTO();
						mileStoneDTO.setMatricesAliasName(matricesMasterFilter
								.getMatricesAliasName());
						mileStoneDTO.setMatricesName(matricesMasterFilter
								.getMatricesName());
						for (Milestones milestone : mileStoneList) {
							List<Date> ts =null;
							if (matricesMasterFilter.getMatricesId().equals(
									milestone.getSubReferenceId())
									&& matricesMasterFilter.getFunctionCode()
											.equals(milestone.getTaskCode())) {
								ts=mileStoneDTO.getMilestoneTimeStamp();
								if(ts==null){
									ts = new ArrayList<Date>();
								}
								ts.add(0,milestone.getMilestoneTimestamp());
								mileStoneDTO.setMilestoneTimeStamp(ts);
								// mileStoneAchievedSet.add(mileStoneDTO.getMatricesName());
							}

						}
						milestoneListDTO.add(mileStoneDTO);
					}
					// remove duplicate object if present ,check within
					// duplicate set whether acheived date is set or not ,if set
					// then add it or else add default
					for (MilestoneListDTO mileStoneDTOnew : milestoneListDTO) {
						// find duplicate
						if (null == mileStoneMap.get(mileStoneDTOnew
								.getMatricesAliasName())) {
							mileStoneMap.put(mileStoneDTOnew.getMatricesName(),
									mileStoneDTOnew);
						}
						// if not null ,then check whether mileStoneDTONew
						// acheived date is set ,overwrite it
						else if (null != mileStoneMap.get(mileStoneDTOnew
								.getMatricesName())
								&& null != mileStoneDTOnew
										.getMilestoneTimeStamp()) {
							mileStoneMap.put(mileStoneDTOnew.getMatricesName(),
									mileStoneDTOnew);
						}
					}

					trackCallStatusDTO = new TrackCallStatusDTO();
					trackCallStatusDTO.setWlfwSubProcessId(subProcessField
							.getWlfwSubProcessId());

					if (null != subProcessField.getMotorSnNum()) {
						trackCallStatusDTO.setMotorSnNum(subProcessField
								.getMotorSnNum());
					}
					if (null != subProcessField.getMlfbSpiridon()) {

						trackCallStatusDTO.setMlfbSpiridon(subProcessField
								.getMlfbSpiridon());
					}
					if (null != subProcessField.getMotorMaterialSpec()) {

						trackCallStatusDTO
								.setMaterialSpecification(subProcessField
										.getMotorMaterialSpec());
					}
					if (null != subProcessField.getFrameSize()) {

						trackCallStatusDTO.setFrameSize(subProcessField
								.getFrameSize());
					}
					if (null != subProcessField.getSubWarrantyType()) {

						trackCallStatusDTO
								.setSubWarrantyType(MotorRepairConstants.WARRANTY_SUB_TYPE
										.of(subProcessField
												.getSubWarrantyType())
										.toString());
					}
					if (null != subProcessField.getFinalWarrantyState()) {
						trackCallStatusDTO
								.setFinalWarrantyState(MotorRepairConstants.WARRANTY_TYPE
										.of(subProcessField
												.getFinalWarrantyState())
										.toString());
					} else {
						trackCallStatusDTO
								.setFinalWarrantyState(MotorRepairConstants.WARRANTY_TYPE
										.of(subProcessField
												.getInitialWarrantyClaim())
										.toString());
					}
					List<MilestoneListDTO> finalMileStoneList = new ArrayList<MilestoneListDTO>();

					finalMileStoneList.addAll(mileStoneMap.values());
					// for(MilestoneListDTO finalMileStone:
					// mileStoneMap.values())
					// {
					// finalMileStoneList.add(finalMileStone);
					// }

					trackCallStatusDTO.setMileStoneList(finalMileStoneList);
					trackCallStatusFinalListDTO.add(trackCallStatusDTO);
				}

				/*
				 * if (trackCallStatusListDTO == null) { trackCallStatusListDTO
				 * = new ArrayList<TrackCallStatusDTO>(); }
				 */

				trackCallStatusListDTO.addAll(trackCallStatusFinalListDTO);

			}
		}

		return trackCallStatusListDTO;
	}
}
