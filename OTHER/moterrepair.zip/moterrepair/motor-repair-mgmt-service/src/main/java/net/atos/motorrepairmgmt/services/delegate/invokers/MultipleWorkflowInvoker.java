/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorDetailsDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component(value = "multipleWorkflowInvoker")
public class MultipleWorkflowInvoker extends BaseWorkflowInvoker {

	@Autowired
	private WorkflowInvoker workflowInvoker;

	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;

	@Autowired
	private SubProcessFieldsService subProcessFieldsService;

	@Autowired
	private ConfigDetailService configDetailService;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MultipleWorkflowInvoker.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MULTIPLE_WORKFLOW_INVOKER: BEGIN: " + execution.getId()));
        String previousFunctionCode = execution.getVariable(ActivitiConstants.FUNCTION_CODE).toString();


		// iterate over multiple motor detai
		SubProcessFieldsDTO subProcessFieldDTO = subProcessFieldsService
				.getSubprocessFieldWithMotorDetailsByMasterworkflowId(Long.parseLong(execution.getVariable(
						ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID).toString()));

		String checkFromSuperAdmin = execution.getVariable(ActivitiConstants.FROM_SUPER_ADMIN).toString();
		if(checkFromSuperAdmin.equals("1")){
			String functionCode = MotorRepairConstants.SYS_MULTIPLE_WORKFLOW;
			Map<String, Object> nextProcessVars = new HashMap<String, Object>();
			setNextProcessVariables(execution, nextProcessVars);
			
			// TODO - change this to fetch from UI
						nextProcessVars.put(ActivitiConstants.IS_MOTOR_RECV, 0);
						// TODO - change this to fetch from UI
						nextProcessVars.put(ActivitiConstants.REASSIGN, 0);
						//set process variable id
						nextProcessVars.put(ActivitiConstants.SUB_PROCESS_ID, execution.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString());
			
			List<ConfigDetailDTO> configDetailDTOs = configDetailService
					.findEnabledNVisibleConfigDetailsByTypeNSubType(MotorRepairConstants.FRAME_SIZE_LIMIT,
							MotorRepairConstants.FRAME_SIZE_1, MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);

			if (null != configDetailDTOs) {
				ConfigDetailDTO configDetailDTO = configDetailDTOs.get(0);
				if (null != configDetailDTO) {
					nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_1, configDetailDTO.getConfigIntVal());
				}
			}
			
			configDetailDTOs = configDetailService
					.findEnabledNVisibleConfigDetailsByTypeNSubType(MotorRepairConstants.FRAME_SIZE_LIMIT,
							MotorRepairConstants.FRAME_SIZE_2, MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);
			
			if (null != configDetailDTOs) {
				ConfigDetailDTO configDetailDTO = configDetailDTOs.get(0);
				if (null != configDetailDTO) {
					nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_2, configDetailDTO.getConfigIntVal());
				}
			}

			String procInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
		    LOGGER.info(("MULTIPLE_WORKFLOW_INVOKER: INVOKED NEW WORKFLOW FOR SUBPROCESS: " 
					+ execution.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString() +" ; MotorDetail: " + execution.getVariable(ActivitiConstants.FRAME_SIZE)
				+ "; ProcessInstanceId: " + procInstanceId + "; ExecId: " + execution.getId()));
		}
		
		else{
			
		
		for (MotorDetailsDTO motorDetailDTO : subProcessFieldDTO.getMotorDetailsDTOList()) {
			// TODO Set Function Code of the Next Workflow to be executed
			String functionCode = MotorRepairConstants.SYS_MULTIPLE_WORKFLOW;
			Map<String, Object> nextProcessVars = new HashMap<String, Object>();
			// TODO Set only required process variables from the workflow
			setNextProcessVariables(execution, nextProcessVars, motorDetailDTO);

			/*nextProcessVars.put(ActivitiConstants.INIT_WARRANRTY,
					MotorRepairConstants.WARRANTY_TYPE.of(motorDetailDTO.getInitialWarrantyClaim()).toString());*/

			// TODO - change this to fetch from UI
			nextProcessVars.put(ActivitiConstants.IS_MOTOR_RECV, 0);
			 if(previousFunctionCode.equals(MotorRepairConstants.CCC_NEW_SERVICE_REC_MOTOR)){

                nextProcessVars.put(ActivitiConstants.IS_MOTOR_RECV, 1);

			 					}
			// TODO - change this to fetch from UI
			nextProcessVars.put(ActivitiConstants.REASSIGN, 0);
			//set process variable id
			nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID, motorDetailDTO.getSubProcessId());

			// set framesize ranges in the process variables FRAME_SIZE_LIMIT FRAME_SIZE
			List<ConfigDetailDTO> configDetailDTOs = configDetailService
					.findEnabledNVisibleConfigDetailsByTypeNSubType(MotorRepairConstants.FRAME_SIZE_LIMIT,
							MotorRepairConstants.FRAME_SIZE_1, MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);

			if (null != configDetailDTOs) {
				ConfigDetailDTO configDetailDTO = configDetailDTOs.get(0);
				if (null != configDetailDTO) {
					nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_1, configDetailDTO.getConfigIntVal());
				}
			}
			
			configDetailDTOs = configDetailService
					.findEnabledNVisibleConfigDetailsByTypeNSubType(MotorRepairConstants.FRAME_SIZE_LIMIT,
							MotorRepairConstants.FRAME_SIZE_2, MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);
			
			if (null != configDetailDTOs) {
				ConfigDetailDTO configDetailDTO = configDetailDTOs.get(0);
				if (null != configDetailDTO) {
					nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_2, configDetailDTO.getConfigIntVal());
				}
			}

			String procInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
			LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MULTIPLE_WORKFLOW_INVOKER: INVOKED NEW WORKFLOW FOR SUBPROCESS: "
					+ subProcessFieldDTO.getWlfwSubProcessId() + "; MotorDetail: " + motorDetailDTO.getFrameSize()
					+ "; ProcessInstanceId: " + procInstanceId + "; ExecId: " + execution.getId()));
		}
		}
		LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MULTIPLE_WORKFLOW_INVOKER: END: " + execution.getId()));
	}

}
