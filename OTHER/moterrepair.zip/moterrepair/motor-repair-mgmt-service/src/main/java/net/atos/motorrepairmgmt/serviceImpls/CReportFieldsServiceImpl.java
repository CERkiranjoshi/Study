package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.BReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.CReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.entity.ARCRepairEstimates;
import net.atos.motorrepairmgmt.entity.CReportFields;
import net.atos.motorrepairmgmt.entity.ElectricalObservation;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.CReportFieldsRepository;
import net.atos.motorrepairmgmt.repository.ElectricalObservationRepository;
import net.atos.motorrepairmgmt.repository.MotorNamePlateDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorSpeedDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorVoltageDetailRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.CReportFieldsService;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610051
 * 
 */
@Service
public class CReportFieldsServiceImpl implements CReportFieldsService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The CReportFields Repository */
	@Autowired
	private CReportFieldsRepository cReportFieldsRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The MotorSpeedDetail Repository */
	@Autowired
	private MotorSpeedDetailRepository motorSpeedDetailRepository;

	/** The MotorNamePlateDetail Repository */
	@Autowired
	private MotorNamePlateDetailRepository motorNamePlateDetailRepository;

	/** The MotorVoltageDetail Repository */
	@Autowired
	private MotorVoltageDetailRepository motorVoltageDetailRepository;

	/** The ElectricalObservationDetail Repository */
	@Autowired
	private ElectricalObservationRepository electricalObservationRepository;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(CReportFieldsServiceImpl.class);

	/**
	 * This method creates/updates a CReportFields record. The method performs an update operation when
	 * motorCReportFieldId is passed and an existing record with matching motorCReportFieldId is fetched for updation Or
	 * it will create a new record.
	 * 
	 * @param CReportFieldsDTO
	 *            The cReportFields Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public CReportFieldsDTO createUpdateCReportFields(CReportFieldsDTO cReportFieldsDTO) {
		LOGGER.info("CReportFieldsServiceImpl : createUpdateCReportFields : Start");
		CReportFields cReportFieldsDetails = new CReportFields();
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		ElectricalObservationDTO electricalObservationDTO = null;
		ElectricalObservation electricalObservationDetail = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		MotorVoltageDetail motorVoltageDetail = null;
		MotorVoltageDetailDTO motorVoltageDetailDTO = null;

		Long returnId = -1l;
		try {
			if (null != cReportFieldsDTO) {
				if (null != cReportFieldsDTO.getMotorCReportFieldId()) {
					cReportFieldsDetails = cReportFieldsRepository.findOne(cReportFieldsDTO.getMotorCReportFieldId());
					if (null != cReportFieldsDetails) {
						cReportFieldsDTO.setModifiedOn(new Date());
						cReportFieldsDTO.setFunctionCode(cReportFieldsDetails.getFunctionCode());
						// cReportFieldsDTO.setCreatedOn(cReportFieldsDetails
						// .getCreatedOn());
					}
				} else {
					if (null == cReportFieldsDTO.getCreatedOn()) {
						cReportFieldsDTO.setCreatedOn(new Date());
						// cReportFieldsDTO.setModifiedOn(new Date());
					}
				}
				if (null == cReportFieldsDetails) {
					cReportFieldsDetails = new CReportFields();
				}
				if (null != cReportFieldsDTO.getSubProcessFields()) {
					SubProcessFields subProcessFieldsDetail = subProcessFieldsRepository.findOne(cReportFieldsDTO
							.getSubProcessFields().getWlfwSubProcessId());
					cReportFieldsDetails.setSubProcessFields(subProcessFieldsDetail);
					cReportFieldsDTO.setFunctionCode(subProcessFieldsDetail.getFunctionCode());
					
				}
				if (null != cReportFieldsDTO.getMotorSpeedDetail()) {
					// motor speedDetail create update begins here
					List<MotorSpeedDetail> motorSpeedDetailEntityList = new ArrayList<MotorSpeedDetail>();

					List<MotorSpeedDetail> existMotorSpeedDetailList = cReportFieldsDetails.getMotorSpeedDetail();
					List<MotorSpeedDetail> existingMotorSpeedDetailFromInput = new ArrayList<MotorSpeedDetail>();
					List<MotorSpeedDetail> newMotorSpeedDetailList = null;
					List<MotorSpeedDetail> finalMotorSpeedDetailList = new ArrayList<MotorSpeedDetail>();

					for (MotorSpeedDetailDTO motorSpeedDetailDTORecord : cReportFieldsDTO.getMotorSpeedDetail()) {
						if (null != motorSpeedDetailDTORecord) {
							motorSpeedDetailEntityList.add(dozerBeanMapper.map(motorSpeedDetailDTORecord,
									MotorSpeedDetail.class));
						}
					}
					// motor speedDetail list from json DTO
					for (MotorSpeedDetail motorSpeedDetailEntityRecord : motorSpeedDetailEntityList) {
						// if motor speedDetail id is coming ,then it should be existing
						// one else
						// throws an exception
						//set audit 
						motorSpeedDetailEntityRecord.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						motorSpeedDetailEntityRecord.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						if (null != motorSpeedDetailEntityRecord.getMotorSpeedDetailId()) {
							boolean isExist = false;
							// existing MotorSpeedDetail list in CReportFeilds
							// entity
							for (MotorSpeedDetail existingMotorSpeedDetailRecord : existMotorSpeedDetailList) {
								// if record already exists in DB
								if (motorSpeedDetailEntityRecord.getMotorSpeedDetailId().equals(
										existingMotorSpeedDetailRecord.getMotorSpeedDetailId())) {

									BeanUtils.copyProperties(motorSpeedDetailEntityRecord,
											existingMotorSpeedDetailRecord,
											NullPropertyMapper.getNullPropertyNames(motorSpeedDetailEntityRecord));
									LOGGER.info("Saved object with MotorSpeedDetailId: "
											+ existingMotorSpeedDetailRecord.getMotorSpeedDetailId());
									existingMotorSpeedDetailRecord.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
									existingMotorSpeedDetailRecord.setModifiedOn(new Date());
									existingMotorSpeedDetailFromInput.add(existingMotorSpeedDetailRecord);
									isExist = true;
									break;
								}
							}
							if (!isExist) {
								LOGGER.info("Spares Id is incorrect Create New Subprocess Workflow");
								throw new MotorRepairException(MotorRepairException.INPUT_ERR,
										"Spares Id is incorrect", "Create New Subprocess Workflow");
							}
						}
						// if motor speedDetail id is null ,that indicates it is new
						// entry
						else {
							if (newMotorSpeedDetailList == null) {
								newMotorSpeedDetailList = new ArrayList<MotorSpeedDetail>();
							}
							// add new Motor speedDetail
							newMotorSpeedDetailList.add(motorSpeedDetailEntityRecord);
						}
					}

					if (existingMotorSpeedDetailFromInput != null && existingMotorSpeedDetailFromInput.size() > 0) {
						finalMotorSpeedDetailList.addAll(existingMotorSpeedDetailFromInput);
					}
					if (newMotorSpeedDetailList != null && newMotorSpeedDetailList.size() > 0) {
						finalMotorSpeedDetailList.addAll(newMotorSpeedDetailList);
					}

					// to delete old motor speedDetail entries from database which is
					// not
					// coming from DTO

					if (null != cReportFieldsDetails.getMotorSpeedDetail()) {
						cReportFieldsDetails.getMotorSpeedDetail().clear();
					} else {
						cReportFieldsDetails.setMotorSpeedDetail(new ArrayList<MotorSpeedDetail>());
					}
					cReportFieldsDetails.getMotorSpeedDetail().addAll(finalMotorSpeedDetailList);

				}
				cReportFieldsDTO.setMotorSpeedDetail(null);

				if (null != cReportFieldsDTO.getMotorNamePlateDetail()) {
					motorNamePlateDetailDTO = cReportFieldsDTO.getMotorNamePlateDetail();
					if (null == motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {
						motorNamePlateDetailDTO.setCreatedOn(new Date());
						motorNamePlateDetail = new MotorNamePlateDetail();
						if (null == cReportFieldsDetails) {
							cReportFieldsDetails = new CReportFields();
						}

						cReportFieldsDTO.setMotorNamePlateDetail(motorNamePlateDetailDTO);
						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						//set audit 
						motorNamePlateDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						cReportFieldsDTO.setMotorNamePlateDetail(null);

					} else {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
						if (null != motorNamePlateDetail) {
							motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
						} else {
							motorNamePlateDetailDTO.setCreatedOn(new Date());
						}
						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						//set audit 
						motorNamePlateDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						cReportFieldsDTO.setMotorNamePlateDetail(null);
					}
				}

				if (null != cReportFieldsDTO.getMotorVoltageDetail()) {
					motorVoltageDetailDTO = cReportFieldsDTO.getMotorVoltageDetail();
					if (null == cReportFieldsDTO.getMotorVoltageDetail().getMotorVoltageDetailId()) {
						motorVoltageDetail = new MotorVoltageDetail();
						motorVoltageDetailDTO = cReportFieldsDTO.getMotorVoltageDetail();
						BeanUtils.copyProperties(motorVoltageDetailDTO, motorVoltageDetail,
								getNullPropertyNames(motorVoltageDetailDTO));
						motorVoltageDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						motorVoltageDetail.setModifiedOn(new Date());
						//set audit 
						motorVoltageDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						motorVoltageDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setMotorVoltageDetail(motorVoltageDetail);
						cReportFieldsDTO.setMotorVoltageDetail(null);
					} else {
						motorVoltageDetail = motorVoltageDetailRepository.findOne(motorVoltageDetailDTO
								.getMotorVoltageDetailId());
						BeanUtils.copyProperties(motorVoltageDetailDTO, motorVoltageDetail,
								getNullPropertyNames(motorVoltageDetailDTO));
						motorVoltageDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						motorVoltageDetail.setModifiedOn(new Date());
						//set audit 
						motorVoltageDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						motorVoltageDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setMotorVoltageDetail(motorVoltageDetail);
						cReportFieldsDTO.setMotorVoltageDetail(null);
					}
				}

				if (null != cReportFieldsDTO.getElectricalObservation()) {
					electricalObservationDTO = cReportFieldsDTO.getElectricalObservation();
					if (null == electricalObservationDTO.getMotorElecObsId()) {
						electricalObservationDetail = new ElectricalObservation();
						if (null == cReportFieldsDetails) {
							cReportFieldsDetails = new CReportFields();
						}

						cReportFieldsDTO.setElectricalObservation(electricalObservationDTO);
						BeanUtils.copyProperties(electricalObservationDTO, electricalObservationDetail,
								NullPropertyMapper.getNullPropertyNames(electricalObservationDTO));
						electricalObservationDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						electricalObservationDetail.setModifiedOn(new Date());
						//set audit 
						electricalObservationDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						electricalObservationDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setElectricalObservation(electricalObservationDetail);
						cReportFieldsDTO.setElectricalObservation(null);
					} else {
						electricalObservationDetail = electricalObservationRepository.findOne(electricalObservationDTO
								.getMotorElecObsId());
						BeanUtils.copyProperties(electricalObservationDTO, electricalObservationDetail,
								NullPropertyMapper.getNullPropertyNames(electricalObservationDTO));
						electricalObservationDetail.setModifiedByRefId(cReportFieldsDTO.getModifiedByRefId());
						electricalObservationDetail.setModifiedOn(new Date());
						//set audit 
						electricalObservationDetail.setFunctionCode(cReportFieldsDTO.getFunctionCode());
						electricalObservationDetail.setWlfwSubProcessId(cReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						cReportFieldsDetails.setElectricalObservation(electricalObservationDetail);
						cReportFieldsDTO.setElectricalObservation(null);
					}
				}

				cReportFieldsDTO.setSubProcessFields(null);

				BeanUtils
						.copyProperties(cReportFieldsDTO, cReportFieldsDetails, getNullPropertyNames(cReportFieldsDTO));
				//set audit
				cReportFieldsDetails.setFunctionCode(cReportFieldsDTO.getFunctionCode());
				CReportFields savedObj = cReportFieldsRepository.save(cReportFieldsDetails);
				if (null != savedObj) {
					LOGGER.info("CReportFieldsServiceImpl : createUpdateCReportFields : Record Saved/Updated");
					cReportFieldsDTO = new CReportFieldsDTO();
					cReportFieldsDTO = dozerBeanMapper.map(savedObj, CReportFieldsDTO.class);
				}
			} else {
				LOGGER.info("CReportFieldsServiceImpl : createUpdateCReportFields : cReportFieldsDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return cReportFieldsDTO;
	}

	/**
	 * This method deletes a CReportFields on the basis of its motorCReportFieldId.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteCReportFieldsByMotorCReportFieldId(Long motorCReportFieldId) {
		LOGGER.info("CReportFieldsServiceImpl : deleteCReportFieldsByMotorCReportFieldId : Start");
		boolean returnVal = false;
		try {
			if (null != motorCReportFieldId) {
				cReportFieldsRepository.delete(motorCReportFieldId);
				returnVal = true;
			} else {
				LOGGER.info("CReportFieldsServiceImpl : deleteCReportFieldsByMotorCReportFieldId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("CReportFieldsServiceImpl : deleteCReportFieldsByMotorCReportFieldId : Not Deleted. Record Not Present");
		}
		return returnVal;
	}

	/**
	 * This method retrieves all the cReportFieldsDetails
	 * 
	 * @return List of CReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public List<CReportFieldsDTO> getAllCReportFields() {
		LOGGER.info("CReportFieldsServiceImpl : getAllCReportFields : Start");
		List<CReportFieldsDTO> cReportFieldsDTOs = null;
		CReportFieldsDTO cReportFieldsDTO = null;
		List<CReportFields> cReportFieldsDetails = cReportFieldsRepository.findAll();
		if (null != cReportFieldsDetails) {
			cReportFieldsDTOs = new ArrayList<CReportFieldsDTO>();
			for (CReportFields cReportFieldsRecord : cReportFieldsDetails) {
				cReportFieldsDTO = new CReportFieldsDTO();
				cReportFieldsDTO = dozerBeanMapper.map(cReportFieldsRecord, CReportFieldsDTO.class);
				cReportFieldsDTOs.add(cReportFieldsDTO);
			}
		}
		LOGGER.info("CReportFieldsServiceImpl : getAllCReportFields : End");
		return cReportFieldsDTOs;
	}

	/**
	 * This method retrieves MotorVoltageDetail
	 * 
	 * @return MotorVoltageDetailDTO
	 * 
	 */
	@Override
	@Transactional
	public MotorVoltageDetailDTO getVoltageDetailByCReportId(Long motorCReportFieldId) {
		LOGGER.info("CReportFieldsServiceImpl : getVoltageDetailByCReportId : Start");
		MotorVoltageDetailDTO motorVoltageDetailDTO = null;
		MotorVoltageDetail motorVoltageDetail = cReportFieldsRepository
				.findVoltageDetailByCReportId(motorCReportFieldId);
		if (null != motorVoltageDetail) {
			motorVoltageDetailDTO = new MotorVoltageDetailDTO();
			motorVoltageDetailDTO = dozerBeanMapper.map(motorVoltageDetail, MotorVoltageDetailDTO.class);

		}
		LOGGER.info("CReportFieldsServiceImpl : getVoltageDetailByCReportId : End");
		return motorVoltageDetailDTO;
	}

	/**
	 * This method retrieves MotorNamePlateDetail
	 * 
	 * @return MotorNamePlateDetailDTO
	 * 
	 */
	@Override
	@Transactional
	public MotorNamePlateDetailDTO getNamePlateByCReportId(Long motorCReportFieldId) {
		LOGGER.info("CReportFieldsServiceImpl : getNamePlateByCReportId : Start");
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		MotorNamePlateDetail motorNamePlateDetail = cReportFieldsRepository
				.findNamePlateByCReportId(motorCReportFieldId);
		if (null != motorNamePlateDetail) {
			motorNamePlateDetailDTO = new MotorNamePlateDetailDTO();
			motorNamePlateDetailDTO = dozerBeanMapper.map(motorNamePlateDetail, MotorNamePlateDetailDTO.class);

		}
		LOGGER.info("CReportFieldsServiceImpl : getNamePlateByCReportId : End");
		return motorNamePlateDetailDTO;
	}

	/**
	 * This method retrieves motorSpeedDetailDetail
	 * 
	 * @return List of MotorSpeedDetailDTO
	 * 
	 */
	@Override
	@Transactional
	public List<MotorSpeedDetailDTO> getSpeedDetailByCReportId(Long motorCReportFieldId) {
		LOGGER.info("CReportFieldsServiceImpl : getSpeedDetailByCReportId : Start");
		List<MotorSpeedDetailDTO> motorSpeedDetailDTOs = null;
		MotorSpeedDetailDTO motorSpeedDetailDTO = null;
		List<MotorSpeedDetail> motorSpeedDetailDetail = cReportFieldsRepository
				.findSpeedDetailByCReportId(motorCReportFieldId);
		if (null != motorSpeedDetailDetail) {
			motorSpeedDetailDTOs = new ArrayList<MotorSpeedDetailDTO>();
			for (MotorSpeedDetail MotorSpeedDetailRecord : motorSpeedDetailDetail) {
				motorSpeedDetailDTO = new MotorSpeedDetailDTO();
				motorSpeedDetailDTO = dozerBeanMapper.map(MotorSpeedDetailRecord, MotorSpeedDetailDTO.class);
				motorSpeedDetailDTOs.add(motorSpeedDetailDTO);
			}

		}
		LOGGER.info("CReportFieldsServiceImpl : getSpeedDetailByCReportId : End");
		return motorSpeedDetailDTOs;
	}

	/**
	 * This method retrieves cReportFieldsDetail
	 * 
	 * @return CReportFieldsDTO object
	 * 
	 */
	@Override
	@Transactional
	public CReportFieldsDTO getCReportFieldsBySubProcessID(Long wlfwSubProcessId) {
		LOGGER.info("CReportFieldsServiceImpl : getCReportFieldsBySubProcessID : Start");
		CReportFieldsDTO cReportFieldsDTO = null;
		CReportFields cReportFieldsDetail = cReportFieldsRepository.findCReportFieldsBySubProcessID(wlfwSubProcessId);
		if (null != cReportFieldsDetail) {
			cReportFieldsDTO = new CReportFieldsDTO();
			cReportFieldsDTO = dozerBeanMapper.map(cReportFieldsDetail, CReportFieldsDTO.class);
			cReportFieldsDTO.setFunctionCode(cReportFieldsDetail.getFunctionCode());
		}
		LOGGER.info("CReportFieldsServiceImpl : getCReportFieldsBySubProcessID : End");
		return cReportFieldsDTO;
	}

	/**
	 * This method add or update SpeedDetail To CReportFields
	 * 
	 * @param MotorSpeedDetailDTO
	 *            and motorCReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean addUpdateSpeedDetailToCReportFields(Long motorCReportFieldId,
			List<MotorSpeedDetailDTO> motorSpeedDetailDTOList) {
		LOGGER.info("CReportFieldsServiceImpl : addUpdateSpeedDetailToCReportFields : Start");
		boolean returnVal = false;
		CReportFields cReportFields = null;
		CReportFields savedObject = null;
		MotorSpeedDetail motorSpeedDetail = null;
		List<MotorSpeedDetail> motorSpeedDetailList = null;
		try {
			if (null != motorCReportFieldId && null != motorSpeedDetailDTOList) {
				cReportFields = cReportFieldsRepository.findOne(motorCReportFieldId);
				if (null != cReportFields) {
					motorSpeedDetailList = new ArrayList<MotorSpeedDetail>();
					for (MotorSpeedDetailDTO motorSpeedDetailDTO : motorSpeedDetailDTOList) {
						if (null != motorSpeedDetailDTO.getMotorSpeedDetailId()) {
							motorSpeedDetail = motorSpeedDetailRepository.findOne(motorSpeedDetailDTO
									.getMotorSpeedDetailId());
						}
						motorSpeedDetail = dozerBeanMapper.map(motorSpeedDetailDTO, MotorSpeedDetail.class);
						motorSpeedDetailList.add(motorSpeedDetail);
					}
					List<MotorSpeedDetail> existMotorSpeedDetailList = cReportFields.getMotorSpeedDetail();
					if (null != existMotorSpeedDetailList && existMotorSpeedDetailList.size() > 0) {
						motorSpeedDetailList.addAll(existMotorSpeedDetailList);
					}
					cReportFields.setMotorSpeedDetail(motorSpeedDetailList);
					savedObject = cReportFieldsRepository.save(cReportFields);
				}
				LOGGER.info("CReportFieldsServiceImpl : addUpdateSpeedDetailToCReportFields : Record Saved");
				if (null != savedObject) {
					returnVal = true;
				}
			} else {
				LOGGER.info("CReportFieldsServiceImpl : addUpdateSpeedDetailToCReportFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method add or update MotorNamePlateDetail To CReportFields
	 * 
	 * @param MotorNamePlateDetailDTO
	 *            and motorCReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean addUpdateMotorNamePlateDetailToCReportFields(Long motorCReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToCReportFields : Start");
		boolean returnVal = false;
		CReportFields cReportFields = null;
		CReportFields savedObj = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		try {
			if (null != motorCReportFieldId && null != motorNamePlateDetailDTO) {
				cReportFields = cReportFieldsRepository.findOne(motorCReportFieldId);
				if (null != cReportFields) {
					if (null != motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
					} else {
						motorNamePlateDetailDTO.setCreatedOn(new Date());
					}
					if (null == motorNamePlateDetailDTO.getCreatedOn()) {
						motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
					}
					motorNamePlateDetail = dozerBeanMapper.map(motorNamePlateDetailDTO, MotorNamePlateDetail.class);
					cReportFields.setMotorNamePlateDetail(motorNamePlateDetail);
					savedObj = cReportFieldsRepository.save(cReportFields);
					if (null != savedObj) {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToCReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToCReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method add or update MotorVoltageDetail To CReportFields
	 * 
	 * @param motorVoltageDetailDTO
	 *            and motorCReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean addUpdateMotorVoltageDetailToCReportFields(Long motorCReportFieldId,
			MotorVoltageDetailDTO motorVoltageDetailDTO) {
		LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorVoltageDetailDTOToCReportFields : Start");
		boolean returnVal = false;
		CReportFields cReportFields = null;
		CReportFields savedObj = null;
		MotorVoltageDetail motorVoltageDetail = null;
		try {
			if (null != motorCReportFieldId && null != motorVoltageDetailDTO) {
				cReportFields = cReportFieldsRepository.findOne(motorCReportFieldId);
				if (null != cReportFields) {
					if (null != motorVoltageDetailDTO.getMotorVoltageDetailId()) {
						motorVoltageDetail = motorVoltageDetailRepository.findOne(motorVoltageDetailDTO
								.getMotorVoltageDetailId());
					}

					motorVoltageDetail = dozerBeanMapper.map(motorVoltageDetailDTO, MotorVoltageDetail.class);
					cReportFields.setMotorVoltageDetail(motorVoltageDetail);
					savedObj = cReportFieldsRepository.save(cReportFields);
					if (null != savedObj) {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorVoltageDetailDTOToCReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateMotorVoltageDetailDTOToCReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method add or update SubProcessFields To CReportFields
	 * 
	 * @param SubProcessFieldsDTO
	 *            and motorCReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long addUpdateSubProcessFieldsToCReportFields(Long motorCReportFieldId,
			SubProcessFieldsDTO subProcessFieldsDTO) {
		LOGGER.info("CReportFieldsServiceImpl : addUpdateSubProcessFieldsToCReportFields : Start");
		Long returnVal = -1l;
		CReportFields cReportFields = null;
		CReportFields savedObj = null;
		SubProcessFields subProcessFields = null;
		try {
			if (null != motorCReportFieldId && null != subProcessFieldsDTO) {
				cReportFields = cReportFieldsRepository.findOne(motorCReportFieldId);
				if (null != cReportFields) {
					if (null != subProcessFieldsDTO.getWlfwSubProcessId()) {
						subProcessFields = subProcessFieldsRepository
								.findOne(subProcessFieldsDTO.getWlfwSubProcessId());
					} else {

						subProcessFieldsDTO.setCreatedOn(new Date());
					}
					if (null == subProcessFieldsDTO.getCreatedOn()) {
						subProcessFieldsDTO.setCreatedOn(subProcessFields.getCreatedOn());
					}
					subProcessFields = dozerBeanMapper.map(subProcessFieldsDTO, SubProcessFields.class);
					cReportFields.setSubProcessFields(subProcessFields);
					savedObj = cReportFieldsRepository.save(cReportFields);
					if (null != savedObj) {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateSubProcessFieldsToCReportFields : Record Saved/Updated");
						returnVal = savedObj.getMotorCReportFieldId();
					} else {
						LOGGER.info("CReportFieldsServiceImpl : addUpdateSubProcessFieldsToCReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method retrieves a CReportFields on the basis of its motorCReportFieldId.
	 * 
	 * @param motorCReportFieldId
	 *            The arcRepairEstimate Id
	 * @return CReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public CReportFieldsDTO getCReportFieldsByMotorCReportFieldId(Long motorCReportFieldId) {
		LOGGER.info("CReportFieldsServiceImpl : getCReportFieldsByMotorCReportFieldId : Start");
		CReportFieldsDTO cReportFieldsDTO = null;
		CReportFields cReportFieldsDTODetails = null;
		if (null != motorCReportFieldId) {
			cReportFieldsDTODetails = cReportFieldsRepository.findOne(motorCReportFieldId);
			if (null != cReportFieldsDTODetails) {
				cReportFieldsDTO = new CReportFieldsDTO();
				cReportFieldsDTO = dozerBeanMapper.map(cReportFieldsDTODetails, CReportFieldsDTO.class);
			}
		}
		LOGGER.info("CReportFieldsServiceImpl : getCReportFieldsByMotorCReportFieldId : End");
		return cReportFieldsDTO;
	}

	@Override
	public CReportFieldsDTO getCReportFieldsApprovedStatusBySubprocessFieldId(Long subProcessId) {
		LOGGER.info("CReportFieldsServiceImpl : getCReportFieldsApprovedStatusBySubprocessFieldId : Start");
		CReportFieldsDTO cReportFieldsDTO = null;
		if (null != subProcessId) {
			Object[] objectArr = cReportFieldsRepository.findCReportFieldsApprovedStatusSubProcessID(subProcessId);
			if (null != objectArr) {

				cReportFieldsDTO = new CReportFieldsDTO();
				if (null != objectArr[0]) {
					cReportFieldsDTO.setMotorCReportFieldId(Long.parseLong(objectArr[0].toString()));
				}
				if (null != objectArr[1]) {
					cReportFieldsDTO.setApprovalStatus(Integer.parseInt(objectArr[1].toString()));
				}
				if (null != objectArr[2]) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					try {
						if(null != objectArr[2])
							cReportFieldsDTO.setStatusUpdatedOn(sdf.parse(objectArr[2].toString()));
					} catch (ParseException e) {
						LOGGER.warn("Error while parsing date in the pattern: yyyy-MM-dd HH:mm:ss.SSS for value: " + objectArr[2].toString());
					}
				}
				if (null != objectArr[3]) {
					cReportFieldsDTO.setStatusUpdatedByRefId(objectArr[3].toString());
				}

			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsApprovedStatusBySubprocessFieldId : End");

		return cReportFieldsDTO;

	}
}
