package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.entity.AdditionalContactDetail;
import net.atos.motorrepairmgmt.repository.AdditionalContactDetailRepository;
import net.atos.motorrepairmgmt.services.AdditionalContactDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class AdditionalContactDetailServiceImpl implements AdditionalContactDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The AdditionalContactDetail Repository */
	@Autowired
	private AdditionalContactDetailRepository additionalContactDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(AdditionalContactDetailServiceImpl.class);

	/**
	 * The method creates/updates a AdditionalContactDetail record. The method
	 * performs an update operation when additionalContactDetailId is passed and
	 * an existing record with matching additionalContactDetailId is fetched for
	 * updation.
	 * 
	 * @param additionalContactDetailDTO
	 *            The AdditionalContact Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateAdditionalContactDetail(AdditionalContactDetailDTO additionalContactDetailDTO) {
		LOGGER.info("AdditionalContactDetailServiceImpl : createUpdateAdditionalContactDetail : Start");
		Long returnId = -1l;
		AdditionalContactDetail additionalContactDetails = new AdditionalContactDetail();
		try {
			if (null != additionalContactDetailDTO) {
				if (null != additionalContactDetailDTO.getAdditionalContactDetailId()) {
					additionalContactDetails = additionalContactDetailRepository.findOne(additionalContactDetailDTO
							.getAdditionalContactDetailId());
				}
				BeanUtils.copyProperties(additionalContactDetailDTO, additionalContactDetails,
						NullPropertyMapper.getNullPropertyNames(additionalContactDetailDTO));

				AdditionalContactDetail savedObj = additionalContactDetailRepository.save(additionalContactDetails);
				LOGGER.info("AdditionalContactDetailServiceImpl : createUpdateAdditionalContactDetail : Record Saved/Updated");
				if (null != savedObj) {
					returnId = savedObj.getAdditionalContactDetailId();
				}
			} else {
				LOGGER.info("AdditionalContactDetailServiceImpl : createUpdateAdditionalContactDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return returnId;
	}

	/**
	 * The method retrieves all the AdditionalContactDetail
	 * 
	 * @return List of AdditionalContactDetail DTOs
	 * 
	 */
	@Override
	public List<AdditionalContactDetailDTO> getAllAdditionalContactDetail() {
		LOGGER.info("AdditionalContactDetailServiceImpl : getAllAdditionalContactDetail : Start");

		List<AdditionalContactDetailDTO> additionalContactDetailDTOs = null;

		List<AdditionalContactDetail> additionalContactDetails = additionalContactDetailRepository.findAll();

		if (null != additionalContactDetails) {
			additionalContactDetailDTOs = new ArrayList<AdditionalContactDetailDTO>();

			AdditionalContactDetailDTO additionalContactDetailDTO = null;

			for (AdditionalContactDetail additionalContactDetailRecord : additionalContactDetails) {
				additionalContactDetailDTO = new AdditionalContactDetailDTO();

				additionalContactDetailDTO = dozerBeanMapper.map(additionalContactDetailRecord,
						AdditionalContactDetailDTO.class);

				additionalContactDetailDTOs.add(additionalContactDetailDTO);
			}
		}
		LOGGER.info("AdditionalContactDetailServiceImpl : getAllAdditionalContactDetail : End");
		return additionalContactDetailDTOs;
	}

	/**
	 * The method retrieves a AdditionalContactDetail on the basis of
	 * additionalContactDetail id.
	 * 
	 * @param additionalContactDetailId
	 *            The AdditionalContactDetail Id
	 * @return AdditionalContactDetail DTO
	 * 
	 */
	@Override
	public AdditionalContactDetailDTO getAdditionalContactDetailByAdditionalContactDetailId(
			Long additionalContactDetailId) {
		LOGGER.info("AdditionalContactDetailServiceImpl : getAdditionalContactDetailByAdditionalContactDetailId : Start");
		AdditionalContactDetailDTO additionalContactDetailDTO = null;
		if (null != additionalContactDetailId) {
			AdditionalContactDetail additionalContactDetails = additionalContactDetailRepository
					.findOne(additionalContactDetailId);

			if (null != additionalContactDetails) {
				additionalContactDetailDTO = dozerBeanMapper.map(additionalContactDetails,
						AdditionalContactDetailDTO.class);
			}
		}
		LOGGER.info("AdditionalContactDetailServiceImpl : getAdditionalContactDetailByAdditionalContactDetailId : End");
		return additionalContactDetailDTO;
	}

	/**
	 * The deletes a AdditionalContactDetail on the basis its
	 * additionalContactDetail id.
	 * 
	 * @param additionalContactDetailId
	 *            The AdditionalContactDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteAdditionalContactDetailByAdditionalContactDetailId(Long additionalContactDetailId) {
		LOGGER.info("AdditionalContactDetailServiceImpl : deleteAdditionalContactDetailByAdditionalContactDetailId : Start");
		boolean returnVal = false;
		try {
			if (null != additionalContactDetailId) {
				additionalContactDetailRepository.delete(additionalContactDetailId);
				returnVal = true;
			} else {
				LOGGER.info("AdditionalContactDetailServiceImpl : deleteAdditionalContactDetailByAdditionalContactDetailId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}
