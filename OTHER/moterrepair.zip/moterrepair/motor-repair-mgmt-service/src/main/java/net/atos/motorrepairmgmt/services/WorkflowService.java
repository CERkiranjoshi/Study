package net.atos.motorrepairmgmt.services;




/**
 * @author a610013
 * 
 */
public interface WorkflowService {
	

	String generateCSVForAllWorkflowData(String gspRefNo,String wlfwSubProcessId);
	
}
