/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */

@Component(value = "parasARCProcessVariablesInvoker")
public class ParasARCProcessVariablesInvoker implements JavaDelegate {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ParasARCProcessVariablesInvoker.class);

	@Autowired
	private ARCMasterService arcMasterService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS_ARC_PROCESS_VARIABLE_INVOKER: START " + execution.getId());

		// // TODO Set only required process variables from the workflow
		// int parasTypeARCId = 0;
		// try {
		// parasTypeARCId = (null != execution.getVariable(ActivitiConstants.CONFIG_PARAS_ARC_TYPE)) ? Integer
		// .parseInt(execution.getVariable(ActivitiConstants.CONFIG_PARAS_ARC_TYPE).toString()) : 0;
		// } catch (Exception e) {
		// LOGGER.warn("DISPATCH_MOTOR_TO_PARAS_INVOKER: PARAS TYPE ARC ID not set in workflow?");
		// throw new MotorRepairException(MotorRepairException.PROCESS_ERR,
		// "PARAS TYPE ARC not found in Process Variables!!",
		// "PARAS TYPE not available in Process variables or in Config!");
		// }
		//
		// if (0 != parasTypeARCId) {
		//
		// // TODO this wud require to be changed as ARC types would be multiple
		// List<ARCMasterDTO> arcMasterDTOs = arcMasterService.getARCMasterByArcType(parasTypeARCId);
		//
		// if ((null != arcMasterDTOs) && (0 < arcMasterDTOs.size())) {
		//
		// ARCMasterDTO arcMasterDTO = arcMasterDTOs.get(0);
		//
		// // Setting variables related to PARAS
		// execution.setVariable(ActivitiConstants.ARC_REF_ID, arcMasterDTO.getArcId());
		// execution.setVariable(ActivitiConstants.ARC_TYPE, arcMasterDTO.getArcType());
		// execution.setVariable(ActivitiConstants.ARC_NAME, arcMasterDTO.getArcName());
		// LOGGER.info("PARAS_ARC_PROCESS_VARIABLE_INVOKER: END " + execution.getId()
		// + " PARAS ARC TYPE DETAILS SET");
		// } else {
		// throw new MotorRepairException(MotorRepairException.PROCESS_ERR, "PARAS TYPE ARC not available!!",
		// "PARAS TYPE not available in Process variables or in Config!");
		// }
		// } else {
		// throw new MotorRepairException(MotorRepairException.PROCESS_ERR, "PARAS TYPE ARC not available!!",
		// "PARAS TYPE not available in Process variables or in Config!");
		//
		// }
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS_ARC_PROCESS_VARIABLE_INVOKER: END " + execution.getId());
	}
}
