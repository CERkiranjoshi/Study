/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.Date;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorDetailsDTO;
import net.atos.motorrepairmgmt.dto.MotorSalesDetailDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;
import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;
import net.atos.motorrepairmgmt.entity.MasterWorkflowFields;
import net.atos.motorrepairmgmt.repository.MasterWorkflowFieldsRepository;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.MotorSalesDetailService;
import net.atos.motorrepairmgmt.services.RegionMasterService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.TemplateInfoService;
import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.TaskStatus;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.runtime.Execution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component
public abstract class BaseWorkflowInvoker implements JavaDelegate {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BaseWorkflowInvoker.class);

	@Autowired
	protected WorkflowInvoker workflowInvoker;

	@Autowired
	private SubProcessFieldsService subProcessFieldsService;

	@Autowired
	private MasterWorkflowFieldsRepository masterWorkflowFieldsRepository;

	@Autowired
	protected ActorFunctionMasterService actorFunctionMasterService;

	@Autowired
	protected ConfigDetailService configDetailService;

	@Autowired
	protected TemplateInfoService templateInfoService;

	@Autowired
	private RegionMasterService regionMasterService;

	@Autowired
	private MotorSalesDetailService motorSalesDetailService;

	@Autowired
	private ARCMasterService arcMasterService;

	/**
	 * Implementing classes are expected to call this method that sets the next fresh values of process variables to be
	 * utilized from the current execution in a new map to ensure that old process variables are not sent to the new
	 * process
	 * 
	 * @param execution
	 * @param nextProcessVars
	 */
	protected void setNextProcessVariables(DelegateExecution execution, Map<String, Object> nextProcessVars) {
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID));
		nextProcessVars.put(ActivitiConstants.MOTOR_SN_NO, execution.getVariable(ActivitiConstants.MOTOR_SN_NO));

		String gspRefNumber = execution.getVariable(ActivitiConstants.GSP_REF_NO).toString();

		nextProcessVars.put(ActivitiConstants.GSP_REF_NO, gspRefNumber);
		nextProcessVars.put(ActivitiConstants.FRAME_SIZE, execution.getVariable(ActivitiConstants.FRAME_SIZE));
		nextProcessVars.put(ActivitiConstants.RECLAIM_ID, execution.getVariable(ActivitiConstants.RECLAIM_ID));
		nextProcessVars.put(ActivitiConstants.CHECK_WARRANTY, execution.getVariable(ActivitiConstants.CHECK_WARRANTY));
		nextProcessVars.put(ActivitiConstants.INIT_WARRANRTY, execution.getVariable(ActivitiConstants.INIT_WARRANRTY));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP));
		nextProcessVars.put(ActivitiConstants.BATCH_PROCESS_ID,
				execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID));

		nextProcessVars.put(ActivitiConstants.MLFB_SPIRIDON_CODE,
				execution.getVariable(ActivitiConstants.MLFB_SPIRIDON_CODE));

		if (null == execution.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID)) {
			// FETCH THIS VALUE AND SET IT

			MasterWorkflowFields masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByGspRefNo(gspRefNumber);

			nextProcessVars.put(ActivitiConstants.MASTER_BATCH_PROCESS_ID, masterWorkflowFields.getBatchProcessId());

		} else {

			nextProcessVars.put(ActivitiConstants.MASTER_BATCH_PROCESS_ID,
					execution.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID));
		}
		// --------------- ADDED Parallel Process IDs if available
		// ---------------//
		if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID))
			nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_ID,
					execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID));

		if (null != execution.getVariable(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG))
			nextProcessVars.put(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG,
					execution.getVariable(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG));

		if (null != execution.getVariable(MotorRepairConstants.PRE_APPROVAL_FUNC_CODE))
			nextProcessVars.put(MotorRepairConstants.PRE_APPROVAL_FUNC_CODE,
					execution.getVariable(MotorRepairConstants.PRE_APPROVAL_FUNC_CODE));
		if (null != execution.getVariable(MotorRepairConstants.POST_APPROVAL_FUNC_CODE))
			nextProcessVars.put(MotorRepairConstants.POST_APPROVAL_FUNC_CODE,
					execution.getVariable(MotorRepairConstants.POST_APPROVAL_FUNC_CODE));

		if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID))
			nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID,
					execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID));
		if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE))
			nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_TYPE,
					execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE));

		// ----------------------------------------------------------------------
		// //
		nextProcessVars.put(ActivitiConstants.MASTER_PROCESS_ID,
				execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID));
		nextProcessVars.put(ActivitiConstants.SUB_PROCESS_ID, execution.getVariable(ActivitiConstants.SUB_PROCESS_ID));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID));
		// passing assignee attribute from previous process to next
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));
		// set customer name
		nextProcessVars.put(ActivitiConstants.CUST_NAME, execution.getVariable(ActivitiConstants.CUST_NAME));
		// set email title
		nextProcessVars.put(ActivitiConstants.SUB_TITLE, execution.getVariable(ActivitiConstants.SUB_TITLE));
		// set arc name
		nextProcessVars.put(ActivitiConstants.ARC_NAME, execution.getVariable(ActivitiConstants.ARC_NAME));
		// set ARC ref Id
		nextProcessVars.put(ActivitiConstants.ARC_REF_ID, execution.getVariable(ActivitiConstants.ARC_REF_ID));
		// check sent to paras
		nextProcessVars.put(ActivitiConstants.CHECK_SENT_TO_PARAS,
				execution.getVariable(ActivitiConstants.CHECK_SENT_TO_PARAS));
		// set ARC type
		nextProcessVars.put(ActivitiConstants.ARC_TYPE, execution.getVariable(ActivitiConstants.ARC_TYPE));
		// set status
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_STATUS, TaskStatus.New.toString());
		// set status date
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_STATUS_DATE, new Date());
		// set severity
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_SEVERITY,
				MotorRepairConstants.SEVERITY.NORMAL.toString());
		// set created date ,& created by
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_DATE, new Date());
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_BY,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));
		nextProcessVars.put(ActivitiConstants.CHECK_FS_VISIT_WITH_SPARES,
				execution.getVariable(ActivitiConstants.CHECK_FS_VISIT_WITH_SPARES));
		// set region name
		nextProcessVars.put(ActivitiConstants.SALES_OFFICE_N_REGION_NAME,
				execution.getVariable(ActivitiConstants.SALES_OFFICE_N_REGION_NAME));

		// check only spares
		nextProcessVars.put(ActivitiConstants.CHECK_ONLY_SPARES,
				execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL));
		nextProcessVars.put(ActivitiConstants.CHECK_SPARE_LIST_SIZE,
				execution.getVariable(ActivitiConstants.CHECK_SPARE_LIST_SIZE));

		// check FS job completed & check
		nextProcessVars.put(ActivitiConstants.CHECK_FS_JOB_COMPLETED,
				execution.getVariable(ActivitiConstants.CHECK_FS_JOB_COMPLETED));
		// set FS visited or not flag
		nextProcessVars.put(ActivitiConstants.CHECK_FS_VISITED,
				execution.getVariable(ActivitiConstants.CHECK_FS_VISITED));
		nextProcessVars.put(ActivitiConstants.CHECK_PROCESS_TYPE,
				execution.getVariable(ActivitiConstants.CHECK_PROCESS_TYPE));
		nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_TYPE,
				execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE));
		nextProcessVars.put(ActivitiConstants.DISPATCH_TO_PARAS,
				execution.getVariable(ActivitiConstants.DISPATCH_TO_PARAS));
		// added check TS decision
		nextProcessVars.put(ActivitiConstants.CHECK_TS_DECISION,
				execution.getVariable(ActivitiConstants.CHECK_TS_DECISION));
		// replacement decsion
		nextProcessVars.put(ActivitiConstants.CHECK_REPLACEMENT_APPROVAL,
				execution.getVariable(ActivitiConstants.CHECK_REPLACEMENT_APPROVAL));
		nextProcessVars
				.put(ActivitiConstants.CHECK_CTS_STATE, execution.getVariable(ActivitiConstants.CHECK_CTS_STATE));
		nextProcessVars.put(ActivitiConstants.CHECK_FS_LINK_ORDER_CREATED,
				execution.getVariable(ActivitiConstants.CHECK_FS_LINK_ORDER_CREATED));
		nextProcessVars.put(ActivitiConstants.REPAIR_STATUS, execution.getVariable(ActivitiConstants.REPAIR_STATUS));
		nextProcessVars
				.put(ActivitiConstants.CHECK_FLOW_TYPE, execution.getVariable(ActivitiConstants.CHECK_FLOW_TYPE));
		nextProcessVars
				.put(ActivitiConstants.WAIT_FOR_SPARES, execution.getVariable(ActivitiConstants.WAIT_FOR_SPARES));
		nextProcessVars.put(ActivitiConstants.SPARES_SHIP_TO_PARTY,
				execution.getVariable(ActivitiConstants.SPARES_SHIP_TO_PARTY));
		nextProcessVars.put(ActivitiConstants.CHECK_FS_VISIT,
				execution.getVariable(ActivitiConstants.CHECK_FS_VISIT));
		//set motor & spare road permit reqd flag value
		nextProcessVars.put(ActivitiConstants.CHECK_MOTOR_ROAD_PERMIT_REQ,
				execution.getVariable(ActivitiConstants.CHECK_MOTOR_ROAD_PERMIT_REQ));
		nextProcessVars.put(ActivitiConstants.CHECK_SPARE_ROAD_PERMIT_REQ,
				execution.getVariable(ActivitiConstants.CHECK_SPARE_ROAD_PERMIT_REQ));
		nextProcessVars.put(ActivitiConstants.NOTIFY,
				execution.getVariable(ActivitiConstants.NOTIFY));
	}

	/**
	 * Implementing classes are expected to call this method that sets the next fresh values of process variables to be
	 * utilized from the current execution in a new map to ensure that old process variables are not sent to the new
	 * process
	 * 
	 * @param execution
	 * @param nextProcessVars
	 */
	protected void setNextProcessVariables(DelegateExecution execution, Map<String, Object> nextProcessVars,
			MotorDetailsDTO motorDetailDTO) {
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID));
		nextProcessVars.put(ActivitiConstants.MOTOR_SN_NO, motorDetailDTO.getMotorSnNum());
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID, motorDetailDTO.getSubProcessId());
		nextProcessVars.put(ActivitiConstants.INIT_WARRANRTY,
				MotorRepairConstants.WARRANTY_TYPE.of(motorDetailDTO.getInitialWarrantyClaim()).toString());
		String gspRefNumber = execution.getVariable(ActivitiConstants.GSP_REF_NO).toString();
		if (null != motorDetailDTO.getRegionId()) {
			Long regionId = Long.parseLong(motorDetailDTO.getRegionId());
			// fetch region name based on Id from region master

			MotorSalesDetailDTO motorSalesDetailDTO = motorSalesDetailService
					.getMotorSalesDetailByMotorSalesDetailId(Long.parseLong(motorDetailDTO.getSalesOfficeRefId()));
			RegionMasterDTO regionMasterDTO = regionMasterService.getRegionMasterByRegionIdAndTenantIdAndSolCatId(
					regionId, MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
			if (null != regionMasterDTO && null != motorSalesDetailDTO) {
				String saleOfficeNRegionName = motorSalesDetailDTO.getName() + ActivitiConstants.COMMA
						+ regionMasterDTO.getRegionName();
				nextProcessVars.put(ActivitiConstants.SALES_OFFICE_N_REGION_NAME, saleOfficeNRegionName);
			}
		}

		nextProcessVars.put(ActivitiConstants.GSP_REF_NO, gspRefNumber);
		nextProcessVars.put(ActivitiConstants.FRAME_SIZE, motorDetailDTO.getFrameSize());
		nextProcessVars.put(ActivitiConstants.RECLAIM_ID, execution.getVariable(ActivitiConstants.RECLAIM_ID));
		nextProcessVars.put(ActivitiConstants.INIT_WARRANRTY,
				MotorRepairConstants.WARRANTY_TYPE.of(motorDetailDTO.getInitialWarrantyClaim()).toString());
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP));
		nextProcessVars.put(ActivitiConstants.BATCH_PROCESS_ID,
				execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID));

		nextProcessVars.put(ActivitiConstants.MLFB_SPIRIDON_CODE, motorDetailDTO.getMlfbSpiridon());
		if (null == execution.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID)) {
			// FETCH THIS VALUE AND SET IT

			MasterWorkflowFields masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByGspRefNo(gspRefNumber);

			nextProcessVars.put(ActivitiConstants.MASTER_BATCH_PROCESS_ID, masterWorkflowFields.getBatchProcessId());

		} else {

			nextProcessVars.put(ActivitiConstants.MASTER_BATCH_PROCESS_ID,
					execution.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID));
		}
		// --------------- ADDED Parallel Process IDs if available
		// ---------------//
		if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID))
			nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_ID,
					execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID));
		if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID))
			nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID,
					execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID));
		// ----------------------------------------------------------------------
		// //
		nextProcessVars.put(ActivitiConstants.MASTER_PROCESS_ID,
				execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID));
		nextProcessVars.put(ActivitiConstants.SUB_PROCESS_ID, motorDetailDTO.getSubProcessId());
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY));
		// passing assignee attribute from previous process to next
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));
		// set customer name
		nextProcessVars.put(ActivitiConstants.CUST_NAME, execution.getVariable(ActivitiConstants.CUST_NAME));
		// set email title
		nextProcessVars.put(ActivitiConstants.SUB_TITLE, execution.getVariable(ActivitiConstants.SUB_TITLE));
		// set arc name
		nextProcessVars.put(ActivitiConstants.ARC_NAME, execution.getVariable(ActivitiConstants.ARC_NAME));
		// set ARC ref Id
		nextProcessVars.put(ActivitiConstants.ARC_REF_ID, execution.getVariable(ActivitiConstants.ARC_REF_ID));
		// set ARC Type
		nextProcessVars.put(ActivitiConstants.ARC_TYPE, execution.getVariable(ActivitiConstants.ARC_TYPE));
		// set status
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_STATUS, TaskStatus.New.toString());
		// set status date
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_STATUS_DATE, new Date());
		// set severity
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_SEVERITY,
				MotorRepairConstants.SEVERITY.NORMAL.toString());
		// set created date ,& created by
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_DATE, new Date());
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_BY,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));
		// set region name
		nextProcessVars.put(ActivitiConstants.SALES_OFFICE_N_REGION_NAME,
				execution.getVariable(ActivitiConstants.SALES_OFFICE_N_REGION_NAME));
		nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL,
				execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL));
		nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_1,
				execution.getVariable(ActivitiConstants.CONFIG_FRAME_SIZE_1));
		nextProcessVars.put(ActivitiConstants.CONFIG_FRAME_SIZE_2,
				execution.getVariable(ActivitiConstants.CONFIG_FRAME_SIZE_2));
		nextProcessVars.put(ActivitiConstants.CONFIG_PARAS_ARC_TYPE,
				execution.getVariable(ActivitiConstants.CONFIG_PARAS_ARC_TYPE));
		nextProcessVars.put(ActivitiConstants.IS_MOTOR_RECV, execution.getVariable(ActivitiConstants.IS_MOTOR_RECV));

	}

	/**
	 * Invokes the workflow with fresh set of process variables<br>
	 * 
	 * @param processVariables
	 *            Values must be fresh to avoid unintentional flow execution<br>
	 * 
	 * @param previousFunctionCode
	 *            Function code of the workflow that is invoking the new workflow<br>
	 * @param functionCode
	 *            Function code of the new workflow<br>
	 * @throws Exception
	 */
	protected String invokeWorkflow(Map<String, Object> processVariables, String previousFunctionCode,
			String functionCode) throws Exception {
		// Check for Approval Workflow
		int sendForApproval = 0;

		try {
			sendForApproval = (null != processVariables.get(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG)) ? Integer
					.parseInt(String.valueOf(processVariables.get(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG))) : 0;
		} catch (NumberFormatException e) {
			LOGGER.debug("SEND_FOR_APPROVAL_FLAG parseble");
		}

		if (1 == sendForApproval) {
			LOGGER.info("BASE_INVOKER: Invoke Approval Workflow for function code: " + functionCode
					+ "; previousFunctionCode: " + previousFunctionCode);

			String postApprovalFunctionCode = (null != processVariables
					.get(MotorRepairConstants.POST_APPROVAL_FUNC_CODE)) ? processVariables.get(
					MotorRepairConstants.POST_APPROVAL_FUNC_CODE).toString() : null;

			if (null == postApprovalFunctionCode) {
				postApprovalFunctionCode = functionCode;
			}

			processVariables.put(MotorRepairConstants.PRE_APPROVAL_FUNC_CODE, previousFunctionCode);
			processVariables.put(MotorRepairConstants.POST_APPROVAL_FUNC_CODE, postApprovalFunctionCode);
			processVariables.remove(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG);

			return invokeWorkflow(processVariables, previousFunctionCode, MotorRepairConstants.APP_APPROVAL_CLEARANCE,
					false);
		} else {
			return invokeWorkflow(processVariables, previousFunctionCode, functionCode, false);
		}
	}

	/**
	 * Invokes the workflow with fresh set of process variables while keeping AssignedTo Field Intact<br>
	 * Must be invoked ONLY for RECALL<br>
	 * 
	 * @param processVariables
	 *            Values must be fresh to avoid unintentional flow execution<br>
	 * 
	 * @param previousFunctionCode
	 *            Function code of the workflow that is invoking the new workflow<br>
	 * @param functionCode
	 *            Function code of the new workflow<br>
	 * @throws Exception
	 */
	protected String invokeWorkflowForRecall(Map<String, Object> processVariables, String previousFunctionCode,
			String functionCode) throws Exception {

		return invokeWorkflow(processVariables, previousFunctionCode, functionCode, true);
	}

	/**
	 * 
	 * @param processVariables
	 *            Values must be fresh to avoid unintentional flow execution<br>
	 * @param previousFunctionCode
	 *            Function code of the workflow that is invoking the new workflow<br>
	 * @param functionCode
	 *            Function code of the new workflow<br>
	 * @param isRecalled
	 *            if Recalled, do not remove AssignedTo
	 * @return
	 * @throws Exception
	 */
	private String invokeWorkflow(Map<String, Object> processVariables, String previousFunctionCode,
			String functionCode, boolean isRecalled) throws Exception {
		LOGGER.info("BASE_INVOKER: BEGIN: Invoke Workflow for function code: " + functionCode
				+ "; previousFunctionCode: " + previousFunctionCode);

		if ((null != processVariables.get(ActivitiConstants.RECLAIM_ID))
				&& (!MotorRepairConstants.CCC_RECLAIMED_TASK.equals(functionCode))) {
			LOGGER.info("BASE_INVOKER: INVOCATION OF WORKFLOW FOR Next functionCode: " + functionCode
					+ " IS SKIPPED AS TASK HAS BEEN RECLAIMED!!");
		} else {

			if (null != functionCode) {
				processVariables.put(ActivitiConstants.FUNCTION_CODE, functionCode);
				processVariables.put(ActivitiConstants.PREV_FUNCTION_CODE, previousFunctionCode);

				ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
						.getActorFunctionMasterByFunctionCode(functionCode);
				String workflowName = actorFunctionMasterDTO.getWorkflowName();
				//if function code is other than approval clearance then only allow to override
				if (!functionCode.equals(MotorRepairConstants.APP_APPROVAL_CLEARANCE)) {
					// TODO Set GROUP NAME FROM FUNCTION MAP
					if (actorFunctionMasterDTO.getActorMasterDTOList() != null
							&& actorFunctionMasterDTO.getActorMasterDTOList().size() > 0) {
						processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP,
								actorFunctionMasterDTO.getActorMasterDTOList().get(0).getActorName());
						// VALUE FOR ARC_REFID IS HANDLED DIFFERENTLY INCASE OF
						// PARAS ARC ,IT IS NOT REQUIRED TO SET THIS
						// FROM SUBPROCESS FIELD DTO FOR PARAS
						if (functionCode.startsWith(MotorRepairConstants.ARC)) {
							// get SubProcessId from process variable map
							// Long subProcessId =
							// Long.parseLong(processVariables.get(
							// ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID).toString());
							// find ARCrefId from subProcessId
							// Long arcRefId =
							// subProcessFieldsService.getARCRefIdBySubProcessId(subProcessId);
							// set assign to parameter based on ARC refId
							String arcRefId = (null != processVariables.get(ActivitiConstants.ARC_REF_ID)) ? String
									.valueOf(processVariables.get(ActivitiConstants.ARC_REF_ID)) : null;
							if (null != arcRefId) {
								ARCMasterDTO arcMasterDTO = arcMasterService
										.getARCMasterByArcId(Long.valueOf(arcRefId));
								if (null != arcMasterDTO) {
									processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL,
											arcMasterDTO.getArcContactEmail());
								}
							}

							processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO,
									processVariables.get(ActivitiConstants.ARC_REF_ID));
							processVariables.put(ActivitiConstants.ARC_TYPE,
									processVariables.get(ActivitiConstants.ARC_TYPE));

						} else {
							if (!isRecalled) {
								// reset assignedto
								processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO, null);
							}
						}
					}
				}
				processVariables.put(ActivitiConstants.FUNCTION_NAME, actorFunctionMasterDTO.getFunctionName());
				// if function code starts with ARC task

				processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_BY,
						processVariables.get(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));
				processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_DATE, new Date());
				processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ACTUAL_START_DATE, new Date());

				// TODO set the region for this task
				// processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_REGION,
				// value);

				// Invoke Task Assignment Notifications
				LOGGER.info("BASE_INVOKER: Invoke ASSIGNMENT NOTIFICATION : BEGIN");
				List<ConfigDetailDTO> configDetails = configDetailService.findConfigDetailsByConfigTypeNSubType(
						MotorRepairConstants.ASSIGNMENT_EMAIL_CONFIG_TYPE,
						MotorRepairConstants.ASSIGNMENT_EMAIL_CONFIG_SUBTYPE, MotorRepairConstants.TENANT_ID,
						MotorRepairConstants.PROGRAM_ID);

				if ((null != configDetails) && (1 == configDetails.size())) {
					ConfigDetailDTO configDetailDTO = configDetails.get(0);
					if (configDetailDTO.getConfigIntVal().intValue() == 1) {

						LOGGER.info("BASE_INVOKER: ASSIGNMENT NOTIFICATION ENABLED");
						// Fetch the template details from templateInfoService

						List<TemplateInfoDTO> templateInfos = templateInfoService
								.findTemplateInfoByFunCodeNNotificationType(
										processVariables.get(ActivitiConstants.FUNCTION_CODE).toString(),
										MotorRepairConstants.TASK_NOTIFY_TYPE.NEW_TASK.getValue());
						LOGGER.info("BASEWORKFLOW :FUNCTION CODE:"
								+ processVariables.get(ActivitiConstants.FUNCTION_CODE));
						for (TemplateInfoDTO templateInfoDTO : templateInfos) {
							LOGGER.info("BASE_INVOKER: ASSIGNMENT NOTIFICATION TEMPLATE: "
									+ templateInfoDTO.getFunctionCode() + "; " + templateInfoDTO.getTemplateCode());

							processVariables.put(ActivitiConstants.NOTIFY, 1);
							processVariables.put(MotorRepairConstants.TEMPLATE_CODE, templateInfoDTO.getTemplateCode());

							LOGGER.info("BASE_INVOKER: INVOKE NOTIFICATION HANDLER: ");
							sendNotification(processVariables);
						}
					}
				}
				LOGGER.info("BASE_INVOKER: Invoke ASSIGNMENT NOTIFICATION : END");

				// call ARC assignment .bpmn
				return workflowInvoker.startNewProcess(processVariables, workflowName);
			} else {
				LOGGER.info("BASE_INVOKER: No function found for function code: " + functionCode);
			} // function code is not null
		} // else not reclaimed
		LOGGER.info("BASE_INVOKER: END: Invoke Workflow for function code: " + functionCode
				+ "; previousFunctionCode: " + previousFunctionCode);
		return null;
	}

	/**
	 * Invoke Notification workflow.
	 * 
	 * @param execution
	 * @param nextProcessVars
	 * @return
	 */
	protected String sendNotification(Map<String, Object> nextProcessVars) {
		String functionCode = MotorRepairConstants.SYS_NOTIFICATION;
		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);
		String workflowName = actorFunctionMasterDTO.getWorkflowName();
		// TODO set nextProcessVars with appropriate values
		nextProcessVars.put(ActivitiConstants.CHECK_EDIT_ENABLED, 0);
		return workflowInvoker.startNewProcess(nextProcessVars, workflowName);

	}

}
