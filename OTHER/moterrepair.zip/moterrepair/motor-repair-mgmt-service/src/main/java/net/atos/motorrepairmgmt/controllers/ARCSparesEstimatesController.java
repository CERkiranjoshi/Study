package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;
import net.atos.motorrepairmgmt.services.ARCSparesEstimatesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610051
 * 
 */
@Controller
@EnableSwagger
@RequestMapping(value = "arcSparesEstimatesService")
public class ARCSparesEstimatesController {

	/** The ARCRepairEstimates Service */
	@Autowired
	private ARCSparesEstimatesService arcSparesEstimatesService;

	/**
	 * This method is used for creating and updating ARCSparesEstimates.
	 * 
	 * @param ARCSparesEstimatesDTO
	 *            The arcSparesEstimatesDTO
	 * 
	 * @return Boolean
	 */
	@RequestMapping(value = "/createUpdateARCSparesEstimates", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates ARCSparesEstimates with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateARCSparesEstimates(@RequestBody ARCSparesEstimatesDTO arcSparesEstimatesDTO) {

		return arcSparesEstimatesService.createUpdateARCSparesEstimates(arcSparesEstimatesDTO);
	}

	/**
	 * This method is used for deleting ARCSparesEstimates.
	 * 
	 * @param arcSparesEstimateId
	 *            The ARCSparesEstimate Id
	 * 
	 * @return Boolean
	 */

	@RequestMapping(value = "/deleteARCSparesEstimatesByARCSparesEstimateId/{arcSparesEstimateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete ARCSparesEstimates By ARCSparesEstimate Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ARCSparesEstimate Id value") })
	public @ResponseBody Boolean deleteARCSparesEstimatesByARCSparesEstimateId(
			@ApiParam(value = "ARCSparesEstimate Id to delete", required = true) @PathVariable("arcSparesEstimateId") Long arcSparesEstimateId) {
		try {
			return arcSparesEstimatesService.deleteARCSparesEstimatesByARCSparesEstimateId(arcSparesEstimateId);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method is used for retrieving ARCSparesEstimates based on
	 * arcSparesEstimateId.
	 * 
	 * @param arcSparesEstimateId
	 *            The ARCSparesEstimate Id
	 * 
	 * @return ARCSparesEstimatesDTO
	 * 
	 */
	@RequestMapping(value = "/getARCSparesEstimatesByARCSparesEstimateId/{arcSparesEstimateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCSparesEstimates By ARCSparesEstimate Id", notes = "Returns a ARCSparesEstimates entity when ARCSparesEstimate Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid ARCSparesEstimate Id supplied"),
			@ApiResponse(code = 404, message = "ARCSparesEstimates not found") })
	public @ResponseBody ARCSparesEstimatesDTO getARCSparesEstimatesByARCSparesEstimateId(
			@ApiParam(value = "ARCSparesEstimate Id of the ARCSparesEstimates that needs to be fetched", required = true) @PathVariable("arcSparesEstimateId") Long arcSparesEstimateId) {
		return arcSparesEstimatesService.getARCSparesEstimatesByARCSparesEstimateId(arcSparesEstimateId);
	}

	/**
	 * 
	 * This method is used for retrieving all ARCSparesEstimates.
	 * 
	 * @return ARCSparesEstimatesDTOs
	 */
	@RequestMapping(value = "/getAllARCSparesEstimates", method = RequestMethod.GET)
	@ApiOperation(value = "Find All ARCSparesEstimates", notes = "Returns a ARCSparesEstimates Master entity", response = ARCRepairEstimatesDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation") })
	public @ResponseBody List<ARCSparesEstimatesDTO> getAllARCSparesEstimates() {
		return arcSparesEstimatesService.getAllARCSparesEstimates();
	}
}
