package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.DReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.services.DReportFieldsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610051
 * 
 */
@Controller
@EnableSwagger
@RequestMapping(value = "dReportFieldsService")
public class DReportFieldsController {

	/** The DReportFields Service */
	@Autowired
	private DReportFieldsService dReportFieldsService;

	/**
	 * This method is used for creating and updating DReportFields.
	 * 
	 * @param DReportFieldsDTO
	 *            The arcRepairEstimatesDTO
	 * 
	 * @return Boolean
	 */
	@RequestMapping(value = "/createUpdateDReportFields", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates CReportFields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	DReportFieldsDTO createUpdateDReportFields(
			@RequestBody DReportFieldsDTO dReportFieldsDTO) {

		return dReportFieldsService.createUpdateDReportFields(dReportFieldsDTO);
	}

	/**
	 * This method is used for deleting DReportFields.
	 * 
	 * @param motorDReportFieldId
	 *            The MotorDReportField Id
	 * 
	 * @return Boolean
	 */

	@RequestMapping(value = "/deleteDReportFieldsByMotorDReportFieldId/{motorDReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete DReportFields By motorDReportField Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid motorDReportField Id value") })
	public @ResponseBody
	Boolean deleteDReportFieldsByMotorDReportFieldId(
			@PathVariable("motorDReportFieldId") Long motorDReportFieldId) {
		try {
			return dReportFieldsService
					.deleteDReportFieldsByMotorDReportFieldId(motorDReportFieldId);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 
	 * This method is used for retrieving all DReportFields.
	 * 
	 * @return List of DReportFieldsDTOs
	 */
	@RequestMapping(value = "/getAllDReportFields", method = RequestMethod.GET)
	@ApiOperation(value = "Find All CReportFields", notes = "Returns a DReportFields entity ", response = DReportFieldsDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation") })
	public @ResponseBody
	List<DReportFieldsDTO> getAllDReportFields() {
		return dReportFieldsService.getAllDReportFields();
	}

	/**
	 * This method is used for retrieving DReportFields based on
	 * WlfwSubProcessId of SubProcessFields.
	 * 
	 * @param WlfwSubProcessId
	 *            The WlfwSubProcess Id
	 * 
	 * @return List of DReportFieldsDTO
	 * 
	 */
	@RequestMapping(value = "/getDReportFieldsBySubProcessID/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CReportFields By WlfwSubProcess Id of SubProcessFields", notes = "Returns a CReportFields entity when WlfwSubProcess Id is passed", response = DReportFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid WlfwSubProcess Id supplied"),
			@ApiResponse(code = 404, message = "CReportFields not found") })
	public @ResponseBody
	DReportFieldsDTO getDReportFieldsBySubProcessID(
			@ApiParam(value = "WlfwSubProcess Id of the SubProcessFields", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return dReportFieldsService
				.getDReportFieldsBySubProcessID(wlfwSubProcessId);
	}

	/**
	 * This method is used for retrieving MotorNamePlateDetail based on
	 * motorDReportFieldId of DReportFields.
	 * 
	 * @param motorDReportFieldId
	 *            The MotorDReportField Id
	 * 
	 * @return MotorNamePlateDetailDTO
	 * 
	 */
	@RequestMapping(value = "/getNamePlateByDReportId/{motorDReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorNamePlateDetail By MotorDReportField Id of DReportFields", notes = "Returns a MotorNamePlateDetail entity when MotorDReportField Id is passed", response = MotorNamePlateDetailDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotoDCReportField Id supplied"),
			@ApiResponse(code = 404, message = "MotorNamePlateDetail not found") })
	public @ResponseBody
	MotorNamePlateDetailDTO getNamePlateByDReportId(
			@ApiParam(value = "MotorDReportField Id of the DReportFields", required = true) @PathVariable("motorDReportFieldId") Long motorDReportFieldId) {
		return dReportFieldsService
				.getNamePlateByDReportId(motorDReportFieldId);
	}

	/**
	 * This method is used to add or Update MotorNamePlateDetail To
	 * CReportFields based on motorDReportFieldId of CReportFields.
	 * 
	 * @param motorDReportFieldId
	 *            The MotorDReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateMotorNamePlateDetailToDReportFields/{motorDReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update MotorNamePlateDetail to CReportFields when motorDReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorDReportField Id supplied") })
	public @ResponseBody
	Boolean addUpdateMotorNamePlateDetailToDReportFields(
			@ApiParam(value = "motorDReportField Id of the DReportFields", required = true) @PathVariable("motorDReportFieldId") Long motorDReportFieldId,
			@ApiParam(value = "MotorNamePlateDetailDTO to be added in DReportFields", required = true) @RequestBody MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		return dReportFieldsService
				.addUpdateMotorNamePlateDetailToDReportFields(
						motorDReportFieldId, motorNamePlateDetailDTO);
	}

	/**
	 * This method is used to add or Update SubProcessFields To CReportFields
	 * based on motorDReportFieldId of CReportFields.
	 * 
	 * @param motorDReportFieldId
	 *            The MotorDReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateSubProcessFieldsToDReportFields/{motorDReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update SubProcessFields to CReportFields when motorCReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied") })
	public @ResponseBody
	Long addUpdateSubProcessFieldsToDReportFields(
			@ApiParam(value = "motorCReportField Id of the CReportFields", required = true) @PathVariable("motorDReportFieldId") Long motorDReportFieldId,
			@ApiParam(value = "SubProcessFieldsDTO to be added in CReportFields", required = true) @RequestBody SubProcessFieldsDTO subProcessFieldsDTO) {
		return dReportFieldsService.addUpdateSubProcessFieldsToDReportFields(
				motorDReportFieldId, subProcessFieldsDTO);
	}

	/**
	 * This method is used for retrieving ARCRepairEstimates based on
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * 
	 * @return ARCRepairEstimatesDTO
	 * 
	 */
	@RequestMapping(value = "/getDReportFieldsByMotorDReportFieldId/{motorDReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find DReportFields By motorDReportField Id", notes = "Returns a DReportFields entity when motorDReportField Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorDReportField Id supplied"),
			@ApiResponse(code = 404, message = "ArcRepairEstimate not found") })
	public @ResponseBody
	DReportFieldsDTO getDReportFieldsByMotorDReportFieldId(
			@ApiParam(value = "motorDReportField Id of the DReportFields that needs to be fetched", required = true) @PathVariable("motorDReportFieldId") Long motorDReportFieldId) {
		return dReportFieldsService
				.getDReportFieldsByMotorDReportFieldId(motorDReportFieldId);
	}
}
