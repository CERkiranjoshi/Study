package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;
import net.atos.motorrepairmgmt.services.RegionMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603975
 * 
 */

@Controller
@EnableSwagger
@RequestMapping(value = "regionMasterService")
public class RegionMasterController {
	@Autowired
	private RegionMasterService regionMasterService;

	@RequestMapping(value = "/createUpdateRegionMaster", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  RegionMaster with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateRegionMaster(
			@ApiParam(value = " RegionMaster Data object that needs to be added or update in the RegionMAster") @RequestBody RegionMasterDTO regionMasterDTO) {
		return regionMasterService.createUpdateRegionMaster(regionMasterDTO);
	}

	@RequestMapping(value = "/getAllRegionMaster", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find  RegionMaster ", notes = "Returns a  RegionMaster entity", response = RegionMasterDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<RegionMasterDTO> getAllRegionMaster() {
		return regionMasterService.getAllRegionMaster();
	}

	@RequestMapping(value = "/getARCMasterListByRegionIDAndTenantIdAndSolCatId/{regionId}/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By regionId , tenantId and solutionCategoryId ", notes = "Returns a ARCMaster entity when regionId ,tenantId and solutionCategoryId is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<ARCMasterDTO> getARCMasterListByRegionIDAndTenantIdAndSolCatId(
			@ApiParam(value = "ARCMaster  based on regionId, tenantId and solutionCategoryId   needs to be fetched", required = true) @PathVariable("regionId") final Long regionId,
			@PathVariable("tenantId") final String tenantId,
			@PathVariable("solutionCategoryId") final String solutionCategoryId) {
		return regionMasterService.getARCMasterListByRegionIDAndTenantIdAndSolCatId(regionId, tenantId,
				solutionCategoryId);
	}

	@RequestMapping(value = "/getRegionMasterListByTenantIdAndSolCatId/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find RegionMaster By tenantId and solCategoryId", notes = "Returns a RegionMaster entity when  tenantId and solutionCategoryIdis passed", response = RegionMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<RegionMasterDTO> getRegionMasterListByTenantIdAndSolCatId(
			@ApiParam(value = "RegionMaster based on tenantId and solutionCategoryId   needs to be fetched", required = true) @PathVariable("tenantId") final String tenantId,
			@PathVariable("solutionCategoryId") final String solutionCategoryId) {
		return regionMasterService.getRegionMasterListByTenantIdAndSolCatId(tenantId, solutionCategoryId);
	}

	@RequestMapping(value = "/getRegionMasterListByTenantId/{tenantId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find regionMaster By tenantId", notes = "Returns a RegionMaster entity when tenantId is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<RegionMasterDTO> getRegionMasterListByTenantId(
			@ApiParam(value = "RegionMaster based on tenantId needs to be fetched", required = true) @PathVariable("tenantId") final String tenantId) {
		return regionMasterService.getRegionMasterListByTenantId(tenantId);
	}

	@RequestMapping(value = "/deleteRegionMasterByRegionId/{regionId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete RegionMaster By RegionMaster Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid RegionMaster Id value") })
	public @ResponseBody Boolean deleteRegionMasterByRegionId(
			@ApiParam(value = " RegionMaster Id to delete", required = true) @PathVariable("regionId") final Long regionId) {
		return regionMasterService.deleteRegionMasterByRegionId(regionId);
	}

}
