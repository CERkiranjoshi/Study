/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.services.delegate.invokers.BaseWorkflowInvoker;
import net.atos.singetons.ReclaimIdHolder;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ReclaimWorkflowHandler handles invoked CCC Reclaim Workflow. It takes care of multiple invocations and ensures only
 * one task is allocated to the actor for processing reclaims.
 * 
 * @author Anand Ved
 * 
 */
@Component
public class ReclaimWorkflowHandler extends BaseWorkflowInvoker {

	@Autowired
	private WorkflowInvoker workflowInvoker;

	@Autowired
	private ReclaimIdHolder reclaimIdHolder;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ReclaimWorkflowHandler.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: Start " + execution.getId()));

		Object reclaimIdObj = execution.getVariable(ActivitiConstants.RECLAIM_ID);

		if (null == reclaimIdObj) {
			LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: NULL ReclaimId: " + reclaimIdObj);
		} else {

			if (reclaimIdHolder.isProcessedRecalimId(reclaimIdObj.toString())) {
				// SKIP For this Id
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: Skipping for ReclaimId: " + reclaimIdObj);
			} else {
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: Processing for ReclaimId: " + reclaimIdObj);
				if (reclaimIdHolder.addReclaimId(reclaimIdObj.toString())) {

					LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: reclaimId: " + reclaimIdObj + "; Function Code: "
							+ execution.getVariable(ActivitiConstants.FUNCTION_CODE) + "; Function name: "
							+ execution.getVariable(ActivitiConstants.FUNCTION_NAME + "; "));
					// Allow this workflow process to proceed.
					execution.setVariable(ActivitiConstants.CHECK_PROCEED, "PROCEED");

				} else {
					// Here due to race condition, skip further process
					if (LOGGER.isDebugEnabled())
						LOGGER.debug("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: Race condition, skipping for reclaimId: "
								+ reclaimIdObj + "; Previous Function Code: "
								+ execution.getVariable(ActivitiConstants.PREV_FUNCTION_CODE)
								+ "; Previous Function name: "
								+ execution.getVariable(ActivitiConstants.PREV_FUNCTION_NAME + "; "));
					execution.setVariable(ActivitiConstants.CHECK_PROCEED, "SKIP");
					
				}
			}
		}

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECLAIM_WORKFLOW_HANDLER: End " + execution.getId());

	}

}
