package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.services.MotorNamePlateDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "motorNamePlateDetailService")
public class MotorNamePlateDetailController {

	@Autowired
	private MotorNamePlateDetailService motorNamePlateDetailService;

	@RequestMapping(value = "/createUpdateMotorNamePlateDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates MotorNamePlateDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMotorNamePlateDetail(
			@ApiParam(value = "MotorNamePlateDetail object that needs to be added or update in the MotorNamePlateDetail") @RequestBody MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		return motorNamePlateDetailService.createUpdateMotorNamePlateDetail(motorNamePlateDetailDTO);
	}

	@RequestMapping(value = "/getAllMotorNamePlateDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorNamePlateDetail ", notes = "Returns a MotorNamePlateDetail entity", response = MotorNamePlateDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<MotorNamePlateDetailDTO> getAllMotorNamePlateDetail() {
		return motorNamePlateDetailService.getAllMotorNamePlateDetail();
	}

	@RequestMapping(value = "/getNamePlateByNamePlateID/{namePlateFieldId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MotorNamePlateDetail By MotorNamePlateDetail Id", notes = "Returns a MotorNamePlateDetail entity when MotorNamePlateDetail Id is passed", response = MotorNamePlateDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorNamePlateDetail Id supplied"),
			@ApiResponse(code = 404, message = "MotorNamePlateDetail not found") })
	public @ResponseBody MotorNamePlateDetailDTO getNamePlateByNamePlateID(
			@ApiParam(value = "MotorNamePlateDetail Id of the MotorNamePlateDetail that needs to be fetched", required = true) @PathVariable("namePlateFieldId") Long namePlateFieldId) {
		return motorNamePlateDetailService.getNamePlateByNamePlateId(namePlateFieldId);
	}

	@RequestMapping(value = "/deleteMotorNamePlateDetailByNamePlateFieldId/{namePlateFieldId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete MotorNamePlateDetail By MotorNamePlateDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid MotorNamePlateDetail Id value") })
	public @ResponseBody Boolean deleteMotorNamePlateDetailByNamePlateFieldId(
			@ApiParam(value = "MotorNamePlateDetail Id to delete", required = true) @PathVariable("namePlateFieldId") Long namePlateFieldId) {
		try {
			return motorNamePlateDetailService.deleteMotorNamePlateDetailByNamePlateFieldId(namePlateFieldId);
		} catch (Exception e) {
			return false;
		}
	}
}