package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.services.UploadAttachmentsService;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@EnableSwagger
@RequestMapping(value = "uploadAttachmentsService")
@Controller
public class UploadAttachmentsController {

	@Autowired
	private UploadAttachmentsService uploadFileService;

	// upload
	@RequestMapping(value = "/uploadDocument/{wlfwSubProcessId}", method = RequestMethod.POST)
	@ApiOperation(value = "Upload Document", notes = "", response = Void.class)
	public @ResponseBody
	List<MotorAttachmentDetailDTO> uploadDocument(
			@ApiParam(value = "wlfwSubProcessId of SubProcessFields object") @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "Description To be Upload") @RequestParam(value = "description", required = true) String description,
			@ApiParam(value = "UploadedBy user ID") @RequestParam(value = "uploadedBy", required = true) String uploadedBy,
			@ApiParam(value = "AttachmentType") @RequestParam(value = "attachmentType", required = true) Integer attachmentType,
			@ApiParam(value = "File To be Upload") @RequestParam(value = "file", required = true) MultipartFile file,
			@ApiParam(value = "TenantId") @RequestParam(value = "tenantId", required = true) String tenantId,
			@ApiParam(value = "solCatId") @RequestParam(value = "solCatId", required = true) String solCatId,
			@ApiParam(value = "isInternal") @RequestParam(value = "isInternal", required = true) Integer isInternal,
			@ApiParam(value = "methodCallValue") @RequestParam(value = "methodCallValue", required = true) Integer methodCallValue) {
		return uploadFileService.uploadDocument(file, wlfwSubProcessId, description, uploadedBy, attachmentType,
				tenantId, solCatId, isInternal,methodCallValue);
	}

	// donwload
	@RequestMapping(value = "/downloadDocument/{motorAttachmentsId}", method = RequestMethod.GET)
	public @ResponseBody
	void downloadDocument(
			HttpSession session,
			HttpServletResponse response,
			@ApiParam(value = "motorAttachmentsId of MotorAttachment Object to be download") @PathVariable("motorAttachmentsId") Long motorAttachmentsId)
			throws Exception {

		uploadFileService.downloadDocument(session, response, motorAttachmentsId);

	}

	@RequestMapping(value = "/deleteDocument/{motorAttachmentsId}/{deletedBy}", method = RequestMethod.POST)
	public @ResponseBody
	boolean deleteDocument(
		    @PathVariable("motorAttachmentsId") Long motorAttachmentsId,
			@PathVariable("deletedBy") String deletedBy) {
		boolean flag = uploadFileService.deleteFile(motorAttachmentsId, deletedBy);
		return flag;
	}

	@RequestMapping(value = "/getAllMotorAttachmentDetailBySubprocesssId/{wlfwSubProcessId}/{external}/{uploadedBy}", method = { RequestMethod.GET })
	public @ResponseBody
	List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetailBySubprocesssId(
			@PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@PathVariable("external")  Boolean external,
			@PathVariable("uploadedBy") String uploadedBy) {
		return uploadFileService.getAllMotorAttachmentDetailBySubprocesssId(wlfwSubProcessId, external, uploadedBy);
	}
	
	// upload
		@RequestMapping(value = "/uploadDocumentForMultipleSubprocess/{masterWorkflowFieldId}", method = RequestMethod.POST)
		@ApiOperation(value = "Upload Document", notes = "", response = Void.class)
		public @ResponseBody
		List<MotorAttachmentDetailDTO> uploadDocumentForMultipleSubprocess(
				@ApiParam(value = "Description To be Upload") @RequestParam(value = "description", required = true) String description,
				@ApiParam(value = "UploadedBy user ID") @RequestParam(value = "uploadedBy", required = true) String uploadedBy,
				@ApiParam(value = "AttachmentType") @RequestParam(value = "attachmentType", required = true) Integer attachmentType,
				@ApiParam(value = "File To be Upload") @RequestParam(value = "file", required = true) MultipartFile file,
				@ApiParam(value = "TenantId") @RequestParam(value = "tenantId", required = true) String tenantId,
				@ApiParam(value = "solCatId") @RequestParam(value = "solCatId", required = true) String solCatId,
				@ApiParam(value = "isInternal") @RequestParam(value = "isInternal", required = true) Integer isInternal,
				@ApiParam(value = "wlfwSubProcessId of SubProcessFields object") @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId,
				@ApiParam(value = "methodCallValue") @RequestParam(value = "methodCallValue", required = true) Integer methodCallValue) {
			return uploadFileService.uploadDocumentForMultipleSubprocess(file, description, uploadedBy, attachmentType,
					tenantId, solCatId, isInternal,masterWorkflowFieldId,methodCallValue);
		}
		
		@RequestMapping(value = "/deleteDocumentForMultipleSubprocess/{motorAttachmentsId}/{deletedBy}", method = RequestMethod.POST)
		public @ResponseBody
		boolean deleteDocumentForMultipleSubprocess(
			    @PathVariable("motorAttachmentsId") Long motorAttachmentsId,
				@PathVariable("deletedBy") String deletedBy) {
			boolean flag = uploadFileService.deleteDocumentForMultipleSubprocess(motorAttachmentsId, deletedBy);
			return flag;
		}
}
