/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.entity.ParallelProcess;
import net.atos.motorrepairmgmt.repository.ParallelProcessRepository;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.services.delegate.invokers.BaseWorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component(value = "endParallelProcessHandler")
public class EndParallelProcessHandler extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(EndParallelProcessHandler.class);

	/**
	 * Parallel Process Repository
	 */
	@Autowired
	private ParallelProcessRepository parallelProcessRepository;

	@Autowired
	private ARCMasterService arcMasterService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: START " + execution.getId());

		/**
		 * Steps:<br>
		 * Obtain the parallelProcess Id from the execution variable.<br>
		 * Fetch the list of existing Parallel Processes for this ID which are IN_EXEC state.<br>
		 * If there are more than one Parallel Processes in IN_EXEC state, update the current one to close it using the
		 * INIT_PARALLEL_PROC_ID from the execution thread.<br>
		 * If there is only one Parallel Process running, update it to close it and invoke the next flow based on which
		 * type of parallel process it is.<br>
		 */

		String parallelProcessId = (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID)) ? execution
				.getVariable(ActivitiConstants.PARALLEL_PROCESS_ID).toString() : null;

		String parallelProcessType = (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE)) ? execution
				.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE).toString() : null;

		Long parallelProcessThreadId = (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID) ? Long
				.parseLong(execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID).toString()) : null);
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: Parallel Process ID: " + parallelProcessId
				+ "; Parallel Process Thread ID: " + parallelProcessThreadId + "; Parallel Process Type: "
				+ parallelProcessType);

		List<ParallelProcess> parallelProcesses = parallelProcessRepository.findByParallelProcessIdAndState(
				parallelProcessId, MotorRepairConstants.IN_EXEC);
		if (null != parallelProcesses) {
			if (1 < parallelProcesses.size()) {
				for (ParallelProcess parallelProcess : parallelProcesses) {
					LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId()
							+ "] Processing list for Parallel Process ID: " + parallelProcessId
							+ "; Parallel Process Thread ID: " + parallelProcess.getParallelProcessThreadId()
							+ "; Parallel Process Type: " + parallelProcessType);
					// Find Parallel Process for this execution thread and update state to completion
					if (parallelProcess.getParallelProcessThreadId().equals(parallelProcessThreadId)) {
						completeParallelProcess(parallelProcess);
						LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId()
								+ "] Updated status for Parallel Process ID: " + parallelProcessId
								+ "; Parallel Process Thread ID: " + parallelProcess.getParallelProcessThreadId()
								+ "; Parallel Process Type: " + parallelProcess.getParallelProcessType()
								+ "; Parallel Process Type: " + parallelProcessType + "; Now sleeping....");
						break;
					}
				}
			} else {
				if (parallelProcesses.size() > 0) {
					ParallelProcess parallelProcess = parallelProcesses.get(0);
					LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId()
							+ "] Processing list for Parallel Process ID: " + parallelProcessId
							+ "; Parallel Process Thread ID: " + parallelProcess.getParallelProcessThreadId()
							+ "; Parallel Process Type: " + parallelProcessType);
					// UPDATE this parallel process to close it and invoke the next workflow
					completeParallelProcess(parallelProcess);

					LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId()
							+ "] Updated status for Parallel Process ID: " + parallelProcessId
							+ "; Parallel Process Thread ID: " + parallelProcess.getParallelProcessThreadId()
							+ "; Parallel Process Type: " + parallelProcessType + "; Now Invoking next Workflow..");

					if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.A.toString().equals(
							parallelProcess.getParallelProcessType())) {
						// Invoke Parallel Process Function for Process Type A

						initiateNextFunctionFlow(execution, MotorRepairConstants.CCC_LINKED_ORDER_CLOSURE, false);

					} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.B.toString().equals(
							parallelProcess.getParallelProcessType())) {

						// Invoke Parallel Process Function for Process Type B
						// check if its spares dispatch
						if ((null == execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES))
								|| (execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES).toString().equals("0"))) {
							initiateNextFunctionFlow(execution, MotorRepairConstants.CCC_CLEARANCE_TO_ARC_DISPATCH,
									false);
						} else {
							if((null != execution.getVariable(ActivitiConstants.CHECK_FS_VISITED))
									&& (execution.getVariable(ActivitiConstants.CHECK_FS_VISITED).toString().equals("1"))) {
								initiateNextFunctionFlow(execution, MotorRepairConstants.CCC_CLOSURE_VERIFY_CUST, false);
							} else {
								initiateNextFunctionFlow(execution, MotorRepairConstants.CCC_LINKED_ORDER_CLOSURE, false);
							}
						}
					} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.C.toString().equals(
							parallelProcess.getParallelProcessType())) {

						// Invoke Parallel Process Function for Process Type C

						// RECEIVE MOTOR BY PARAS

						initiateNextFunctionFlow(execution, MotorRepairConstants.ARC_RECEIVE_MOTOR_WITH_GSP, true);
					} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.D.toString().equals(
							parallelProcess.getParallelProcessType())) {

						// Invoke Parallel Process Function for Process Type D
						// RECEIVE MOTOR BY PARAS
						initiateNextFunctionFlow(execution, MotorRepairConstants.ARC_RECEIVE_MOTOR_WITH_GSP, true);
					} else {
						LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId()
								+ "] Updated status for Parallel Process ID: " + parallelProcessId
								+ "; Parallel Process Thread ID: " + parallelProcess.getParallelProcessThreadId()
								+ "; Unknown Parallel Process Type: " + parallelProcess.getParallelProcessType()
								+ "; Incoming Parallel Process Type: " + parallelProcessType);
					}

				}
			}
		}
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: END " + execution.getId());
	}

	private String initiateNextFunctionFlow(DelegateExecution execution, String functionCode, boolean shippedToParas)
			throws Exception {
		LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId() + "] Initiating New Workflow: "
				+ functionCode);
		Map<String, Object> nextProcessVars = new HashMap<String, Object>();
		setNextProcessVariables(execution, nextProcessVars);

		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

		// REMOVE PARALLEL PROCESS VARIABLES SINCE PARALLEL PROCESS ENDS
		nextProcessVars.remove(ActivitiConstants.PARALLEL_PROCESS_ID);
		nextProcessVars.remove(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID);
		nextProcessVars.remove(ActivitiConstants.PARALLEL_PROCESS_TYPE);

		if (shippedToParas) {
			// PARAS's ARC Id would be set.
			setParasVariables(execution, nextProcessVars);
		}
		
		String newProcessInstId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
		LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: [" + execution.getId() + "] Initiated New Workflow: " + functionCode
				+ "; with ProcessInstanceId: " + newProcessInstId);
		return newProcessInstId;
	}

	private void completeParallelProcess(ParallelProcess parallelProcess) {
		// TODO set appropriate user reference if available
		parallelProcess.setClosedByRefId(MotorRepairConstants.SYSTEM_USER);
		parallelProcess.setClosedOn(new Date());
		parallelProcess.setParallelProcessState(MotorRepairConstants.COMPLETED);

		parallelProcessRepository.save(parallelProcess);
	}

	private void setParasVariables(DelegateExecution execution, Map<String, Object> nextProcessVars) {
		int parasTypeARCId = 0;
		List<ConfigDetailDTO> configDetailDTOList = configDetailService.findEnabledNVisibleConfigDetailsByTypeNSubType(
				MotorRepairConstants.SYSTEM_CONFIG, MotorRepairConstants.PARAS_ARC_TYPE, MotorRepairConstants.TENANT_ID,
				MotorRepairConstants.PROGRAM_ID);
		if (null != configDetailDTOList && configDetailDTOList.size() > 0) {
			parasTypeARCId=configDetailDTOList.get(0).getConfigIntVal();
			
		}
		if (0 != parasTypeARCId) {

			// TODO this wud require to be changed as ARC types would be multiple
			List<ARCMasterDTO> arcMasterDTOs = arcMasterService.getARCMasterByArcType(parasTypeARCId);

			if ((null != arcMasterDTOs) && (0 < arcMasterDTOs.size())) {

				ARCMasterDTO arcMasterDTO = arcMasterDTOs.get(0);

				// Setting variables related to PARAS
				nextProcessVars.put(ActivitiConstants.ARC_REF_ID, arcMasterDTO.getArcId().toString());
				nextProcessVars.put(ActivitiConstants.ARC_TYPE, arcMasterDTO.getArcType());
				nextProcessVars.put(ActivitiConstants.ARC_NAME, arcMasterDTO.getArcName().toString());
				nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL, arcMasterDTO.getArcContactEmail());
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END_PARALLEL_PROCESS_INVOKER: END " + execution.getId() + " PARAS ARC TYPE DETAILS SET");
			} else {
				LOGGER.error("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS TYPE ARC not available! PARAS TYPE not available in Process variables or in Config!");
			}
		} else {
			LOGGER.error("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS TYPE ARC not available! PARAS TYPE not available in Process variables or in Config!");
		}
	}

}
