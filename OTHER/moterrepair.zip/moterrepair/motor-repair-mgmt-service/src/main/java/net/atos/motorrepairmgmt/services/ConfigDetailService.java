/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;

/**
 * @author Sweety Kothari
 *
 */
public interface ConfigDetailService {

	public List<ConfigDetailDTO> findConfigDetailsByConfigTypeNSubType(String configType, String subType,
			String tenantId,String solnCatId);
	
	public List<ConfigDetailDTO> findEnabledNVisibleConfigDetailsByTypeNSubType(String configType, String subType,
			String tenantId,String solnCatId);
	public boolean refreshCacheData(String tenantId,String solcatId);
	public List<ConfigDetailDTO> findConfigDetailsByConfigType(
			String configType,  String tenantId, String solnCatId);
	public List<ConfigDetailDTO> findEnabledNVisibleConfigDetailsByType(String configType, 
			String tenantId,String solnCatId);
	public List<ConfigDetailDTO> findConfigDetailByTenantIdNSolnCatId(String tenantId,String solcatId); 
	public Long createUpdateConfigDetail(ConfigDetailDTO configDetailDTO);
}
