/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.taskmgmt.activiti.engine.IProcessEngine;
import net.atos.taskmgmt.activiti.mapper.ProcessVariableMapper;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.service.AdditionalProcessVariableService;

/**
 * @author a593775
 *
 */
@Service
public class WorkflowInvokerImpl implements WorkflowInvoker {

	@Autowired
	private IProcessEngine processEngineImpl;

	@Autowired
	private AdditionalProcessVariableService additionalProcessVariableService;

	@Override
    public String startNewProcess(Map<String,Object> procVariables,String workflowName) {
		String instanceKey = processEngineImpl.startNewProcess(workflowName, procVariables);
		return instanceKey;
	}

}
