package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;

/**
 * @author a603975
 * 
 */

public interface WorkflowStateService {
	Integer createUpdateWorkflowState(WorkflowStateDTO workflowStateDTO);

	List<WorkflowStateDTO> getAllWorkflowState();

	Boolean deleteWorkflowStateByWorkflowStateId(Integer workflowStateId);

	WorkflowStateDTO getWorkflowStateByWorkflowStateId(Integer workflowStateId);
	
	WorkflowStateDTO getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId ( Integer workflowStateId,String tenantId,String solutionCategoryId);

}
