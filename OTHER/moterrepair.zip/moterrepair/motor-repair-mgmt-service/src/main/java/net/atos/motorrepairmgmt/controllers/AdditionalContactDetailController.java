package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.services.AdditionalContactDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "additionalContactDetailService")
public class AdditionalContactDetailController {

	@Autowired
	private AdditionalContactDetailService additionalContactDetailService;

	@RequestMapping(value = "/createUpdateAdditionalContactDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates AdditionalContactDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateAdditionalContactDetail(
			@ApiParam(value = "AdditionalContactDetail object that needs to be added or update in the AdditionalContactDetail") @RequestBody AdditionalContactDetailDTO additionalContactDetailDTO) {
		return additionalContactDetailService.createUpdateAdditionalContactDetail(additionalContactDetailDTO);
	}

	@RequestMapping(value = "/getAllAdditionalContactDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find AdditionalContactDetail ", notes = "Returns a AdditionalContactDetail entity", response = AdditionalContactDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<AdditionalContactDetailDTO> getAllAdditionalContactDetail() {
		return additionalContactDetailService.getAllAdditionalContactDetail();
	}

	@RequestMapping(value = "/getAdditionalContactDetailByAdditionalContactDetailId/{additionalContactDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find AdditionalContactDetail By AdditionalContactDetail Id", notes = "Returns a AdditionalContactDetail entity when AdditionalContactDetail Id is passed", response = AdditionalContactDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid AdditionalContactDetail Id supplied"),
			@ApiResponse(code = 404, message = "AdditionalContactDetail not found") })
	public @ResponseBody AdditionalContactDetailDTO getAdditionalContactDetailByAdditionalContactDetailId(
			@ApiParam(value = "AdditionalContactDetail Id of the AdditionalContactDetail that needs to be fetched", required = true) @PathVariable("additionalContactDetailId") Long additionalContactDetailId) {
		return additionalContactDetailService
				.getAdditionalContactDetailByAdditionalContactDetailId(additionalContactDetailId);
	}

	@RequestMapping(value = "/deleteAdditionalContactDetailByAdditionalContactDetailId/{additionalContactDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete AdditionalContactDetail By AdditionalContactDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid AdditionalContactDetail Id value") })
	public @ResponseBody Boolean deleteAdditionalContactDetailByAdditionalContactDetailId(
			@ApiParam(value = "AdditionalContactDetail Id to delete", required = true) @PathVariable("additionalContactDetailId") Long additionalContactDetailId) {
		try {
			return additionalContactDetailService
					.deleteAdditionalContactDetailByAdditionalContactDetailId(additionalContactDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}