/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.listeners;

import java.util.Date;

import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants.BENCHMARK_STATE;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants.FUNCTION_ENABLED_FLAG;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants.FUNCTION_MILESTONE_FLAG;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.singetons.TaskSLAManager;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.context.SpringApplicationContext;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.BenchmarksDTO;
import net.atos.taskmgmt.common.dto.MatricesMasterDTO;
import net.atos.taskmgmt.common.dto.MilestonesDTO;
import net.atos.taskmgmt.service.ActorFunctionMasterService;
import net.atos.taskmgmt.service.BenchmarksService;
import net.atos.taskmgmt.service.MatricesMasterService;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.impl.el.FixedValue;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component
public class BenchmarkEventListener implements TaskListener, ExecutionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1668734390109L;

	private FixedValue benchmarkType;

	private FixedValue benchmarkName;

	/**
	 * @return the benchmarkType
	 */
	public FixedValue getBenchmarkType() {
		return benchmarkType;
	}

	/**
	 * @param benchmarkType
	 *            the benchmarkType to set
	 */
	public void setBenchmarkType(FixedValue benchmarkType) {
		this.benchmarkType = benchmarkType;
	}

	/**
	 * @return the benchmarkName
	 */
	public FixedValue getBenchmarkName() {
		return benchmarkName;
	}

	/**
	 * @param benchmarkName
	 *            the benchmarkName to set
	 */
	public void setBenchmarkName(FixedValue benchmarkName) {
		this.benchmarkName = benchmarkName;
	}

	/**
	 * Benchmark Service to insert into benchmark table
	 */
	private BenchmarksService benchmarkService;

	/**
	 * Milestone service to insert into milestone
	 */
	private MatricesMasterService matricesMasterService;

	/**
	 * Actor Function Master service to fetch details of the function from
	 */
	private ActorFunctionMasterService actorFunctionMasterService;

	/**
	 * Task SLA Manager
	 */
	private TaskSLAManager taskSLAManager;

	/**
	 * Unique Id Generator
	 */
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BenchmarkEventListener.class);

	private String logBenchmark(String functionCode, String processInstanceId, String assigned, String taskId,
			String tenantId, String executionId, String batchProcessId, String masterProcessId, String subProcessId,
			String refId, String taskPriority, String taskStaus, boolean checkForMilestone, String programId,
			Long parallelProcessThreadId) {
		// Insert into DB
		BenchmarksDTO benchmarksDTO = new BenchmarksDTO();

		ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();

		// Fetch function details
		actorFunctionMasterService = applicationContext.getBean(ActorFunctionMasterService.class);

		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);

		if (null != actorFunctionMasterDTO) {

			if (FUNCTION_ENABLED_FLAG.TRUE.getValue() == actorFunctionMasterDTO.getFunctionEnabled()) {

				benchmarksDTO.setBenchmarkName(actorFunctionMasterDTO.getFunctionName());

				benchmarksDTO.setBenchmarkState(MotorRepairConstants.BENCHMARK_STATE.valueOf(
						benchmarkType.getValue(null).toString()).getValue());

				benchmarksDTO.setProcessInstanceId(processInstanceId);

				// Set other params
				benchmarksDTO.setBatchProcessId(batchProcessId);
				benchmarksDTO.setActionByRefId(assigned);
				benchmarksDTO.setBenchmarkTimestamp(new Date());
				benchmarksDTO.setMastProcessId(masterProcessId);

				// TODO set proper SLA based on process variable
				benchmarksDTO.setSlaState(MotorRepairConstants.FUNCTION_SLA_STATE.IN_SLA.getValue());

				benchmarksDTO.setSubProcessId(subProcessId);
				benchmarksDTO.setSubReferenceId(refId);

				// set task_status, task_code, task_priority
				benchmarksDTO.setTaskCode(actorFunctionMasterDTO.getFunctionCode());
				benchmarksDTO.setTaskId(taskId);
				benchmarksDTO.setTaskPriority(taskPriority);
				benchmarksDTO.setTaskStaus(taskStaus);
				benchmarksDTO.setTenantId(tenantId);
				benchmarksDTO.setSolutionCategoryId(programId);
				// set parallel process Id
				benchmarksDTO.setParallelProcessId(parallelProcessThreadId);

				taskSLAManager = applicationContext.getBean(TaskSLAManager.class);
				uniqueIdGenerator = applicationContext.getBean(UniqueIdGenerator.class);

				// Manage SLAs here
				if (BENCHMARK_STATE.ASSIGNED.toString().equals(benchmarkType.getValue(null).toString())) {

					/**
					 * TTO Steps:<br>
					 * 1. Task is assigned to Group<br>
					 * 2. For this taskcode, fetch the SLA details from Function SLA & Escalation Hierarchy<br>
					 * 3. Start TTO timer for this task<br>
					 * 4. When the task is OWNED, this TTO Timer must be stopped.<br>
					 * 5. Also, TTO timer must be stopped, if this Task is Recalled, Rejected, Reclaimed by Workflow.
					 */

					// Create timer for TTO
					LOGGER.info("BENCHMARK_EVENT_LISTENER: Invoking TTO SLA Timer for executionId: " + executionId
							+ "; taskId: " + taskId + "; Function Code: " + functionCode);

					// TODO fetch this from SLA & Escalation configuration screen
					String schedulerId = taskSLAManager.triggerTTOScheduler(batchProcessId, masterProcessId, processInstanceId,
							MotorRepairConstants.SYSTEM_USER, subProcessId, functionCode, refId, 30, 1, taskId,
							taskPriority);

				} else if (BENCHMARK_STATE.OWNED.toString().equals(benchmarkType.getValue(null).toString())) {

					// Create timer for TTO
					LOGGER.info("BENCHMARK_EVENT_LISTENER: Invoking TTO SLA Timer for executionId: " + executionId
							+ "; taskId: " + taskId + "; Function Code: " + functionCode);
				}

				// Milestone is only acheived if the task has been completed successfully
				// remove checkmilestone
				if ((FUNCTION_MILESTONE_FLAG.TRUE.getValue() == actorFunctionMasterDTO.getIsMilestone())
						&& BENCHMARK_STATE.COMPLETED.toString().equals(benchmarkType.getValue(null).toString())) {

					// Fetch Matrices master to get Milestone name
					matricesMasterService = applicationContext.getBean(MatricesMasterService.class);

					MatricesMasterDTO matricesMasterDTO = matricesMasterService
							.getMatricesMasterByFunctionCode(functionCode);
					if(null != matricesMasterDTO) {
						// Use Matrices master's milestone
						MilestonesDTO milestonesDTO = new MilestonesDTO();
						// set batch process id
						milestonesDTO.setBatchProcessId(batchProcessId);
	
						// set master workflow process id
						milestonesDTO.setMastProcessId(masterProcessId);
	
						// set solution category id
						milestonesDTO.setSolutionCategoryId(programId);
						//
						milestonesDTO.setMilestoneName(matricesMasterDTO.getMatricesAliasName());
						milestonesDTO.setMilestoneTimeStamp(new Date());
						milestonesDTO.setProcessInstanceId(processInstanceId);
	
						// SET GSP Reference Id
						milestonesDTO.setReferenceId(refId);
						milestonesDTO.setSubProcessId(subProcessId);
						// SET Matrices reference Id
						milestonesDTO.setSubReferenceId(matricesMasterDTO.getMatricesId());
						milestonesDTO.setTaskId(taskId);
						milestonesDTO.setTenantId(tenantId);
						milestonesDTO.setTaskCode(actorFunctionMasterDTO.getFunctionCode());
						// set Parallel process id
						milestonesDTO.setParallelProcessId(parallelProcessThreadId);
						// Set Milestone if function is a milestone in case of Benchmark Type is COMPLETED
						benchmarksDTO.setMilestones(milestonesDTO);
					} else {
						LOGGER.warn("BENCHMARK_EVENT_LISTENER: Milestone matrices missing for function code: " + functionCode);
					}
				} else {
					if (LOGGER.isDebugEnabled())
						LOGGER.debug("BENCHMARK_EVENT_LISTENER: Either Function is not a milestone or Task is not completed for executionId: "
								+ executionId + "; checkForMilestone: " + checkForMilestone);
				}

				// Initialize benchmark service
				benchmarkService = applicationContext.getBean(BenchmarksService.class);
				// Insert into benchmark table
				String benchmarkId = benchmarkService.createUpdateBenchmarks(benchmarksDTO);
				if (null == benchmarkId) {
					LOGGER.warn("BENCHMARK_EVENT_LISTENER: Some error in setting benchmark for executionId: "
							+ executionId);
				}

				return benchmarkId;

			} else {
				LOGGER.warn("BENCHMARK_EVENT_LISTENER: Function for functionCode: " + functionCode
						+ " is disabled!! No benchmarks would be inserted");
			}
		} else {
			LOGGER.warn("BENCHMARK_EVENT_LISTENER: No Functions found for functionCode: " + functionCode);
		}
		return null;

	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.TaskListener#notify(org.activiti.engine. delegate.DelegateTask)
	 */

	@Override
	public void notify(DelegateTask delegateTask) {

		LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BENCHMARK_EVENT_LISTENER: START: TL: Executed for: " + delegateTask.getEventName() + "; "
				+ delegateTask.getName() + "; benchmarkName is " + benchmarkName.getValue(null).toString()
				+ "  & benchmark type is " + benchmarkType.getValue(null).toString() + "; executionId: "
				+ delegateTask.getExecutionId());

		Object functionCodeObj = delegateTask.getExecution().getVariable(ActivitiConstants.FUNCTION_CODE);

		// fetch function details for function code
		if (null != functionCodeObj) {

			String functionCode = functionCodeObj.toString();
			String assigned = null;
			if (null != delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO)) {
				delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO).toString();
			}
			if (null == assigned)
				assigned = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP).toString();

			String tenantId = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString();
			String programId = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID).toString();
			// TODO remove when testing is done
			if ((null != delegateTask.getVariable(ActivitiConstants.BATCH_PROCESS_ID))
					&& (null != delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID))
					&& (null != delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID))) {
				String batchProcessId = delegateTask.getVariable(ActivitiConstants.BATCH_PROCESS_ID).toString();
				String masterProcessId = delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID).toString();
				String subProcessId = delegateTask
						.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID).toString();

				String subReferenceId = delegateTask.getVariable(ActivitiConstants.GSP_REF_NO).toString();
				String taskPriority = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY).toString();

				// TODO SET taskStatus
				String taskStatus = null; // delegateTask.getVariable(ActivitiConstants.GSP_REF_NO).toString();

				// Milestone is acheived only if task has been completed and CHECK_ACCEPT = ACCEPTED // ${CHECK_ACCEPT==
				// "ACCEPT"}
				boolean checkForMilestone = false;
				// TO DO based upon value
				// commenting below code as we will check for milestone for actor function
				/*
				 * Object checkAcceptObj = delegateTask.getVariable(ActivitiConstants.CHECK_ACCEPT); if (checkAcceptObj
				 * != null) { checkForMilestone = MotorRepairConstants.CHECK_ACCEPT_STATE.ACCEPT.getValue().equals(
				 * checkAcceptObj.toString()); }
				 */
				Long parallelProcessThreadId = null;
				if (null != delegateTask.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID)) {
					parallelProcessThreadId = Long.parseLong(delegateTask.getVariable(
							ActivitiConstants.PARALLEL_PROCESS_THREAD_ID).toString());
				}
				// LOG BENCHMARK
				logBenchmark(functionCode, delegateTask.getProcessInstanceId(), assigned, delegateTask.getId(),
						tenantId, delegateTask.getExecutionId(), batchProcessId, masterProcessId, subProcessId,
						subReferenceId, taskPriority, taskStatus, checkForMilestone, programId, parallelProcessThreadId);
			}
		}
		LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BENCHMARK_EVENT_LISTENER: END: TL: Executed completed for: " + delegateTask.getEventName() + "; "
				+ delegateTask.getName() + "; executionId: " + delegateTask.getExecutionId());
	}

	@Override
	public void notify(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BENCHMARK_EVENT_LISTENER: START: EL: Executed for: " + execution.getEventName() + "; "
				+ execution.getCurrentActivityName() + "; benchmarkName is " + benchmarkName.getValue(null).toString()
				+ "  & benchmark type is " + benchmarkType.getValue(null).toString() + "; executionId: "
				+ execution.getId());

		Object functionCodeObj = execution.getVariable(ActivitiConstants.FUNCTION_CODE);

		// fetch function details for function code
		if (null != functionCodeObj) {

			String functionCode = functionCodeObj.toString();
			String assignedToStr = null;
			Object assigned = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO);
			if (null == assigned) {
				assignedToStr = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP).toString();
			} else {
				assignedToStr = assigned.toString();
			}

			String tenantId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString();
			String programId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID).toString();

			// TODO remove when testing is done
			if ((null != execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID))
					&& (null != execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID))
					&& (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID))) {
				String batchProcessId = execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID).toString();
				String masterProcessId = execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID).toString();
				String subProcessId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID)
						.toString();
				String subReferenceId = execution.getVariable(ActivitiConstants.GSP_REF_NO).toString();
				String taskPriority = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY).toString();

				// TODO SET taskStatus
				String taskStatus = null; // delegateTask.getVariable(ActivitiConstants.GSP_REF_NO).toString();
				Long parallelProcessThreadId = null;
				if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID)) {
					parallelProcessThreadId = Long.parseLong(execution.getVariable(
							ActivitiConstants.PARALLEL_PROCESS_THREAD_ID).toString());
				}
				// LOG BENCHMARK; Execution ASSUMPTION: Listeners are never milestones
				logBenchmark(functionCode, execution.getProcessInstanceId(), assignedToStr,
						execution.getCurrentActivityId(), tenantId, execution.getId(), batchProcessId, masterProcessId,
						subProcessId, subReferenceId, taskPriority, taskStatus, false, programId,
						parallelProcessThreadId);
			}
		}

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BENCHMARK_EVENT_LISTENER: END: EL: Executed completed for: " + execution.getEventName() + "; "
				+ execution.getCurrentActivityName() + "; executionId: " + execution.getId());
	}

}
