package net.atos.motorrepairmgmt.serviceImpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.atos.motorrepairmgmt.dto.RoleUserMapDTO;
import net.atos.motorrepairmgmt.repository.RoleUserMapRepository;
import net.atos.motorrepairmgmt.services.RoleUserMapService;

@Service
public class RoleUserMapServiceImpl implements RoleUserMapService {

	@Autowired
	private RoleUserMapRepository aRCUserMapRepository;
	
	@Override
	public RoleUserMapDTO getARCRefIdByUserName(String userName) {
		// TODO Auto-generated method stub
		//List<Long> Object=new ArrayList<Long>();
		RoleUserMapDTO roleUserMapDTO=new RoleUserMapDTO();
		Object[] objectArr=aRCUserMapRepository.getARCRefIdByUserName(userName);
		if(null != objectArr){
			if (null != objectArr[0]) {
				roleUserMapDTO.setReferenceId(Long.parseLong(objectArr[0].toString()));	
			}
			if (null != objectArr[1]) {
				roleUserMapDTO.setType(Integer.parseInt(objectArr[1].toString()));	
			}
		}
		return roleUserMapDTO;
	}

}
