package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.CReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;

/**
 * @author a610051
 * 
 */
public interface CReportFieldsService {

	CReportFieldsDTO createUpdateCReportFields(CReportFieldsDTO cReportFieldsDTO);

	Boolean deleteCReportFieldsByMotorCReportFieldId(Long motorCReportFieldId);

	List<CReportFieldsDTO> getAllCReportFields();

	MotorVoltageDetailDTO getVoltageDetailByCReportId(Long motorCReportFieldId);

	MotorNamePlateDetailDTO getNamePlateByCReportId(Long motorCReportFieldId);

	List<MotorSpeedDetailDTO> getSpeedDetailByCReportId(Long motorCReportFieldId);

	CReportFieldsDTO getCReportFieldsBySubProcessID(Long wlfwSubProcessId);

	Boolean addUpdateSpeedDetailToCReportFields(Long motorCReportFieldId,
			List<MotorSpeedDetailDTO> motorSpeedDetailDTOList);

	Boolean addUpdateMotorNamePlateDetailToCReportFields(Long motorCReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO);

	Boolean addUpdateMotorVoltageDetailToCReportFields(Long motorCReportFieldId,
			MotorVoltageDetailDTO motorVoltageDetailDTO);

	Long addUpdateSubProcessFieldsToCReportFields(Long motorCReportFieldId, SubProcessFieldsDTO subProcessFieldsDTO);

	CReportFieldsDTO getCReportFieldsByMotorCReportFieldId(Long motorCReportFieldId);
	
	CReportFieldsDTO getCReportFieldsApprovedStatusBySubprocessFieldId(Long wlfwSubProcessId);
	
}
