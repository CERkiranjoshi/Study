package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;
import net.atos.motorrepairmgmt.services.MotorOrderDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "motorOrderDetailService")
public class MotorOrderDetailController {

	@Autowired
	private MotorOrderDetailService motorOrderDetailService;

	@RequestMapping(value = "/createUpdateMotorOrderDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates MotorOrderDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMotorOrderDetail(
			@ApiParam(value = "MotorOrderDetail object that needs to be added or update in the MotorOrderDetail") @RequestBody MotorOrderDetailDTO orderDetailDTO) {
		return motorOrderDetailService.createUpdateMotorOrderDetail(orderDetailDTO);
	}

	@RequestMapping(value = "/getAllMotorOrderDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find Motor Order Detail ", notes = "Returns a MotorOrderDetail entity", response = MotorOrderDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<MotorOrderDetailDTO> getAllMotorOrderDetail() {
		return motorOrderDetailService.getAllMotorOrderDetail();
	}

	@RequestMapping(value = "/getMotorOrderDetailByMotorOrderDetailId/{motorOrderDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MotorOrderDetail By motorOrderDetail Id", notes = "Returns a MotorOrderDetail entity when MotorOrderDetail Id is passed", response = MotorOrderDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorOrderDetail Id supplied"),
			@ApiResponse(code = 404, message = "MotorOrderDetail not found") })
	public @ResponseBody MotorOrderDetailDTO getMotorOrderDetailByMotorOrderDetailId(
			@ApiParam(value = "motorOrderDetailId of the MotorOrderDetail that needs to be fetched", required = true) @PathVariable("motorOrderDetailId") Long motorOrderDetailId) {
		return motorOrderDetailService.getMotorOrderDetailByMotorOrderDetailId(motorOrderDetailId);
	}

	@RequestMapping(value = "/deleteMotorOrderDetailByMotorOrderDetailId/{motorOrderDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete MotorOrderDetail By motorOrderDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid motorOrderDetail Id value") })
	public @ResponseBody Boolean deleteMotorOrderDetailByMotorOrderDetailId(
			@ApiParam(value = "motorOrderDetailId to delete", required = true) @PathVariable("motorOrderDetailId") Long motorOrderDetailId) {
		try {
			return motorOrderDetailService.deleteMotorOrderDetailByMotorOrderDetailId(motorOrderDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}