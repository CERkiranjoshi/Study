package net.atos.motorrepairmgmt.services;

import java.util.List;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;

/**
 * @author a603981
 *
 */
public interface MotorNamePlateDetailService {

	public Long createUpdateMotorNamePlateDetail(MotorNamePlateDetailDTO motorNamePlateDetailDTO);

	public List<MotorNamePlateDetailDTO> getAllMotorNamePlateDetail();

	public MotorNamePlateDetailDTO getNamePlateByNamePlateId(Long motorNamePlateFieldsId);

	public Boolean deleteMotorNamePlateDetailByNamePlateFieldId(Long motorNamePlateFieldsId);
}
