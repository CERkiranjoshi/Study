/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author Sweety Kothari
 *
 */
@Component(value="preNotificationHandler")
public class PreNotificationHandler implements JavaDelegate{

	private static final Logger LOGGER = Logger.getLogger(PreNotificationHandler.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; START: PreNotificationHandler execute ");
		
	}

}
