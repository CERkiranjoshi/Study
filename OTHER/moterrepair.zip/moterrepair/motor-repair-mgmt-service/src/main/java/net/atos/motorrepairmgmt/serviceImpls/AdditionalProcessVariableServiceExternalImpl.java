package net.atos.motorrepairmgmt.serviceImpls;



import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.BReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.CReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.DReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSalesDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;
import net.atos.motorrepairmgmt.services.FSEVisitDetailService;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.dto.TaskProcessAttributesDTO;
import net.atos.motorrepairmgmt.entity.MotorSparesDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.entity.TaskProcessAttributes;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.services.BReportFieldsService;
import net.atos.motorrepairmgmt.services.CReportFieldsService;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.DReportFieldsService;
import net.atos.motorrepairmgmt.services.MotorSalesDetailService;
import net.atos.motorrepairmgmt.services.RegionMasterService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.TaskProcessAttributesService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.soclomo.common.dto.taskmgmt.TaskStatus;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.TaskAttributeLogsDTO;
import net.atos.taskmgmt.common.dto.TaskAuditDTO;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.service.AdditionalProcessVariableServiceExternal;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 * @author a585382
 * 
 */
@Component
public class AdditionalProcessVariableServiceExternalImpl implements AdditionalProcessVariableServiceExternal {

	private static final Logger LOGGER = Logger.getLogger(AdditionalProcessVariableServiceExternalImpl.class);
	
	@Autowired
	private DozerBeanMapper dozerBeanMapper;
	
	@Autowired
	private SubProcessFieldsService subProcessFieldsService;
	
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepo;
	
	@Autowired
	private BReportFieldsService  bReportFieldsService;
	
	@Autowired
	private CReportFieldsService  cReportFieldsService;
	
	@Autowired
	private DReportFieldsService  dReportFieldsService;
	
	@Autowired
	private ARCMasterService aRCMasterService;
	
	@Autowired
	private ConfigDetailService configDetailService;
	
	@Autowired
	private TaskProcessAttributesService taskProcessAttributesService;
	
	@Autowired
	private RegionMasterService regionMasterService;
	
	@Autowired
	private MotorSalesDetailService motorSalesDetailService;
	
	@Override
	@Transactional
	public Long saveAddtionalProccessVariables(TaskDetailsDTO taskDetailsDTO) throws Exception {
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : saveAddtionalProccessVariables : start"); 
	    Long procVarId=null;
	   try{
		   Long id=-1l;
		   String userName=null;
		  
		   String functionCode=taskDetailsDTO.getFunctionCode();
		   if(taskDetailsDTO.getAssignedTo() == null||taskDetailsDTO.getAssignedTo().equals("")){
			   userName=taskDetailsDTO.getCreatedBy();
		   }else{
			   userName=taskDetailsDTO.getAssignedTo();
		   }
		  
		  if( null != taskDetailsDTO.getSubprocessFieldDTO()){
			   taskDetailsDTO.getSubprocessFieldDTO().setModifiedByRefId(userName);
			   taskDetailsDTO.getSubprocessFieldDTO().setFunctionCode(functionCode);
			   if(null !=taskDetailsDTO.getSubprocessFieldDTO().getMotorDetailsDTOList() && taskDetailsDTO.getFromSuperAdmin()==0){
				   procVarId= subProcessFieldsService.saveMultipleSubProcessFields(taskDetailsDTO.getSubprocessFieldDTO());
			   }
			   else{
			   procVarId= subProcessFieldsService.createUpdateSubProcessFields(taskDetailsDTO.getSubprocessFieldDTO());
			   }
		  }
		    //check for B report ,if present then addBreport
		  if(null != taskDetailsDTO.getBreportFieldDTO()){
			  //check for BReportFieldId by SubProcessId ,if present then assign the same id to it 
			  BReportFieldsDTO bReportFieldDTO=bReportFieldsService.getBReportFieldsBySubProcessId(procVarId);
			  if(null !=bReportFieldDTO){
			  taskDetailsDTO.getBreportFieldDTO().setbReportFieldId(bReportFieldDTO.getbReportFieldId());
			  }
			  taskDetailsDTO.getBreportFieldDTO().setModifiedByRefId(userName);
			  taskDetailsDTO.getBreportFieldDTO().setFunctionCode(functionCode);
			  bReportFieldsService.createUpdateBReportFields(taskDetailsDTO.getBreportFieldDTO());
		  }
		  if(null != taskDetailsDTO.getCreportFieldDTO()){
			 
			  //check for CReportFieldId by SubProcessId ,if present then assign the same id to it 
			  CReportFieldsDTO cReportFieldDTO=cReportFieldsService.getCReportFieldsBySubProcessID(procVarId);
			  if(null !=cReportFieldDTO){
			  taskDetailsDTO.getCreportFieldDTO().setMotorCReportFieldId(cReportFieldDTO.getMotorCReportFieldId());
			  }
			  taskDetailsDTO.getCreportFieldDTO().setModifiedByRefId(userName);
			  taskDetailsDTO.getCreportFieldDTO().setFunctionCode(functionCode);
			  cReportFieldsService.createUpdateCReportFields(taskDetailsDTO.getCreportFieldDTO());
		  }
		  if(null !=taskDetailsDTO.getDreportFieldDTO()){
			  //check for DReportFieldId by SubProcessId ,if present then assign the same id to it 
			  DReportFieldsDTO dReportFieldDTO=dReportFieldsService.getDReportFieldsBySubProcessID(procVarId);
			  if(null !=dReportFieldDTO){
			  taskDetailsDTO.getDreportFieldDTO().setMotorDReportFieldId(dReportFieldDTO.getMotorDReportFieldId());
			  }
			  taskDetailsDTO.getDreportFieldDTO().setModifiedByRefId(userName);
			  taskDetailsDTO.getDreportFieldDTO().setFunctionCode(functionCode);
			  dReportFieldsService.createUpdateDReportFields(taskDetailsDTO.getDreportFieldDTO());
		  }
		  
		  
		} catch (Exception e) {
			LOGGER.info("AdditionalProcessVariableServiceExternalImpl : saveAddtionalProccessVariables : exception : " + e.getMessage());
			throw e;
		}
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : saveAddtionalProccessVariables : end");
		return procVarId;
	}
	
	@Override
	@Transactional
	public void getAddtionalProcessVariables(Long processVariableId, TaskDetailsDTO taskDetailsDTO) {
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : getAddtionalProcessVariables : start");
		
		try {
			if(processVariableId != null) {
				if(taskDetailsDTO == null) {
					taskDetailsDTO = new TaskDetailsDTO();
				}
				//for register a service call fetch subProcess with MotorDetailDTO list
				SubProcessFieldsDTO subprocessFieldDTO=null;
				if(null != taskDetailsDTO.getFunctionCode() && (taskDetailsDTO.getFunctionCode().equals(MotorRepairConstants.CCC_NEW_SERVICE_FOR_MOTOR)|| taskDetailsDTO.getFunctionCode().equals(MotorRepairConstants.CCC_NEW_SERVICE_REC_MOTOR)) && taskDetailsDTO.getFromSuperAdmin()==0){
					 subprocessFieldDTO=subProcessFieldsService.getSubprocessFieldWithMotorDetailsByMasterworkflowId(processVariableId);
				}
				else{
					 subprocessFieldDTO=subProcessFieldsService.getSubProcessFieldsByWlfwSubProcessId(processVariableId);
				}
              taskDetailsDTO.setSubprocessFieldDTO(subprocessFieldDTO);
              //fetch B report 
              BReportFieldsDTO bReportFieldsDTO=bReportFieldsService.getBReportFieldsApprovedStatusBySubprocessFieldId(processVariableId);
              if(null !=bReportFieldsDTO){
            	  taskDetailsDTO.setBreportFieldDTO(bReportFieldsDTO); 
              }
              //fetch C report
              CReportFieldsDTO cReportFieldsDTO=cReportFieldsService.getCReportFieldsApprovedStatusBySubprocessFieldId(processVariableId);
              if(null !=cReportFieldsDTO){
            	  taskDetailsDTO.setCreportFieldDTO(cReportFieldsDTO); 
              }
              //fetch D report
              DReportFieldsDTO dReportFieldsDTO=dReportFieldsService.getDReportFieldsApprovedStatusBySubProcessID(processVariableId);
              if(null !=dReportFieldsDTO){
            	  taskDetailsDTO.setDreportFieldDTO(dReportFieldsDTO); 
              }
			}
		} catch (Exception e) {
			LOGGER.info("AdditionalProcessVariableServiceExternalImpl : getAddtionalProcessVariables : exception : " + e.getMessage());
			e.printStackTrace();
		}
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : getAddtionalProcessVariables : end");
	}

	

	@Override
	@Transactional
	public void deleteProcessVariables(Long processVariableId) {
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : deleteProcessVariables : start");
		try {
			if(processVariableId != null) {
				subProcessFieldsService.deleteSubProcessFieldsByWlfwSubProcessId(processVariableId);
			}
		} catch (Exception e) {
			LOGGER.info("AdditionalProcessVariableServiceExternalImpl : deleteProcessVariables : exception : " + e.getMessage());
			e.printStackTrace();
		}
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : deleteProcessVariables : end");
	}

	@Override
	public TaskAuditDTO auditTaskDetailsDTO(TaskDetailsDTO oldTaskDetailsDTO,
			TaskDetailsDTO newTaskDetailsDTO) {
		// TODO Auto-generated method stub
		TaskAuditDTO taskAuditDTO= new TaskAuditDTO();
		taskAuditDTO.setProcessInstanceId(newTaskDetailsDTO.getProcessInstanceId());
		taskAuditDTO.setTaskId(newTaskDetailsDTO.getTaskId());
		taskAuditDTO.setUpdateBy(newTaskDetailsDTO.getAssignedTo());
		List<TaskAttributeLogsDTO> taskAttributeLogsList= new ArrayList<TaskAttributeLogsDTO>();
		findFieldChanges(taskAttributeLogsList,oldTaskDetailsDTO.getSubprocessFieldDTO(),newTaskDetailsDTO.getSubprocessFieldDTO());
		taskAuditDTO.setTaskAttributeLogsList(taskAttributeLogsList);
		return taskAuditDTO;
	}

	@Override
	public void updateProcessInstaceId(Long processVariableId, String processInstanceId) {
		// TODO Auto-generated method stub
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : updateProcessInstaceId : "+processInstanceId+" variable id "+processVariableId);
		try {
			if((processVariableId != null) && (StringUtils.isNotBlank(processInstanceId))) {
				SubProcessFields subProcessFields = subProcessFieldsRepo.findOne(processVariableId);
				if(subProcessFields != null) {
					subProcessFields.setProcessInstanceId(processInstanceId);
					subProcessFieldsRepo.save(subProcessFields);
				}
			}
		} catch (Exception e) {
			LOGGER.info("AdditionalProcessVariableServiceExternalImpl : updateProcessInstaceId : exception : " + e.getMessage());
			e.printStackTrace();
		}
		LOGGER.info("AdditionalProcessVariableServiceExternalImpl : updateProcessInstaceId : end");
	}
	
	public static void findFieldChanges(List<TaskAttributeLogsDTO> attributeLogList, SubProcessFieldsDTO oldSubProcessFieldDTO,
			SubProcessFieldsDTO newSubProcessFieldDTO) {
		// ARC Code
		if (!StringUtils.equals(newSubProcessFieldDTO.getArcCode(), oldSubProcessFieldDTO.getArcCode())) {
			addToAttributeList(attributeLogList, "ARC CODE", oldSubProcessFieldDTO.getArcCode(),
					newSubProcessFieldDTO.getArcCode());
		}
	}
	public static void addToAttributeList(List<TaskAttributeLogsDTO> attributeLogList, String attributeName,
			String oldValue, String newValue) {
		TaskAttributeLogsDTO attributeLog = new TaskAttributeLogsDTO();
		attributeLog.setAttributeName(attributeName);
		if (oldValue != null) {
			attributeLog.setOldValue(oldValue);
		} else {
			attributeLog.setOldValue("");
		}
		if (newValue != null) {
			attributeLog.setNewValue(newValue);
		} else {
			attributeLog.setNewValue("");
		}
		attributeLogList.add(attributeLog);

	}
	
	public TaskDetailsDTO setFieldsInTaskDetailDTO(
			TaskDetailsDTO taskDetailsDTO) {
		// TODO Auto-generated method stub
		if (null != taskDetailsDTO.getSubprocessFieldDTO().getFrameSize()) {
			taskDetailsDTO.setFrameSize(taskDetailsDTO.getSubprocessFieldDTO()
					.getFrameSize());
		}
		if (null != taskDetailsDTO.getSubprocessFieldDTO()
				.getArcMotorReceivedState()) {
			taskDetailsDTO.setMotorReceivedState(taskDetailsDTO
					.getSubprocessFieldDTO().getArcMotorReceivedState());
		}
		if(null !=taskDetailsDTO.getSubprocessFieldDTO()
				.getMotorSnNum()){
		taskDetailsDTO.setMotorSnNum(taskDetailsDTO.getSubprocessFieldDTO()
				.getMotorSnNum());
		}
		if(null !=taskDetailsDTO.getSubprocessFieldDTO()
				.getMlfbSpiridon()){
		taskDetailsDTO.setMlfbSpiridon(taskDetailsDTO.getSubprocessFieldDTO()
				.getMlfbSpiridon());
		}
		if(null !=taskDetailsDTO.getSubprocessFieldDTO()
				.getSubjectTitle()){
		taskDetailsDTO.setSubTitle(taskDetailsDTO.getSubprocessFieldDTO()
				.getSubjectTitle());
		}
		if(null !=taskDetailsDTO.getSubprocessFieldDTO()
				.getMasterWorkflowFields()){
			if(null != taskDetailsDTO.getSubprocessFieldDTO()
				.getMasterWorkflowFields().getGspRefNo()){
		       taskDetailsDTO.setGspRefNo(taskDetailsDTO.getSubprocessFieldDTO()
				.getMasterWorkflowFields().getGspRefNo());
			}
			//set customer detail base on customer type value 
			List<CustomerDetailDTO> customerDetailList=taskDetailsDTO.getSubprocessFieldDTO().getMasterWorkflowFields().getCustomerDetails();
			if(null != customerDetailList)
			{
				String custName=getCustomerNameFromList(customerDetailList);
				taskDetailsDTO.setCustName(custName);
			}
			
			//set master batch process Id 
			taskDetailsDTO.setMasterBatchProcId(taskDetailsDTO.getSubprocessFieldDTO().getMasterWorkflowFields().getBatchProcessId());
		
		}
		if (null == taskDetailsDTO.getCreatedDate()) {
			taskDetailsDTO.setCreatedDate(new Date());
		}
		if (null == taskDetailsDTO.getActualStartDate()) {
			taskDetailsDTO.setActualStartDate(new Date());
		}
		if (null == taskDetailsDTO.getStatus()) {
			taskDetailsDTO.setStatus(TaskStatus.New.toString());
		}
		if (null != taskDetailsDTO.getSubprocessFieldDTO().getSubWarrantyType()) {
			taskDetailsDTO
					.setSubWarrantyType(MotorRepairConstants.WARRANTY_SUB_TYPE
							.of(taskDetailsDTO.getSubprocessFieldDTO()
									.getSubWarrantyType()).toString());
		}
		if (null != taskDetailsDTO.getSubprocessFieldDTO()
				.getFinalWarrantyState()) {
			taskDetailsDTO
					.setFinalWarrantyState(MotorRepairConstants.WARRANTY_TYPE
							.of(taskDetailsDTO.getSubprocessFieldDTO()
									.getFinalWarrantyState()).toString());
		}
		if (null != taskDetailsDTO.getSubprocessFieldDTO()
				.getInitialWarrantyClaim()) {
			taskDetailsDTO
					.setInitWarrantyState(MotorRepairConstants.WARRANTY_TYPE
							.of(taskDetailsDTO.getSubprocessFieldDTO()
									.getInitialWarrantyClaim()).toString());
		}
		// convert subprocessId ,master process Id ,batch process Id from Long
		// to String
		if (null != taskDetailsDTO.getSubprocessFieldDTO()
				.getWlfwSubProcessId()) {
			taskDetailsDTO.setSubProcessId(taskDetailsDTO
					.getSubprocessFieldDTO().getWlfwSubProcessId().toString());
		}
		
		if (null!=taskDetailsDTO.getSubprocessFieldDTO().getMasterWorkflowFields() && null != taskDetailsDTO.getSubprocessFieldDTO()
				.getMasterWorkflowFields() && null != taskDetailsDTO.getSubprocessFieldDTO()
				.getMasterWorkflowFields().getMasterWorkflowFieldId()) {
			taskDetailsDTO.setMasterProcessId(taskDetailsDTO
					.getSubprocessFieldDTO().getMasterWorkflowFields()
					.getMasterWorkflowFieldId().toString());
		}
		if (null != taskDetailsDTO.getSubprocessFieldDTO().getBatchProcId()) {
			taskDetailsDTO.setBatchProcessId(taskDetailsDTO
					.getSubprocessFieldDTO().getBatchProcId());
		}
		//set checkapproval status based on breport approval status
		//at a time only one B report ,C Report or D report will be passed from UI
		if(null !=taskDetailsDTO.getBreportFieldDTO() && null !=taskDetailsDTO.getBreportFieldDTO().getApprovalStatus()){
			taskDetailsDTO.setCheckApproval(MotorRepairConstants.REPORT_STATUS.of(taskDetailsDTO.getBreportFieldDTO().getApprovalStatus()).toString());
		}
		if(null !=taskDetailsDTO.getCreportFieldDTO() && null !=taskDetailsDTO.getCreportFieldDTO().getApprovalStatus()){
			taskDetailsDTO.setCheckApproval(MotorRepairConstants.REPORT_STATUS.of(taskDetailsDTO.getCreportFieldDTO().getApprovalStatus()).toString());
		}
		// set A report status
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getaReportApproval()){
			taskDetailsDTO.setCheckApproval(MotorRepairConstants.REPORT_STATUS.of(taskDetailsDTO.getSubprocessFieldDTO().getaReportApproval()).toString());
		}
	
		//set closure type in taskDetailDTO 
        if(null !=taskDetailsDTO.getSubprocessFieldDTO().getWorkflowClosureType()){
        taskDetailsDTO.setCheckClosure(MotorRepairConstants.SUBPROCESS_STATE.of(taskDetailsDTO.getSubprocessFieldDTO().getWorkflowClosureType()).toString());
        }
        
  



       //set task priority to medium 
		if(null ==taskDetailsDTO.getPriority()){
			taskDetailsDTO.setPriority(MotorRepairConstants.TASK_PRIORITY.MEDIUM.getValue());
		}
		
		// if arcRefId is not null && taskDetailSTO.arcName is null then set
			if(!(taskDetailsDTO.getFunctionCode().equals(MotorRepairConstants.ARC_DISPATCH_MOTOR)) && (taskDetailsDTO.getDispatchMotorToParas()==0)){
				if (null != taskDetailsDTO.getSubprocessFieldDTO().getArcRefId()) {
					// fetch ARCMaster by ARCRefId
					ARCMasterDTO arcMasterDTO = aRCMasterService.getARCMasterByArcId(taskDetailsDTO.getSubprocessFieldDTO()
							.getArcRefId());
					taskDetailsDTO.setArcName(arcMasterDTO.getArcName());
					//VALUE FOR ARC_REFID IS HANDLED DIFFERENTLY INCASE OF PARAS ARC ,IT IS NOT REQUIRED TO SET THIS FROM SUBPROCESS FIELD DTO FOR PARAS
					taskDetailsDTO.setArcRefId(Long.toString(taskDetailsDTO.getSubprocessFieldDTO().getArcRefId()));
					taskDetailsDTO.setArcType(arcMasterDTO.getArcType());
				}
		}
		
		//check dispatch motor to PARAS parameter is set 
//		if(taskDetailsDTO.getDispatchMotorToParas()==1)
//		{
//			//fetch ARC Ref id whose ARC type=3 & then set all above parameter
//			ARCMasterDTO arcMasterDTO = aRCMasterService.getARCMasterByArcId(taskDetailsDTO.getSubprocessFieldDTO()
//					.getArcRefId());
//			taskDetailsDTO.setArcName(arcMasterDTO.getArcName());
//			taskDetailsDTO.setArcRefId(Long.toString(taskDetailsDTO.getSubprocessFieldDTO().getArcRefId()));
//			taskDetailsDTO.setArcType(arcMasterDTO.getArcType());
//		}
//		
	    //check customer feedback value in subProcessFieldDTO
		taskDetailsDTO.setCheckFeedback(taskDetailsDTO.getSubprocessFieldDTO().getCustFeedback());
		
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getfSEVisitDetails() && taskDetailsDTO.getSubprocessFieldDTO().getfSEVisitDetails().size()>0)
		{
			//visit completed flag =0 get that visit type
			for(FSEVisitDetailDTO fseVisitDetailDTO:taskDetailsDTO.getSubprocessFieldDTO().getfSEVisitDetails()){
				if(fseVisitDetailDTO.getVisitStatus()==null ||(fseVisitDetailDTO.getVisitStatus()!=null && fseVisitDetailDTO.getVisitStatus()==0)){
					taskDetailsDTO.setCheckFSVisit(fseVisitDetailDTO.getFseVisitType());
					break;
				}
			}
		}
		//set check quote to accept 
		taskDetailsDTO.setCheckQuoteAccept(taskDetailsDTO.getSubprocessFieldDTO().getQuotationAcceptance());
		//set TS support decision in taskDetailDTO ,>0 check to avoid default value
		if(taskDetailsDTO.getSubprocessFieldDTO().getTsSupportDecision()>0){
			taskDetailsDTO.setCheckTSDecision(MotorRepairConstants.TS_SUPPORT_DECISION.of(taskDetailsDTO.getSubprocessFieldDTO().getTsSupportDecision()).name());
		}
		else{
			//check for existing taskDetailDTO value ,if it is 0 ,else carry the same
			if(null==taskDetailsDTO.getCheckTSDecision()){
				//previously not set
				taskDetailsDTO.setCheckTSDecision(MotorRepairConstants.TS_SUPPORT_DECISION.DEFAULT.name());
			}
		}
		//set region name
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getRegionId() && null != taskDetailsDTO.getSubprocessFieldDTO().getSalesOfficeRefId()){
			Long regionId=Long.parseLong(taskDetailsDTO.getSubprocessFieldDTO().getRegionId());
			//fetch region name based on Id from region master
		
		    MotorSalesDetailDTO motorSalesDetailDTO=motorSalesDetailService.getMotorSalesDetailByMotorSalesDetailId(Long.parseLong(taskDetailsDTO.getSubprocessFieldDTO().getSalesOfficeRefId()));
			RegionMasterDTO regionMasterDTO=regionMasterService.getRegionMasterByRegionIdAndTenantIdAndSolCatId(regionId, MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
			if(null !=regionMasterDTO && null !=motorSalesDetailDTO){
				taskDetailsDTO.setSalesOfficeNRegionName(motorSalesDetailDTO.getName()+ActivitiConstants.COMMA+regionMasterDTO.getRegionName());
			}
		}
		//set job closed & visit in TaskDetailDTO
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getIsJobCompleted() ){
			taskDetailsDTO.setCheckFSVisited(taskDetailsDTO.getSubprocessFieldDTO().getIsJobCompleted() );
		}
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getIsJobClosed() ){
			taskDetailsDTO.setCheckFSJobCompleted(taskDetailsDTO.getSubprocessFieldDTO().getIsJobClosed() );
		}
		//set cts approval state
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getIsCts()){
			taskDetailsDTO.setIsCTSApproved(taskDetailsDTO.getSubprocessFieldDTO().getIsCts());
		}
		
		//set spares lsit size based on spares 
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getMotorSparesDetails() ){
			if(taskDetailsDTO.getSubprocessFieldDTO().getMotorSparesDetails().size()>0){
			taskDetailsDTO.setCheckSparesListSize(taskDetailsDTO.getSubprocessFieldDTO().getMotorSparesDetails().size());
		}
		else{//set to 0
			taskDetailsDTO.setCheckSparesListSize(0);
			}
		}
		//set spare dispatch road permit reqd
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getSparesDispatchRpReq()){
			taskDetailsDTO.setCheckSpareRoadPermitReq(taskDetailsDTO.getSubprocessFieldDTO().getSparesDispatchRpReq());
		}
		//set motor dispatch road permit reqd
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getMotorDispatchRoadPermitReq()){
			taskDetailsDTO.setCheckMotorRoadPermitReq(taskDetailsDTO.getSubprocessFieldDTO().getMotorDispatchRoadPermitReq());
		}
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getReplacement_status()){
	    	taskDetailsDTO.setReplacementStatus(taskDetailsDTO.getSubprocessFieldDTO().getReplacement_status());
	    }
		if(null != taskDetailsDTO.getSubprocessFieldDTO().getRepairStatus()){
	    	taskDetailsDTO.setRepairStatus(taskDetailsDTO.getSubprocessFieldDTO().getRepairStatus());
	    }
		return taskDetailsDTO;
		
	}

	private String getCustomerNameFromList(List<CustomerDetailDTO> customerDetailList){
		String custName=null;
		if(null !=customerDetailList)
		{
			//fetch record whose customer type =1 ,which is end customer
			for(CustomerDetailDTO custDetailDTO:customerDetailList){
				if(custDetailDTO.getCustType().equals(MotorRepairConstants.CUST_TYPE.END_CUSTOMER.getValue())){
					custName=custDetailDTO.getCustomerName();
					if(null != custName) {
					break;
					}
				}
				else if (custDetailDTO.getCustType().equals(MotorRepairConstants.CUST_TYPE.CHANNEL_PARTNER.getValue()) ){
					custName=custDetailDTO.getCustomerName();
					if(null != custName) {
						break;
						}
				}
				else if (custDetailDTO.getCustType().equals(MotorRepairConstants.CUST_TYPE.DEALER_DETAIL.getValue()) ){
					custName=custDetailDTO.getCustomerName();
					if(null != custName) {
						break;
						}
				}
				else
				{
					custName=custDetailDTO.getCustomerName();
					break;
				}
			}
		}
		return custName;
	}
	
	// set any additional process variable in map if needed
	@Override
	public Map<String, Object> setProcVariables(TaskDetailsDTO taskDetailsDTO) {
		
		
		// begin :motor repair mgmt related variables
		Map<String, Object> procVariables = new HashMap<String, Object>();
		// take config frame size from DB
		List<ConfigDetailDTO> configDetailDTOList = configDetailService.findEnabledNVisibleConfigDetailsByTypeNSubType(
				MotorRepairConstants.FRAME_SIZE_LIMIT, MotorRepairConstants.FRAME_SIZE_1, MotorRepairConstants.TENANT_ID,
				MotorRepairConstants.PROGRAM_ID);
		if (null != configDetailDTOList && configDetailDTOList.size() > 0) {
			procVariables.put(ActivitiConstants.CONFIG_FRAME_SIZE_1, configDetailDTOList.get(0).getConfigIntVal());
		}
		// take config PARAS ARC TYPE from DB
		configDetailDTOList = configDetailService.findEnabledNVisibleConfigDetailsByTypeNSubType(
				MotorRepairConstants.SYSTEM_CONFIG, MotorRepairConstants.PARAS_ARC_TYPE, MotorRepairConstants.TENANT_ID,
				MotorRepairConstants.PROGRAM_ID);
		int parasARCType = 0;
		if (null != configDetailDTOList && configDetailDTOList.size() > 0) {
			parasARCType=configDetailDTOList.get(0).getConfigIntVal();
			procVariables.put(ActivitiConstants.CONFIG_PARAS_ARC_TYPE, parasARCType);
		}
		procVariables.put(ActivitiConstants.FRAME_SIZE, taskDetailsDTO.getFrameSize());
		procVariables.put(ActivitiConstants.REASSIGN, taskDetailsDTO.getReassign());
		procVariables.put(ActivitiConstants.IS_MOTOR_RECV, taskDetailsDTO.getMotorReceivedState());
		procVariables.put(ActivitiConstants.FROM_SUPER_ADMIN, taskDetailsDTO.getFromSuperAdmin());
		procVariables.put(ActivitiConstants.INIT_WARRANRTY, taskDetailsDTO.getInitWarrantyState());
		procVariables.put(ActivitiConstants.TASK_BENCHMARK_NAME, taskDetailsDTO.getTaskBenchmarkName());
		procVariables.put(ActivitiConstants.TASK_BENCHMARK_TYPE, taskDetailsDTO.getTaskBenchmarkType());
		procVariables.put(ActivitiConstants.CHECK_ACCEPT, taskDetailsDTO.getCheckAccept());
		procVariables.put(ActivitiConstants.CHECK_CLOSURE, taskDetailsDTO.getCheckClosure());
		procVariables.put(ActivitiConstants.CHECK_PROCEED, taskDetailsDTO.getCheckProceed());
		procVariables.put(ActivitiConstants.NOTIFY, taskDetailsDTO.getNotify());
		procVariables.put(ActivitiConstants.CHECK_REVIEW_REQ, taskDetailsDTO.getCheckReviewReq());

		procVariables.put(ActivitiConstants.CHECK_WARRANTY, taskDetailsDTO.getFinalWarrantyState());
		procVariables.put(ActivitiConstants.CHECK_APPROVAL, taskDetailsDTO.getCheckApproval());
		procVariables.put(ActivitiConstants.MLFB_SPIRIDON_CODE, taskDetailsDTO.getMlfbSpiridon());
		procVariables.put(ActivitiConstants.GSP_REF_NO, taskDetailsDTO.getGspRefNo());
		procVariables.put(ActivitiConstants.MOTOR_SN_NO, taskDetailsDTO.getMotorSnNum());
		procVariables.put(ActivitiConstants.FUNCTION_CODE, taskDetailsDTO.getFunctionCode());
		procVariables.put(ActivitiConstants.FUNCTION_NAME, taskDetailsDTO.getFunctionName());
		procVariables.put(ActivitiConstants.PREV_FUNCTION_CODE, taskDetailsDTO.getPrevFunctionCode());
		// set subProcessId
		procVariables.put(ActivitiConstants.SUB_PROCESS_ID, taskDetailsDTO.getSubProcessId());
		procVariables.put(ActivitiConstants.PARALLEL_PROCESS_ID, taskDetailsDTO.getParallelProcessId());
		procVariables.put(ActivitiConstants.BATCH_PROCESS_ID, taskDetailsDTO.getBatchProcessId());
		procVariables.put(ActivitiConstants.MASTER_PROCESS_ID, taskDetailsDTO.getMasterProcessId());
		procVariables.put(ActivitiConstants.CHECK_WARRANTY_SUB_TYPE, taskDetailsDTO.getSubWarrantyType());
       
		procVariables.put(ActivitiConstants.CHECK_FEEDBACK, taskDetailsDTO.getCheckFeedback());

		procVariables.put(ActivitiConstants.CHECK_WORKFLOW_STATUS, taskDetailsDTO.getCheckWorkflowStatus());
		procVariables.put(ActivitiConstants.CHECK_FS_ASSIGNED, taskDetailsDTO.getCheckFSAssigned());
	//	procVariables.put(ActivitiConstants.CHECK_FS_VISITED, taskDetailsDTO.getCheckFSVisited());
		procVariables.put(ActivitiConstants.CHECK_FS_VISIT, taskDetailsDTO.getCheckFSVisit());
		//check only spares variable set same as TsSupportDecision
		if(null != taskDetailsDTO.getCheckTSDecision()) {
			if(taskDetailsDTO.getCheckTSDecision().equals(MotorRepairConstants.TS_SUPPORT_DECISION.DISPATCH_ONLY_SPARES.toString())){
				procVariables.put(ActivitiConstants.CHECK_ONLY_SPARES,MotorRepairConstants.TRUE);
			}
			else if(taskDetailsDTO.getCheckTSDecision().equals(MotorRepairConstants.TS_SUPPORT_DECISION.FS_VISIT_WITH_SPARES.toString())){
				procVariables.put(ActivitiConstants.CHECK_ONLY_SPARES,MotorRepairConstants.TS_SUPPORT_DECISION.FS_VISIT_WITH_SPARES.getValue());
              }
			else{
				procVariables.put(ActivitiConstants.CHECK_ONLY_SPARES,MotorRepairConstants.FALSE);
			}
		}
		//check if it was FS & then visit with spares
		if(taskDetailsDTO.getCheckFSVisit()== MotorRepairConstants.FS_VISIT_TYPE.FS_VISIT_WITH_SPARES.getValue()){
			procVariables.put(ActivitiConstants.CHECK_ONLY_SPARES,MotorRepairConstants.TS_SUPPORT_DECISION.FS_VISIT_WITH_SPARES.getValue());
		}
		procVariables.put(ActivitiConstants.CHECK_TS_DECISION, taskDetailsDTO.getCheckTSDecision());

		procVariables.put(ActivitiConstants.CHECK_SPARE_LIST_SIZE, taskDetailsDTO.getCheckSparesListSize());
		procVariables.put(ActivitiConstants.CHECK_FS_JOB_COMPLETED, taskDetailsDTO.getCheckFSJobCompleted());
		// set customer name
		procVariables.put(ActivitiConstants.CUST_NAME, taskDetailsDTO.getCustName());
		if(null!=taskDetailsDTO.getSubTitle()){
		procVariables.put(ActivitiConstants.SUB_TITLE, taskDetailsDTO.getSubTitle());}
		procVariables.put(ActivitiConstants.MASTER_BATCH_PROCESS_ID, taskDetailsDTO.getMasterBatchProcId());
		procVariables.put(ActivitiConstants.ARC_NAME, taskDetailsDTO.getArcName());
		procVariables.put(ActivitiConstants.ARC_REF_ID, taskDetailsDTO.getArcRefId());
		procVariables.put(ActivitiConstants.ARC_TYPE, taskDetailsDTO.getArcType());
		procVariables.put(ActivitiConstants.CHECK_CLOSURE, taskDetailsDTO.getCheckClosure());
		//set reassign function codeCHEC
		procVariables.put(ActivitiConstants.REASSIGN_FUNCTION_CODE,taskDetailsDTO.getReassignFunctionCode());
		procVariables.put(ActivitiConstants.CHECK_FS_VISIT_WITH_SPARES, taskDetailsDTO.getCheckFSVisit());
		procVariables.put(ActivitiConstants.PARALLEL_PROCESS_TYPE, taskDetailsDTO.getParallelProcessType());
        //set dispatch motor to PARAS
		procVariables.put(ActivitiConstants.DISPATCH_TO_PARAS, taskDetailsDTO.getDispatchMotorToParas());
		//set check quote 
		procVariables.put(ActivitiConstants.CHECK_QUOTE_ACCEPT,taskDetailsDTO.getCheckQuoteAccept());
		//VALUE FOR ARC_REFID IS HANDLED DIFFERENTLY INCASE OF PARAS ARC ,IT IS NOT REQUIRED TO SET THIS FROM SUBPROCESS FIELD DTO FOR PARAS
				
//		int arcType=taskDetailsDTO.getArcType();
//			if (arcType == parasARCType) {
//				procVariables.put(ActivitiConstants.CHECK_SENT_TO_PARAS, 1);
//			} else {
//				procVariables.put(ActivitiConstants.CHECK_SENT_TO_PARAS, 0);
//			}
		if(null!=taskDetailsDTO.getSalesOfficeNRegionName()){	
		procVariables.put(ActivitiConstants.SALES_OFFICE_N_REGION_NAME, taskDetailsDTO.getSalesOfficeNRegionName());}
		procVariables.put(ActivitiConstants.CHECK_FS_VISITED, taskDetailsDTO.getCheckFSVisited());
		procVariables.put(ActivitiConstants.CHECK_FS_JOB_COMPLETED, taskDetailsDTO.getCheckFSJobCompleted());
		//set isCTS approved 
		procVariables.put(ActivitiConstants.CHECK_CTS_STATE,taskDetailsDTO.getIsCTSApproved());
		//customer call TS ref req
		procVariables.put(ActivitiConstants.CHECK_TS_REF_REQ,taskDetailsDTO.getCheckTSRefReq());
		procVariables.put(ActivitiConstants.CHECK_SENT_TO_PARAS,taskDetailsDTO.getCheckSentToParas());
		//set closure refer toTS
		if(null !=taskDetailsDTO.getSubprocessFieldDTO().getReferToTS() ){
			procVariables.put(ActivitiConstants.CLOSURE_REF_TO_TS,taskDetailsDTO.getSubprocessFieldDTO().getReferToTS());
        }
		else{
			procVariables.put(ActivitiConstants.CLOSURE_REF_TO_TS,0);
		}
		procVariables.put(ActivitiConstants.CHECK_REPLACEMENT_APPROVAL,taskDetailsDTO.getReplacementStatus());
		procVariables.put(ActivitiConstants.CHECK_FS_LINK_ORDER_CREATED , taskDetailsDTO.getCheckFSLinkOrderCreated());	
		procVariables.put(ActivitiConstants.REPAIR_STATUS , taskDetailsDTO.getRepairStatus());	
		//set wait for spares in procVariable
		procVariables.put(ActivitiConstants.WAIT_FOR_SPARES , taskDetailsDTO.getWaitForSpares());	
		//set ship to party flag
		procVariables.put(ActivitiConstants.SPARES_SHIP_TO_PARTY , taskDetailsDTO.getSpareShipToParty());	
		//set APPROVERS_DECISION
		procVariables.put(ActivitiConstants.APPROVERS_DECISION , taskDetailsDTO.getApprovalStatus());	
		//set spare road permit reqd variable
		procVariables.put(ActivitiConstants.CHECK_SPARE_ROAD_PERMIT_REQ , taskDetailsDTO.getCheckSpareRoadPermitReq());
        //set motor road permit reqd
		procVariables.put(ActivitiConstants.CHECK_MOTOR_ROAD_PERMIT_REQ , taskDetailsDTO.getCheckMotorRoadPermitReq());
		LOGGER.info("Process Variable Map "+procVariables.toString());
		return procVariables;
	}
	
	public Long saveTaskProcessAttributes(TaskDetailsDTO taskDetailsDTO) {
		TaskProcessAttributesDTO taskProcessAttributesDTO=mapTaskDetailDTOToTaskProcessAttributes(taskDetailsDTO);
		Long id=taskProcessAttributesService.createUpdateTaskParameterDetails(taskProcessAttributesDTO);
		return id;
	}

	private TaskProcessAttributesDTO mapTaskDetailDTOToTaskProcessAttributes(TaskDetailsDTO taskDetailsDTO) {
		TaskProcessAttributesDTO taskProcessAttributesDTO =new TaskProcessAttributesDTO();
		//taskProcessAttributesDTO.setAcceptedBy();
		//taskProcessAttributesDTO.setAcceptedOn(acceptedOn);
		taskProcessAttributesDTO.setActivitiTaskId(taskDetailsDTO.getTaskId());
		taskProcessAttributesDTO.setArcMotorReceivedState(taskDetailsDTO.getArcMotorReceivedState());
		taskProcessAttributesDTO.setArcName(taskDetailsDTO.getArcName());
		taskProcessAttributesDTO.setArcRefId(taskDetailsDTO.getArcRefId());
		taskProcessAttributesDTO.setAssignedToBy(taskDetailsDTO.getAssignee());
		taskProcessAttributesDTO.setAssignedToGroup(taskDetailsDTO.getAssignedToGroup());
		//taskProcessAttributesDTO.setAssignedToGroupBy();
		//taskProcessAttributesDTO.setAssignedToGroupOn(assignedToGroupOn);
		//taskProcessAttributesDTO.setAssignedToOn();
		taskProcessAttributesDTO.setAssignedToRefId(taskDetailsDTO.getAssignedTo());
		taskProcessAttributesDTO.setCheckClosure(taskDetailsDTO.getCheckClosure());
		taskProcessAttributesDTO.setCheckFSAssigned(taskDetailsDTO.getCheckFSAssigned());
		taskProcessAttributesDTO.setCheckFSJobCompleted(taskDetailsDTO.getCheckFSJobCompleted());
		//taskProcessAttributesDTO.setCheckParallelProcessType(taskDetailsDTO.getCheckParallelProcessType());
		taskProcessAttributesDTO.setCheckWorkflowStatus(taskDetailsDTO.getCheckWorkflowStatus());
		taskProcessAttributesDTO.setCreatedByRefId(taskDetailsDTO.getCreatedBy());
		//taskProcessAttributesDTO.setCreatedOn();
		taskProcessAttributesDTO.setCustName(taskDetailsDTO.getCustName());
		taskProcessAttributesDTO.setEditNotification(taskDetailsDTO.getEditNotification());
		//taskProcessAttributesDTO.setExecutionId();
		taskProcessAttributesDTO.setFinalWarrantyState(taskDetailsDTO.getFinalWarrantyState());
		taskProcessAttributesDTO.setFrameSize(taskDetailsDTO.getFrameSize());
		taskProcessAttributesDTO.setFunctionCode(taskDetailsDTO.getFunctionCode());
		taskProcessAttributesDTO.setGspRefNo(taskDetailsDTO.getGspRefNo());
		taskProcessAttributesDTO.setInitialWarrantyState(taskDetailsDTO.getInitWarrantyState());
		taskProcessAttributesDTO.setIsJobClosed(taskDetailsDTO.getIsJobClosed());
		taskProcessAttributesDTO.setIsJobCompleted(taskDetailsDTO.getIsJobCompleted());
		taskProcessAttributesDTO.setMasterBatchProcessId(taskDetailsDTO.getMasterBatchProcId());
		taskProcessAttributesDTO.setMasterProcessId(taskDetailsDTO.getMasterProcessId());
		taskProcessAttributesDTO.setNotify(taskDetailsDTO.getNotify());
		taskProcessAttributesDTO.setParalledBatchProcessId(taskDetailsDTO.getParallelProcessId());
		taskProcessAttributesDTO.setPrevFunctionCode(taskDetailsDTO.getPrevFunctionCode());
		taskProcessAttributesDTO.setPriority(taskDetailsDTO.getPriority());
		taskProcessAttributesDTO.setProcessInstId(taskDetailsDTO.getProcessInstanceId());
		taskProcessAttributesDTO.setProgramId(taskDetailsDTO.getProgramId());
		//taskProcessAttributesDTO.setRecalledByRefId();
		//taskProcessAttributesDTO.setRecalledOn(recalledOn);
		//taskProcessAttributesDTO.setRejectedByRefId(rejectedByRefId);
		//taskProcessAttributesDTO.setRejectedOn(rejectedOn);
		taskProcessAttributesDTO.setSubProcessId(taskDetailsDTO.getSubProcessId());
		taskProcessAttributesDTO.setSubProcState(taskDetailsDTO.getSubProcState());
		taskProcessAttributesDTO.setSubTitle(taskDetailsDTO.getSubTitle());
		taskProcessAttributesDTO.setSubWarrantyType(taskDetailsDTO.getSubWarrantyType());
		taskProcessAttributesDTO.setTaskCurrentSLAState(taskDetailsDTO.getTaskCurrentSLAState());
		taskProcessAttributesDTO.setTaskStatus(taskDetailsDTO.getTaskStatus());
		taskProcessAttributesDTO.setTenantId(taskDetailsDTO.getTenantId());
		//taskProcessAttributesDTO.setVisitCompleted(taskDetailsDTO.);
		return taskProcessAttributesDTO;
	
	}
}