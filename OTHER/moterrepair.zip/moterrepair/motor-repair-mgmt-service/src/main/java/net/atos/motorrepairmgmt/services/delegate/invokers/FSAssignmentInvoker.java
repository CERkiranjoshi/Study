/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 *
 */
@Component(value="fsAssignmentInvoker")
public class FSAssignmentInvoker extends BaseWorkflowInvoker {

	@Autowired
	private WorkflowInvoker workflowInvoker;

	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;

	@Autowired
	private SubProcessFieldsService subProcessFieldsService;
	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(FSAssignmentInvoker.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; START: FSAssignmentInvoker ");
		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT FUNCTION_CODE
				String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
						.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

				// TODO Set Function Code of the Next Workflow to be executed
				String functionCode = MotorRepairConstants.FS_ASSIGNMENT;

				Map<String, Object> nextProcessVars = new HashMap<String, Object>();

				// TODO Set only required process variables from the workflow
				setNextProcessVariables(execution, nextProcessVars);

				String procInstanceId=invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; END: FSAssignmentInvoker "+procInstanceId);

	}

	private TaskDetailsDTO setProcessVariable(TaskDetailsDTO taskDetailDTO, DelegateExecution execution) {
		if (null != execution.getVariable(ActivitiConstants.IS_MOTOR_RECV)) {
			taskDetailDTO.setMotorReceivedState(Integer.parseInt(execution.getVariable(ActivitiConstants.IS_MOTOR_RECV)
					.toString()));
		}
		// set process variable id
		if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID)) {
			String processVarId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID)
					.toString();
			// get SubProcess Object by subProcess Id
			// SubProcessFieldsDTO
			// subProcessFieldDTO=subProcessFieldsService.getSubProcessFieldsByWlfwSubProcessId(Long.parseLong(processVarId));
			// taskDetailDTO.setSubprocessFieldDTO(subProcessFieldDTO);
		}

		if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID)) {
			taskDetailDTO.setTenantId(execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString());
		}
		if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID)) {
			taskDetailDTO
					.setProgramId(execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID).toString());
		}
		if (null != execution.getVariable(ActivitiConstants.MOTOR_SN_NO)) {
			taskDetailDTO.setMotorSnNum(execution.getVariable(ActivitiConstants.MOTOR_SN_NO).toString());
		}
		if (null != execution.getVariable(ActivitiConstants.GSP_REF_NO)) {
			taskDetailDTO.setGspRefNo(execution.getVariable(ActivitiConstants.GSP_REF_NO).toString());
		}
		if (null != execution.getVariable(ActivitiConstants.FRAME_SIZE)) {
			taskDetailDTO
					.setFrameSize(Integer.parseInt(execution.getVariable(ActivitiConstants.FRAME_SIZE).toString()));
		}
		if (null != execution.getVariable(ActivitiConstants.CHECK_WARRANTY)) {
			taskDetailDTO.setFinalWarrantyState(execution.getVariable(ActivitiConstants.CHECK_WARRANTY).toString());
		}
		if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP)) {
			taskDetailDTO.setAssignedToGroup(execution.getVariable(
					ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP).toString());
		}
		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(MotorRepairConstants.ARC_ASSIGNMENT_CODE);
		taskDetailDTO.setWorkflowName(actorFunctionMasterDTO.getWorkflowName());
		taskDetailDTO.setFunctionName(actorFunctionMasterDTO.getFunctionName());

		return taskDetailDTO;
	}

}
