package net.atos.motorrepairmgmt.services;

import java.util.List;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;

/**
 * @author a603981
 *
 */
public interface MotorSpeedDetailService {

	public Long createUpdateMotorSpeedDetail(MotorSpeedDetailDTO motorSpeedDetailDTO);

	public List<MotorSpeedDetailDTO> getAllMotorSpeedDetail();

	public MotorSpeedDetailDTO getSpeedDetailByspeedDetailId(Long motorSpeedDetailId);

	public Boolean deleteMotorSpeedDetailBySpeedDetailId(Long motorSpeedDetailId);
}
