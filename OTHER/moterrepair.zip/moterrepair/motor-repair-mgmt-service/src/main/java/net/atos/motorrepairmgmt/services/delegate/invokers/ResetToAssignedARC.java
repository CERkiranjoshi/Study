/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Sweety Kothari
 *
 */
@Component(value = "resetToAssignedARC")
public class ResetToAssignedARC  extends BaseWorkflowInvoker{
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ResetToAssignedARC.class);
	
	@Autowired
	private SubProcessFieldsService subProcessFieldsService;
	
	@Autowired
	private ARCMasterService arcMasterService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+";  ResetToAssignedToARC :START");
		Long subProcessId=(Long)execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID);
		 Long arcRefId = subProcessFieldsService.getARCRefIdBySubProcessId(subProcessId);
		 if (null != arcRefId) {
			    LOGGER.info(" ResetToAssignedToARC :ARC REF ID "+arcRefId);
				ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(Long.valueOf(arcRefId));
				if (null != arcMasterDTO) {
					execution.setVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_EMAIL,
							arcMasterDTO.getArcContactEmail());
					 execution.setVariable(ActivitiConstants.ARC_REF_ID,
							 arcMasterDTO.getArcId().toString());
					 execution.setVariable(ActivitiConstants.ARC_TYPE,
							 arcMasterDTO.getArcType());
					 execution.setVariable(ActivitiConstants.ARC_NAME,
							 arcMasterDTO.getArcName());
				}
			}
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+";  ResetToAssignedToARC :END");
	}

}
