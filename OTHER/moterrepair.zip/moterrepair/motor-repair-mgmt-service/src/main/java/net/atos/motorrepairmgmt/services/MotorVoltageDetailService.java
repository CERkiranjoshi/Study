package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;

/**
 * @author a603981
 *
 */
public interface MotorVoltageDetailService {
	public Long createUpdateMotorVoltageDetail(MotorVoltageDetailDTO motorVoltageDetailDTO);

	public List<MotorVoltageDetailDTO> getAllMotorVoltageDetail();

	public MotorVoltageDetailDTO getVoltageDetailByVoltageDetailId(Long motorVoltageDetailId);

	public Boolean deleteMotorVoltageDetailByMotorVoltageDetailId(Long motorVoltageDetailId);
}
