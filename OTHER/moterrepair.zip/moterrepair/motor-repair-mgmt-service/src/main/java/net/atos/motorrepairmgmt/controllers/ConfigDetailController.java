/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.services.ConfigDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author Sweety Kothari
 *
 */
@EnableSwagger
@Controller
@RequestMapping(value = "configDetailService")
public class ConfigDetailController {

	@Autowired
	private ConfigDetailService configDetailService;
	
	@RequestMapping(value = "/getAllConfigDetailByTypeNSubType/{tenantId}/{solnCatId}/{type}/{subType}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All config detail by type and subType", notes = "Returns a list of config detail based on argument provided", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody List<ConfigDetailDTO> getAllConfigDetailByTypeNSubType(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId,@PathVariable("type") String type,@PathVariable("subType") String subType) {
		return configDetailService.findConfigDetailsByConfigTypeNSubType(type, subType, tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/getEnabledNVisibleConfigDetailByTypeNSubType/{tenantId}/{solnCatId}/{type}/{subType}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All config detail by type and subType", notes = "Returns a list of config detail based on argument provided", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody List<ConfigDetailDTO> getEnabledNVisibleConfigDetailByTypeNSubType(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId,@PathVariable("type") String type,@PathVariable("subType") String subType) {
		return configDetailService.findEnabledNVisibleConfigDetailsByTypeNSubType(type, subType, tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/getAllConfigDetailByType/{tenantId}/{solnCatId}/{type}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All config detail by type and subType", notes = "Returns a list of config detail based on argument provided", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody List<ConfigDetailDTO> getAllConfigDetailByTypeNSubType(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId,@PathVariable("type") String type) {
		return configDetailService.findConfigDetailsByConfigType(type, tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/getEnabledNVisibleConfigDetailByType/{tenantId}/{solnCatId}/{type}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All config detail by type ", notes = "Returns a list of config detail based on argument provided", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody List<ConfigDetailDTO> getEnabledNVisibleConfigDetailByType(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId,@PathVariable("type") String type) {
		return configDetailService.findEnabledNVisibleConfigDetailsByType(type,  tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/refreshConfigDetails/{tenantId}/{solnCatId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Refresh config details  ", notes = "Refreshes config detail by tenant id and solution category id", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody boolean refreshConfigDetails(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId) {
		return configDetailService.refreshCacheData(tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/getAllConfigDetailByTenantIdNSolnCatId/{tenantId}/{solnCatId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All config detail by tenantId and solnCatId", notes = "Returns a list of config detail based on argument provided", response = ConfigDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody List<ConfigDetailDTO> getAllConfigDetailByTenantIdNSolnCatId(
			@ApiParam(value = "Find All config detail by tenantId and solnCatId", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId) {
		return configDetailService.findConfigDetailByTenantIdNSolnCatId(tenantId, solnCatId);
	}
	
	@RequestMapping(value = "/createUpdateConfigDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update ConfigDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long createUpdateConfigDetail(
			@ApiParam(value = "ConfigDetail object that needs to be added or update in the ConfigDetail") @RequestBody ConfigDetailDTO configDetailDTO) {
		return configDetailService
				.createUpdateConfigDetail(configDetailDTO);
	}
}
