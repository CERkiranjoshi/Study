package net.atos.motorrepairmgmt.services;

import java.util.List;
import net.atos.motorrepairmgmt.dto.ARCMasterDTO;

/**
 * @author a603975
 * 
 */

public interface ARCMasterService {
	Long createUpdateARCMaster(ARCMasterDTO arcMasterDTO);

	List<ARCMasterDTO> getAllARCMaster();

	ARCMasterDTO getARCMasterByArcId(Long arcId);

	List<ARCMasterDTO> getARCMasterListByArcName(String arcName);

	List<ARCMasterDTO> getARCMasterListByRegionId(Long regionId);

	Boolean deleteARCMasterByArcId(Long arcId);
	
	List<ARCMasterDTO> getARCMasterByArcType(Integer arcType);

}
