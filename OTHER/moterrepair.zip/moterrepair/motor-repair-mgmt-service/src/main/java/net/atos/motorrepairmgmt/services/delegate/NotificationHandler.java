/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.motorrepairmgmt.services.NotificationService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Sweety Kothari
 * 
 */
@Component(value = "notificationHandler")
public class NotificationHandler implements JavaDelegate {

	@Autowired
	private NotificationService notificationService;

	private static final Logger LOGGER = Logger.getLogger(NotificationHandler.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		/*
		 * fetch function code ,email code from process variable *Based upon trigger notification method from service
		 */
	    LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; NOTIFICATION_HANDLER: START ");
		Long subProcessId = (Long) execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID);
		if(null!=execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)){
			subProcessId=Long.valueOf(execution.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString());
		}
		String functionCode = null;
		String arcRefId = null;
		if (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) {
			functionCode = execution.getVariable(ActivitiConstants.FUNCTION_CODE).toString();
		} else {
			LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; Function Code is null");
		}
		if (null != execution.getVariableLocal(MotorRepairConstants.TEMPLATE_CODE) && null != execution.getVariable(MotorRepairConstants.ASSIGNED_TO_GROUP)) {
			String templateCodeStr = execution.getVariableLocal(MotorRepairConstants.TEMPLATE_CODE).toString();
			String groupName = execution.getVariable(MotorRepairConstants.ASSIGNED_TO_GROUP).toString();
			
			if(execution.getVariable(MotorRepairConstants.ARC_REF_ID) != null){
				 arcRefId = execution.getVariable(MotorRepairConstants.ARC_REF_ID).toString();
			}
			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; Function Code:"+functionCode+"- Template Code:"+templateCodeStr);
			notificationService.triggerAssignmentNotification(functionCode, templateCodeStr, subProcessId,groupName,arcRefId);
		}
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; NOTIFICATION_HANDLER: END ");
	}

}
