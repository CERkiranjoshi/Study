/**
 * 
 */
package net.atos.singetons;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.atos.motorrepairmgmt.services.delegate.ReclaimWorkflowHandler;

import org.apache.log4j.Logger;

/**
 * This is a holder of reclaim ids in the system. This class is used to handle reclaim requests per RECLAIM_ID. The
 * class would maintain a static hashset to store processed RECLAIM_ID.
 * 
 * @author Anand Ved
 *
 */
public class ReclaimIdHolder {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ReclaimWorkflowHandler.class);

	// 60 mins of TTL
	public static final Long DEFAULT_TTL = 60 * 60 * 1000L; // min x sec x millis

	/**
	 * Reclaim Id holder
	 */
	private static final Map<String, Long> RECLAIM_ID_HOLDER = Collections.synchronizedMap(new HashMap<String, Long>());

	private static final ReclaimIdHolder reclaimIdHolder = new ReclaimIdHolder();
	
	/**
	 * Default Constructor. Initiate cleanup thread to ensure reclaimIds are cleaned every DETAULT_TTL
	 */
	public ReclaimIdHolder() {
		LOGGER.info("RECLAIM_ID_HOLDER: INITIALIZED");
	}

	public static ReclaimIdHolder getInstance() {
		return reclaimIdHolder;
	}
	
	/**
	 * Method to add Reclaim Ids to reclaim holder. reclaim holder is synchronized to avoid undesirable additions.
	 * 
	 * @param reclaimId
	 * @return boolean<br>
	 *         true indicates reclaimId did not exist prior<br>
	 *         false indicates reclaimId existed prior<br>
	 */
	public boolean addReclaimId(String reclaimId) {
		synchronized (RECLAIM_ID_HOLDER) {
			if (null != reclaimId) {
				// Add only if reclaimId is not inserted, else return false.
				if (!RECLAIM_ID_HOLDER.containsKey(reclaimId)) {
					long currentTS = System.currentTimeMillis();
					// set TTL as current time + DEFAULT_TTL
					RECLAIM_ID_HOLDER.put(reclaimId, (currentTS + DEFAULT_TTL));
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Method to check if reclaimId exists in the holder.
	 * 
	 * @param reclaimId
	 * @return boolean<br>
	 *         true if holder contains this reclaimId<br>
	 *         false if holder does not contain this reclaimId<br>
	 */
	public boolean isProcessedRecalimId(String reclaimId) {
		return RECLAIM_ID_HOLDER.containsKey(reclaimId);
	}


	/**
	 * Method to clean up Reclaim Holder at a predefined interval of DEFAULT_TTL.<br>
	 * Cleanup best case: reclaimIds are cleaned as soon as their ttl expires.<br>
	 * Cleanup worst case: reclaimIds are cleaned in a max period of their ttl + DEFAULT_TTL.<br>
	 */
	public void cleanUp() {
		LOGGER.info("RECLAIM_HOLDER: Clean Up: Begin holder size: " + RECLAIM_ID_HOLDER.size());
		long now = System.currentTimeMillis();
		synchronized (RECLAIM_ID_HOLDER) {
			for (Iterator<String> reclaimIdsKey = RECLAIM_ID_HOLDER.keySet().iterator(); reclaimIdsKey.hasNext();) {
				String reclaimId = reclaimIdsKey.next();
				Long ttlPeriod = RECLAIM_ID_HOLDER.get(reclaimId);
				if (now >= ttlPeriod) {
					// remove
					Long storedTTL = RECLAIM_ID_HOLDER.remove(reclaimId);
					if (LOGGER.isTraceEnabled())
						LOGGER.trace("RECLAIM_HOLDER: Clean Up: Removing reclaimId : " + reclaimId
								+ " for expired ttl at: " + storedTTL);
				}
			}
		}
		LOGGER.info("RECLAIM_HOLDER: Clean Up: End holder size: " + RECLAIM_ID_HOLDER.size());
	}
}
