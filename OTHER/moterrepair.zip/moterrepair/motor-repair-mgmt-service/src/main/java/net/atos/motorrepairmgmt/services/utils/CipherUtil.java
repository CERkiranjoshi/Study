/**
 * 
 */
package net.atos.motorrepairmgmt.services.utils;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component
public class CipherUtil {

	private static final String ENCRYPTION_ALGO = "AES";

	public String encryptString(String key, String textToEncrypt) {
		try {

			Key aesKey = new SecretKeySpec(key.getBytes(), ENCRYPTION_ALGO);
			Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);

			// encrypt the text
			cipher.init(Cipher.ENCRYPT_MODE, aesKey);
			byte[] encrypted = cipher.doFinal(textToEncrypt.getBytes());

			String encryptedText = Hex.encodeHexString(encrypted);

			System.out.println("EncryptedStr  >>>" + encryptedText + "<<<");

			return encryptedText;

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}

		return null;
	}

	public String decryptString(String key, String textToDecrypt) {

		try {
			Key aesKey = new SecretKeySpec(key.getBytes(), ENCRYPTION_ALGO);
			Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);

			// decrypt the text
			cipher.init(Cipher.DECRYPT_MODE, aesKey);

			byte[] toDecrypt = Hex.decodeHex(textToDecrypt.toCharArray());

			String decrypted = new String(cipher.doFinal(toDecrypt));

			return decrypted;

		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (DecoderException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static void main_001(String[] args) {
		CipherUtil cu = new CipherUtil();
		UniqueIdGenerator uid = new UniqueIdGenerator();

		String key = uid.generateUniqueId();
		System.out.println("UniqueId: " + key);

		String textToEncrypt = "TI-0000023324";

		String encryptedTicket = cu.encryptString(key, textToEncrypt);

		System.out.println("Encrypted Ticket ==> " + encryptedTicket);

		String decryptedTicket = cu.decryptString(key, encryptedTicket);

		System.out.println("Decrypted Ticket ==> " + decryptedTicket);

	}
}
