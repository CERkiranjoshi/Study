/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.Map;
/**
 * @author Sweety Kothari
 *
 */
public interface WorkflowInvoker {

	public String startNewProcess(Map<String,Object> procVariables,String workflowName);
}
