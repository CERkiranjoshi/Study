/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.SparesMasterDTO;
import net.atos.motorrepairmgmt.entity.SparesMaster;
import net.atos.motorrepairmgmt.repository.SparesMasterRepository;
import net.atos.motorrepairmgmt.services.SparesMasterService;

/**
 * @author Sweety Kothari
 *
 */
@Service
public class SparesServiceImpl implements SparesMasterService{

	@Autowired
	private SparesMasterRepository sparesMasterRepo;
	
	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;
	
	
	@Override
	@Transactional
	public List<SparesMasterDTO> getAllSparesByTenantIdNSolutionCategory(String tenantId, String solutionCatId) {
		// TODO Auto-generated method stub
		
		List<SparesMaster> sparesMasterList=sparesMasterRepo.findSparesByTenantIdNSolutionCategory(tenantId, solutionCatId);
		List<SparesMasterDTO> sparesMasterDTOList= null;
		SparesMasterDTO spareMasterDTO=null;
		if (null != sparesMasterList && sparesMasterList.size() > 0) {
			sparesMasterDTOList = new ArrayList<SparesMasterDTO>();
			for (SparesMaster spareMaster : sparesMasterList) {
				spareMasterDTO = dozerBeanMapper.map(spareMaster, SparesMasterDTO.class);
				sparesMasterDTOList.add(spareMasterDTO);
			}
		}	
		return sparesMasterDTOList;
	}

	@Override
	@Transactional
	public SparesMasterDTO getSparesMasterById(Long id) {
		// TODO Auto-generated method stub
		SparesMaster spareMaster=sparesMasterRepo.findOne(id);
		SparesMasterDTO sparesMasterDTO=dozerBeanMapper.map(spareMaster, SparesMasterDTO.class);
		return sparesMasterDTO;
	}

}
