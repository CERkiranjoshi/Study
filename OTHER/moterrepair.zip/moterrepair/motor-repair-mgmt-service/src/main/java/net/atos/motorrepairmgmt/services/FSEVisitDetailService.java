/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;
import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;

/**
 * @author a603981
 *
 */
public interface FSEVisitDetailService {

	public Long createUpdateFSEVisitDetail(FSEVisitDetailDTO fSEVisitDetailDTO);

	public List<FSEVisitDetailDTO> getAllFSEVisitDetail();

	public FSEVisitDetailDTO getFSEVisitDetailById(Long fseVisitDetailId);

	public List<FSEVisitDetailDTO> getFSEVisitByName(String fseName);

	public Boolean deleteFSEVisitDetailByFSEVisitDetailId(Long fseVisitDetailId);
}
