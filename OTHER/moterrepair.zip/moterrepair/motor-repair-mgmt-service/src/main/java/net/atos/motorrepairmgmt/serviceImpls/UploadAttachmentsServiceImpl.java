package net.atos.motorrepairmgmt.serviceImpls;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorAttachmentDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.MotorAttachmentDetailRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.UploadAttachmentsService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;

/**
 * @author a610039
 * 
 */

@Service
public class UploadAttachmentsServiceImpl implements UploadAttachmentsService {

	/** The MotorSparesDetail Repository */
	@Autowired
	private MotorAttachmentDetailRepository motorAttachmentDetailRepository;

	/** The MotorSparesDetail Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The DozerBeanMapper */
	@Autowired
	private ConfigDetailService configDetailService;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(UploadAttachmentsServiceImpl.class);

	/**
	 * The method upload Documnets . The method performs create operation of MotorAttachments when wlfwSubProcess Id and
	 * upload Document to file location
	 * 
	 * 
	 * @param File
	 *            The File to be uploaded
	 * @param wlfwSubProcessId
	 *            The Subpoocess Id
	 * @param description
	 * 
	 * @param uploadedBy
	 * 
	 * @return MotorAttachmentDetailDTO List
	 * 
	 */
	/* upload */
	@Override
	@Transactional
	public List<MotorAttachmentDetailDTO> uploadDocument(MultipartFile file, Long wlfwSubProcessId, String description,
			String uploadedBy, Integer attachmentType, String tenantId, String solCatId, Integer isInternal,Integer methodCallValue) {

		LOGGER.info("UploadAttachmentsServiceImpl : uploadDocument : Start");
		List<MotorAttachmentDetailDTO> motorAttachmentDTOList = null;
		if (file.isEmpty()) {
			LOGGER.info("File size is empty");
		} else {

			String fileName = file.getOriginalFilename();
			InputStream inputStream = null;
			OutputStream outputStream = null;
			System.out.println("Id" + wlfwSubProcessId);
			System.out.println("size" + file.getSize());
			String location = null;
			List<ConfigDetailDTO> configDetailDTOList = null;

			try {
				inputStream = file.getInputStream();

				int hashcode = fileName.hashCode();
				int mask = 255;
				int firstDir = hashcode & mask;
				int secondDir = (hashcode >> 8) & mask;

				StringBuilder path = new StringBuilder(File.separator);
				path.append(String.format("%03d", firstDir));
				path.append(File.separator);
				path.append(String.format("%03d", secondDir));
				path.append(File.separator);

				System.out.println(path);

				String filestamp = System.currentTimeMillis() + fileName;

				System.out.println("filename :" + filestamp);

				configDetailDTOList = configDetailService.findConfigDetailsByConfigTypeNSubType(
						MotorRepairConstants.ATTACHMENT, MotorRepairConstants.BASE_LOCATION,
						MotorRepairConstants.PROGRAM_ID, MotorRepairConstants.TENANT_ID);

				for (ConfigDetailDTO configDetailDTO : configDetailDTOList) {
					location = configDetailDTO.getConfigStrVal();
				}

				File newFile = new File(location + path + filestamp);
				if (!newFile.exists()) {
					newFile.getParentFile().mkdirs();
					newFile.createNewFile();
				}
				outputStream = new FileOutputStream(newFile);
				int read = 0;
				byte[] bytes = new byte[1024];

				while ((read = inputStream.read(bytes)) != -1) {
					outputStream.write(bytes, 0, read);
				}
				motorAttachmentDTOList = new ArrayList<MotorAttachmentDetailDTO>();
				motorAttachmentDTOList = setMotorAttachmentDetailDTOList(file, filestamp, path, description,
						uploadedBy, wlfwSubProcessId, attachmentType, tenantId, solCatId, isInternal, location,methodCallValue);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				LOGGER.info("exception" + e);
			} finally {
				try {
					outputStream.close();
					inputStream.close();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		LOGGER.info("UploadAttachmentsServiceImpl : uploadDocument : End");
		return motorAttachmentDTOList;
	}

	/**
	 * This method Get MotorAttachmentDetailDTOList
	 * 
	 * @return MotorAttachmentDetailDTO List
	 * 
	 */
	private List<MotorAttachmentDetailDTO> setMotorAttachmentDetailDTOList(MultipartFile file, String filestamp,
			StringBuilder path, String description, String uploadedBy, Long wlfwSubProcessId, Integer attachmentType,
			String tenantId, String solCatId, Integer isInternal, String baseFolder,Integer methodCallValue) {

		LOGGER.info("UploadAttachmentsServiceImpl : setMotorAttachmentDetailDTOList : Start");

		List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOFinalList = new ArrayList<MotorAttachmentDetailDTO>();
		MotorAttachmentDetail motorAttachmentDetail = new MotorAttachmentDetail();
		MotorAttachmentDetailDTO motorAttachmentDetailDTOFinal = new MotorAttachmentDetailDTO();
		List<MotorAttachmentDetail> motorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();
		List<MotorAttachmentDetail> motorAttachmentDetailFinalList = new ArrayList<MotorAttachmentDetail>();
		SubProcessFields subProcessField = null;
		SubProcessFields savedObject = null;
		boolean external = false;

		motorAttachmentDetail.setAttachmentType(attachmentType);
		motorAttachmentDetail.setUploadedOn(new Date());
		motorAttachmentDetail.setAttachmentUrl(path.toString() + filestamp);
		motorAttachmentDetail.setBaseFolder(baseFolder);
		motorAttachmentDetail.setFileName(file.getOriginalFilename());
		motorAttachmentDetail.setFileSize(file.getSize());
		motorAttachmentDetail.setIsDeleted(0);
		motorAttachmentDetail.setIsInternal(isInternal);
		motorAttachmentDetail.setTenantId(tenantId);
		motorAttachmentDetail.setSolutionCategoryId(solCatId);

		if (!description.equals("undefined")) {
			motorAttachmentDetail.setDescription(description);
		}
		motorAttachmentDetail.setUploadedBy(uploadedBy);

		motorAttachmentDetailList.add(motorAttachmentDetail);

		subProcessField = subProcessFieldsRepository.findOne(wlfwSubProcessId);
		//to check this method is comming from uploadDocumentForMultipleSubprocess or not 
		if (methodCallValue == 0) {
			motorAttachmentDetailFinalList.add(motorAttachmentDetail);
			subProcessField.getMotorAttachmentDetails().addAll(motorAttachmentDetailFinalList);
			savedObject = subProcessFieldsRepository.save(subProcessField);

			if (null != savedObject) {
				if (isInternal == 0) {
					external = true;
				}
				motorAttachmentDetailDTOFinalList = getAllMotorAttachmentDetailBySubprocesssId(
						savedObject.getWlfwSubProcessId(), external, uploadedBy);
			}

		} else if (methodCallValue == 1) {
			for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentDetailList) {
				motorAttachmentDetailDTOFinal = dozerBeanMapper.map(motorAttachmentDetailRecord,
						MotorAttachmentDetailDTO.class);
				motorAttachmentDetailDTOFinalList.add(motorAttachmentDetailDTOFinal);
			}
		}

		if (null != motorAttachmentDetailDTOFinalList) {
			LOGGER.info("File saved in DB");

		} else {
			LOGGER.info("File saved in DB unsuccessfull");
		}
		LOGGER.info("UploadAttachmentsServiceImpl : setMotorAttachmentDetailDTOList : End");
		return motorAttachmentDetailDTOFinalList;
	}

	/**
	 * This deletes a uploaded File on the basis its motorAttachmentsId.
	 * 
	 * @param motorAttachmentsId
	 *            The MotorAttachments Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public boolean deleteFile(Long motorAttachmentsId, String deletedBy) {
		LOGGER.info("UploadAttachmentsServiceImpl : deleteFile : Start");
		boolean flag = false;

		if (null != motorAttachmentsId) {
			MotorAttachmentDetail motorAttachmentDetail = motorAttachmentDetailRepository.findOne(motorAttachmentsId);
			motorAttachmentDetail.setDeletedOn(new Date());
			motorAttachmentDetail.setIsDeleted(1);
			motorAttachmentDetail.setDeletedBy(deletedBy);
			flag = true;

			LOGGER.info("UploadAttachmentsServiceImpl : File deleted ");
		}
		LOGGER.info("UploadAttachmentsServiceImpl : deleteFile : End");
		return flag;
	}

	/**
	 * This Download Document on the basis its motorAttachmentsId.
	 * 
	 * @param motorAttachmentsId
	 *            The MotorAttachments Id
	 * 
	 * @return void
	 * 
	 */
	/* download */
	@Override
	@Transactional
	public void downloadDocument(HttpSession session, HttpServletResponse response, Long motorAttachmentsId) {
		LOGGER.info("UploadAttachmentsServiceImpl : downloadDocument : Start");
		InputStream is = null;
		if (null != motorAttachmentsId) {
			MotorAttachmentDetail motorAttachmentDetail = motorAttachmentDetailRepository.findOne(motorAttachmentsId);
			if (null != motorAttachmentDetail) {
				try {

					String baseFolder = motorAttachmentDetail.getBaseFolder();
					String attachmentUrl = motorAttachmentDetail.getAttachmentUrl();
					String fileName = motorAttachmentDetail.getFileName();

					File file = new File(baseFolder + attachmentUrl);

					response.setContentType(new MimetypesFileTypeMap().getContentType(file));
					response.setContentLength((int) file.length());
					response.setHeader("content-disposition",
							"attachment; filename=" + URLEncoder.encode(fileName, "UTF-8"));

					is = new FileInputStream(file);
					FileCopyUtils.copy(is, response.getOutputStream());

				} catch (IOException e) {
					LOGGER.info("exception" + e);
				} finally {

					try {
						if (is != null) {

							is.close();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			}
		}
		LOGGER.info("UploadAttachmentsServiceImpl : downloadDocument : End");
	}

	/**
	 * The method retrieves a MotorAttachmentDetail on the basis of motorAttachments Id.
	 * 
	 * @param motorAttachments
	 *            Id The MotorAttachmentDetail motorAttachmentsId
	 * @return MotorAttachmentDetailDTO
	 * 
	 */
	@Override
	public List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetailBySubprocesssId(Long wlfwSubProcessId,
			Boolean external, String uploadedBy) {
		LOGGER.info("UploadAttachmentsServiceImpl : getAllMotorAttachmentDetailBySubprocesssId : Start");
		List<MotorAttachmentDetail> motorAttachmentDetailList = null;
		List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOFinalList = null;
		MotorAttachmentDetailDTO motorAttachmentDetailDTO = null;
		List<MotorAttachmentDetail> motorAttachmentDetailListForARCMain = null;
		Integer isInternal;
		Integer isDeleted;
		if (null != wlfwSubProcessId) {
			LOGGER.info("Fetch Attchments For wlfwSubProcessId: " + wlfwSubProcessId);
			if (external) {
				isInternal = 0;
				isDeleted = 0;
				LOGGER.info("Fetch Attchments For external: Start ");
				motorAttachmentDetailListForARCMain = new ArrayList<MotorAttachmentDetail>();
				motorAttachmentDetailListForARCMain = subProcessFieldsRepository
						.findAllMotorAttachmentDetailBySubprocesssIdAndIsInternal(wlfwSubProcessId, isInternal,
								isDeleted);
				LOGGER.info("Fetch Attchments For external: End ");
			} else {
				LOGGER.info("Fetch Attchments For Internal: Start ");
				motorAttachmentDetailList = subProcessFieldsRepository
						.findAllMotorAttachmentDetailBySubprocesssId(wlfwSubProcessId);
				LOGGER.info("Fetch Attchments For Internal: End ");
			}
		} else {
			LOGGER.info("wlfwSubProcessId is Null: " + wlfwSubProcessId);
		}
		if ((null != motorAttachmentDetailList && motorAttachmentDetailList.size() > 0)
				|| (null != motorAttachmentDetailListForARCMain && motorAttachmentDetailListForARCMain.size() > 0)) {
			motorAttachmentDetailDTOFinalList = new ArrayList<MotorAttachmentDetailDTO>();

			if (external) {

				for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentDetailListForARCMain) {
					if (motorAttachmentDetailRecord.getUploadedBy().equals(uploadedBy)) {

						motorAttachmentDetailDTO = new MotorAttachmentDetailDTO();

						motorAttachmentDetailDTO = dozerBeanMapper.map(motorAttachmentDetailRecord,
								MotorAttachmentDetailDTO.class);
						motorAttachmentDetailDTOFinalList.add(motorAttachmentDetailDTO);
					}
				}
			} else {
				for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentDetailList) {

					motorAttachmentDetailDTO = new MotorAttachmentDetailDTO();

					motorAttachmentDetailDTO = dozerBeanMapper.map(motorAttachmentDetailRecord,
							MotorAttachmentDetailDTO.class);
					motorAttachmentDetailDTOFinalList.add(motorAttachmentDetailDTO);

				}
			}

		}
		LOGGER.info("UploadAttachmentsServiceImpl : getAllMotorAttachmentDetailBySubprocesssId : End");
		return motorAttachmentDetailDTOFinalList;
	}

	/**
	 * This Download Document on the basis its motorAttachmentsId.
	 * 
	 * @param motorAttachmentsId
	 *            The MotorAttachments Id
	 * 
	 * @return void
	 * 
	 */
	/* download */
	@Override
	@Transactional
	public List<MotorAttachmentDetailDTO> uploadDocumentForMultipleSubprocess(MultipartFile file, String description,
			String uploadedBy, Integer attachmentType, String tenantId, String solCatId, Integer isInternal,
			Long masterWorkflowFieldId,Integer methodCallValue) {
		LOGGER.info("UploadAttachmentsServiceImpl : uploadDocumentForMultipleSubprocess : Start");

		Long wlfwSubProcessId = null;
		List<MotorAttachmentDetailDTO> motorAttachmentDTOList = null;
		List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOReturnFinal = null;
		List<MotorAttachmentDetail> motorAttachmentReturnList = null;
		List<MotorAttachmentDetail> motorAttachmentDetailList = null;
		MotorAttachmentDetail motorAttachmentDetail = null;
		SubProcessFields subProcessField = null;
		SubProcessFields savedObject = null;
		List<SubProcessFields> subProcessFieldList = null;
		List<Long> subprocessIdList = new ArrayList<Long>();

		if (null != masterWorkflowFieldId) {
			subProcessFieldList = subProcessFieldsRepository
					.findSubProcessFieldsByMasterWorkflowId(masterWorkflowFieldId);
		}

		for (SubProcessFields SubProcessFieldEntity : subProcessFieldList) {
			subprocessIdList.add(SubProcessFieldEntity.getWlfwSubProcessId());
		}

		if (null != subprocessIdList && subprocessIdList.size() > 0) {

			motorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();

			wlfwSubProcessId = subprocessIdList.get(0);
			motorAttachmentDTOList = uploadDocument(file, wlfwSubProcessId, description, uploadedBy, attachmentType,
					tenantId, solCatId, isInternal,methodCallValue);

		}

		if (null != subprocessIdList && subprocessIdList.size() > 0) {

			for (int i = 0; i < subprocessIdList.size(); i++) {

				motorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();
				motorAttachmentDetailDTOReturnFinal = new ArrayList<MotorAttachmentDetailDTO>();
				subProcessField = new SubProcessFields();
				wlfwSubProcessId = subprocessIdList.get(i);
				subProcessField = subProcessFieldsRepository.findOne(wlfwSubProcessId);
				subProcessField.getMotorAttachmentDetails();

				for (MotorAttachmentDetailDTO motorAttachmentDetailDTO : motorAttachmentDTOList) {
					motorAttachmentDetail = new MotorAttachmentDetail();
					motorAttachmentDetailDTO.setMotorAttachmentsId(null);
					motorAttachmentDetail = dozerBeanMapper.map(motorAttachmentDetailDTO, MotorAttachmentDetail.class);
					motorAttachmentDetailList.add(motorAttachmentDetail);
				}
				subProcessField.getMotorAttachmentDetails().addAll(motorAttachmentDetailList);
				savedObject = subProcessFieldsRepository.save(subProcessField);
				if (null != savedObject) {
					LOGGER.info("File saved in DB");
					motorAttachmentReturnList = savedObject.getMotorAttachmentDetails();
					for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentReturnList) {
						MotorAttachmentDetailDTO motorAttachmentDetailDTO = new MotorAttachmentDetailDTO();
						motorAttachmentDetailDTO = dozerBeanMapper.map(motorAttachmentDetailRecord,
								MotorAttachmentDetailDTO.class);
						motorAttachmentDetailDTOReturnFinal.add(motorAttachmentDetailDTO);
					}

				} else {
					LOGGER.info("File saved in DB unsuccessfull");
				}
			}
		}
		LOGGER.info("UploadAttachmentsServiceImpl : uploadDocumentForMultipleSubprocess : End");
		return motorAttachmentDetailDTOReturnFinal;
	}

	/**
	 * This deletes a uploaded File on the basis its motorAttachmentsId.
	 * 
	 * @param motorAttachmentsId
	 *            The MotorAttachments Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public boolean deleteDocumentForMultipleSubprocess(Long motorAttachmentsId, String deletedBy) {
		LOGGER.info("UploadAttachmentsServiceImpl : deleteFile : Start");
		boolean flag = false;
		List<MotorAttachmentDetail> motorAttachmentDetailList = null;
		MotorAttachmentDetail savedObject = null;

		if (null != motorAttachmentsId) {
			motorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();
			MotorAttachmentDetail motorAttachmentDetail = motorAttachmentDetailRepository.findOne(motorAttachmentsId);

			motorAttachmentDetailList = motorAttachmentDetailRepository
					.findAllMotorAttachmentDetailBasedOnFileName(motorAttachmentDetail.getAttachmentUrl());

			for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentDetailList) {
				motorAttachmentDetailRecord.setDeletedOn(new Date());
				motorAttachmentDetailRecord.setIsDeleted(1);
				motorAttachmentDetailRecord.setDeletedBy(deletedBy);

				savedObject = motorAttachmentDetailRepository.save(motorAttachmentDetailRecord);
				if (null != savedObject) {
					flag = true;
					LOGGER.info("UploadAttachmentsServiceImpl : File deleted ");
				}
			}
		}
		LOGGER.info("UploadAttachmentsServiceImpl : deleteFile : End");
		return flag;
	}
}
