package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.DispatchDetailDTO;
import net.atos.motorrepairmgmt.services.DispatchDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610039
 * 
 */
@EnableSwagger
@RequestMapping(value = "dispatchDetailService")
@Controller
public class DispatchDetailController {

	@Autowired
	private DispatchDetailService dispatchDetailService;

	@RequestMapping(value = "/createUpdateDispatchDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update Dispatch Detail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateDispatchDetail(
			@ApiParam(value = "DispatchDetail object that needs to be added or update in the DispatchDetail") @RequestBody DispatchDetailDTO dispatchDetailDTO) {
		return dispatchDetailService.createUpdateDispatchDetail(dispatchDetailDTO);
	}

	@RequestMapping(value = "/getAllDispatchDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find Dispatch Detail", notes = "Returns a Dispatch Detail entity", response = CustomerDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<DispatchDetailDTO> getAllCustomerDetail() {
		return dispatchDetailService.getAllDispatchDetail();
	}

	@RequestMapping(value = "/getDispatchDetailByDispatchId/{dispatchId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find Dispatch Detail By Customer Id", notes = "Returns a Dispatch Detail entity when dispatch Id is passed", response = CustomerDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid dispatch Id supplied"),
			@ApiResponse(code = 404, message = " dispatch detail not found") })
	public @ResponseBody DispatchDetailDTO getDispatchDetailByDispatchId(
			@ApiParam(value = "Customer Id of the CustomerDetail that needs to be fetched", required = true) @PathVariable("dispatchId") Long dispatchId) {
		return dispatchDetailService.getDispatchDetailByDispatchId(dispatchId);
	}

	@RequestMapping(value = "/deleteDispatchDetailByDispatchId/{dispatchId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete Dispatch Detail By dispatch Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid  dispatch Id value") })
	public @ResponseBody Boolean deleteDispatchDetailByDispatchId(
			@ApiParam(value = "Customer Id to delete", required = true) @PathVariable("dispatchId") Long dispatchId) {
		try {
			return dispatchDetailService.deleteDispatchDetailByDispatchId(dispatchId);
		} catch (Exception e) {
			return false;
		}
	}

}

