/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.services.MotorSparesDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603327
 * 
 */
@Controller
@EnableSwagger
@RequestMapping("motorSparesDetailService")
public class MotorSparesDetailController {

	@Autowired
	private MotorSparesDetailService motorSparesDetailService;

	@RequestMapping(value = "/getAllMotorSparesDetail", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find All Motor Spares Detail", notes = "Returns a Motor Spares Detail Entity", response = MotorSparesDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 404, message = "Motor Spares Detail not found") })
	public @ResponseBody List<MotorSparesDetailDTO> getAllMotorSparesDetail() {
		return motorSparesDetailService.getAllMotorSparesDetail();
	}

	@RequestMapping(value = "/createUpdateMotorSparesDetail", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates Motor Spares Detail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateTenant(
			@ApiParam(value = "Motor Spares Detail object that needs to be added or update in the MotorSparesDetail") @RequestBody MotorSparesDetailDTO motorSparesDetailDTO) {
		return motorSparesDetailService.createUpdateMotorSparesDetail(motorSparesDetailDTO);
	}

	@RequestMapping(value = "/deleteMotorSparesDetail/{materialId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Delete Motor Spares Detail By Material Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid Material Id value") })
	public @ResponseBody Boolean deleteMotorSparesDetail(
			@ApiParam(value = "Material Id to delete") @PathVariable("materialId") Long materialId) {
		try {
			return motorSparesDetailService.deleteMotorSparesDetail(materialId);
		} catch (Exception e) {
			return false;
		}
	}

	@RequestMapping(value = "/getMotorSparesDetailById/{materialId}", produces = { "application/json" }, method = { RequestMethod.GET })
	@ApiOperation(value = "Find Motor Spares Detail By Material Id", notes = "Returns a Motor Spares Detail entity when Material Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid Material Id supplied"),
			@ApiResponse(code = 404, message = "Motor Spares Detail not found") })
	public @ResponseBody MotorSparesDetailDTO getMotorSparesDetailById(
			@ApiParam(value = "Material Id of the Motor Spares Detail that needs to be fetched", required = true) @PathVariable(value = "materialId") Long materialId) {
		return motorSparesDetailService.getMotorSparesDetailById(materialId);

	}
	
	@RequestMapping(value = "/getMotorSparesDetailByMaterialIdandTenantIdandSolCatId/{materialId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody MotorSparesDetailDTO getMotorSparesDetailByMaterialIdandTenantIdandSolCatId(
			@PathVariable(value = "materialId") final Long materialId,
			@PathVariable(value = "tenantId") final String tenantId,
			@PathVariable(value = "solutionCategoryId")final String solutionCategoryId) {
		return motorSparesDetailService.getMotorSparesDetailByMaterialIdandTenantIdandSolCatId(materialId, tenantId,solutionCategoryId);
		
	}

}
