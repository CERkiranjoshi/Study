package net.atos.motorrepairmgmt.services.delegate;

import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.services.delegate.invokers.BaseWorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.taskmgmt.activiti.engine.TaskManagementService;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Class to handle Recall of tasks by CCC Actor
 * 
 * @author Anand Ved
 * 
 */

@Component(value = "recallAssignment")
public class RecallAssignment extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(RecallAssignment.class);

	@Autowired
	TaskManagementService taskManagementService;

	/**
	 * Steps:</br> 1. Check if this task is already claimed</br> 2. In case of claimed, throw an error. (Does throwing
	 * exception leads to workflow in hung state?)</br> 3.
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECALL_ASSIGNMENT: BEGIN");

		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

		Map<String, Object> nextProcessVars = new HashMap<String, Object>();

		String recalledByUserRefId = (null != execution.getVariable(ActivitiConstants.TASK_RECALLED_BY)) ? String
				.valueOf(execution.getVariable(ActivitiConstants.TASK_RECALLED_BY)) : null;

		if (null != recalledByUserRefId) {


			// TODO Set only required process variables from the workflow
			setNextProcessVariables(execution, nextProcessVars);

			nextProcessVars.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO, recalledByUserRefId);

			String procInstanceId = invokeWorkflowForRecall(nextProcessVars, null, previousFunctionCode);
			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECALL_ASSIGNMENT: Invoked Previous Workflow with procInstanceId: " + procInstanceId);
		} else {

			throw new MotorRepairException(MotorRepairException.PROCESS_ERR,
					"Task cannot be recalled by: 'null' user reference Id", null);
		}

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; RECALL_ASSIGNMENT: END");
	}

}
