package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.services.ARCRepairEstimatesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610051
 * 
 */
@Controller
@EnableSwagger
@RequestMapping(value = "arcRepairEstimatesService")
public class ARCRepairEstimatesController {

	/** The ARCRepairEstimates Service */
	@Autowired
	private ARCRepairEstimatesService arcRepairEstimatesService;

	/**
	 * This method is used for creating and updating ARCRepairEstimates.
	 * 
	 * @param ARCRepairEstimatesDTO
	 *            The arcRepairEstimatesDTO
	 * 
	 * @return Boolean
	 */
	@RequestMapping(value = "/createUpdateARCRepairEstimates", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates ARCRepairEstimates with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateARCRepairEstimates(@RequestBody ARCRepairEstimatesDTO arcRepairEstimatesDTO) {

		return arcRepairEstimatesService.createUpdateARCRepairEstimates(arcRepairEstimatesDTO);
	}

	/**
	 * This method is used for deleting ARCRepairEstimates.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * 
	 * @return Boolean
	 */

	@RequestMapping(value = "/deleteARCRepairEstimatesByArcRepairEstimateId/{arcRepairEstimateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete ARCRepairEstimates By ArcRepairEstimate Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ArcRepairEstimate Id value") })
	public @ResponseBody Boolean deleteARCRepairEstimatesByArcRepairEstimateId(
			@ApiParam(value = "ArcRepairEstimate Id to delete", required = true) @PathVariable("arcRepairEstimateId") Long arcRepairEstimateId) {
		try {
			return arcRepairEstimatesService.deleteARCRepairEstimatesByArcRepairEstimateId(arcRepairEstimateId);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method is used for retrieving ARCRepairEstimates based on
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * 
	 * @return ARCRepairEstimatesDTO
	 * 
	 */
	@RequestMapping(value = "/getARCRepairEstimatesByARCRepairEstimateId/{arcRepairEstimateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCRepairEstimates By ArcRepairEstimate Id", notes = "Returns a ARCRepairEstimates entity when ArcRepairEstimate Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid ArcRepairEstimate Id supplied"),
			@ApiResponse(code = 404, message = "ArcRepairEstimate not found") })
	public @ResponseBody ARCRepairEstimatesDTO getARCRepairEstimatesByARCRepairEstimateId(
			@ApiParam(value = "ArcRepairEstimate Id of the ARCRepairEstimates that needs to be fetched", required = true) @PathVariable("arcRepairEstimateId") Long arcRepairEstimateId) {
		return arcRepairEstimatesService.getARCRepairEstimatesByARCRepairEstimateId(arcRepairEstimateId);
	}

	/**
	 * 
	 * This method is used for retrieving all ARCRepairEstimates.
	 * 
	 * @return List of ARCRepairEstimatesDTO
	 */
	@RequestMapping(value = "/getAllARCRepairEstimates", method = RequestMethod.GET)
	@ApiOperation(value = "Find All ARCRepairEstimates", notes = "Returns a ARCRepairEstimates entity ", response = ARCRepairEstimatesDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation") })
	public @ResponseBody List<ARCRepairEstimatesDTO> getAllARCRepairEstimates() {
		return arcRepairEstimatesService.getAllARCRepairEstimates();
	}

}
