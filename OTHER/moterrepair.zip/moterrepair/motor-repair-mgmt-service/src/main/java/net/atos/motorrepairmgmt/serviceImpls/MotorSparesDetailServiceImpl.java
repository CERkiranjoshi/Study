/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorSparesDetail;
import net.atos.motorrepairmgmt.repository.MotorSparesDetailRepository;
import net.atos.motorrepairmgmt.services.MotorSparesDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

/**
 * @author a603327
 * 
 */
@Component
public class MotorSparesDetailServiceImpl implements MotorSparesDetailService {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorSparesDetailServiceImpl.class);
	/**
	 * The Dozer Bean Mapper
	 */
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	/** The MotorSparesDetail Repository */
	@Autowired
	private MotorSparesDetailRepository motorSparesDetailRepository;

	/** The UniqueIdGenerator */
	@Autowired
	UniqueIdGenerator uniqueIdGenerator;

	/**
	 * The method retrieves all the MotorSparesDetail
	 * 
	 * @return List of MotorSparesDetail DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<MotorSparesDetailDTO> getAllMotorSparesDetail() {
		LOGGER.info("MotorSparesDetailServiceImpl : getAllMotorSparesDetail : Start");
		List<MotorSparesDetailDTO> motorSparesDetailDTOs = null;
		List<MotorSparesDetail> motorSparesDetails = motorSparesDetailRepository.findAll();
		if (null != motorSparesDetails) {
			motorSparesDetailDTOs = new ArrayList<MotorSparesDetailDTO>();
			for (MotorSparesDetail motorSparesDetailRecord : motorSparesDetails) {
				MotorSparesDetailDTO motorSparesDetailDTO = new MotorSparesDetailDTO();
				motorSparesDetailDTO = dozerBeanMapper.map(motorSparesDetailRecord, MotorSparesDetailDTO.class);
				motorSparesDetailDTOs.add(motorSparesDetailDTO);
			}
		}
		LOGGER.info("MotorSparesDetailServiceImpl : getAllMotorSparesDetail : End");
		return motorSparesDetailDTOs;
	}

	/**
	 * The deletes a MotorSparesDetail on the basis its materialId.
	 * 
	 * @param materialId
	 *            The MotorSparesDetail materialId
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteMotorSparesDetail(Long materialId) {
		LOGGER.info("MotorSparesDetailServiceImpl : deleteMotorSparesDetail() : Start");
		try {
			if (null != materialId) {
				motorSparesDetailRepository.delete(materialId);
				return true;
			}
		} catch (Exception e) {
			LOGGER.info("Error in deletion " + e);
			return false;
		}
		LOGGER.info("MotorSparesDetailServiceImpl : deleteMotorSparesDetail() : End");
		return false;
	}

	/**
	 * The method creates/updates a motorSparesDetail record. The method
	 * performs an update operation when materialId is passed and an existing
	 * record with matching materialId is fetched for updation.
	 * 
	 * @param motorSparesDetailDTO
	 *            The MotorSparesDetail Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateMotorSparesDetail(MotorSparesDetailDTO motorSparesDetailDTO) {
		LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorSparesDetail() : Start");
		MotorSparesDetail motorSparesDetails = new MotorSparesDetail();
		Long id = -1l;
		if (null != motorSparesDetailDTO) {
			if (null != motorSparesDetailDTO.getMaterialId()) {
				motorSparesDetails = motorSparesDetailRepository.findOne(motorSparesDetailDTO.getMaterialId());
			}
			BeanUtils.copyProperties(motorSparesDetailDTO, motorSparesDetails,
					NullPropertyMapper.getNullPropertyNames(motorSparesDetailDTO));

			motorSparesDetailRepository.save(motorSparesDetails);
			LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorSparesDetail() : Record Saved/Updated");
			id = motorSparesDetails.getMaterialId();
		}
		LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorSparesDetail() : Not saved");
		return id;
	}

	/**
	 * The method retrieves a MotorSparesDetail on the basis of material Id
	 * 
	 * @param motorSparesDetail
	 *            id The MotorSparesDetail materialId
	 * @return MotorSparesDetailDTO
	 * 
	 */
	@Override
	public MotorSparesDetailDTO getMotorSparesDetailById(Long materialId) {
		LOGGER.info("MotorSparesDetailServiceImpl : getMotorSparesDetailById : Start");
		MotorSparesDetailDTO motorSparesDetailDTO = null;
		if (null != materialId) {
			MotorSparesDetail motorSparesDetails = motorSparesDetailRepository.findOne(materialId);
			if (null != motorSparesDetails) {
				motorSparesDetailDTO = dozerBeanMapper.map(motorSparesDetails, MotorSparesDetailDTO.class);
			}
		}
		LOGGER.info("MotorSparesDetailServiceImpl : getMotorSparesDetailById : End");
		return motorSparesDetailDTO;
	}
	
	@Override
	public MotorSparesDetailDTO getMotorSparesDetailByMaterialIdandTenantIdandSolCatId(
			Long materialId, String tenantId, String solutionCategoryId) {
		LOGGER.info("MotorSparesDetailServiceImpl : getMotorSparesDetailByMaterialIdandTenantIdandSolCatId : Start");
		 
		MotorSparesDetailDTO motorSparesDetailDTO=null;
		MotorSparesDetail motorSparesDetails=null;
		if (null != materialId && null != tenantId && null != solutionCategoryId) {
			motorSparesDetails = motorSparesDetailRepository.findMotorSparesDetailsByMaterialIdAndTenantIdAndSolCatId(materialId,tenantId,
					solutionCategoryId);
		}
		if (null != motorSparesDetails ) {
			
			motorSparesDetailDTO=new MotorSparesDetailDTO();
			motorSparesDetailDTO= dozerBeanMapper.map(motorSparesDetails, MotorSparesDetailDTO.class);
		}
		LOGGER.info("MotorSparesDetailServiceImpl : getMotorSparesDetailByMaterialIdandTenantIdandSolCatId : End");
		return motorSparesDetailDTO;
	}

}
