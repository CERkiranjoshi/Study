/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;
import net.atos.motorrepairmgmt.entity.TemplateInfo;
import net.atos.motorrepairmgmt.repository.TemplateInfoRepository;
import net.atos.motorrepairmgmt.services.TemplateInfoService;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author a593775
 * 
 */
@Service
public class TemplateInfoServiceImpl implements TemplateInfoService {

	@Autowired
	private TemplateInfoRepository templateInfoRepository;

	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.EmailTemplateInfoService#findEmailTemplateInfoByFunCodeNEmailCode(java.lang
	 * .String, java.lang.String)
	 */
	@Override
	public List<TemplateInfoDTO> findTemplateInfoByFunCodeNEmailCode(String functionCode, String emailCode) {
		List<TemplateInfo> emailTemplateInfo = null;
		if (null != emailCode) {
			List<String> codeList = new ArrayList<String>(Arrays.asList(emailCode.split(",")));
			emailTemplateInfo = templateInfoRepository.getTemplateInfoByFunCodeNEmailCode(functionCode, codeList);
		} else {
			// fetch with functioncode
			emailTemplateInfo = templateInfoRepository.getTemplateInfoByFunctionCode(functionCode);
			
		}
		List<TemplateInfoDTO> templateInfoDTOList = new ArrayList<TemplateInfoDTO>();
		for (TemplateInfo templateInfo : emailTemplateInfo) {
			templateInfoDTOList.add(dozerBeanMapper.map(templateInfo, TemplateInfoDTO.class));
		}

		return templateInfoDTOList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.TemplateInfoService#findTemplateInfoByFunCodeNNotificationType(java.lang.String
	 * , java.lang.Integer)
	 */
	@Override
	public List<TemplateInfoDTO> findTemplateInfoByFunCodeNNotificationType(String functionCode,
			Integer notificationType) {
		List<TemplateInfo> emailTemplateInfo = null;
		if (null != notificationType) {
			emailTemplateInfo = templateInfoRepository.getTemplateInfoByFunCodeNNotificationType(functionCode,
					notificationType);
		}
		List<TemplateInfoDTO> templateInfoDTOList = new ArrayList<TemplateInfoDTO>();
		for (TemplateInfo templateInfo : emailTemplateInfo) {
			templateInfoDTOList.add(dozerBeanMapper.map(templateInfo, TemplateInfoDTO.class));
		}

		return templateInfoDTOList;
	}

}
