package net.atos.motorrepairmgmt.services;

import java.sql.SQLException;
import java.util.List;

import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;
import net.atos.motorrepairmgmt.dto.RMTTaskLogDTO;
import net.atos.motorrepairmgmt.dto.SearchByParameterDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.utils.MotorRepairException;

public interface SubProcessFieldsService {

	public Long createUpdateSubProcessFields(SubProcessFieldsDTO subProcessFieldsDTO) throws MotorRepairException;

	public List<SubProcessFieldsDTO> getAllSubProcessFieldsByTenantId(String tenantId);

	public SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessId(Long wlfwSubProcessId);

	public List<SubProcessFieldsDTO> getSubProcessFieldsByFrameSize(Integer frameSize);

	public List<SubProcessFieldsDTO> getSubProcessFieldsByGrnVrreId(String grnVrreId);

	public List<MotorSparesDetailDTO> getMotorSparesDetailsByWlfwSubProcessId(Long wlfwSubProcessId);

	public List<MotorOrderDetailDTO> getMotorOrderDetailByWlfwSubProcessId(Long wlfwSubProcessId);

	public List<ParallelProcessDTO> getParallelProcessByWlfwSubProcessId(Long wlfwSubProcessId);

	public Boolean deleteSubProcessFieldsByWlfwSubProcessId(Long wlfwSubProcessId);

	public Long addParallelProcessToSubProcessField(Long wlfwSubProcessId,
			List<ParallelProcessDTO> parallelProcessDetailDTOList);

	public Long addUpdateMotorOrderDetailsToSubProcessDetail(Long wlfwSubProcessId,
			List<MotorOrderDetailDTO> motorOrderDetailDTOs);

	public Long addUpdateFSEVisitDetailsToSubProcessDetail(Long wlfwSubProcessId,
			List<FSEVisitDetailDTO> fSEVisitDetailDTOs);

	public List<MotorAttachmentDetailDTO> getMotorAttachmentDetailByWlfwSubProcessId(Long wlfwSubProcessId);

	public List<FSEVisitDetailDTO> getFSEVisitDetailByWlfwSubProcessId(Long wlfwSubProcessId);

	public Long addMotorAttachmentDetailToSubProcessFields(Long wlfwSubProcessId,
			List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOList);
                                                                                                          
	public Long addMotorSparesDetailToSubProcessFields(Long wlfwSubProcessId,
			List<MotorSparesDetailDTO> motorSparesDetailDTOList);

	public Long getARCRefIdBySubProcessId(Long subProcessId);  
	
	public List<SearchByParameterDTO> searchByParameter(SearchByParameterDTO searchByParameterDTO);
	
	public SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessIdandTenantIdandSolCatId(Long wlfwSubProcessId, String tenantId,String solutionCategoryId);
	
	public Long saveMultipleSubProcessFields(SubProcessFieldsDTO subProcessFieldsDTO);
	public SubProcessFieldsDTO getSubprocessFieldWithMotorDetailsByMasterworkflowId(Long processVariableId);

	public List<RMTTaskLogDTO> getWorkLogBySubProcessFieldsBy(Long wlfwSubProcessId) throws SQLException;
	
	public Boolean deleteMultipleSubProcessFieldsForGroup(List<Long> subprocessIdList);
}
