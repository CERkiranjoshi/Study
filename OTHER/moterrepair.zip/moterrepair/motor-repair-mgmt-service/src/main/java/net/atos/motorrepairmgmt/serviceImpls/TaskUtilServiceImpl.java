/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.Date;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.services.TaskUtilService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.taskmgmt.activiti.engine.TaskManagementService;
import net.atos.taskmgmt.activiti.mapper.ProcessVariableMapper;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.ClaimDTO;
import net.atos.taskmgmt.common.dto.TaskDTO;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.common.dto.TaskFilter;
import net.atos.taskmgmt.common.dto.TaskStatus;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service implementation to claim all active tasks for a given subprocessId.
 * 
 * @author Anand Ved
 * 
 */
@Service
public class TaskUtilServiceImpl implements TaskUtilService {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(TaskUtilServiceImpl.class);

	@Autowired
	private TaskManagementService taskMgmtService;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.atos.motorrepairmgmt.services.ClaimWorkflowService#claimAllTasks( java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public String claimAllTasks(String tenantId, String programId, Long subprocessId, String userRefId,String assignedToEmail) {
		// Fetch subprocess workflow id
		LOGGER.info("TASK_UTIL_SERVICE: CLAIM ALL TASKS: tenantId is " + tenantId + "; programId is " + programId
				+ "; subProcessId is " + subprocessId + "; userRefId is " + userRefId);
		if (null == subprocessId) {
			// Subprocess Workflow Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: CLAIM ALL TASKS:  Fetched SubprocessWorkflow ID is null");
		}
		if (null == tenantId) {
			// Tenant Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: CLAIM ALL TASKS: Fetched tenant ID is null");
		}
		if (null == programId) {
			// program Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: CLAIM ALL TASKS: Fetched program ID is null");
		}
		if (null == userRefId) {
			// program Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: CLAIM ALL TASKS: Fetched userRefId is null");
		}

		if (LOGGER.isDebugEnabled())
			LOGGER.debug("TASK_UTIL_SERVICE: CLAIM ALL TASKS: Fetched SubprocessWorkflow ID: " + subprocessId);
		// Get all active tasks by Subprocess Workflow Id

		TaskFilter taskFilter = new TaskFilter();
		taskFilter.setTenantId(tenantId);
		taskFilter.setProgramId(programId.toString());
		taskFilter.setProcessVariablesId(subprocessId);
		taskFilter.setStatus(TaskStatus.New.toString());

		List<TaskDTO> activeTasks = taskMgmtService.getAllTasks(taskFilter);

		// generate unique id and assign as reclaim id
		LOGGER.info("active task size is " + activeTasks.size());
		String reclaimId = uniqueIdGenerator.generateUniqueId();

		// Iterate over tasks and mark them closed. Ensure that the
		// benchmark states for these tasks are set to 6: RECLAIMED
		for (TaskDTO taskDTO : activeTasks) {
			// set user who invoked this reclaim workflow
			// COMMIT this Task DTO
			ClaimDTO claimDTO = new ClaimDTO();
			claimDTO.setAssignedToEmail(assignedToEmail);
			claimDTO.setTaskId(taskDTO.getTaskId());
			claimDTO.setUserId(userRefId);
			TaskDetailsDTO taskDetailsDTO = taskMgmtService.claimTask(claimDTO);

			taskDetailsDTO.setActualEndDate(new Date());

			try {
				Map<String, Object> procVariables = ProcessVariableMapper.createTaskManagerVariables(taskDetailsDTO);

				// SET PROCESS VARIABLES
				// 1. ${CHECK_ACCEPT== "REJECT"}
				// 2. ${RECLAIM_WORKFLOW_NAME}
				// 3. ANY OTHER PROC VARS AS required by
				// net.atos.motorrepairmgmt.services.delegate.invokers.ReclaimWorkflowHandler
				procVariables.put(ActivitiConstants.CHECK_ACCEPT, ActivitiConstants.RECLAIMED_WORKFLOW);
				procVariables.put(ActivitiConstants.RECLAIM_ID, reclaimId);

				taskMgmtService.completeTask(taskDetailsDTO.getTaskId(), procVariables, taskDetailsDTO);
				LOGGER.info("TASK_UTIL_SERVICE: CLAIM ALL TASKS: completed task for task id "
						+ taskDetailsDTO.getTaskId() + "; Reclaim Id: " + reclaimId);
			} catch (Exception e) {
				LOGGER.error("TASK_UTIL_SERVICE: CLAIM ALL TASKS: Fetched SubprocessWorkflow ID: ", e);
				e.printStackTrace();
			}

		}
		return reclaimId;

	}

	private String processTask(String taskId, String userRefId, String closeReason, String functionCode)
			throws Exception {
		LOGGER.info("TASK_UTIL_SERVICE: PROCESS TASK: START userRefId is " + userRefId + "; taskId is " + taskId
				+ "; closeReason is " + closeReason + "; functionCode is" + functionCode);
		// set user who invoked this
		TaskDetailsDTO taskDetailsDTO = taskMgmtService.claimTask(taskId, userRefId);

		taskDetailsDTO.setActualEndDate(new Date());

		Map<String, Object> procVariables = ProcessVariableMapper.createTaskManagerVariables(taskDetailsDTO);

		// SET PROCESS VARIABLES
		// 1. ${CHECK_ACCEPT== "REJECT"}
		// 2. ${RECLAIM_WORKFLOW_NAME}
		// 3. ANY OTHER PROC VARS AS required by
		// net.atos.motorrepairmgmt.services.delegate.invokers.ReclaimWorkflowInvoker
		procVariables.put(ActivitiConstants.CHECK_ACCEPT, closeReason);
		procVariables.put(ActivitiConstants.FUNCTION_CODE, functionCode);
		procVariables.put(ActivitiConstants.TASK_RECALLED_BY, userRefId);
		taskMgmtService.completeTask(taskDetailsDTO.getTaskId(), procVariables, taskDetailsDTO);

		LOGGER.info("TASK_UTIL_SERVICE: PROCESS TASK: END userRefId is " + userRefId + "; taskId is " + taskId
				+ "; closeReason is " + closeReason + "; functionCode is" + functionCode);

		return null;
	}

	@Override
	public String recallTask(String userRefId, String taskId, String prevFunctionCode) {
		LOGGER.info("TASK_UTIL_SERVICE: RECALL TASK: START userRefId is " + userRefId + "; taskId is " + taskId
				+ "; , prevFunctionCode " + prevFunctionCode);
		if (null == userRefId) {
			// userRefId is null
			LOGGER.warn("TASK_UTIL_SERVICE: RECALL TASK: Fetched userRefId is null");

		}
		if (null == taskId) {
			// program Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: RECALL TASK: Fetched taskId is null");
		}
		// Get all active tasks by Subprocess Workflow Id
		try {
			processTask(taskId, userRefId, "RECALLED", prevFunctionCode);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOGGER.info("TASK_UTIL_SERVICE: RECALL TASK: END userRefId is " + userRefId + "; taskId is " + taskId
				+ "; prevFunctionCode is " + prevFunctionCode);
		return null;
	}

	@Override
	public String rejectTask(String userRefId, String taskId, String prevFunctionCode) {
		LOGGER.info("TASK_UTIL_SERVICE: REJECT TASK:  userRefId is " + userRefId + "; taskId is " + taskId
				+ "; , prevFunctionCode " + prevFunctionCode);

		if (null == userRefId) {
			// program Id is null
			LOGGER.warn("TASK_UTIL_SERVICE: REJECT TASK: Fetched userRefId is null");
		}
		// Get all active tasks by Subprocess Workflow Id
		try {
			processTask(taskId, userRefId, "REJECT", prevFunctionCode);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
}
