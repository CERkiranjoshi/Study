package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.repository.MotorNamePlateDetailRepository;
import net.atos.motorrepairmgmt.services.MotorNamePlateDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class MotorNamePlateDetailServicesImpl implements MotorNamePlateDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The MotorNamePlateDetail Repository */
	@Autowired
	private MotorNamePlateDetailRepository motorNamePlateDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorNamePlateDetailServicesImpl.class);

	/**
	 * The method creates/updates a MotorNamePlateDetail record. The method
	 * performs an update operation when namePlateFieldId is passed and an
	 * existing record with matching namePlateFieldId is fetched for updation.
	 * 
	 * @param motorNamePlateDetailDTO
	 *            The motor NamePlate Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateMotorNamePlateDetail(MotorNamePlateDetailDTO motorNamePlateDetailDTO) {

		LOGGER.info("MotorNamePlateDetailServicesImpl : createUpdateMotorNamePlateDetail : Start");
		Long id = -1l;
		MotorNamePlateDetail motorNamePlateDetail = new MotorNamePlateDetail();
		try {
			if (null != motorNamePlateDetailDTO) {

				if (null != motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {

					motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
							.getMotorNamePlateFieldsId());
					if (null != motorNamePlateDetail) {
						motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
						motorNamePlateDetailDTO.setMfgDate(new Date());
					}
				} else {

					motorNamePlateDetailDTO.setCreatedOn(new Date());
					motorNamePlateDetailDTO.setMfgDate(new Date());
				}

				BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
						NullPropertyMapper.getNullPropertyNames(motorNamePlateDetailDTO));

				MotorNamePlateDetail savedObj = motorNamePlateDetailRepository.save(motorNamePlateDetail);

				LOGGER.info("MotorNamePlateDetailServicesImpl : createUpdateMotorNamePlateDetail : Record Saved/Updated");

				if (savedObj != null) {
					id = savedObj.getMotorNamePlateFieldsId();
				}
			} else {
				LOGGER.info("MotorNamePlateDetailServicesImpl : createUpdateMotorNamePlateDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return id;
	}

	/**
	 * The method retrieves all the motorNamePlateDetail
	 * 
	 * @return List of MotorNamePlateDetail DTOs
	 * 
	 */
	@Override
	public List<MotorNamePlateDetailDTO> getAllMotorNamePlateDetail() {

		LOGGER.info("MotorNamePlateDetailServicesImpl : getAllMotorNamePlateDetail : Start");

		List<MotorNamePlateDetailDTO> motorNamePlateDetailDTOs = null;

		List<MotorNamePlateDetail> motorNamePlateDetails = motorNamePlateDetailRepository.findAll();

		if (null != motorNamePlateDetails) {
			motorNamePlateDetailDTOs = new ArrayList<MotorNamePlateDetailDTO>();

			MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;

			for (MotorNamePlateDetail motorNamePlateDetailRecord : motorNamePlateDetails) {
				motorNamePlateDetailDTO = new MotorNamePlateDetailDTO();

				motorNamePlateDetailDTO = dozerBeanMapper
						.map(motorNamePlateDetailRecord, MotorNamePlateDetailDTO.class);

				motorNamePlateDetailDTOs.add(motorNamePlateDetailDTO);
			}
		}
		LOGGER.info("MotorNamePlateDetailServicesImpl : getAllMotorNamePlateDetail : End");
		return motorNamePlateDetailDTOs;
	}

	/**
	 * The method retrieves a MotorNamePlateDetail on the basis of
	 * namePlateField id.
	 * 
	 * @param NamePlateFieldId
	 *            The namePlateField Id
	 * @return MotorNamePlateDetail DTO
	 * 
	 */
	@Override
	public MotorNamePlateDetailDTO getNamePlateByNamePlateId(Long namePlateFieldId) {
		LOGGER.info("MotorNamePlateDetailServicesImpl : getMotorNamePlateDetailByNamePlateFieldId : Start");
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		if (null != namePlateFieldId) {
			MotorNamePlateDetail motorNamePlateDetails = motorNamePlateDetailRepository.findOne(namePlateFieldId);

			if (null != motorNamePlateDetails) {
				motorNamePlateDetailDTO = dozerBeanMapper.map(motorNamePlateDetails, MotorNamePlateDetailDTO.class);
			}
		}
		LOGGER.info("MotorNamePlateDetailServicesImpl : getMotorNamePlateDetailByNamePlateFieldId : End");
		return motorNamePlateDetailDTO;
	}

	/**
	 * The deletes a MotorNamePlateDetail on the basis its namePlateField id.
	 * 
	 * @param namePlateFieldId
	 *            The NamePlateField Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMotorNamePlateDetailByNamePlateFieldId(Long namePlateFieldId) {
		LOGGER.info("MotorNamePlateDetailServicesImpl : deleteMotorNamePlateDetailByNamePlateFieldId : Start");
		boolean returnVal = false;
		try {
			if (null != namePlateFieldId) {
				motorNamePlateDetailRepository.delete(namePlateFieldId);
				returnVal = true;
			} else {
				LOGGER.info("MotorNamePlateDetailServicesImpl : deleteMotorNamePlateDetailByNamePlateFieldId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}