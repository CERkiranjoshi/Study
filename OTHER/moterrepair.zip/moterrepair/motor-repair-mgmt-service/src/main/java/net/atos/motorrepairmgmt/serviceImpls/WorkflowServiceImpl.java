package net.atos.motorrepairmgmt.serviceImpls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.repository.WorkflowRepository;
import net.atos.motorrepairmgmt.services.WorkflowService;
/**
 * @author a610013
 * 
 */
@Service
public class WorkflowServiceImpl implements WorkflowService {

	@Autowired
	private WorkflowRepository workflowRepository;
	
	@Override
	@Transactional
	public String generateCSVForAllWorkflowData(String gspRefNo,String wlfwSubProcessId) {
		return workflowRepository.findAllMasterWorkflowFieldsWorkflow(gspRefNo,wlfwSubProcessId);
	}
}
