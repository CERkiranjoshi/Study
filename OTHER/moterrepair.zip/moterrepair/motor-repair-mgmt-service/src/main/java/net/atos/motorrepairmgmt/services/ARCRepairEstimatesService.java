package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;

/**
 * @author a610051
 * 
 */
public interface ARCRepairEstimatesService {

	Long createUpdateARCRepairEstimates(ARCRepairEstimatesDTO arcRepairEstimatesDTO);

	Boolean deleteARCRepairEstimatesByArcRepairEstimateId(Long arcRepairEstimateId);

	ARCRepairEstimatesDTO getARCRepairEstimatesByARCRepairEstimateId(Long arcRepairEstimateId);

	List<ARCRepairEstimatesDTO> getAllARCRepairEstimates();
}
