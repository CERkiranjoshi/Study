/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component(value = "motorRoadPermitReqdEmailNotifier")
public class MotorRoadPermitReqdEmailNotifier extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorRoadPermitReqdEmailNotifier.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID) + "; masterWorkflowId: "
				+ execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
				+ "; MOTOR_ROAD_PERMIT_EMAIL_NOTIFIER: START " + execution.getId());

		// execution.setVariable(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG, 1);

		LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID) + "; masterWorkflowId: "
				+ execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
				+ "; MOTOR_ROAD_PERMIT_EMAIL_NOTIFIER: END " + execution.getId());
	}

}
