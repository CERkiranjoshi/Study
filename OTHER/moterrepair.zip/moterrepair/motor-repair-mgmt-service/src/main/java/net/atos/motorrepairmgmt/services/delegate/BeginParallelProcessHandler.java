/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.entity.ParallelProcess;
import net.atos.motorrepairmgmt.repository.ParallelProcessRepository;
import net.atos.motorrepairmgmt.services.delegate.invokers.BaseWorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component(value = "beginParallelProcessHandler")
public class BeginParallelProcessHandler extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BeginParallelProcessHandler.class);

	/**
	 * Unique Id Generator
	 */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Parallel Process Repository
	 */
	@Autowired
	private ParallelProcessRepository parallelProcessRepository;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID) + "; masterWorkflowId: "
				+ execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
				+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: START " + execution.getId());
		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT FUNCTION_CODE
		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.PREV_FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.PREV_FUNCTION_CODE).toString() : null;

		String parallelProcessType = (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE)) ? execution
				.getVariable(ActivitiConstants.PARALLEL_PROCESS_TYPE).toString() : null;

		Map<String, Object> nextProcessVars = new HashMap<String, Object>();
		setNextProcessVariables(execution, nextProcessVars);

		String parallelProcessId = uniqueIdGenerator.generateUniqueId();

		// Set only required process variables from the workflow
		nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_ID, parallelProcessId);
		nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_TYPE, parallelProcessType);

		if (null != parallelProcessType) {

			// IF CURRENT FUNCTION CODE is FOR B & D Report Approval, 2 new processes are invoked.
			if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.A.toString().equals(parallelProcessType)) {

				LOGGER.info(" subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [A] " + execution.getId()
						+ "; Begining Parallel Process A with ParallelProcessID: " + parallelProcessId);
				// BEGIN INVOKE Parallel Process A

				String[] functionCodes = { MotorRepairConstants.ARC_BEGIN_REPAIRS,
						MotorRepairConstants.CCC_PREPARES_SPARES };

				for (String functionCode : functionCodes) {

					long parallelProcessThreadId = uniqueIdGenerator.generateLongUniqueId();
					nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID, parallelProcessThreadId);

					// invoke ARC Begin Repairs
					String newProcessInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [A] " + execution.getId()
							+ "; Process for functionCode: " + functionCode + " invoked; ParallelProcessID: "
							+ parallelProcessId + "; procInstId: " + newProcessInstanceId);

					// create parallel Process Id object
					createNewParallelProcess(execution, newProcessInstanceId, parallelProcessId, functionCode,
							previousFunctionCode, parallelProcessThreadId,
							MotorRepairConstants.PARALLEL_PROCESS_TYPES.A.getValue());
				}

				// END INVOKE Parallel Process A

			} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.B.toString().equals(parallelProcessType)) {

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [B] " + execution.getId()
						+ "; Begining Parallel Process B with ParallelProcessID: " + parallelProcessId);
				// INVOKE Parallel Process B

				// Set Function Code of the Next Workflow to be executed

				String[] functionCodes = { MotorRepairConstants.CCC_LINK_ORDER_INT_SPARES,
						MotorRepairConstants.RCS_PERFORMA_INVOICE, MotorRepairConstants.ARC_BEGIN_REPAIRS };

				for (String functionCode : functionCodes) {
                    //SKIP THIS IN CASE OF FSE VISIT WITH SPARES & DISPATCH ONLY SPARES
					if (MotorRepairConstants.ARC_BEGIN_REPAIRS.equals(functionCode)) {
						// TODO SET FLAG FOR ARC_BEGIN_REPAIRS IF NON-SPARES CASE
						if ((null != execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES))
								&& (execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES).toString().equals("1") ||
										execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES).
										toString().equals("3"))) {
							// DO NOT PROCESS ARC_BEGIN_REPAIRS Flow
							continue;
						}
					}

					if (MotorRepairConstants.RCS_PERFORMA_INVOICE.equals(functionCode)) {
						// TODO SET FLAG FOR ARC_BEGIN_REPAIRS IF NON-SPARES CASE
						if ((null != execution.getVariable(ActivitiConstants.CHECK_CTS_STATE))
								&& (execution.getVariable(ActivitiConstants.CHECK_CTS_STATE).toString().equals("1"))) {
							// DO NOT PROCESS RCS_PERFORMA_INVOICE Flow
							continue;
						}
					}
					
					if (MotorRepairConstants.CCC_LINK_ORDER_INT_SPARES.equals(functionCode)) {
						// DO NOT PROCESS CCC_LINK_ORDER_INT_SPARES Flow if FS has already visited && is Dispatch
						// Only Spares case & FSE REVISIT with spares case instead switch the flow to go to OEC for Processing Spares Procurement
						if (((null != execution.getVariable(ActivitiConstants.CHECK_FS_VISITED)) && (execution
								.getVariable(ActivitiConstants.CHECK_FS_VISITED).toString().equals("1")))
								&& ((null != execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES)) && ((execution
										.getVariable(ActivitiConstants.CHECK_ONLY_SPARES).toString().equals("1"))
										||( execution.getVariable(ActivitiConstants.CHECK_ONLY_SPARES).toString().equals("3"))))) {
							functionCode = MotorRepairConstants.OEC_PROCESS_SPARES_PROCURMENT;
						}
					}

					long parallelProcessThreadId = uniqueIdGenerator.generateLongUniqueId();

					// set parallel process thread id in process variables
					nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID, parallelProcessThreadId);
					nextProcessVars.put(ActivitiConstants.ARC_REF_ID,
							execution.getVariable(ActivitiConstants.ARC_REF_ID));
					nextProcessVars.put(ActivitiConstants.ARC_TYPE, execution.getVariable(ActivitiConstants.ARC_TYPE));
					nextProcessVars.put(ActivitiConstants.ARC_NAME, execution.getVariable(ActivitiConstants.ARC_NAME));

					// invoke ARC Begin Repairs
					String newProcessInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [B] " + execution.getId()
							+ "; Process for functionCode: " + functionCode + " invoked; ParallelProcessID: "
							+ parallelProcessId + "; procInstId: " + newProcessInstanceId);

					// create parallel Process Id object
					createNewParallelProcess(execution, newProcessInstanceId, parallelProcessId, functionCode,
							previousFunctionCode, parallelProcessThreadId,
							MotorRepairConstants.PARALLEL_PROCESS_TYPES.B.getValue());

				}

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: [B] " + execution.getId()
						+ "; Completed Invoking Parallel Process B with ParallelProcessID: " + parallelProcessId);
				// END INVOKE Parallel Process B
			} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.C.toString().equals(parallelProcessType)) {

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [C] " + execution.getId()
						+ "; Begining Parallel Process C with ParallelProcessID: " + parallelProcessId);
				// INVOKE Parallel Process C

				// Set Function Code of the Next Workflow to be executed

				String[] functionCodes = { MotorRepairConstants.ARC_DISPATCH_MOTOR,
						MotorRepairConstants.CCC_CS_SALES_ORDER };

				for (String functionCode : functionCodes) {

					long parallelProcessThreadId = uniqueIdGenerator.generateLongUniqueId();

					// set parallel process thread id in process variables
					nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID, parallelProcessThreadId);
					nextProcessVars.put(ActivitiConstants.ARC_REF_ID,
							execution.getVariable(ActivitiConstants.ARC_REF_ID));
					nextProcessVars.put(ActivitiConstants.ARC_TYPE, execution.getVariable(ActivitiConstants.ARC_TYPE));
					nextProcessVars.put(ActivitiConstants.ARC_NAME, execution.getVariable(ActivitiConstants.ARC_NAME));
					nextProcessVars.put(ActivitiConstants.CHECK_SENT_TO_PARAS, 1);
					// set flow type
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; setting flow type as Replacement ");
					nextProcessVars.put(MotorRepairConstants.CHECK_FLOW_TYPE,
							MotorRepairConstants.FLOW_TYPE.REPLACEMENT.toString());
					//

					// invoke ARC Begin Repairs
					String newProcessInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [C] " + execution.getId()
							+ "; Process for functionCode: " + functionCode + " invoked; ParallelProcessID: "
							+ parallelProcessId + "; procInstId: " + newProcessInstanceId);

					// create parallel Process Id object
					createNewParallelProcess(execution, newProcessInstanceId, parallelProcessId, functionCode,
							previousFunctionCode, parallelProcessThreadId,
							MotorRepairConstants.PARALLEL_PROCESS_TYPES.C.getValue());

				}

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: [C] " + execution.getId()
						+ "; Completed Invoking Parallel Process C with ParallelProcessID: " + parallelProcessId);
				// END INVOKE Parallel Process B
			} else if (MotorRepairConstants.PARALLEL_PROCESS_TYPES.D.toString().equals(parallelProcessType)) {

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [D] " + execution.getId()
						+ "; Begining Parallel Process D with ParallelProcessID: " + parallelProcessId);
				// INVOKE Parallel Process D

				// TODO Set Function Code of the Next Workflow to be executed

				String[] functionCodes = { MotorRepairConstants.ARC_DISPATCH_MOTOR,
						MotorRepairConstants.CCC_CS_SALES_ORDER };

				for (String functionCode : functionCodes) {

					long parallelProcessThreadId = uniqueIdGenerator.generateLongUniqueId();

					// set parallel process thread id in process variables
					nextProcessVars.put(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID, parallelProcessThreadId);

					// SET FOR PARAS REPLACEMENT CASE: Warranty - In Warranty; Warranty Subtype - Product Warranty
					nextProcessVars.put(ActivitiConstants.CHECK_WARRANTY,
							MotorRepairConstants.WARRANTY_TYPE.IN_WARRANTY.toString());
					nextProcessVars.put(ActivitiConstants.CHECK_WARRANTY_SUB_TYPE,
							MotorRepairConstants.WARRANTY_SUB_TYPE.PRODUCT_WARRANTY.toString());
					// set flow type
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; setting flow type as Replacement ");
					nextProcessVars.put(MotorRepairConstants.CHECK_FLOW_TYPE,
							MotorRepairConstants.FLOW_TYPE.REPLACEMENT.toString());
					//
					// invoke ARC Begin Repairs
					String newProcessInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
					LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
							+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
							+ "; BEGIN_PARALLEL_PROCESS_INVOKER: [D] " + execution.getId()
							+ "; Process for functionCode: " + functionCode + " invoked; ParallelProcessID: "
							+ parallelProcessId + "; procInstId: " + newProcessInstanceId);

					// create parallel Process Id object
					createNewParallelProcess(execution, newProcessInstanceId, parallelProcessId, functionCode,
							previousFunctionCode, parallelProcessThreadId,
							MotorRepairConstants.PARALLEL_PROCESS_TYPES.D.getValue());
				}

				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: [D] " + execution.getId()
						+ "; Completed Invoking Parallel Process D with ParallelProcessID: " + parallelProcessId);
				// END INVOKE Parallel Process B
			}
		} else {

			LOGGER.warn("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
					+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
					+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: PARALLEL PROCESS TYPE NOT SET!! " + execution.getId());
		}

		LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID) + "; masterWorkflowId: "
				+ execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
				+ "; BEGIN_BEGIN_PARALLEL_PROCESS_INVOKER: END " + execution.getId());
	}

	private ParallelProcess createNewParallelProcess(DelegateExecution execution, String newProcessInstanceId,
			String parallelProcId, String functionCode, String prevFunctionCode, long parallelProcessThreadId,
			String parallelProcessType) {

		ParallelProcess parallelProcess = new ParallelProcess();

		parallelProcess.setParallelProcessThreadId(parallelProcessThreadId);
		parallelProcess.setParallelProcessId(parallelProcId);
		parallelProcess.setParallelProcessType(parallelProcessType);

		LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID) + "; masterWorkflowId: "
				+ execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID) + "; PARALLEL_PROCESS_INVOKER: "
				+ execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNEE));

		parallelProcess.setCreatedByRefId((null != execution
				.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO) ? execution.getVariable(
				ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO).toString() : ((null != execution
				.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP)) ? execution.getVariable(
				ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP).toString() : null))); // TODO user/group who
																								// invoked
		parallelProcess.setCreatedOn(new Date());
		parallelProcess.setInitProcessInsId(execution.getProcessInstanceId());
		parallelProcess.setInitTaskCode(prevFunctionCode);

		parallelProcess.setInitTaskId(String.valueOf(execution.getVariables().get(
				ActivitiConstants.ACTIVITI_PROC_VAR_TASK_ID)));
		parallelProcess.setMasterWorkflowFieldId(Long.parseLong(execution.getVariable(
				ActivitiConstants.MASTER_PROCESS_ID).toString()));
		parallelProcess.setParallelProcessState(MotorRepairConstants.IN_EXEC);
		parallelProcess.setPpBatchProcessId(String.valueOf(execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID)));

		parallelProcess.setProcessInstancId(newProcessInstanceId);
		parallelProcess.setFunctionCode(functionCode);
		// parallelProcess.setTaskId(""); // TODO taskId that was created
		// set tenant Id ,Solution category Id
		parallelProcess.setSolutionCategoryId(String.valueOf(execution
				.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID)));
		parallelProcess
				.setTenantId(String.valueOf(execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID)));
		parallelProcess.setWlfwSubProcessId(Long.parseLong(execution.getVariable(
				ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID).toString()));
		parallelProcess.setCreatedByRefId(String.valueOf(execution
				.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO)));

		return parallelProcessRepository.saveAndFlush(parallelProcess);

	}

}
