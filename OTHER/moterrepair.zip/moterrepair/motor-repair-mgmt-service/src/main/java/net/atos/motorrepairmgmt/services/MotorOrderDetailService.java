/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;

/**
 * @author a603981
 *
 */
public interface MotorOrderDetailService {

	public Long createUpdateMotorOrderDetail(MotorOrderDetailDTO motorOrderDetailDTO);

	public List<MotorOrderDetailDTO> getAllMotorOrderDetail();

	public MotorOrderDetailDTO getMotorOrderDetailByMotorOrderDetailId(Long motorOrderDetailId);

	public Boolean deleteMotorOrderDetailByMotorOrderDetailId(Long motorOrderDetailId);
}
