package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.services.MotorSpeedDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "motorSpeedDetailService")
public class MotorSpeedDetailController {

	@Autowired
	private MotorSpeedDetailService motorSpeedDetailService;

	@RequestMapping(value = "/createUpdateMotorSpeedDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates MotorSpeedDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMotorSpeedDetail(
			@ApiParam(value = "MotorSpeedDetail object that needs to be added or update in the MotorSpeedDetail") @RequestBody MotorSpeedDetailDTO motorSpeedDetailDTO) {
		return motorSpeedDetailService.createUpdateMotorSpeedDetail(motorSpeedDetailDTO);
	}

	@RequestMapping(value = "/getAllMotorSpeedDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSpeedDetail ", notes = "Returns a MotorSpeedDetail entity", response = MotorSpeedDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<MotorSpeedDetailDTO> getAllMotorSpeedDetail() {
		return motorSpeedDetailService.getAllMotorSpeedDetail();
	}

	@RequestMapping(value = "/getSpeedDetailByspeedDetailID/{motorSpeedDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MotorSpeedDetail By MotorSpeedDetail Id", notes = "Returns a MotorSpeedDetail entity when MotorSpeedDetail Id is passed", response = MotorSpeedDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorSpeedDetail Id supplied"),
			@ApiResponse(code = 404, message = "MotorSpeedDetail not found") })
	public @ResponseBody MotorSpeedDetailDTO getSpeedDetailByspeedDetailID(
			@ApiParam(value = "MotorSpeedDetail Id of the MotorSpeedDetail that needs to be fetched", required = true) @PathVariable("motorSpeedDetailId") Long motorSpeedDetailId) {
		return motorSpeedDetailService.getSpeedDetailByspeedDetailId(motorSpeedDetailId);
	}

	@RequestMapping(value = "/deleteMotorSpeedDetailBySpeedDetailID/{motorSpeedDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete MotorSpeedDetail By MotorSpeedDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid MotorSpeedDetail Id value") })
	public @ResponseBody Boolean deleteMotorSpeedDetailBySpeedDetailID(
			@ApiParam(value = "MotorSpeedDetail Id to delete", required = true) @PathVariable("motorSpeedDetailId") Long motorSpeedDetailId) {
		try {
			return motorSpeedDetailService.deleteMotorSpeedDetailBySpeedDetailId(motorSpeedDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}