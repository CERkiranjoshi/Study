package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.services.MotorVoltageDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "motorVoltageDetailService")
public class MotorVoltageDetailController {

	@Autowired
	private MotorVoltageDetailService motorVoltageDetailService;

	@RequestMapping(value = "/createUpdateMotorVoltageDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates MotorVoltageDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMotorVoltageDetail(
			@ApiParam(value = "MotorVoltageDetail object that needs to be added or update in the MotorVoltageDetail") @RequestBody MotorVoltageDetailDTO motorVoltageDetailDTO) {
		return motorVoltageDetailService.createUpdateMotorVoltageDetail(motorVoltageDetailDTO);
	}

	@RequestMapping(value = "/getAllMotorVoltageDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorVoltageDetail ", notes = "Returns a MotorVoltageDetail entity", response = MotorVoltageDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<MotorVoltageDetailDTO> getAllMotorVoltageDetail() {
		return motorVoltageDetailService.getAllMotorVoltageDetail();
	}

	@RequestMapping(value = "/getVoltageDetailByVoltageDetailID/{motorVoltageDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MotorVoltageDetail By MotorVoltageDetail Id", notes = "Returns a MotorVoltageDetail entity when MotorVoltageDetail Id is passed", response = MotorVoltageDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorVoltageDetail Id supplied"),
			@ApiResponse(code = 404, message = "motorVoltageDetail not found") })
	public @ResponseBody MotorVoltageDetailDTO getVoltageDetailByVoltageDetailID(
			@ApiParam(value = "MotorVoltageDetail Id of the MotorVoltageDetail that needs to be fetched", required = true) @PathVariable("motorVoltageDetailId") Long motorVoltageDetailId) {
		return motorVoltageDetailService.getVoltageDetailByVoltageDetailId(motorVoltageDetailId);
	}

	@RequestMapping(value = "/deleteMotorVoltageDetailByMotorVoltageDetailID/{motorVoltageDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete MotorVoltageDetail By MotorVoltageDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid MotorVoltageDetail Id value") })
	public @ResponseBody Boolean deleteMotorVoltageDetailByMotorVoltageDetailID(
			@ApiParam(value = "MotorVoltageDetail Id to delete", required = true) @PathVariable("motorVoltageDetailId") Long motorVoltageDetailId) {
		try {
			return motorVoltageDetailService.deleteMotorVoltageDetailByMotorVoltageDetailId(motorVoltageDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}