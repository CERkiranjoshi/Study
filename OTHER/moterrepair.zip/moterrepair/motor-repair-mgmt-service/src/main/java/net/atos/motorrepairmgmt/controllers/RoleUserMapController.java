/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;


import net.atos.motorrepairmgmt.dto.RoleUserMapDTO;
import net.atos.motorrepairmgmt.services.RoleUserMapService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author Sweety Kothari
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "roleUserMapService")
public class RoleUserMapController {

	@Autowired
	private RoleUserMapService roleUserMapService;
	
	@RequestMapping(value = "/getRefIdByUserName", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Get  Ref Id by user name", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody RoleUserMapDTO getRefIdByUserName(
			@ApiParam(value = " ARC user name") @RequestBody String userName) {
		return roleUserMapService.getARCRefIdByUserName(userName);
	}
}
