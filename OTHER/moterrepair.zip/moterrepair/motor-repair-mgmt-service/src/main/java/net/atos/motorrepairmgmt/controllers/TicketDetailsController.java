package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.TicketDetailsDTO;
import net.atos.motorrepairmgmt.services.TicketDetailsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

@Controller
@EnableSwagger
@RequestMapping(value = "ticketDetails")
public class TicketDetailsController {
	
	@Autowired
	private TicketDetailsService  ticketDeteailsService;

	@RequestMapping(value = "/getAllTicketDetails", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All details", notes = "", response = TicketDetailsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<TicketDetailsDTO> getAllTicketDetails()
	{
		return ticketDeteailsService.getAllTicketDetails();
	}
	
	@RequestMapping(value = "/createUpdateTicketDetails", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  TicketDetails with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateTicketDetails(
			@ApiParam(value = " TicketDetails Data object that needs to be added or update in the TicketDetailsDTO") @RequestBody TicketDetailsDTO ticketDetailDTO) {
		return ticketDeteailsService.createUpdateTicketDetails(ticketDetailDTO);
	}
	
	@RequestMapping(value = "/getTicketDeteailByTicketdetailsId/{ticketdetailsId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find TicketDeteail By ticketdetails Id", notes = "Returns a TicketDeteail entity when ticketdetails Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid ticketdetails Id supplied"),
			@ApiResponse(code = 404, message = "TicketDeteail not found") })
	public @ResponseBody TicketDetailsDTO getTicketDeteailByTicketdetailsId(
			@ApiParam(value = "ticketdetails Id of the TicketDeteail that needs to be fetched", required = true) @PathVariable("ticketdetailsId") Long ticketdetailsId) {
		return ticketDeteailsService.getTicketDeteailByTicketdetailsId(ticketdetailsId);
	}
	
	@RequestMapping(value = "/claimTickets", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  TicketDetails with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean claimTickets(
			@ApiParam(value = " TicketDetails Data object that needs to be added or update in the TicketDetailsDTO") @RequestBody List<TicketDetailsDTO> ticketDetailDTOList) {
		return ticketDeteailsService.claimTickets(ticketDetailDTOList);
	}
	
	@RequestMapping(value = "/getAllTicketDeteailCountByTicketStatus/{functionCode}/{userId}/{arcRefId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find TicketDeteail By ticketdetails Id", notes = "Returns a TicketDeteail entity when ticketdetails Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid ticketdetails Id supplied"),
			@ApiResponse(code = 404, message = "TicketDeteail not found") })
	public @ResponseBody Long getAllTicketDeteailCount(@ApiParam(value = "functionCode of the TicketDeteail that needs to be fetched", required = true) @PathVariable("functionCode") Integer functionCode,
			@ApiParam(value = "user Id of the TicketDeteail that needs to be fetched", required = true) @PathVariable("userId") String userId,
			@ApiParam(value = "arcRef Id of the TicketDeteail that needs to be fetched", required = true) @PathVariable("arcRefId") Long arcRefId) 
			{
		return ticketDeteailsService.getAllTicketDeteailCountByTicketStatus(functionCode,userId,arcRefId);
	}
}
