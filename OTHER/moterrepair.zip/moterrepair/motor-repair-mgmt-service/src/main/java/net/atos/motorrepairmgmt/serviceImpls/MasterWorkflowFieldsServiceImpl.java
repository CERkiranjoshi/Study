package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.MasterWorkflowFieldsDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;
import net.atos.motorrepairmgmt.entity.AdditionalContactDetail;
import net.atos.motorrepairmgmt.entity.CustomerDetail;
import net.atos.motorrepairmgmt.entity.MasterWorkflowFields;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.entity.WorkflowState;
import net.atos.motorrepairmgmt.repository.AdditionalContactDetailRepository;
import net.atos.motorrepairmgmt.repository.CustomerDetailRepository;
import net.atos.motorrepairmgmt.repository.MasterWorkflowFieldsRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.repository.WorkflowStateRepository;
import net.atos.motorrepairmgmt.services.MasterWorkflowFieldsService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610039
 * 
 */
@Service
@Transactional
public class MasterWorkflowFieldsServiceImpl implements MasterWorkflowFieldsService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The MasterWorkflowFields Repository */
	@Autowired
	private MasterWorkflowFieldsRepository masterWorkflowFieldsRepository;

	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The CustomerDetail Repository */
	@Autowired
	private CustomerDetailRepository customerDetailRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/** The AdditionalContactDetail Repository */
	@Autowired
	private AdditionalContactDetailRepository additionalContactDetailRepository;

	@Autowired
	private WorkflowStateRepository workflowStateRepository;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MasterWorkflowFieldsServiceImpl.class);

	/**
	 * The method creates/updates a MasterWorkflowFields record. The method
	 * performs an update operation when MasterWorkflowFieldId is passed and an
	 * existing record with matching MasterWorkflowFieldId is fetched for
	 * updation
	 * 
	 * @param masterWorkflowFieldsDTO
	 *            The MasterWorkflow Fields
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateMasterWorkflowFields(MasterWorkflowFieldsDTO masterWorkflowFieldsDTO) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : createUpdateMasterWorkflowFields : Start");
		MasterWorkflowFields masterWorkflowFields = null;
		List<CustomerDetailDTO> customerDetailDTOs = null;
		List<AdditionalContactDetailDTO> additionalContactDetailDTOs = null;
		WorkflowStateDTO workflowStateDTO = null;
		WorkflowState workflowStateDetails = null;

		Long id = -1l;
		try {
			if (null != masterWorkflowFieldsDTO) {
				if (null != masterWorkflowFieldsDTO.getMasterWorkflowFieldId()) {
					masterWorkflowFields = masterWorkflowFieldsRepository.findOne(masterWorkflowFieldsDTO
							.getMasterWorkflowFieldId());
				} else {

					masterWorkflowFieldsDTO.setCreatedOn(new Date());
				}

				if (null != masterWorkflowFieldsDTO.getCustomerDetails()) {
					customerDetailDTOs = new ArrayList<CustomerDetailDTO>();
					List<CustomerDetail> customerDetailsList = new ArrayList<CustomerDetail>();

					if (null != masterWorkflowFields && null != masterWorkflowFields.getCustomerDetails()) {
						List<CustomerDetailDTO> existCustomerDetailDTOList = new ArrayList<CustomerDetailDTO>();
						List<CustomerDetail> existCustomerDetailList = masterWorkflowFields.getCustomerDetails();
						CustomerDetailDTO customerDetailDTO = null;

						if (null != existCustomerDetailList && existCustomerDetailList.size() > 0) {

							for (CustomerDetail customerDetailRecord : existCustomerDetailList) {
								customerDetailDTO = new CustomerDetailDTO();
								BeanUtils.copyProperties(customerDetailRecord, customerDetailDTO,
										NullPropertyMapper.getNullPropertyNames(customerDetailRecord));
								existCustomerDetailDTOList.add(customerDetailDTO);
							}
							customerDetailDTOs.addAll(existCustomerDetailDTOList);
						}
					}
					if (null == masterWorkflowFields) {
						masterWorkflowFields = new MasterWorkflowFields();
					}
					for (CustomerDetailDTO customerDetailDTO : customerDetailDTOs) {
						CustomerDetail customerDetails = new CustomerDetail();
						BeanUtils.copyProperties(customerDetailDTO, customerDetails,
								getNullPropertyNames(customerDetailDTO));
						customerDetailsList.add(customerDetails);
					}
					masterWorkflowFields.setCustomerDetails(customerDetailsList);
					masterWorkflowFieldsDTO.setCustomerDetails(null);

				}

				if (null != masterWorkflowFieldsDTO.getAdditionalContactDetails()) {
					additionalContactDetailDTOs = new ArrayList<AdditionalContactDetailDTO>();
					List<AdditionalContactDetail> additionalContactDetailsList = new ArrayList<AdditionalContactDetail>();

					if (null != masterWorkflowFields && null != masterWorkflowFields.getAdditionalContactDetails()) {
						List<AdditionalContactDetailDTO> existAdditionalContactDetailsDTOList = new ArrayList<AdditionalContactDetailDTO>();
						List<AdditionalContactDetail> existAdditionalContactDetailsList = masterWorkflowFields
								.getAdditionalContactDetails();
						AdditionalContactDetailDTO additionalContactDetailDTO = null;
						if (null != existAdditionalContactDetailsList && existAdditionalContactDetailsList.size() > 0) {
							for (AdditionalContactDetail additionalContactDetailRecord : existAdditionalContactDetailsList) {
								additionalContactDetailDTO = new AdditionalContactDetailDTO();

								BeanUtils.copyProperties(additionalContactDetailRecord, additionalContactDetailDTO,
										NullPropertyMapper.getNullPropertyNames(additionalContactDetailRecord));

								existAdditionalContactDetailsDTOList.add(additionalContactDetailDTO);
							}
							additionalContactDetailDTOs.addAll(existAdditionalContactDetailsDTOList);
						}
					}

					if (null == masterWorkflowFields) {
						masterWorkflowFields = new MasterWorkflowFields();
					}
					for (AdditionalContactDetailDTO additionalContactDetailDTO : additionalContactDetailDTOs) {
						AdditionalContactDetail additionalContactDetail = new AdditionalContactDetail();
						BeanUtils.copyProperties(additionalContactDetailDTO, additionalContactDetail,
								getNullPropertyNames(additionalContactDetailDTO));
						additionalContactDetailsList.add(additionalContactDetail);
					}
					masterWorkflowFields.setAdditionalContactDetails(additionalContactDetailsList);
					masterWorkflowFieldsDTO.setAdditionalContactDetails(null);

				}

				if (null != masterWorkflowFieldsDTO.getWorkflowState()) {
					workflowStateDTO = masterWorkflowFieldsDTO.getWorkflowState();
					if (null == workflowStateDTO.getWorkflowStateId()) {
						workflowStateDTO.setCreatedOn(new Date());
						workflowStateDTO.setModifiedOn(new Date());
						workflowStateDetails = new WorkflowState();
						if (null == masterWorkflowFields) {
							masterWorkflowFields = new MasterWorkflowFields();
						}
						workflowStateDTO.setCreatedOn(new Date());
						workflowStateDTO.setModifiedOn(new Date());
						masterWorkflowFieldsDTO.setWorkflowState(workflowStateDTO);
						BeanUtils.copyProperties(workflowStateDTO, workflowStateDetails,
								NullPropertyMapper.getNullPropertyNames(workflowStateDTO));

						masterWorkflowFields.setWorkflowState(workflowStateDetails);

						masterWorkflowFieldsDTO.setWorkflowState(null);

					} else {
						workflowStateDetails = workflowStateRepository.findOne(workflowStateDTO.getWorkflowStateId());
						if (null != workflowStateDetails) {
							workflowStateDTO.setCreatedOn(workflowStateDetails.getCreatedOn());
							workflowStateDTO.setModifiedOn(new Date());
						} else {
							workflowStateDTO.setCreatedOn(new Date());
							workflowStateDTO.setModifiedOn(new Date());
						}
						BeanUtils.copyProperties(workflowStateDTO, workflowStateDetails,
								NullPropertyMapper.getNullPropertyNames(workflowStateDTO));

						masterWorkflowFields.setWorkflowState(workflowStateDetails);

						masterWorkflowFieldsDTO.setWorkflowState(null);
					}
				}

				BeanUtils.copyProperties(masterWorkflowFieldsDTO, masterWorkflowFields,
						NullPropertyMapper.getNullPropertyNames(masterWorkflowFieldsDTO));

				MasterWorkflowFields savedObject = masterWorkflowFieldsRepository.save(masterWorkflowFields);
				LOGGER.info("MasterWorkflowFieldsServiceImpl : createUpdateMasterWorkflowFields : Record Saved/Updated");
				if (null != savedObject) {
					id = savedObject.getMasterWorkflowFieldId();
				}

			} else {
				LOGGER.info("MasterWorkflowFieldsServiceImpl : createUpdateMasterWorkflowFields : MasterWorkflowFieldsDTO sent is Null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	/**
	 * The method retrieves all MasterWorkflowFields on the basis its tenantId.
	 * 
	 * @param tenantId
	 *            The tenant Id
	 * @return List of masterWorkflowFields DTO
	 * 
	 */
	@Override
	public List<MasterWorkflowFieldsDTO> getAllMasterWorkflowFieldsByTenantId(String tenantId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getAllMasterWorkflowFieldsByTenantId : Start");
		List<MasterWorkflowFieldsDTO> masterWorkflowFieldsDTOs = null;
		List<MasterWorkflowFields> masterWorkflowFields = masterWorkflowFieldsRepository
				.findAllMasterWorkflowFieldsByTenantId(tenantId);
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = new MasterWorkflowFieldsDTO();
		if (null != masterWorkflowFields && masterWorkflowFields.size() > 0) {
			masterWorkflowFieldsDTOs = new ArrayList<MasterWorkflowFieldsDTO>();
			for (MasterWorkflowFields masterWorkflowFieldsRecord : masterWorkflowFields) {
				masterWorkflowFieldsDTO = dozerBeanMapper
						.map(masterWorkflowFieldsRecord, MasterWorkflowFieldsDTO.class);
				masterWorkflowFieldsDTOs.add(masterWorkflowFieldsDTO);
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getAllMasterWorkflowFieldsByTenantId : End");
		return masterWorkflowFieldsDTOs;
	}

	/**
	 * The method retrieves a MasterWorkflowFields on the basis its
	 * masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The masterWorkflowField Id
	 * @return masterWorkflowFields DTO
	 * 
	 */

	@Override
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByMasterWorkflowFieldId : Start");
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		if (null != masterWorkflowFieldId) {
			MasterWorkflowFields masterWorkflowFields = masterWorkflowFieldsRepository.findOne(masterWorkflowFieldId);
			if (null != masterWorkflowFields) {
				masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFields, MasterWorkflowFieldsDTO.class);
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByMasterWorkflowFieldId : End");
		return masterWorkflowFieldsDTO;
	}

	/**
	 * The method retrieves a MasterWorkflowFields on the basis its tenantId and
	 * solutionCategoryId.
	 * 
	 * @param tenantId
	 *            The Tenant Id
	 * @param solutionCategoryId
	 *            The SolutionCategory Id
	 * @return List of masterWorkflowFields DTO
	 * 
	 */
	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryId(String tenantId,
			String solutionCategoryId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getMasterWorkflowFieldsByMasterWorkflowFieldIdAndSolutionCategoryId : Start");
		List<MasterWorkflowFieldsDTO> masterWorkflowFieldsDTOs = null;
		List<MasterWorkflowFields> masterWorkflowFields = null;
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		if (null != tenantId && null != solutionCategoryId) {
			masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByTenantIdAndSolutionCategoryId(tenantId, solutionCategoryId);
			if (null != masterWorkflowFields && masterWorkflowFields.size() > 0) {
				masterWorkflowFieldsDTOs = new ArrayList<MasterWorkflowFieldsDTO>();
				for (MasterWorkflowFields masterWorkflowFieldsRecord : masterWorkflowFields) {
					masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFieldsRecord,
							MasterWorkflowFieldsDTO.class);
					masterWorkflowFieldsDTOs.add(masterWorkflowFieldsDTO);
				}
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByMasterWorkflowFieldIdAndSolutionCategoryId : End");
		return masterWorkflowFieldsDTOs;
	}

	/**
	 * The method retrieves a MasterWorkflowFields on the basis its tenantId and
	 * solutionCategoryId and gspRefNo.
	 * 
	 * @param tenantId
	 *            The Tenant Id
	 * @param solutionCategoryId
	 *            The SolutionCategory Id
	 * @param gspRefNo
	 *            The GspRefNo
	 * @return List of masterWorkflowFields DTO
	 * 
	 */
	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(
			String tenantId, String solutionCategoryId, String gspRefNo) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo : Start");
		List<MasterWorkflowFieldsDTO> masterWorkflowFieldsDTOs = null;
		List<MasterWorkflowFields> masterWorkflowFields = null;
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		if (null != tenantId && null != solutionCategoryId && null != gspRefNo) {
			masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(tenantId, solutionCategoryId,
							gspRefNo);
			if (null != masterWorkflowFields && masterWorkflowFields.size() > 0) {
				masterWorkflowFieldsDTOs = new ArrayList<MasterWorkflowFieldsDTO>();
				for (MasterWorkflowFields masterWorkflowFieldsRecord : masterWorkflowFields) {
					masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFieldsRecord,
							MasterWorkflowFieldsDTO.class);
					masterWorkflowFieldsDTOs.add(masterWorkflowFieldsDTO);
				}
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo : End");
		return masterWorkflowFieldsDTOs;
	}

	/**
	 * The method retrieves a MasterWorkflowFields on the basis its tenantId and
	 * solutionCategoryId and WorkflowState's stateName.
	 * 
	 * @param tenantId
	 *            The Tenant Id
	 * @param solutionCategoryId
	 *            The SolutionCategory Id
	 * @param stateName
	 *            The StateName
	 * @return List of masterWorkflowFields DTO
	 * 
	 */
	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(
			String tenantId, String solutionCategoryId, String stateName) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName : Start");
		List<MasterWorkflowFieldsDTO> masterWorkflowFieldsDTOs = null;
		List<MasterWorkflowFields> masterWorkflowFields = null;
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		if (null != tenantId && null != solutionCategoryId && null != stateName) {
			masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(tenantId, solutionCategoryId,
							stateName);
			if (null != masterWorkflowFields && masterWorkflowFields.size() > 0) {
				masterWorkflowFieldsDTOs = new ArrayList<MasterWorkflowFieldsDTO>();
				for (MasterWorkflowFields masterWorkflowFieldsRecord : masterWorkflowFields) {
					masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFieldsRecord,
							MasterWorkflowFieldsDTO.class);
					masterWorkflowFieldsDTOs.add(masterWorkflowFieldsDTO);
				}
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName : End");
		return masterWorkflowFieldsDTOs;
	}

	/**
	 * The method retrieves a CustomerDetail on the basis of
	 * MasterWorkflowFields masterWorkflowId.
	 * 
	 * @param masterWorkflowId
	 *            The masterWorkflowField Id
	 * @return customerDetailDTO
	 * 
	 */

	@Override
	public List<CustomerDetailDTO> getCustomerDetailListByMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getCustomerDetailListByMasterWorkflowId : Start");
		List<CustomerDetailDTO> customerDetailDTOs = null;
		List<CustomerDetail> customerDetails = null;
		CustomerDetailDTO customerDetailDTO = null;
		if (null != masterWorkflowFieldId) {
			customerDetails = masterWorkflowFieldsRepository
					.findCustomerDetailListByMasterWorkflowFieldId(masterWorkflowFieldId);

			if (null != customerDetails && customerDetails.size() > 0) {
				customerDetailDTOs = new ArrayList<CustomerDetailDTO>();
				for (CustomerDetail customerDetailRecord : customerDetails) {
					customerDetailDTO = dozerBeanMapper.map(customerDetailRecord, CustomerDetailDTO.class);
					customerDetailDTOs.add(customerDetailDTO);
				}
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getCustomerDetailListByMasterWorkflowId : End");
		return customerDetailDTOs;
	}

	/**
	 * The method retrieves SubProcessFields on the basis of
	 * MasterWorkflowFields masterWorkflowId.
	 * 
	 * @param masterWorkflowId
	 *            The masterWorkflowField Id
	 * @return SubProcessFieldsDTO
	 * 
	 */

	/**
	 * The method retrieves AdditionalContactDetail on the basis of
	 * MasterWorkflowFields masterWorkflowId.
	 * 
	 * @param masterWorkflowId
	 *            The masterWorkflowField Id
	 * @return AdditionalContactDetailDTO
	 * 
	 */

	@Override
	public List<AdditionalContactDetailDTO> getAdditionalContactDetailByMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getAdditionalContactDetailByMasterWorkflowFieldId : Start");
		List<AdditionalContactDetailDTO> additionalContactDetailDTOs = null;
		List<AdditionalContactDetail> additionalContactDetails = null;
		AdditionalContactDetailDTO additionalContactDetailDTO = null;
		if (null != masterWorkflowFieldId) {
			additionalContactDetails = masterWorkflowFieldsRepository
					.findAdditionalContactDetailByMasterWorkflowFieldId(masterWorkflowFieldId);

			if (null != additionalContactDetails && additionalContactDetails.size() > 0) {
				additionalContactDetailDTOs = new ArrayList<AdditionalContactDetailDTO>();
				for (AdditionalContactDetail additionalContactDetailRecord : additionalContactDetails) {
					additionalContactDetailDTO = dozerBeanMapper.map(additionalContactDetailRecord,
							AdditionalContactDetailDTO.class);
					additionalContactDetailDTOs.add(additionalContactDetailDTO);
				}
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getAdditionalContactDetailByMasterWorkflowFieldId : End");
		return additionalContactDetailDTOs;
	}

	/**
	 * The method retrieves WorkflowState on the basis of MasterWorkflowFields
	 * masterWorkflowId.
	 * 
	 * @param masterWorkflowId
	 *            The masterWorkflowField Id
	 * @return WorkflowStateDTO
	 * 
	 */

	@Override
	public WorkflowStateDTO getWorkflowStateByMasterWorkflowFieldId(Long masterWorkflowFieldId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl :  getWorkflowStateByMasterWorkflowFieldId : Start");
		WorkflowStateDTO workflowStateDTO = null;
		WorkflowState workflowState = null;

		if (null != masterWorkflowFieldId) {
			workflowState = masterWorkflowFieldsRepository
					.findWorkflowStateByMasterWorkflowFieldId(masterWorkflowFieldId);
			if (null != workflowState) {
				workflowStateDTO = dozerBeanMapper.map(workflowState, WorkflowStateDTO.class);
			}

		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getWorkflowStateByMasterWorkflowFieldId : End");
		return workflowStateDTO;

	}

	/**
	 * The method adds or update SubProcessField to MasterWorkflowFields on the
	 * basis of its masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The MasterWorkflowField Id
	 * @param subProcessFieldsDTO
	 *            The List of SubProcessFieldsDTO
	 * @return Boolean
	 * 
	 */

	/**
	 * The method adds or updates CustomerDetail to MasterWorkflowFields on the
	 * basis of its masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The MasterWorkflowField Id
	 * @param subProcessFieldsDTO
	 *            The List of SubProcessFieldsDTO
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean addUpdateCustomerDetailsToMasterWorkflowFields(Long masterWorkflowFieldId,
			List<CustomerDetailDTO> customerDetailDTOList) {

		LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateCustomerDetailsToMasterWorkflowFields : Start");
		boolean returnVal = false;
		MasterWorkflowFields masterWorkflowFields;
		MasterWorkflowFields savedObject = null;
		CustomerDetail customerDetails = null;
		List<CustomerDetail> customerDetailList = new ArrayList<CustomerDetail>();
		try {
			if (null != masterWorkflowFieldId && null != customerDetailDTOList) {
				masterWorkflowFields = masterWorkflowFieldsRepository.findOne(masterWorkflowFieldId);
				if (null != masterWorkflowFields) {
					for (CustomerDetailDTO customerDetailDTO : customerDetailDTOList) {
						if (null != customerDetailDTO.getCustomerId()) {
							customerDetails = customerDetailRepository.findOne(customerDetailDTO.getCustomerId());
						}
						customerDetails = dozerBeanMapper.map(customerDetailDTO, CustomerDetail.class);
						customerDetailList.add(customerDetails);
					}

					List<CustomerDetail> existCustomerDetailList = masterWorkflowFields.getCustomerDetails();
					if (null != existCustomerDetailList && existCustomerDetailList.size() > 0) {
						customerDetailList.addAll(existCustomerDetailList);
					}
					masterWorkflowFields.setCustomerDetails(customerDetailList);
					savedObject = masterWorkflowFieldsRepository.save(masterWorkflowFields);
				}
				LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateCustomerDetailsToMasterWorkflowFields : Record Saved");
				if (null != savedObject) {
					returnVal = true;
				}
			} else {
				LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateCustomerDetailsToMasterWorkflowFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * The method adds AdditionalContactDetail to MasterWorkflowFields on the
	 * basis of its masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The MasterWorkflow Field Id
	 * @param additionalContactDetailDTO
	 *            The AdditionalContactDetailDTO
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean addUpdateAdditionalContactDetailsToMasterWorkflowFields(Long masterWorkflowFieldId,
			List<AdditionalContactDetailDTO> additionalContactDetailDTOList) {

		LOGGER.info("MasterWorkflowFieldsServiceImpl : addAdditionalContactDetailToMasterWorkflowFields : Start");
		boolean returnVal = false;
		MasterWorkflowFields masterWorkflowFields;
		MasterWorkflowFields savedObject = null;

		AdditionalContactDetail additionalContactDetail = null;
		List<AdditionalContactDetail> additionContactDetailList = new ArrayList<AdditionalContactDetail>();
		try {
			if (null != masterWorkflowFieldId && null != additionalContactDetailDTOList) {

				masterWorkflowFields = masterWorkflowFieldsRepository.findOne(masterWorkflowFieldId);

				if (null != masterWorkflowFields) {
					for (AdditionalContactDetailDTO additionalContactDetailDTO : additionalContactDetailDTOList) {
						if (null != additionalContactDetailDTO.getAdditionalContactDetailId()) {
							additionalContactDetail = additionalContactDetailRepository
									.findOne(additionalContactDetailDTO.getAdditionalContactDetailId());
						}
						additionalContactDetail = dozerBeanMapper.map(additionalContactDetailDTO,
								AdditionalContactDetail.class);
						additionContactDetailList.add(additionalContactDetail);
					}

					List<AdditionalContactDetail> existAdditionalContactDetailList = masterWorkflowFields
							.getAdditionalContactDetails();
					if (null != existAdditionalContactDetailList && additionContactDetailList.size() > 0) {
						additionContactDetailList.addAll(existAdditionalContactDetailList);
					}
					masterWorkflowFields.setAdditionalContactDetails(additionContactDetailList);
					savedObject = masterWorkflowFieldsRepository.save(masterWorkflowFields);
				}
				LOGGER.info("MasterWorkflowFieldsServiceImpl : addAdditionalContactDetailToMasterWorkflowFields : Record Saved");
				if (null != savedObject) {
					returnVal = true;
				}
			} else {
				LOGGER.info("MasterWorkflowFieldsServiceImpl : addAdditionalContactDetailToMasterWorkflowFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * The deletes a MasterWorkflowFields on the basis its
	 * masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The masterWorkflowField Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMasterWorkflowFieldsByMasterWorkflowFieldId(Long masterWorkflowFieldId) {

		LOGGER.info("MasterWorkflowFieldsServiceImpl : deleteMasterWorkflowFieldsByMasterWorkflowFieldId : Start");
		boolean returnVal = false;
		try {
			if (null != masterWorkflowFieldId) {
				masterWorkflowFieldsRepository.delete(masterWorkflowFieldId);
				returnVal = true;
			} else {
				LOGGER.info("MasterWorkflowFieldsServiceImpl : deleteMasterWorkflowFieldsByMasterWorkflowFieldId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * The method adds or update WorkflowState to MasterWorkflowFields on the
	 * basis of its masterWorkflowFieldId.
	 * 
	 * @param masterWorkflowFieldId
	 *            The MasterWorkflowField Id
	 * @param WorkflowStateDTO
	 *            The WorkflowStateDTO
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean addUpdateWorkflowStateToMasterWorkflowFields(Long masterWorkflowFieldId,
			WorkflowStateDTO workflowStateDTO) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateWorkflowStateToMasterWorkflowFields : Start");
		boolean returnVal = false;
		MasterWorkflowFields masterWorkflowFields;
		MasterWorkflowFields savedObject = null;

		WorkflowState workflowState = null;

		try {

			if (null != masterWorkflowFieldId && null != workflowStateDTO) {
				masterWorkflowFields = masterWorkflowFieldsRepository.findOne(masterWorkflowFieldId);
				if (null != masterWorkflowFields) {
					workflowStateDTO.setCreatedOn(new Date());
					workflowStateDTO.setModifiedOn(new Date());
					if (null != workflowStateDTO.getWorkflowStateId()) {
						workflowState = workflowStateRepository.findOne(workflowStateDTO.getWorkflowStateId());
						if (null != workflowState) {
							workflowStateDTO.setModifiedOn(new Date());
							workflowStateDTO.setCreatedOn(workflowState.getCreatedOn());
						} else {
							workflowStateDTO.setCreatedOn(new Date());
							workflowStateDTO.setModifiedOn(new Date());
						}
					}

					workflowState = dozerBeanMapper.map(workflowStateDTO, WorkflowState.class);
					masterWorkflowFields.setWorkflowState(workflowState);
					savedObject = masterWorkflowFieldsRepository.save(masterWorkflowFields);

				}

				LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateWorkflowStateToMasterWorkflowFields : Record Saved");
				if (null != savedObject) {
					returnVal = true;
				}
			}

			else {
				LOGGER.info("MasterWorkflowFieldsServiceImpl : addUpdateWorkflowStateToMasterWorkflowFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNo(String gspRefNo) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByGspRefNo : Start");
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		if (null != gspRefNo) {
			MasterWorkflowFields masterWorkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByGspRefNo(gspRefNo);
			if (null != masterWorkflowFields) {
				masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFields, MasterWorkflowFieldsDTO.class);
			}
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByGspRefNo : End");
		return masterWorkflowFieldsDTO;
	}
	
	@Override
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId(
			Long masterWorkflowFieldId, String tenantId,
			String solutionCategoryId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId : Start");
		 
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO=null;
		MasterWorkflowFields masterWorkflowFields=null;
		if (null != masterWorkflowFieldId && null != tenantId && null != solutionCategoryId) {
			masterWorkflowFields = masterWorkflowFieldsRepository.findMasterWorkflowFieldsByMasterWorkflowFieldIdAndTenantIdAndSolCatId(masterWorkflowFieldId,tenantId,
					solutionCategoryId);
		}
		if (null != masterWorkflowFields ) {
			
			masterWorkflowFieldsDTO=new MasterWorkflowFieldsDTO();
			masterWorkflowFieldsDTO=dozerBeanMapper.map(masterWorkflowFields, MasterWorkflowFieldsDTO.class);
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId : End");
		return masterWorkflowFieldsDTO;
	}
	
	@Override
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState(String gspRefNo,String tenantId,String solutionCategoryId) {
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByGspRefNo : Start");
		MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;
		MasterWorkflowFields masterWorkflowFields=null;
		if (null != gspRefNo && null != tenantId && null != solutionCategoryId) {
			masterWorkflowFields = masterWorkflowFieldsRepository.findMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState(gspRefNo,tenantId,
					solutionCategoryId);
		}
			if (null != masterWorkflowFields) {
				masterWorkflowFieldsDTO = dozerBeanMapper.map(masterWorkflowFields, MasterWorkflowFieldsDTO.class);
			}
		
		List<SubProcessFields> subProcessFieldList = null;

				subProcessFieldList = subProcessFieldsRepository
						.findSubProcessFieldsByMasterWorkflowId(masterWorkflowFields.getMasterWorkflowFieldId());
				if(null != subProcessFieldList && subProcessFieldList.size() > 0){
				for (SubProcessFields SubProcessFieldEntity : subProcessFieldList) {
					if(masterWorkflowFields.getQuantity() >= MotorRepairConstants.MAX_QTY) {
							if( SubProcessFieldEntity.getWorkflowClosureType() == MotorRepairConstants.WORKFLOW_CLOSURE_TYPE.COMPLETED.getValue() || SubProcessFieldEntity.getWorkflowClosureType() == MotorRepairConstants.WORKFLOW_CLOSURE_TYPE.IN_EXEC.getValue() || SubProcessFieldEntity.getWorkflowClosureType() == MotorRepairConstants.WORKFLOW_CLOSURE_TYPE.RESOLVED_CLOSURE.getValue()){
						throw new MotorRepairException(
								MotorRepairException.INPUT_ERR,
								"Can not add more motors to it ,as its COMPLETED(0),IN_EXEC(1), RESOLVED_CLOSURE(2) Limit 10 exceed",
								"Create New Subprocess Workflow");
							}
				}
				}	
		}
		LOGGER.info("MasterWorkflowFieldsServiceImpl : getMasterWorkflowFieldsByGspRefNo : End");
		return masterWorkflowFieldsDTO;
	}
	
	
}
