package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;
import net.atos.motorrepairmgmt.services.WorkflowStateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603975
 * 
 */

@Controller
@EnableSwagger
@RequestMapping(value = "workflowStateService")
public class WorkflowStateController {
	@Autowired
	private WorkflowStateService workflowStateService;

	@RequestMapping(value = "/createUpdateWorkflowState", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  WorkflowState with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Integer createUpdateWorkflowState(
			@ApiParam(value = "  WorkflowState Data object that needs to be added or update in the WorkflowState") @RequestBody WorkflowStateDTO workflowStateDTO) {
		return workflowStateService.createUpdateWorkflowState(workflowStateDTO);
	}

	@RequestMapping(value = "/getAllWorkflowState", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find  WorkflowState ", notes = "Returns a  WorkflowState entity", response = WorkflowStateDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<WorkflowStateDTO> getAllWorkflowState() {
		return workflowStateService.getAllWorkflowState();
	}

	@RequestMapping(value = "/getWorkflowStateByWorkflowStateId/{workflowStateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By arcId", notes = "Returns a WorkflowState entity when workflowStateId is passed", response = WorkflowStateDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid workflowStateId supplied"),
			@ApiResponse(code = 404, message = "WorkflowState not found") })
	public @ResponseBody WorkflowStateDTO getWorkflowStateByWorkflowStateId(
			@ApiParam(value = "WorkflowState  based on  workflowStateId  needs to be fetched", required = true) @PathVariable("workflowStateId") final Integer workflowStateId) {
		return workflowStateService.getWorkflowStateByWorkflowStateId(workflowStateId);
	}

	@RequestMapping(value = "/deleteWorkflowStateByWorkflowStateId/{workflowStateId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete WorkflowState By WorkflowState Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid WorkflowState Id value") })
	public @ResponseBody Boolean deleteWorkflowStateByWorkflowStateId(
			@ApiParam(value = "WorkflowState Id to delete", required = true) @PathVariable("workflowStateId") final Integer workflowStateId) {
		return workflowStateService.deleteWorkflowStateByWorkflowStateId(workflowStateId);
	}

	@RequestMapping(value = "/getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId/{workflowStateId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find WorkflowState Fields By workflowStateId ,TenantId and solutionCategoryId", notes = "Returns a WorkflowState Fields entity when workflowStateId,TenantId and SolutionCategoryId is passed", response = WorkflowStateDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid workflowStateId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " WorkflowState Fields not found") })
	public @ResponseBody WorkflowStateDTO getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId(
			@ApiParam(value = "workflowStateId of the WorkflowState that needs to be fetched", required = true)@PathVariable(value = "workflowStateId") final Integer workflowStateId,
			@ApiParam(value = "tenantId of the WorkflowState that needs to be fetched", required = true)@PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "solutionCategoryId of the WorkflowState that needs to be fetched", required = true)@PathVariable(value = "solutionCategoryId")final String solutionCategoryId) {
	  return workflowStateService.getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId(workflowStateId, tenantId,solutionCategoryId);
		 
	}
}
