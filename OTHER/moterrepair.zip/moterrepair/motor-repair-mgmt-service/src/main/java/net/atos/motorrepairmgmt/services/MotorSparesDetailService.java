/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;

/**
 * @author a603327
 *
 */
public interface MotorSparesDetailService {

	public List<MotorSparesDetailDTO> getAllMotorSparesDetail();

	public Boolean deleteMotorSparesDetail(Long materialId);

	public Long createUpdateMotorSparesDetail(MotorSparesDetailDTO motorSparesDetailDTO);

	public MotorSparesDetailDTO getMotorSparesDetailById(Long materialId);
	
	public MotorSparesDetailDTO getMotorSparesDetailByMaterialIdandTenantIdandSolCatId(Long materialId,String tenantId,String solutionCategoryId);

}
