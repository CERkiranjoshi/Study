/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.TaskUtilService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component(value = "preConsolidationHandler")
public class PreConsolidationHandler implements JavaDelegate {

	private static final Logger LOGGER = Logger.getLogger(PreConsolidationHandler.class);

	/**
	 * Subprocess Workflow Repository
	 */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	@Autowired
	private TaskUtilService taskUtilService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PRE_CONSOLIDATION_HANDLER: START [" + execution.getId() + "]");

		/**
		 * Steps:<br>
		 * Fetch Master Workflow Id for this Subprocess.<br>
		 * Fetch All Subprocesses for this Master Workflow Id.<br>
		 * If Only 1 subprocess exist for this Master Workflow, then mark the subprocess as complete and set
		 * CHECK_COMPLETION = 1 & CHECK_EDIT_ENABLED = 0.<br>
		 * Also add the TEMPLATE_CODE for the template to be used for Notification. If more than 1 subprocess exist for
		 * this Master Workflow, then mark the subprocess as complete and set CHECK_COMPLETION = 0.<br>
		 * 
		 * 
		 */

		Long masterWorkflowId = (null != execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)) ? Long
				.parseLong(execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID).toString()) : null;
		Long subprocessWorkflowId = (null != execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)) ? Long
				.parseLong(execution.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString()) : null;

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PRE_CONSOLIDATION_HANDLER: [" + execution.getId() + "] Master Workflow Id: " + masterWorkflowId);

		List<SubProcessFields> subProcesses = subProcessFieldsRepository
				.findSubProcessFieldsByStateAndMasterWorkflowId(ActivitiConstants.SUBPROC_IN_EXEC_STATE,
						masterWorkflowId);

		// TODO Handle subProcess Size = 0 issue
		// TODO Close all tasks for this subprocess which is invoking closure

		if (1 < subProcesses.size()) {
			for (SubProcessFields subProcessFields : subProcesses) {
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PRE_CONSOLIDATION_HANDLER: [" + execution.getId() + "] Subprocess Workflow Id: "
						+ subProcessFields.getWlfwSubProcessId());
				if (subProcessFields.getWlfwSubProcessId().equals(subprocessWorkflowId)) {
					subProcessFields.setSubProcState(ActivitiConstants.SUBPROC_COMPLETED_STATE);
					subProcessFields.setSubProcClosedByRefId(MotorRepairConstants.SYSTEM_CONSOLIDATION);
					subProcessFields.setSubProcClosedOn(new Date());
					// UPDATE AND COMMIT
					subProcessFieldsRepository.save(subProcessFields);

					// Since only more than one subprocess found, do not process further:
					execution.createVariableLocal(ActivitiConstants.CHECK_COMPLETION, 0);

					// TODO Do not claim all tasks as it attempts to claim current task too!
					// taskUtilService.claimAllTasks(MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID,
					// subprocessWorkflowId, MotorRepairConstants.SYSTEM_CONSOLIDATION, null);

					break; // DONE, no further processing required
				}
			}
		} else {
			SubProcessFields subProcessFields = subProcesses.get(0);
			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PRE_CONSOLIDATION_HANDLER: [" + execution.getId() + "] Subprocess Workflow Id: "
					+ subProcessFields.getWlfwSubProcessId());
			subProcessFields.setSubProcState(ActivitiConstants.SUBPROC_COMPLETED_STATE);
			if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO))
				subProcessFields.setSubProcClosedByRefId(execution.getVariable(
						ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO).toString()); // TODO set User
			subProcessFields.setSubProcClosedOn(new Date());
			// UPDATE AND COMMIT
			subProcessFieldsRepository.save(subProcessFields);

			// Since only 1 subprocess found, process further:
			execution.createVariableLocal(ActivitiConstants.CHECK_COMPLETION, 1);
			execution.createVariableLocal(ActivitiConstants.CHECK_EDIT_ENABLED, 0);

		}

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PRE_CONSOLIDATION_HANDLER: END [" + execution.getId() + "]");

	}
}
