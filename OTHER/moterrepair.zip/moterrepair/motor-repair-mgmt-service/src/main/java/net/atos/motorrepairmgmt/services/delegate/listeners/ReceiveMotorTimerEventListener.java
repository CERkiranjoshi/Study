/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.listeners;

import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;
import net.atos.motorrepairmgmt.services.SchedulerDetailsService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.singetons.TaskSLAManager;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.context.SpringApplicationContext;

import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.impl.el.FixedValue;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component
public class ReceiveMotorTimerEventListener implements TaskListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1668734390109L;

	private FixedValue taskEventType;

	// private FixedValue benchmarkName;

	public FixedValue getTaskEventType() {
		return taskEventType;
	}

	public void setTaskEventType(FixedValue taskEventType) {
		this.taskEventType = taskEventType;
	}

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ReceiveMotorTimerEventListener.class);

	/**
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.TaskListener#notify(org.activiti.engine. delegate.DelegateTask)
	 */

	@Override
	public void notify(DelegateTask delegateTask) {

		LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: START: TL: Executed for: " + delegateTask.getEventName() + "; "
				+ delegateTask.getName() + "; taskEventType is " + taskEventType.getValue(null).toString()
				+ "; executionId: " + delegateTask.getExecutionId());

		if ("START".equals(taskEventType.getValue(null).toString())) {

			LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: Scheduling Motor Not Received : ["
					+ delegateTask.getExecutionId() + "] ");

			Object functionCodeObj = delegateTask.getExecution().getVariable(ActivitiConstants.FUNCTION_CODE);

			// fetch function details for function code
			if (null != functionCodeObj) {

				String functionCode = functionCodeObj.toString();
				String assigned = null;
				if (null != delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO)) {
					delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO).toString();
				}
				if (null == assigned)
					assigned = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP)
							.toString();

				String tenantId = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString();

				String batchProcessId = delegateTask.getVariable(ActivitiConstants.BATCH_PROCESS_ID).toString();
				String masterProcessId = delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID).toString();
				String subProcessId = delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString();
				String gspRefNum = delegateTask.getVariable(ActivitiConstants.GSP_REF_NO).toString();
				String taskPriority = delegateTask.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY).toString();
				String taskId = delegateTask.getId();

				ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
				TaskSLAManager taskSLAManager = applicationContext.getBean(TaskSLAManager.class);

				LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: Scheduling Motor Receive Trigger: "
						+ delegateTask.getEventName() + "; " + delegateTask.getName() + "; executionId: "
						+ delegateTask.getExecutionId());
				// TODO Change this to configured value
				int delayInDays = 1;
				String schedulerId = taskSLAManager.triggerMotorNotReceivedScheduler(batchProcessId, masterProcessId,
						delegateTask.getProcessInstanceId(), MotorRepairConstants.SYSTEM_USER, subProcessId, functionCode, gspRefNum, delayInDays, 1, taskId, taskPriority);

				LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: Done Scheduling Motor Not Received : ["
						+ delegateTask.getExecutionId() + "] ");

			}
		} else {
			LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: Cancelling Scheduler : [" + delegateTask.getExecutionId()
					+ "] Task id: " + delegateTask.getId());

			// Fetch Schedulers for this Subprocess
			ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
			SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);

			Object subProcessId = delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID);
			
			LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
					+ "] Fetching Scheduler Details for Subprocess Id : " + subProcessId);
			if (null != subProcessId) {
				TaskSLAManager taskSLAManager = applicationContext.getBean(TaskSLAManager.class);
				SchedulerDetailsDTO schedulerDetail = null;

				List<SchedulerDetailsDTO> schedulderDetailsDTOs = schedulerDetailsService
						.getSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId(Long.parseLong(subProcessId.toString()),
								MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
				LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
						+ "] Scheduler Details : "
						+ ((null != schedulderDetailsDTOs) ? schedulderDetailsDTOs.size() : "0"));
				for (SchedulerDetailsDTO schedulerDetailsDTO : schedulderDetailsDTOs) {
					if (1 != schedulerDetailsDTO.getHasExecuted()) {
						schedulerDetail = schedulerDetailsDTO;
						break;
					}
				}

				if (null != schedulerDetail) {

					LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
							+ "] Scheduler Detail : " + schedulerDetail.getSchedulerId() + "; GSP: "
							+ schedulerDetail.getGspRefNum() + "; SUB_PROCESS_ID: " + schedulerDetail.getSubprocessId());
					// Mark scheduler as cancelled
					schedulerDetail.setHasExecuted(2);
					schedulerDetail.setLastRunTs(new Date());

					LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
							+ "] Updating Scheduler Detail : " + schedulerDetail.getSchedulerId());
					schedulerDetailsService.createUpdateSchedulerDetails(schedulerDetail);

					LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
							+ "] Cancelling task for Scheduler Detail : " + schedulerDetail.getSchedulerId());
					taskSLAManager.cancelTask(schedulerDetail.getSchedulerId());

				} else {
					// ALL TASKS have been completed. Nothing to do further
					LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: [" + delegateTask.getExecutionId()
							+ "] No Scheduler Details found to be in pending state ");
				}
			}

		}
		LOGGER.info("subprocessId: "+delegateTask.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+delegateTask.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; MOTOR_NOT_RECEIVED_EVENT_LISTENER: END: TL: Executed completed for: "
				+ delegateTask.getEventName() + "; " + delegateTask.getName() + "; executionId: "
				+ delegateTask.getExecutionId());
	}
}
