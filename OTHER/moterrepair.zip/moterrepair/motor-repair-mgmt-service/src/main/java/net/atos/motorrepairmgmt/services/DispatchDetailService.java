package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.DispatchDetailDTO;

public interface DispatchDetailService {

	public Long createUpdateDispatchDetail(DispatchDetailDTO dispatchDetailDTO);
	public List<DispatchDetailDTO> getAllDispatchDetail();
	public DispatchDetailDTO getDispatchDetailByDispatchId(Long dispatchId);
	public Boolean deleteDispatchDetailByDispatchId(Long dispatchId);

}
