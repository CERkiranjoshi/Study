/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;





import net.atos.motorrepairmgmt.dto.BuildDetailDTO;
import net.atos.motorrepairmgmt.services.BuildDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a593775
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value="buildDetailService")
public class BuildDetailController {
	
	@Autowired
	private BuildDetailService buildDetailService;

	@RequestMapping(value = "/getBuildDetail/{tenantId}/{solnCatId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find All build detail by tenantId & solution category Id", notes = "Returns build detail", response = BuildDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid value is supplied"),
			@ApiResponse(code = 404, message = "Not found") })
	public @ResponseBody BuildDetailDTO getBuildDetailByTenantIdNSolCategory(
			@ApiParam(value = "Find All config detail by type and subType", required = true) 
			@PathVariable("tenantId") String tenantId,@PathVariable("solnCatId") String solnCatId) {
		return buildDetailService.getCurrentBuildDetailByTenantIdNSolCategory(tenantId, solnCatId);
	}
	
}
