/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;




import net.atos.motorrepairmgmt.dto.ResponseDTO;
import net.atos.motorrepairmgmt.services.TaskUtilService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author Sweety Kothari
 * This controller will handle all event on RECALL,REJECT & RECLAIM
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "workflowEventService")
public class WorkflowEventController {
	
	final static Logger LOGGER= Logger.getLogger(WorkflowEventController.class);

	@Autowired
	private TaskUtilService taskUtilService;
	
	@RequestMapping(value = "/claimAlltask/{tenantId}/{programId}/{subProcessId}/{userRefId}/{assignedToEmail}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Claim all tasks", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody ResponseDTO claimAlltask(
			@ApiParam(value = " Claim all task based on argument passes",required=true)  @PathVariable("tenantId")  String tenantId,
			 @PathVariable("programId")  String programId,@PathVariable("subProcessId")  Long subProcessId,@PathVariable("userRefId")  String userRefId,@PathVariable("assignedToEmail")  String assignedToEmail) {
		LOGGER.info("tenant id is "+tenantId);
		LOGGER.info("programId id is "+programId);
		LOGGER.info("subProcessId id is "+subProcessId);
		ResponseDTO responseDTO= new ResponseDTO();
		responseDTO.setMessage(taskUtilService.claimAllTasks(tenantId, programId, subProcessId, userRefId,assignedToEmail));
		LOGGER.info("response  is "+responseDTO);
		return responseDTO;
	}
	
	@RequestMapping(value = "/recallTask/{taskId}/{userRefId}/{prevFunctionCode}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "recall tasks", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody ResponseDTO recallTask(
			@ApiParam(value = " recall based on argument passes",required=true)  @PathVariable("taskId")  String taskId,
			 @PathVariable("userRefId")  String userRefId,@PathVariable("prevFunctionCode")  String prevFunctionCode) {
		
		ResponseDTO responseDTO= new ResponseDTO();
		responseDTO.setMessage(taskUtilService.recallTask(userRefId, taskId, prevFunctionCode));
		LOGGER.info("response  is "+responseDTO);
		return responseDTO;
	}
	
	
	@RequestMapping(value = "/rejectTask/{taskId}/{userRefId}/{prevFunctionCode}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "reject task", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody ResponseDTO rejectTask(
			@ApiParam(value = " Claim all task based on argument passes",required=true)  @PathVariable("taskId")  String taskId,
			 @PathVariable("userRefId")  String userRefId,@PathVariable("prevFunctionCode")  String prevFunctionCode) {
		ResponseDTO responseDTO= new ResponseDTO();
		responseDTO.setMessage(taskUtilService.rejectTask(userRefId, taskId, prevFunctionCode));
		LOGGER.info("response  is "+responseDTO);
		return responseDTO;
	}

}
