/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import net.atos.motorrepairmgmt.dto.RoleUserMapDTO;


/**
 * @author Sweety Kothari
 *
 */
public interface RoleUserMapService {
	public RoleUserMapDTO getARCRefIdByUserName( String userName);
}
