/**
 * 
 */
package net.atos.motorrepairmgmt.services;

/**
 * Service Interface to claim all active tasks for a given subprocessId.
 * 
 * @author Anand Ved
 *
 */
public interface TaskUtilService {

	public String claimAllTasks(String tenantId, String programId, Long subprocessId, String userRefId,String assignedToEmail);

	public String recallTask(String userRefId, String taskId, String prevFunctionCode);

	public String rejectTask(String userRefId, String taskId, String prevFunctionCode);
}
