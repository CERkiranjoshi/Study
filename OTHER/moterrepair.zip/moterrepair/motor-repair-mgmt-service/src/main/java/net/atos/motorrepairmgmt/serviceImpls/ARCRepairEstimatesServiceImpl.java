package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.entity.ARCRepairEstimates;
import net.atos.motorrepairmgmt.repository.ARCRepairEstimatesRepository;
import net.atos.motorrepairmgmt.services.ARCRepairEstimatesService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

/**
 * @author a610051
 * 
 */
@Service
public class ARCRepairEstimatesServiceImpl implements ARCRepairEstimatesService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The StoreMaster Repository */
	@Autowired
	private ARCRepairEstimatesRepository arcRepairEstimatesRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ARCRepairEstimatesServiceImpl.class);

	/**
	 * This method creates/updates a ARCRepairEstimates record. The method
	 * performs an update operation when arcRepairEstimateId is passed and an
	 * existing record with matching arcRepairEstimateId is fetched for updation
	 * Or it will create a new record
	 * 
	 * @param ARCRepairEstimatesDTO
	 *            The arcRepairEstimates Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateARCRepairEstimates(ARCRepairEstimatesDTO arcRepairEstimatesDTO) {
		LOGGER.info("ARCRepairEstimatesServiceImpl : createUpdateARCRepairEstimates : Start");
		ARCRepairEstimates arcRepairEstimatesDetails = null;
		Long returnId = -1l;
		try {
			if (null != arcRepairEstimatesDTO) {
				if (null != arcRepairEstimatesDTO.getArcRepairEstimateId()) {
					arcRepairEstimatesDetails = arcRepairEstimatesRepository.findOne(arcRepairEstimatesDTO
							.getArcRepairEstimateId());
					if (null != arcRepairEstimatesDetails) {
						arcRepairEstimatesDTO.setModifiedDate(new Date());
					} else {
						arcRepairEstimatesDTO.setCreatedDate(new Date());
						arcRepairEstimatesDTO.setModifiedDate(new Date());
					}
				} else {
					arcRepairEstimatesDTO.setCreatedDate(new Date());
					arcRepairEstimatesDTO.setModifiedDate(new Date());
				}

				if (null == arcRepairEstimatesDetails) {
					arcRepairEstimatesDetails = new ARCRepairEstimates();
				}
				BeanUtils.copyProperties(arcRepairEstimatesDTO, arcRepairEstimatesDetails,
						getNullPropertyNames(arcRepairEstimatesDTO));
				ARCRepairEstimates savedObj = arcRepairEstimatesRepository.save(arcRepairEstimatesDetails);
				if (null != savedObj) {
					LOGGER.info("ARCRepairEstimatesServiceImpl : createUpdateARCRepairEstimates : Record Saved/Updated");
					returnId = savedObj.getArcRepairEstimateId();
				}
			} else {
				LOGGER.info("ARCRepairEstimatesServiceImpl : createUpdateARCRepairEstimates : arcRepairEstimatesDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * This method deletes a ARCRepairEstimates on the basis of its
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The ARCRepairEstimate Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteARCRepairEstimatesByArcRepairEstimateId(Long arcRepairEstimateId) {
		LOGGER.info("ARCRepairEstimatesServiceImpl : deleteARCRepairEstimatesByArcRepairEstimateId : Start");
		boolean returnVal = false;
		try {
			if (null != arcRepairEstimateId) {
				arcRepairEstimatesRepository.delete(arcRepairEstimateId);
				returnVal = true;
			} else {
				LOGGER.info("ARCRepairEstimatesServiceImpl : deleteARCRepairEstimatesByArcRepairEstimateId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("ARCRepairEstimatesServiceImpl : deleteARCRepairEstimatesByArcRepairEstimateId : Not Deleted. Record Not Present");
		}
		return returnVal;
	}

	/**
	 * This method retrieves a ARCRepairEstimates on the basis of its
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * @return ARCRepairEstimatesDTO
	 * 
	 */
	@Override
	@Transactional
	public ARCRepairEstimatesDTO getARCRepairEstimatesByARCRepairEstimateId(Long arcRepairEstimateId) {
		LOGGER.info("ARCRepairEstimatesServiceImpl : getARCRepairEstimatesByARCRepairEstimateId : Start");
		ARCRepairEstimatesDTO arcRepairEstimatesDTO = null;
		ARCRepairEstimates arcRepairEstimatesDetails = null;
		if (null != arcRepairEstimateId) {
			arcRepairEstimatesDetails = arcRepairEstimatesRepository.findOne(arcRepairEstimateId);
			if (null != arcRepairEstimatesDetails) {
				arcRepairEstimatesDTO = new ARCRepairEstimatesDTO();
				arcRepairEstimatesDTO = dozerBeanMapper.map(arcRepairEstimatesDetails, ARCRepairEstimatesDTO.class);
			}
		}
		LOGGER.info("ARCRepairEstimatesServiceImpl : getARCRepairEstimatesByARCRepairEstimateId : End");
		return arcRepairEstimatesDTO;
	}

	/**
	 * This method retrieves all the ARCRepairEstimates
	 * 
	 * @return List of ARCRepairEstimatesDTO
	 * 
	 */
	@Override
	@Transactional
	public List<ARCRepairEstimatesDTO> getAllARCRepairEstimates() {
		LOGGER.info("ARCRepairEstimatesServiceImpl : getAllARCRepairEstimates : Start");
		List<ARCRepairEstimatesDTO> arcRepairEstimatesDTOs = null;
		ARCRepairEstimatesDTO arcRepairEstimatesDTO = null;
		List<ARCRepairEstimates> arcRepairEstimatesDetails = arcRepairEstimatesRepository.findAll();
		if (null != arcRepairEstimatesDetails) {
			arcRepairEstimatesDTOs = new ArrayList<ARCRepairEstimatesDTO>();
			for (ARCRepairEstimates arcRepairEstimatesRecord : arcRepairEstimatesDetails) {
				arcRepairEstimatesDTO = new ARCRepairEstimatesDTO();
				arcRepairEstimatesDTO = dozerBeanMapper.map(arcRepairEstimatesRecord, ARCRepairEstimatesDTO.class);
				arcRepairEstimatesDTOs.add(arcRepairEstimatesDTO);
			}
		}
		LOGGER.info("ARCRepairEstimatesServiceImpl : getAllARCRepairEstimates : End");
		return arcRepairEstimatesDTOs;
	}
}
