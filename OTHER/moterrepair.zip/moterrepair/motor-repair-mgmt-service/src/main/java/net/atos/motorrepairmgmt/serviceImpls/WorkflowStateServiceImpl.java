package net.atos.motorrepairmgmt.serviceImpls;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;
import net.atos.motorrepairmgmt.entity.WorkflowState;
import net.atos.motorrepairmgmt.repository.WorkflowStateRepository;
import net.atos.motorrepairmgmt.services.WorkflowStateService;

/**
 * @author a603975
 * 
 */

@Service
public class WorkflowStateServiceImpl implements WorkflowStateService {
	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private WorkflowStateRepository workflowStateRepository;

	/**
	 * Logger
	 */

	private static final Logger LOGGER = Logger.getLogger(WorkflowStateServiceImpl.class);

	/**
	 * This method creates/updates a WorkflowState record. The method performs
	 * an update operation when workflowStateId is passed or else create new
	 * record if workflowStateId is not found
	 * 
	 * @param workflowStatedto
	 *            The WorkflowState Details
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Integer createUpdateWorkflowState(WorkflowStateDTO workflowStateDTO) {
		LOGGER.info("WorkflowStateServiceImpl : createUpdateWorkflowState : Start");
		WorkflowState workflowStateDetails = new WorkflowState();
		Integer id = -1;
		try {
			if (null != workflowStateDTO) {
				workflowStateDTO.setCreatedOn(new Date());
				workflowStateDTO.setModifiedOn(new Date());

				if (null != workflowStateDTO.getWorkflowStateId()) {
					workflowStateDetails = workflowStateRepository.findOne(workflowStateDTO.getWorkflowStateId());
					if (null != workflowStateDetails) {
						workflowStateDTO.setModifiedOn(new Date());
						workflowStateDTO.setCreatedOn(workflowStateDetails.getCreatedOn());
					} else {
						workflowStateDTO.setCreatedOn(new Date());
						workflowStateDTO.setModifiedOn(new Date());

					}
				}
				workflowStateDetails = dozerBeanMapper.map(workflowStateDTO, WorkflowState.class);
				WorkflowState savedObj = workflowStateRepository.save(workflowStateDetails);
				LOGGER.info("WorkflowStateServiceImpl : createUpdateWorkflowState : Record Saved/Updated");
				if (null != savedObj) {
					id = savedObj.getWorkflowStateId();
				}

			} else {
				LOGGER.info("WorkflowStateServiceImpl : createUpdateWorkflowState : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}

		return id;

	}

	/**
	 * The method retrieves all WorkflowState
	 * 
	 * 
	 * @return WorkflowStateDTO
	 * 
	 */

	@Override
	@Transactional
	public List<WorkflowStateDTO> getAllWorkflowState() {
		LOGGER.info("WorkflowStateServiceImpl : getAllWorkflowState : Start");

		List<WorkflowStateDTO> workflowStateDTOs = null;

		WorkflowStateDTO workflowStateDTO = null;

		List<WorkflowState> workflowStateDetails = workflowStateRepository.findAll();

		if (null != workflowStateDetails) {
			workflowStateDTOs = new ArrayList<WorkflowStateDTO>();

			for (WorkflowState workflowStateRecord : workflowStateDetails) {
				workflowStateDTO = new WorkflowStateDTO();

				workflowStateDTO = dozerBeanMapper.map(workflowStateRecord, WorkflowStateDTO.class);

				workflowStateDTOs.add(workflowStateDTO);
			}
		}
		LOGGER.info("WorkflowStateServiceImpl : getAllWorkflowState : End");
		return workflowStateDTOs;

	}

	/**
	 * The method retrieves a WorkflowState on the basis of workflowStateId.
	 * 
	 * @param workflowStateId
	 *            The workflowStateId
	 * @return WorkflowStateDTO
	 * 
	 */

	@Override
	@Transactional
	public WorkflowStateDTO getWorkflowStateByWorkflowStateId(Integer workflowStateId) {
		LOGGER.info("WorkflowStateServiceImpl : getWorkflowStateByWorkflowstateId : Start");
		WorkflowStateDTO workflowStateDTO = null;
		if (null != workflowStateId) {
			WorkflowState workflowStateDetail = workflowStateRepository
					.findWorkflowStateByWorkflowstateId(workflowStateId);
			if (null != workflowStateDetail) {
				workflowStateDTO = dozerBeanMapper.map(workflowStateDetail, WorkflowStateDTO.class);
			}
		}
		LOGGER.info("WorkflowStateServiceImpl : getWorkflowStateByWorkflowstateId : End");
		return workflowStateDTO;
	}

	/**
	 * The deletes a WorkflowState on the basis its workflowstateId .
	 * 
	 * @param workflowstateId
	 *            The workflowstateId
	 * 
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteWorkflowStateByWorkflowStateId(Integer workflowStateId) {
		LOGGER.info("WorkflowStateServiceImpl : deleteWorkflowStateByWorkflowStateId : Start");
		boolean returnVal = false;
		try {
			if (null != workflowStateId) {
				workflowStateRepository.delete(workflowStateId);
				returnVal = true;
			} else {
				LOGGER.info("WorkflowStateServiceImpl : deleteWorkflowStateByWorkflowStateId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;

	}
	
	@Override
	@Transactional
	public WorkflowStateDTO getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId(
			Integer workflowStateId, String tenantId, String solutionCategoryId) {
		LOGGER.info("WorkflowStateServiceImpl : getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId : Start");
		 
		WorkflowStateDTO workflowStateDTO=null;
		WorkflowState workflowStateDetail=null;
		if (null != workflowStateId && null != tenantId && null != solutionCategoryId) {
			workflowStateDetail = workflowStateRepository.findWorkflowStateByWorkflowstateIdAndTenantIdAndSolCatId(workflowStateId,tenantId,
					solutionCategoryId);
		}
		if (null != workflowStateDetail ) {
			
			workflowStateDTO=new WorkflowStateDTO();
			workflowStateDTO=dozerBeanMapper.map(workflowStateDetail, WorkflowStateDTO.class);
		}
		LOGGER.info("WorkflowStateServiceImpl : getWorkflowStateByWorkflowStateIdandTenantIdandSolCatId : End");
		return workflowStateDTO;
	}


}
