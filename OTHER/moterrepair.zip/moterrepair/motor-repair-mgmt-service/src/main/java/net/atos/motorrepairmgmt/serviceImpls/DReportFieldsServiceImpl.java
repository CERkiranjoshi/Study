package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.DReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.entity.DReportFields;
import net.atos.motorrepairmgmt.repository.MotorNamePlateDetailRepository;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.DReportFieldsRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.DReportFieldsService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610051
 * 
 */
@Service
public class DReportFieldsServiceImpl implements DReportFieldsService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The DReportFields Repository */
	@Autowired
	private DReportFieldsRepository dReportFieldsRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The MotorNamePlateDetail Repository */
	@Autowired
	private MotorNamePlateDetailRepository motorNamePlateDetailRepository;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(DReportFieldsServiceImpl.class);

	/**
	 * This method creates/updates a DReportFields record. The method performs
	 * an update operation when motorDReportFieldId is passed and an existing
	 * record with matching motorDReportFieldId is fetched for updation Or it
	 * will create a new record.
	 * 
	 * @param dReportFieldsDTO
	 *            The DReportFields Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public DReportFieldsDTO createUpdateDReportFields(DReportFieldsDTO dReportFieldsDTO) {
		LOGGER.info("DReportFieldsServiceImpl : createUpdateDReportFields : Start");
		DReportFields dReportFieldsDetails = null;
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		Long returnId = -1l;
		try {
			if (null != dReportFieldsDTO) {
				if (null != dReportFieldsDTO.getMotorDReportFieldId()) {
					dReportFieldsDetails = dReportFieldsRepository.findOne(dReportFieldsDTO.getMotorDReportFieldId());
					if (null != dReportFieldsDetails) {
						dReportFieldsDTO.setModifiedOn(new Date());
						//dReportFieldsDTO.setCreatedOn(dReportFieldsDetails.getCreatedOn());
					} else {
						dReportFieldsDTO.setCreatedOn(new Date());
					}
				} else {
					dReportFieldsDTO.setCreatedOn(new Date());
				}
				if (null == dReportFieldsDetails) {
					dReportFieldsDetails = new DReportFields();
				}
				
				if (null != dReportFieldsDTO.getSubProcessFields()) {
					SubProcessFields subProcessFieldsDetail = subProcessFieldsRepository.findOne(dReportFieldsDTO
							.getSubProcessFields().getWlfwSubProcessId());
					dReportFieldsDetails.setSubProcessFields(subProcessFieldsDetail);
					dReportFieldsDTO.setFunctionCode(subProcessFieldsDetail.getFunctionCode());
				}
				if (null != dReportFieldsDTO.getMotorNamePlateDetail()) {
					motorNamePlateDetailDTO = dReportFieldsDTO.getMotorNamePlateDetail();
					if (null == motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {
						motorNamePlateDetailDTO.setCreatedOn(new Date());
						motorNamePlateDetail = new MotorNamePlateDetail();

						dReportFieldsDTO.setMotorNamePlateDetail(motorNamePlateDetailDTO);
						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(dReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						// set audit
						motorNamePlateDetail.setFunctionCode(dReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(dReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						dReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						dReportFieldsDTO.setMotorNamePlateDetail(null);
					} else {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
						motorNamePlateDetailDTO.setCreatedOn(dReportFieldsDetails.getMotorNamePlateDetail()
								.getCreatedOn());
						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(dReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						//set audit
						motorNamePlateDetail.setFunctionCode(dReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(dReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						dReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						dReportFieldsDTO.setMotorNamePlateDetail(null);
					}
				}
				
				
				dReportFieldsDTO.setSubProcessFields(null);
				BeanUtils
						.copyProperties(dReportFieldsDTO, dReportFieldsDetails, getNullPropertyNames(dReportFieldsDTO));
				//set audit
				dReportFieldsDetails.setFunctionCode(dReportFieldsDTO.getFunctionCode());
				DReportFields savedObj = dReportFieldsRepository.save(dReportFieldsDetails);
				if (null != savedObj) {
					LOGGER.info("DReportFieldsServiceImpl : createUpdateDReportFields : Record Saved/Updated");
					dReportFieldsDTO = new DReportFieldsDTO();
					dReportFieldsDTO = dozerBeanMapper.map(savedObj, DReportFieldsDTO.class);
				}
			} else {
				LOGGER.info("DReportFieldsServiceImpl : createUpdateDReportFields : dReportFieldsDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return dReportFieldsDTO;
	}

	/**
	 * This deletes a DReportFields on the basis of its motorDReportFieldId.
	 * 
	 * @param motorDReportFieldId
	 *            The MotorDReportField Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteDReportFieldsByMotorDReportFieldId(Long motorDReportFieldId) {
		LOGGER.info("DReportFieldsServiceImpl : deleteDReportFieldsByMotorDReportFieldId : Start");
		boolean returnVal = false;
		try {
			if (null != motorDReportFieldId) {
				dReportFieldsRepository.delete(motorDReportFieldId);
				returnVal = true;
			} else {
				LOGGER.info("DReportFieldsServiceImpl : deleteDReportFieldsByMotorDReportFieldId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("DReportFieldsServiceImpl : deleteDReportFieldsByMotorDReportFieldId : Not Deleted. Record Not Present");
		}
		return returnVal;
	}

	/**
	 * This method retrieves all the DReportFields
	 * 
	 * @return List of DReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public List<DReportFieldsDTO> getAllDReportFields() {
		LOGGER.info("DReportFieldsServiceImpl : getAllDReportFields : Start");
		List<DReportFieldsDTO> dReportFieldsDTOs = null;
		DReportFieldsDTO dReportFieldsDTO = null;
		List<DReportFields> dReportFieldsDetails = dReportFieldsRepository.findAll();
		if (null != dReportFieldsDetails) {
			dReportFieldsDTOs = new ArrayList<DReportFieldsDTO>();
			for (DReportFields dReportFieldsRecord : dReportFieldsDetails) {
				dReportFieldsDTO = new DReportFieldsDTO();
				dReportFieldsDTO = dozerBeanMapper.map(dReportFieldsRecord, DReportFieldsDTO.class);
				dReportFieldsDTOs.add(dReportFieldsDTO);
			}
		}
		LOGGER.info("DReportFieldsServiceImpl : getAllDReportFields : End");
		return dReportFieldsDTOs;
	}

	/**
	 * This method retrieves dReportFieldsDetail
	 * 
	 * @return DReportFieldsDTO object
	 * 
	 */
	@Override
	@Transactional
	public DReportFieldsDTO getDReportFieldsBySubProcessID(Long wlfwSubProcessId) {
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsBySubProcessID : Start");

		DReportFieldsDTO dReportFieldsDTO = null;
		DReportFields dReportFieldsDetail = dReportFieldsRepository.findDReportFieldsBySubProcessID(wlfwSubProcessId);
		if (null != dReportFieldsDetail) {
			dReportFieldsDTO = new DReportFieldsDTO();
			dReportFieldsDTO = dozerBeanMapper.map(dReportFieldsDetail, DReportFieldsDTO.class);
			dReportFieldsDTO.setFunctionCode(dReportFieldsDetail.getFunctionCode());
		}
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsBySubProcessID : End");
		return dReportFieldsDTO;
	}

	/**
	 * This method retrieves MotorNamePlateDetail
	 * 
	 * @return MotorNamePlateDetailDTO
	 * 
	 */
	@Override
	@Transactional
	public MotorNamePlateDetailDTO getNamePlateByDReportId(Long motorDReportFieldId) {
		LOGGER.info("DReportFieldsServiceImpl : getNamePlateByDReportId : Start");
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		MotorNamePlateDetail motorNamePlateDetail = dReportFieldsRepository
				.findNamePlateByDReportId(motorDReportFieldId);
		if (null != motorNamePlateDetail) {
			motorNamePlateDetailDTO = new MotorNamePlateDetailDTO();
			motorNamePlateDetailDTO = dozerBeanMapper.map(motorNamePlateDetail, MotorNamePlateDetailDTO.class);
		}
		LOGGER.info("DReportFieldsServiceImpl : getNamePlateByDReportId : End");
		return motorNamePlateDetailDTO;
	}

	/**
	 * This method add or update SpeedDetail To DReportFields
	 * 
	 * @param MotorNamePlateDetailDTO
	 *            and motorDReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean addUpdateMotorNamePlateDetailToDReportFields(Long motorDReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		LOGGER.info("DReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToDReportFields : Start");
		boolean returnVal = false;
		DReportFields dReportFields = null;
		DReportFields savedObj = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		try {
			if (null != motorDReportFieldId && null != motorNamePlateDetailDTO) {
				dReportFields = dReportFieldsRepository.findOne(motorDReportFieldId);
				if (null != dReportFields) {
					if (null != motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
					}
					if (null == motorNamePlateDetailDTO.getCreatedOn()) {
						motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
					}
					motorNamePlateDetail = dozerBeanMapper.map(motorNamePlateDetailDTO, MotorNamePlateDetail.class);
					dReportFields.setMotorNamePlateDetail(motorNamePlateDetail);
					savedObj = dReportFieldsRepository.save(dReportFields);
					if (null != savedObj) {
						LOGGER.info("DReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToDReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("DReportFieldsServiceImpl : addUpdateMotorNamePlateDetailToDReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method add or update SubProcessFields To DReportFields
	 * 
	 * @param SubProcessFieldsDTO
	 *            and motorDReportFieldId
	 * 
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long addUpdateSubProcessFieldsToDReportFields(Long motorDReportFieldId,
			SubProcessFieldsDTO subProcessFieldsDTO) {
		LOGGER.info("DReportFieldsServiceImpl : addUpdateSubProcessFieldsToDReportFields : Start");
		Long returnVal = -1l;
		DReportFields dReportFields = null;
		DReportFields savedObj = null;
		SubProcessFields subProcessFields = null;
		try {
			if (null != motorDReportFieldId && null != subProcessFieldsDTO) {
				dReportFields = dReportFieldsRepository.findOne(motorDReportFieldId);
				if (null != dReportFields) {
					if (null != subProcessFieldsDTO.getWlfwSubProcessId()) {
						subProcessFields = subProcessFieldsRepository
								.findOne(subProcessFieldsDTO.getWlfwSubProcessId());
					}
					subProcessFields = dozerBeanMapper.map(subProcessFieldsDTO, SubProcessFields.class);
					dReportFields.setSubProcessFields(subProcessFields);
					savedObj = dReportFieldsRepository.save(dReportFields);
					if (null != savedObj) {
						LOGGER.info("DReportFieldsServiceImpl : addUpdateSubProcessFieldsToDReportFields : Record Saved/Updated");
						returnVal = savedObj.getMotorDReportFieldId();
					} else {
						LOGGER.info("DReportFieldsServiceImpl : addUpdateSubProcessFieldsToDReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	/**
	 * This method retrieves a DReportFields on the basis of its
	 * motorDReportFieldId.
	 * 
	 * @param motorDReportFieldId
	 *            The arcRepairEstimate Id
	 * @return DReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public DReportFieldsDTO getDReportFieldsByMotorDReportFieldId(Long motorDReportFieldId) {
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsByMotorDReportFieldId : Start");
		DReportFieldsDTO dReportFieldsDTO = null;
		DReportFields dReportFieldsDTODetails = null;
		if (null != motorDReportFieldId) {
			dReportFieldsDTODetails = dReportFieldsRepository.findOne(motorDReportFieldId);
			if (null != dReportFieldsDTODetails) {
				dReportFieldsDTO = new DReportFieldsDTO();
				dReportFieldsDTO = dozerBeanMapper.map(dReportFieldsDTODetails, DReportFieldsDTO.class);
			}
		}
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsByMotorDReportFieldId : End");
		return dReportFieldsDTO;
	}
	
	@Override
	public DReportFieldsDTO getDReportFieldsApprovedStatusBySubProcessID(
			Long wlfwSubProcessId) {
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsApprovedStatusBySubProcessID : Start");

		DReportFieldsDTO dReportFieldsDTO = null;
		if (null != wlfwSubProcessId) {
			Object[] objectArr = dReportFieldsRepository
					.findDReportFieldsApprovedStatusSubProcessID(wlfwSubProcessId);
			if (null != objectArr) {
				
				dReportFieldsDTO = new DReportFieldsDTO();
				if(null != objectArr[0]){
					dReportFieldsDTO.setMotorDReportFieldId(Long.parseLong(objectArr[0].toString()));	
				}
				if(null != objectArr[1]){
					dReportFieldsDTO.setApprovalStatus(Integer.parseInt(objectArr[1].toString()));	
				}
				if (null != objectArr[2]) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					try {
						if(null != objectArr[2])
							dReportFieldsDTO.setStatusUpdatedOn(sdf.parse(objectArr[2].toString()));
					} catch (ParseException e) {
						LOGGER.warn("Error while parsing date in the pattern: yyyy-MM-dd HH:mm:ss.SSS for value: " + objectArr[2].toString());
					}
				}
				if(null != objectArr[3]){
					dReportFieldsDTO.setStatusUpdatedByRefId(objectArr[3].toString());	
				}
			}
		}
		LOGGER.info("DReportFieldsServiceImpl : getDReportFieldsApprovedStatusBySubProcessID : End");
		return dReportFieldsDTO;
	}
}
