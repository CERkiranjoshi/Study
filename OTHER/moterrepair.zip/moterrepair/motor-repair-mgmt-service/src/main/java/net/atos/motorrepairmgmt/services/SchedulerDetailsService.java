package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;

/**
 * @author Anand Ved
 * 
 */
public interface SchedulerDetailsService {
	String createUpdateSchedulerDetails(SchedulerDetailsDTO schedulerDetailsDTO);

	List<SchedulerDetailsDTO> getAllSchedulerDetails();

	SchedulerDetailsDTO getSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(String schedulerDetailsId,
			String tenantId, String solutionCategoryId);

	List<SchedulerDetailsDTO> getSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId(Long subprocessId,
			String tenantId, String solutionCategoryId);

	List<SchedulerDetailsDTO> getAllSchedulerDetailsByTenantIdAndSolCatId(String tenantId, String solutionCategoryId);

	List<SchedulerDetailsDTO> getAllPendingSchedulerDetailsByTenantIdAndSolCatId(String tenantId, String solutionCategoryId);

	Boolean deleteSchedulerDetailsBySchedulerDetailsId(String schedulerDetailsId);
}
