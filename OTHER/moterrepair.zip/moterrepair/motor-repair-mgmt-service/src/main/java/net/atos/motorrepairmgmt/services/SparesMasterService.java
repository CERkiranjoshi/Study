/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.SparesMasterDTO;

/**
 * @author Sweety Kothari
 *
 */
public interface SparesMasterService {

	List<SparesMasterDTO> getAllSparesByTenantIdNSolutionCategory(String tenantId,String solutionCatId);
	SparesMasterDTO getSparesMasterById(Long id);
}
