/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;

/**
 * @author a603981
 *
 */
public interface AdditionalContactDetailService {
	public Long createUpdateAdditionalContactDetail(AdditionalContactDetailDTO additionalContactDetailDTO);

	public List<AdditionalContactDetailDTO> getAllAdditionalContactDetail();

	public AdditionalContactDetailDTO getAdditionalContactDetailByAdditionalContactDetailId(
			Long additionalContactDetailId);

	public Boolean deleteAdditionalContactDetailByAdditionalContactDetailId(Long additionalContactDetailId);
}
