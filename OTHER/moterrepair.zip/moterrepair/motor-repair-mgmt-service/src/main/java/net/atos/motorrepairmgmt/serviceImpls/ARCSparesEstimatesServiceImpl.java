package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;
import net.atos.motorrepairmgmt.entity.ARCSparesEstimates;
import net.atos.motorrepairmgmt.repository.ARCSparesEstimatesRepository;
import net.atos.motorrepairmgmt.services.ARCSparesEstimatesService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610051
 * 
 */
@Service
public class ARCSparesEstimatesServiceImpl implements ARCSparesEstimatesService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/** The ARCSparesEstimates Repository */
	@Autowired
	private ARCSparesEstimatesRepository arcSparesEstimatesRepository;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ARCSparesEstimatesServiceImpl.class);

	/**
	 * This method creates/updates a ARCSparesEstimates record. The method
	 * performs an update operation when arcSparesEstimateId is passed and an
	 * existing record with matching arcSparesEstimateId is fetched for updation
	 * Or it will create a new record .
	 * 
	 * @param ARCSparesEstimatesDTO
	 *            The arcSparesEstimates Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateARCSparesEstimates(ARCSparesEstimatesDTO arcSparesEstimatesDTO) {
		LOGGER.info("ARCSparesEstimatesServiceImpl : createUpdateARCSparesEstimates : Start");
		ARCSparesEstimates arcSparesEstimatesDetails = null;
		Long returnId = -1l;
		try {
			if (null != arcSparesEstimatesDTO) {

				if (null != arcSparesEstimatesDTO.getArcSparesEstimateId()) {
					arcSparesEstimatesDetails = arcSparesEstimatesRepository.findOne(arcSparesEstimatesDTO
							.getArcSparesEstimateId());
				}
				if (null == arcSparesEstimatesDetails) {
					arcSparesEstimatesDetails = new ARCSparesEstimates();
				}
				BeanUtils.copyProperties(arcSparesEstimatesDTO, arcSparesEstimatesDetails,
						getNullPropertyNames(arcSparesEstimatesDTO));
				ARCSparesEstimates savedObj = arcSparesEstimatesRepository.save(arcSparesEstimatesDetails);
				if (null != savedObj) {
					LOGGER.info("ARCSparesEstimatesServiceImpl : createUpdateARCSparesEstimates : Record Saved/Updated");
					returnId = savedObj.getArcSparesEstimateId();
				}
			} else {
				LOGGER.info("ARCSparesEstimatesServiceImpl : createUpdateARCSparesEstimates : arcSparesEstimatesDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * This deletes a ARCSparesEstimates on the basis of its
	 * arcSparesEstimateId.
	 * 
	 * @param arcSparesEstimateId
	 *            The ARCSparesEstimate Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteARCSparesEstimatesByARCSparesEstimateId(Long arcSparesEstimateId) {
		LOGGER.info("ARCSparesEstimatesServiceImpl : deleteARCSparesEstimatesByARCSparesEstimateId : Start");
		boolean returnVal = false;
		try {
			if (null != arcSparesEstimateId) {
				arcSparesEstimatesRepository.delete(arcSparesEstimateId);
				returnVal = true;
			} else {
				LOGGER.info("ARCSparesEstimatesServiceImpl : deleteARCSparesEstimatesByARCSparesEstimateId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("ARCSparesEstimatesServiceImpl : deleteARCSparesEstimatesByARCSparesEstimateId : Not Deleted. Record Not Present");
		}
		return returnVal;
	}

	/**
	 * This method retrieves a ARCSparesEstimates on the basis of its
	 * arcSparesEstimateId.
	 * 
	 * @param arcSparesEstimateId
	 *            The arcSparesEstimate Id
	 * @return ARCSparesEstimates DTO
	 * 
	 */
	@Override
	@Transactional
	public ARCSparesEstimatesDTO getARCSparesEstimatesByARCSparesEstimateId(Long arcSparesEstimateId) {
		LOGGER.info("ARCSparesEstimatesServiceImpl : getARCSparesEstimatesByARCSparesEstimateId : Start");
		ARCSparesEstimatesDTO arcSparesEstimatesDTO = null;
		if (null != arcSparesEstimateId) {
			ARCSparesEstimates arcSparesEstimatesDetails = arcSparesEstimatesRepository.findOne(arcSparesEstimateId);
			if (null != arcSparesEstimatesDetails) {
				arcSparesEstimatesDTO = new ARCSparesEstimatesDTO();
				arcSparesEstimatesDTO = dozerBeanMapper.map(arcSparesEstimatesDetails, ARCSparesEstimatesDTO.class);
			}
		}
		LOGGER.info("ARCSparesEstimatesServiceImpl : getARCSparesEstimatesByARCSparesEstimateId : End");
		return arcSparesEstimatesDTO;
	}

	/**
	 * This method retrieves all the ARCSparesEstimates
	 * 
	 * @return List of ARCSparesEstimatesDTO
	 * 
	 */
	@Override
	@Transactional
	public List<ARCSparesEstimatesDTO> getAllARCSparesEstimates() {
		LOGGER.info("ARCSparesEstimatesServiceImpl : getAllARCSparesEstimates : Start");
		List<ARCSparesEstimatesDTO> arcSparesEstimatesDTOs = null;
		ARCSparesEstimatesDTO arcSparesEstimatesDTO = null;
		List<ARCSparesEstimates> arcSparesEstimatesDetails = arcSparesEstimatesRepository.findAll();
		if (null != arcSparesEstimatesDetails) {
			arcSparesEstimatesDTOs = new ArrayList<ARCSparesEstimatesDTO>();
			for (ARCSparesEstimates arcSparesEstimatesRecord : arcSparesEstimatesDetails) {
				arcSparesEstimatesDTO = new ARCSparesEstimatesDTO();
				arcSparesEstimatesDTO = dozerBeanMapper.map(arcSparesEstimatesRecord, ARCSparesEstimatesDTO.class);
				arcSparesEstimatesDTOs.add(arcSparesEstimatesDTO);
			}
		}
		LOGGER.info("ARCSparesEstimatesServiceImpl : getAllARCSparesEstimates : End");
		return arcSparesEstimatesDTOs;
	}
}
