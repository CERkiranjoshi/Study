/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.atos.motorrepairmgmt.dto.BuildDetailDTO;
import net.atos.motorrepairmgmt.entity.BuildDetail;
import net.atos.motorrepairmgmt.repository.BuildDetailRepository;
import net.atos.motorrepairmgmt.services.BuildDetailService;

/**
 * @author Sweety Kothari
 * service to get detail about build
 */
@Service
public class BuildDetailServiceImpl implements BuildDetailService {
	
	@Autowired
	private BuildDetailRepository buildDetailRepository;
	
	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;
	
	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BuildDetailServiceImpl.class);

	/* 
	 * method to get current build detail by tenantId & solution category id
	 */
	@Override
	public BuildDetailDTO getCurrentBuildDetailByTenantIdNSolCategory(String tenantId, String solCategoryID) {
		// TODO Auto-generated method stub
		LOGGER.info("getCurrentBuildDetailByTenantIdNSolCategory : START" +tenantId +"solution category id "+solCategoryID);
		BuildDetail buildDetail= buildDetailRepository.getCurrentBuildDetail(tenantId, solCategoryID);
		BuildDetailDTO buildDetailDTO=null;
		if(null !=buildDetail){
	     buildDetailDTO=dozerBeanMapper.map(buildDetail, BuildDetailDTO.class);
		}
		LOGGER.info(" getCurrentBuildDetailByTenantIdNSolCategory :END");

        return buildDetailDTO;
	}

}
