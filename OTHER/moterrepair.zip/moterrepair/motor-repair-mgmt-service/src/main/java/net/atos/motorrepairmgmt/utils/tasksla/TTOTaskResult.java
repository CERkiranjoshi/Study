/**
 * 
 */
package net.atos.motorrepairmgmt.utils.tasksla;

/**
 * @author Anand Ved
 *
 */
public class TTOTaskResult {

}
