package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;
import net.atos.motorrepairmgmt.repository.MotorVoltageDetailRepository;
import net.atos.motorrepairmgmt.services.MotorVoltageDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class MotorVoltageDetailServiceImpl implements MotorVoltageDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The MotorVoltageDetail Repository */
	@Autowired
	private MotorVoltageDetailRepository motorVoltageDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorVoltageDetailServiceImpl.class);

	/**
	 * The method creates/updates a MotorVoltageDetail record. The method
	 * performs an update operation when MotorVoltageDetailId is passed and an
	 * existing record with matching MotorVoltageDetailId is fetched for
	 * updation.
	 * 
	 * @param motorVoltageDetailDTO
	 *            The MotorVoltage Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateMotorVoltageDetail(MotorVoltageDetailDTO motorVoltageDetailDTO) {
		LOGGER.info("MotorVoltageDetailServiceImpl : createUpdateMotorVoltageDetail : Start");
		Long id = -1l;
		MotorVoltageDetail motorVoltageDetails = new MotorVoltageDetail();
		try {
			if (null != motorVoltageDetailDTO) {
				if (null != motorVoltageDetailDTO.getMotorVoltageDetailId()) {
					motorVoltageDetails = motorVoltageDetailRepository.findOne(motorVoltageDetailDTO
							.getMotorVoltageDetailId());
				}

				BeanUtils.copyProperties(motorVoltageDetailDTO, motorVoltageDetails,
						NullPropertyMapper.getNullPropertyNames(motorVoltageDetailDTO));

				MotorVoltageDetail savedObj = motorVoltageDetailRepository.save(motorVoltageDetails);
				LOGGER.info("MotorVoltageDetailServiceImpl : createUpdateMotorVoltageDetail : Record Saved/Updated");
				if (null != savedObj) {
					id = savedObj.getMotorVoltageDetailId();
				}
			} else {
				LOGGER.info("MotorVoltageDetailServiceImpl : createUpdateMotorVoltageDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return id;
	}

	/**
	 * The method retrieves all the MotorVoltageDetail
	 * 
	 * @return List of MotorVoltageDetail DTOs
	 * 
	 */
	@Override
	public List<MotorVoltageDetailDTO> getAllMotorVoltageDetail() {
		LOGGER.info("MotorVoltageDetailServiceImpl : getAllMotorVoltageDetail : Start");

		List<MotorVoltageDetailDTO> motorVoltageDetailDTOs = null;

		List<MotorVoltageDetail> motorVoltageDetails = motorVoltageDetailRepository.findAll();

		if (null != motorVoltageDetails) {
			motorVoltageDetailDTOs = new ArrayList<MotorVoltageDetailDTO>();

			MotorVoltageDetailDTO motorVoltageDetailDTO = null;

			for (MotorVoltageDetail motorSpeedDetailRecord : motorVoltageDetails) {
				motorVoltageDetailDTO = new MotorVoltageDetailDTO();

				motorVoltageDetailDTO = dozerBeanMapper.map(motorSpeedDetailRecord, MotorVoltageDetailDTO.class);

				motorVoltageDetailDTOs.add(motorVoltageDetailDTO);
			}
		}
		LOGGER.info("MotorVoltageDetailServiceImpl : getAllMotorVoltageDetail : End");
		return motorVoltageDetailDTOs;
	}

	/**
	 * The method retrieves a MotorVoltageDetail on the basis of
	 * motorVoltageDetail id.
	 * 
	 * @param motorVoltageDetailId
	 *            The MotorVoltageDetail Id
	 * @return MotorVoltageDetail DTO
	 * 
	 */
	@Override
	public MotorVoltageDetailDTO getVoltageDetailByVoltageDetailId(Long motorVoltageDetailId) {
		LOGGER.info("MotorVoltageDetailServiceImpl : getVoltageDetailByVoltageDetailID : Start");
		MotorVoltageDetailDTO motorVoltageDetailDTO = null;
		if (null != motorVoltageDetailId) {
			MotorVoltageDetail motorVoltageDetails = motorVoltageDetailRepository.findOne(motorVoltageDetailId);

			if (null != motorVoltageDetails) {
				motorVoltageDetailDTO = dozerBeanMapper.map(motorVoltageDetails, MotorVoltageDetailDTO.class);
			}
		}
		LOGGER.info("MotorVoltageDetailServiceImpl : getVoltageDetailByVoltageDetailID : End");
		return motorVoltageDetailDTO;
	}

	/**
	 * The deletes a MotorVoltageDetail on the basis its motorVoltageDetail id.
	 * 
	 * @param motorVoltageDetailId
	 *            The motorVoltageDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMotorVoltageDetailByMotorVoltageDetailId(Long motorVoltageDetailId) {
		LOGGER.info("MotorVoltageDetailServiceImpl : deleteMotorVoltageDetailByMotorVoltageDetailID : Start");
		boolean returnVal = false;
		try {
			if (null != motorVoltageDetailId) {
				motorVoltageDetailRepository.delete(motorVoltageDetailId);
				returnVal = true;
			} else {
				LOGGER.info("MotorVoltageDetailServiceImpl : deleteMotorVoltageDetailByMotorVoltageDetailID : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}
