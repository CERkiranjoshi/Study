/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

/**
 * @author a593775
 * 
 */
public interface NotificationService {

	public boolean autoTriggerNotification(String functionCode,
			String templateCode, Long subProcessId);

	public void triggerAssignmentNotification(String functionCode,
			String templateCode, Long subProcessId, String groupName, String arcRefId);

	public void triggerCustomerNotification(String functionCode,
			String templateCode, Long subProcessId, String groupName,String arcRefId);

	public void triggerSLANotification(String functionCode, Integer notifType,
			String slaType, Long subProcessId, String RINumber,
			List<String> toEmailAddress, List<String> ccEmailAddress,
			boolean isEmailEnabled, boolean isSMSEnabled,String arcRefId);

}
