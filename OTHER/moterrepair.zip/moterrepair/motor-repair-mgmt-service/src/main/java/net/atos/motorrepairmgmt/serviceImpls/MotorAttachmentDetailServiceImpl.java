/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorAttachmentDetail;
import net.atos.motorrepairmgmt.repository.MotorAttachmentDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorAttachmentsRepository;
import net.atos.motorrepairmgmt.services.MotorAttachmentDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603327
 * 
 */
@Component
public class MotorAttachmentDetailServiceImpl implements MotorAttachmentDetailService {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorSparesDetailServiceImpl.class);

	/**
	 * The Dozer Bean Mapper
	 */
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	/** The MotorAttachmentDetail Repository */
	@Autowired
	private MotorAttachmentDetailRepository motorAttachmentDetailRepository;

	@Autowired
	private MotorAttachmentsRepository motorAttachmentsRepository;

	/** The UniqueIdGenerator */
	@Autowired
	UniqueIdGenerator uniqueIdGenerator;

	/**
	 * The method retrieves all the MotorAttachmentDetail
	 * 
	 * @return List of MotorAttachmentDetail DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetail() {
		LOGGER.info("MotorAttachmentDetailServiceImpl : getAllMotorAttachmentDetail : Start");
		List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOs = null;
		List<MotorAttachmentDetail> motorAttachmentDetails = motorAttachmentDetailRepository.findAll();
		if (null != motorAttachmentDetails) {
			motorAttachmentDetailDTOs = new ArrayList<MotorAttachmentDetailDTO>();
			for (MotorAttachmentDetail MotorAttachmentDetailRecord : motorAttachmentDetails) {
				MotorAttachmentDetailDTO motorAttachmentDetailDTO = new MotorAttachmentDetailDTO();
				motorAttachmentDetailDTO = dozerBeanMapper.map(MotorAttachmentDetailRecord,
						MotorAttachmentDetailDTO.class);
				motorAttachmentDetailDTOs.add(motorAttachmentDetailDTO);
			}
		}
		LOGGER.info("MotorAttachmentDetailServiceImpl : getAllMotorAttachmentDetail : End");
		return motorAttachmentDetailDTOs;
	}

	/**
	 * The method creates/updates a motorAttachmentDetail record. The method performs an update operation when
	 * motorAttachments Id is passed and an existing record with matching motorAttachments Id is fetched for updation.
	 * 
	 * @param motorAttachmentDetailDTO
	 *            The MotorAttachmentDetail Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateMotorAttachmentDetail(MotorAttachmentDetailDTO motorAttachmentDetailDTO) {
		Long id = -1l;
		LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorAttachmentDetail() : Start");
		MotorAttachmentDetail motorAttachmentDetails = new MotorAttachmentDetail();
		if (null != motorAttachmentDetailDTO) {
			if (null != motorAttachmentDetailDTO.getMotorAttachmentsId()) {
				motorAttachmentDetails = motorAttachmentDetailRepository.findOne(motorAttachmentDetailDTO
						.getMotorAttachmentsId());
			} else {
				motorAttachmentDetailDTO.setUploadedOn(new Date());
			}
			BeanUtils.copyProperties(motorAttachmentDetailDTO, motorAttachmentDetails,
					NullPropertyMapper.getNullPropertyNames(motorAttachmentDetailDTO));
			motorAttachmentDetailRepository.save(motorAttachmentDetails);
			LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorAttachmentDetail() : Record Saved/Updated");
			id = motorAttachmentDetails.getMotorAttachmentsId();
		}
		LOGGER.info("MotorSparesDetailServiceImpl : createUpdateMotorAttachmentDetail() : Not saved");
		return id;
	}

	/**
	 * The deletes a MotorAttachmentDetail on the basis its motorAttachments Id.
	 * 
	 * @param motorAttachmentsId
	 *            The MotorAttachmentDetail motorAttachmentsId
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteMotorAttachmentDetail(Long motorAttachmentsId) {
		LOGGER.info("MotorAttachmentDetailServiceImpl : deleteMotorAttachmentDetail() : Start");
		try {
			if (null != motorAttachmentsId) {
				motorAttachmentDetailRepository.delete(motorAttachmentsId);
				return true;
			}
		} catch (Exception e) {
			LOGGER.info("Error in deletion " + e);
			return false;
		}
		LOGGER.info("MotorAttachmentDetailServiceImpl : deleteMotorAttachmentDetail() : End");
		return false;
	}

	/**
	 * The method retrieves a MotorAttachmentDetail on the basis of motorAttachments Id.
	 * 
	 * @param motorAttachments
	 *            Id The MotorAttachmentDetail motorAttachmentsId
	 * @return MotorAttachmentDetailDTO
	 * 
	 */
	@Override
	public MotorAttachmentDetailDTO getMotorAttachmentDetailById(Long motorAttachmentsId) {
		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentDetailById : Start");
		MotorAttachmentDetailDTO motorAttachmentDetailDTO = null;
		if (null != motorAttachmentsId) {
			MotorAttachmentDetail motorAttachmentDetails = motorAttachmentDetailRepository.findOne(motorAttachmentsId);
			if (null != motorAttachmentDetails) {
				motorAttachmentDetailDTO = dozerBeanMapper.map(motorAttachmentDetails, MotorAttachmentDetailDTO.class);
			}
		}
		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentDetailById : End");
		return motorAttachmentDetailDTO;
	}

	@Override
	public MotorAttachmentDetailDTO getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId(
			Long motorAttachmentsId, String tenantId, String solutionCategoryId) {
		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId : Start");

		MotorAttachmentDetailDTO motorAttachmentDetailDTO = null;
		MotorAttachmentDetail motorAttachmentDetails = null;
		if (null != motorAttachmentsId && null != tenantId && null != solutionCategoryId) {
			motorAttachmentDetails = motorAttachmentDetailRepository
					.findMotorAttachmentDetailByMotorAttachmentsIdAndTenantIdAndSolCatId(motorAttachmentsId, tenantId,
							solutionCategoryId);
		}
		if (null != motorAttachmentDetails) {

			motorAttachmentDetailDTO = new MotorAttachmentDetailDTO();
			motorAttachmentDetailDTO = dozerBeanMapper.map(motorAttachmentDetails, MotorAttachmentDetailDTO.class);
		}
		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId : End");
		return motorAttachmentDetailDTO;
	}

	/**
	 * Fetches Count of attachments for motor based on parameters.
	 * 
	 * @param subprocessId
	 *            The subprocess for which attachment count is to be fetched.
	 * 
	 * @param externalAttachments
	 *            If true, only count of attachments marked for external view is returned
	 * 
	 * @param solnCategoryId
	 *            The solution category for which motor attachements count is to be fetched.
	 * 
	 * @param tenantId
	 *            The tenantId for which motor attachments count is to be fetched.
	 */
	@Override
	public Long getMotorAttachmentCountBySubprocessIdandTenantIdandSolCatId(Long subprocessId,
			boolean externalAttachments, String solnCategoryId, String tenantId, String uploadedBy) {
		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentCountBySubprocessIdandTenantIdandSolCatId : Start");

		Long attachmentsCount = motorAttachmentsRepository.getMotorAttachmentsCount(subprocessId,
				externalAttachments, solnCategoryId, tenantId, uploadedBy);

		LOGGER.info("MotorAttachmentDetailServiceImpl : getMotorAttachmentCountBySubprocessIdandTenantIdandSolCatId : End");
		return attachmentsCount;
	}

}
