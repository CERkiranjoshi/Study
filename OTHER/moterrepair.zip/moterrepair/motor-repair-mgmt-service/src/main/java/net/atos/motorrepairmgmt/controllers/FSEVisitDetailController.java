/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.services.FSEVisitDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603981
 *
 */
@Controller
@EnableSwagger
@RequestMapping(value = "fSEVisitDetailService")
public class FSEVisitDetailController {

	@Autowired
	private FSEVisitDetailService fSEVisitDetailService;

	@RequestMapping(value = "/createUpdateFSEVisitDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates FSEVisitDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateFSEVisitDetail(
			@ApiParam(value = "FSEVisitDetail object that needs to be added or update in the FSEVisitDetail") @RequestBody FSEVisitDetailDTO fSEVisitDetailDTO) {
		return fSEVisitDetailService.createUpdateFSEVisitDetail(fSEVisitDetailDTO);
	}

	@RequestMapping(value = "/getAllFSEVisitDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find FSEVisitDetail ", notes = "Returns a FSEVisitDetail entity", response = FSEVisitDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<FSEVisitDetailDTO> getAllFSEVisitDetail() {
		return fSEVisitDetailService.getAllFSEVisitDetail();
	}

	@RequestMapping(value = "/getFSEVisitDetailById/{fseVisitDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find FSEVisitDetail By FSEVisitDetail Id", notes = "Returns a FSEVisitDetail entity when FSEVisitDetail Id is passed", response = FSEVisitDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid FSEVisitDetail Id supplied"),
			@ApiResponse(code = 404, message = "FSEVisitDetail not found") })
	public @ResponseBody FSEVisitDetailDTO getFSEVisitDetailById(
			@ApiParam(value = "FSEVisitDetail Id of the FSEVisitDetail that needs to be fetched", required = true) @PathVariable("fseVisitDetailId") Long fseVisitDetailId) {
		return fSEVisitDetailService.getFSEVisitDetailById(fseVisitDetailId);
	}

	@RequestMapping(value = "/getFSEVisitByName/{fseName}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find FSEVisitDetail By FSEVisitDetail Name", notes = "Returns a FSEVisitDetail entity when FSEVisitDetail Name is passed", response = FSEVisitDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid FSEVisitDetail Name supplied"),
			@ApiResponse(code = 404, message = "FSEVisitDetail not found") })
	public @ResponseBody List<FSEVisitDetailDTO> getFSEVisitByName(
			@ApiParam(value = "FSEVisitDetail Name of the FSEVisitDetail that needs to be fetched", required = true) @PathVariable("fseName") String fseName) {
		return fSEVisitDetailService.getFSEVisitByName(fseName);
	}

	@RequestMapping(value = "/deleteFSEVisitDetailByFSEVisitDetailId/{fseVisitDetailId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Delete FSEVisitDetail By FSEVisitDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid FSEVisitDetail Id value") })
	public @ResponseBody Boolean deleteFSEVisitDetailByFSEVisitDetailId(
			@ApiParam(value = "FSEVisitDetail Id to delete", required = true) @PathVariable("fseVisitDetailId") Long fseVisitDetailId) {
		try {
			return fSEVisitDetailService.deleteFSEVisitDetailByFSEVisitDetailId(fseVisitDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}
