package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;
import net.atos.motorrepairmgmt.entity.ARCMaster;
import net.atos.motorrepairmgmt.entity.RegionMaster;
import net.atos.motorrepairmgmt.repository.RegionMasterRepository;
import net.atos.motorrepairmgmt.services.RegionMasterService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

/**
 * @author a603975
 * 
 */

@Service
public class RegionMasterServiceImpl implements RegionMasterService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private RegionMasterRepository regionMasterRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(RegionMasterServiceImpl.class);

	/**
	 * The method creates/updates a RegionMaster record. The method performs an
	 * update operation when regionId is passed or else create a new record if
	 * recordId is not found
	 * 
	 * @param regionMasterDTO
	 *            The RegionMaster Details
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Long createUpdateRegionMaster(RegionMasterDTO regionMasterDTO) {
		LOGGER.info("RegionMasterServiceImpl : createUpdateRegionMaster : Start");
		RegionMaster regionMasterDetails = null;
		Long id = -1l;
		try {
			if (null != regionMasterDTO) {
				if (null != regionMasterDTO.getRegionId()) {
					regionMasterDetails = regionMasterRepository.findOne(regionMasterDTO.getRegionId());
				}
				if (null == regionMasterDetails) {
					regionMasterDetails = new RegionMaster();
				}
				// regionMasterDetails = dozerBeanMapper.map(regionMasterDTO,
				// RegionMaster.class);
				BeanUtils.copyProperties(regionMasterDTO, regionMasterDetails, getNullPropertyNames(regionMasterDTO));
				RegionMaster saveObj = regionMasterRepository.save(regionMasterDetails);
				LOGGER.info("RegionMasterServiceImpl : createUpdateRegionMaster : Record Saved/Updated");
				if (null != saveObj) {
					id = saveObj.getRegionId();
				}
			} else {
				LOGGER.info("RegionMasterServiceImpl : createUpdateRegionMaster : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	/**
	 * The method map RegionMaster To DTO
	 * 
	 * @param regionMasterRecord
	 *            The RegionMaster
	 * @return regionMasterDTO
	 * 
	 */

	private RegionMasterDTO mapOnlyEnabledRegionMasterDataToDTO(RegionMaster regionMasterRecord) {

		List<ARCMasterDTO> arcMasterDTOs = new ArrayList<ARCMasterDTO>();
		ARCMasterDTO arcMasterDTO = null;
		RegionMasterDTO regionMasterDTO = null;
		if (null != regionMasterRecord.getRegionEnabled() && regionMasterRecord.getRegionEnabled() == 1) {
			regionMasterDTO = new RegionMasterDTO();

			regionMasterDTO.setRegionId(regionMasterRecord.getRegionId());
			regionMasterDTO.setRegionName(regionMasterRecord.getRegionName());
			regionMasterDTO.setRegionEnabled(regionMasterRecord.getRegionEnabled());
			regionMasterDTO.setTenantId(regionMasterRecord.getTenantId());
			regionMasterDTO.setSolutionCategoryId(regionMasterRecord.getSolutionCategoryId());

			for (ARCMaster arcMaster : regionMasterRecord.getArcMasterList()) {
				if (null != arcMaster.getArcEnabled() && arcMaster.getArcEnabled() == 1) {
					arcMasterDTO = new ARCMasterDTO();
					arcMasterDTO.setArcId(arcMaster.getArcId());
					arcMasterDTO.setArcName(arcMaster.getArcName());
					arcMasterDTO.setArcVCode(arcMaster.getArcVCode());
					arcMasterDTO.setArcAddress(arcMaster.getArcAddress());
					arcMasterDTO.setArcCity(arcMaster.getArcCity());
					arcMasterDTO.setArcZipCode(arcMaster.getArcZipCode());
					arcMasterDTO.setArcContactPerson(arcMaster.getArcContactPerson());
					arcMasterDTO.setArcContactEmail(arcMaster.getArcContactEmail());
					arcMasterDTO.setArcEnabled(arcMaster.getArcEnabled());
					arcMasterDTO.setArcContactMobile(arcMaster.getArcContactMobile());
					arcMasterDTO.setArcContactOffice(arcMaster.getArcContactOffice());
					arcMasterDTO.setArcBranchCity(arcMaster.getArcBranchCity());
					arcMasterDTO.setArcType(arcMaster.getArcType());
					arcMasterDTO.setArcCategory(arcMaster.getArcCategory());
					arcMasterDTO.setArcClientCode(arcMaster.getArcClientCode());
					arcMasterDTO.setArcProductType(arcMaster.getArcProductType());
					arcMasterDTOs.add(arcMasterDTO);
				}
			}
			regionMasterDTO.setArcMasterList(arcMasterDTOs);
		}
		return regionMasterDTO;
	}
	
	
	/**
	 * The method map RegionMaster To DTO
	 * 
	 * @param regionMasterRecord
	 *            The RegionMaster
	 * @return regionMasterDTO
	 * 
	 */

	private RegionMasterDTO mapRegionMasterDataToDTO(RegionMaster regionMasterRecord) {

		List<ARCMasterDTO> arcMasterDTOs = new ArrayList<ARCMasterDTO>();
		ARCMasterDTO arcMasterDTO = null;
		RegionMasterDTO regionMasterDTO = null;
	
			regionMasterDTO = new RegionMasterDTO();

			regionMasterDTO.setRegionId(regionMasterRecord.getRegionId());
			regionMasterDTO.setRegionName(regionMasterRecord.getRegionName());
			regionMasterDTO.setRegionEnabled(regionMasterRecord.getRegionEnabled());
			regionMasterDTO.setTenantId(regionMasterRecord.getTenantId());
			regionMasterDTO.setSolutionCategoryId(regionMasterRecord.getSolutionCategoryId());

			for (ARCMaster arcMaster : regionMasterRecord.getArcMasterList()) {
				
					arcMasterDTO = new ARCMasterDTO();
					arcMasterDTO.setArcId(arcMaster.getArcId());
					arcMasterDTO.setArcName(arcMaster.getArcName());
					arcMasterDTO.setArcVCode(arcMaster.getArcVCode());
					arcMasterDTO.setArcAddress(arcMaster.getArcAddress());
					arcMasterDTO.setArcCity(arcMaster.getArcCity());
					arcMasterDTO.setArcZipCode(arcMaster.getArcZipCode());
					arcMasterDTO.setArcContactPerson(arcMaster.getArcContactPerson());
					arcMasterDTO.setArcContactEmail(arcMaster.getArcContactEmail());
					arcMasterDTO.setArcEnabled(arcMaster.getArcEnabled());
					arcMasterDTO.setArcContactMobile(arcMaster.getArcContactMobile());
					arcMasterDTO.setArcContactOffice(arcMaster.getArcContactOffice());
					arcMasterDTO.setArcBranchCity(arcMaster.getArcBranchCity());
					arcMasterDTO.setArcType(arcMaster.getArcType());
					arcMasterDTO.setArcCategory(arcMaster.getArcCategory());
					arcMasterDTO.setArcClientCode(arcMaster.getArcClientCode());
					arcMasterDTO.setArcProductType(arcMaster.getArcProductType());
					arcMasterDTOs.add(arcMasterDTO);
			}
			
			regionMasterDTO.setArcMasterList(arcMasterDTOs);
		return regionMasterDTO;
	}

	/**
	 * The method retrieves all RegionMasterData
	 * 
	 * 
	 * @return RegionMasterDto
	 * 
	 */

	@Override
	@Transactional
	public List<RegionMasterDTO> getAllRegionMaster() {
		LOGGER.info("RegionMasterServiceImpl : getAllRegionMaster : Start");
		List<RegionMasterDTO> regionMasterDTOs = null;
		List<RegionMaster> regionMasterDetails = regionMasterRepository.findAll();
		if (null != regionMasterDetails && !regionMasterDetails.isEmpty()) {
			regionMasterDTOs = new ArrayList<RegionMasterDTO>();
			RegionMasterDTO regionMasterDTO = null;
			for (RegionMaster regionMasterRecord : regionMasterDetails) {
				regionMasterDTO = new RegionMasterDTO();
				regionMasterDTO = mapRegionMasterDataToDTO(regionMasterRecord);
				regionMasterDTOs.add(regionMasterDTO);
			}
		}
		LOGGER.info("RegionMasterServiceImpl : getAllRegionMaster : End");
		return regionMasterDTOs;
	}

	/**
	 * The method retrieves a ARCMaster Data on the basis of regionId and
	 * tenantId and solutionCategoryId.
	 * 
	 * @param regionId
	 * 
	 * @param tenantId
	 * 
	 * @param solutionCategoryId
	 * 
	 * @return ARCMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public List<ARCMasterDTO> getARCMasterListByRegionIDAndTenantIdAndSolCatId(Long regionId, String tenantId,
			String solutionCategoryId) {
		LOGGER.info("RegionMasterServiceImpl : getARCMasterListByRegionIDAndTenantIdAndSolCatId : Start");
		List<ARCMasterDTO> arcMasterDTOs = null;
		List<ARCMaster> arcMasterDetails = null;
		ARCMasterDTO arcMasterDTO = null;
		if (null != regionId && null != tenantId && null != solutionCategoryId) {
			arcMasterDetails = regionMasterRepository.findARCMasterByRegionIDAndTenantIdAndSolCatId(regionId, tenantId,
					solutionCategoryId);
		}

		if (null != arcMasterDetails) {
			arcMasterDTOs = new ArrayList<ARCMasterDTO>();
			for (ARCMaster arcMasterRecord : arcMasterDetails) {
				arcMasterDTO = new ARCMasterDTO();
				arcMasterDTO.setArcId(arcMasterRecord.getArcId());
				arcMasterDTO.setArcName(arcMasterRecord.getArcName());
				arcMasterDTO.setArcVCode(arcMasterRecord.getArcVCode());
				arcMasterDTO.setArcAddress(arcMasterRecord.getArcAddress());
				arcMasterDTO.setArcCity(arcMasterRecord.getArcCity());
				arcMasterDTO.setArcZipCode(arcMasterRecord.getArcZipCode());
				arcMasterDTO.setArcContactPerson(arcMasterRecord.getArcContactPerson());
				arcMasterDTO.setArcContactEmail(arcMasterRecord.getArcContactEmail());
				arcMasterDTO.setArcEnabled(arcMasterRecord.getArcEnabled());
				arcMasterDTO.setArcContactMobile(arcMasterRecord.getArcContactMobile());
				arcMasterDTO.setArcContactOffice(arcMasterRecord.getArcContactOffice());
				arcMasterDTO.setArcBranchCity(arcMasterRecord.getArcBranchCity());
				arcMasterDTO.setArcType(arcMasterRecord.getArcType());
				arcMasterDTO.setArcCategory(arcMasterRecord.getArcCategory());
				arcMasterDTO.setArcClientCode(arcMasterRecord.getArcClientCode());
				arcMasterDTO.setArcProductType(arcMasterRecord.getArcProductType());
				arcMasterDTOs.add(arcMasterDTO);
			}
		}
		LOGGER.info("RegionMasterServiceImpl : getARCMasterListByRegionIDAndTenantIdAndSolCatId : End");
		return arcMasterDTOs;
	}

	/**
	 * The method retrieves a RegionMaster Data on the basis of tenantId and
	 * solutionCategoryId.
	 * 
	 * @param tenantId
	 * 
	 * @param solutionCategoryId
	 * 
	 * @return RegionMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public List<RegionMasterDTO> getRegionMasterListByTenantIdAndSolCatId(String tenantId, String solutionCategoryId) {
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterListByTenantIdAndSolCatId : Start");
		List<RegionMasterDTO> regionMasterDTOs = null;
		List<RegionMaster> regionMasterDetails = null;
		if (null != tenantId && null != solutionCategoryId) {
			regionMasterDetails = regionMasterRepository.findRegionMasterByTenantIdAndSolCatId(tenantId,
					solutionCategoryId);
		}
		if (null != regionMasterDetails && regionMasterDetails.size() > 0) {
			regionMasterDTOs = new ArrayList<RegionMasterDTO>();
			RegionMasterDTO regionMasterDTO = null;
			for (RegionMaster regionMasterRecord : regionMasterDetails) {
				regionMasterDTO = new RegionMasterDTO();
				regionMasterDTO = mapRegionMasterDataToDTO(regionMasterRecord);
				regionMasterDTOs.add(regionMasterDTO);
			}
		}
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterListByTenantIdAndSolCatId : End");
		return regionMasterDTOs;
	}

	/**
	 * The method retrieves a RegionMaster Data on the basis of tenantId.
	 * 
	 * @param tenantId
	 *            The tenantId
	 * @return RegionMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public List<RegionMasterDTO> getRegionMasterListByTenantId(String tenantId) {
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterListByTenantId : Start");
		List<RegionMasterDTO> regionMasterDTOs = null;
		List<RegionMaster> regionMasterDetails = null;
		if (null != tenantId) {
			regionMasterDetails = regionMasterRepository.findRegionMasterByTenantId(tenantId);
		}
		if (null != regionMasterDetails && !regionMasterDetails.isEmpty()) {
			regionMasterDTOs = new ArrayList<RegionMasterDTO>();
			RegionMasterDTO regionMasterDTO = null;
			for (RegionMaster regionMasterRecord : regionMasterDetails) {
				regionMasterDTO = new RegionMasterDTO();
				regionMasterDTO = mapOnlyEnabledRegionMasterDataToDTO(regionMasterRecord);
				regionMasterDTOs.add(regionMasterDTO);
			}
		}
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterListByTenantId : End");
		return regionMasterDTOs;
	}

	/**
	 * The deletes a RegionMaster on the basis its Region id.
	 * 
	 * @param regionId
	 *            The RegionId
	 * 
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteRegionMasterByRegionId(Long regionId) {
		LOGGER.info("RegionMasterServiceImpl : deleteRegionMasterRegionId : Start");
		boolean returnVal = false;
		try {
			if (null != regionId) {
				regionMasterRepository.delete(regionId);
				returnVal = true;
			} else {
				LOGGER.info("RegionMasterServiceImpl : deleteRegionMasterRegionId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	//get region master based on Id
	@Override
	@Transactional
	public RegionMasterDTO getRegionMasterByRegionIdAndTenantIdAndSolCatId(Long regionId,String tenantId, String solutionCategoryId) {
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterByRegionIdAndTenantIdAndSolCatId : Start");
		RegionMasterDTO regionMasterDTO = null;
		RegionMaster regionMasterDetails = null;
		if (null != tenantId && null !=solutionCategoryId && null !=regionId) {
			regionMasterDetails = regionMasterRepository.findRegionMasterByRegionIdAndTenantIdAndSolCatId(regionId,solutionCategoryId,tenantId);
		}
		if (null != regionMasterDetails ) {
		        regionMasterDTO = new RegionMasterDTO();
				regionMasterDTO = mapRegionMasterDataToDTO(regionMasterDetails);
			}
		LOGGER.info("RegionMasterServiceImpl : getRegionMasterByRegionIdAndTenantIdAndSolCatId : End");
		return regionMasterDTO;
	}

}
