package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.TicketDetailsDTO;

public interface TicketDetailsService   {
	
	public List<TicketDetailsDTO> getAllTicketDetails();
	public Long createUpdateTicketDetails(TicketDetailsDTO ticketDetailsDTO );
	public TicketDetailsDTO getTicketDeteailByTicketdetailsId(Long ticketdetailsId);
	public Boolean claimTickets(List<TicketDetailsDTO> ticketDetailDTOList);
	public Long getAllTicketDeteailCountByTicketStatus(Integer functionCode,String userId,Long arcRefId);
}
