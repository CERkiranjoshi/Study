package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603975
 * 
 */

@Controller
@EnableSwagger
@RequestMapping(value = "arcMasterService")
public class ARCMasterController {
	@Autowired
	private ARCMasterService arcMasterService;

	@RequestMapping(value = "/createUpdateARCMaster", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  ARCMaster with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateARCMaster(
			@ApiParam(value = " ARCMaster Data object that needs to be added or update in the ARCMAster") @RequestBody ARCMasterDTO arcMasterDTO) {
		return arcMasterService.createUpdateARCMaster(arcMasterDTO);
	}

	@RequestMapping(value = "/getAllARCMaster", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find  ARCMaster ", notes = "Returns a  ARCMaster entity", response = ARCMasterDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<ARCMasterDTO> getAllARCMaster() {
		return arcMasterService.getAllARCMaster();
	}

	@RequestMapping(value = "/getARCMasterByArcId/{arcId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By arcId", notes = "Returns a ARCMaster entity when arcId is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody ARCMasterDTO getARCMasterByArcId(
			@ApiParam(value = "ARCMaster  based on  arcId  needs to be fetched", required = true) @PathVariable("arcId") final Long arcId) {
		return arcMasterService.getARCMasterByArcId(arcId);
	}

	@RequestMapping(value = "/getARCMasterListByArcName/{arcName}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By arcId", notes = "Returns a ARCMaster entity when arcName is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<ARCMasterDTO> getARCMasterByArcName(
			@ApiParam(value = "ARCMaster List  based on  arcName  needs to be fetched", required = true) @PathVariable("arcName") final String arcName) {
		return arcMasterService.getARCMasterListByArcName(arcName);
	}

	@RequestMapping(value = "/getARCMasterListByRegionId/{regionId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By regionId", notes = "Returns a ARCMaster entity when regionId is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcId supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<ARCMasterDTO> getARCMastersByRegion(
			@ApiParam(value = "ARCMaster List based on  regionId  needs to be fetched", required = true) @PathVariable("regionId") final Long regionId) {
		return arcMasterService.getARCMasterListByRegionId(regionId);
	}

	@RequestMapping(value = "/deleteARCMasterByArcId/{arcId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete ARCMaster By ARCMaster Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ARCMaster Id value") })
	public @ResponseBody Boolean deleteARCMasterByArcId(
			@ApiParam(value = "ARCMaster Id to delete", required = true) @PathVariable("arcId") final Long arcId) {
		return arcMasterService.deleteARCMasterByArcId(arcId);
	}
	
	@RequestMapping(value = "/getARCMasterByArcType/{arcType}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ARCMaster By arcType", notes = "Returns a ARCMaster entity when arcType is passed", response = ARCMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid arcType supplied"),
			@ApiResponse(code = 404, message = "ARCMaster not found") })
	public @ResponseBody List<ARCMasterDTO> getARCMasterByArcType(
			@ApiParam(value = "ARCMaster List based on  arcType  needs to be fetched", required = true) @PathVariable("arcType") final Integer arcType) {
		return arcMasterService.getARCMasterByArcType(arcType);
	}
	

}
