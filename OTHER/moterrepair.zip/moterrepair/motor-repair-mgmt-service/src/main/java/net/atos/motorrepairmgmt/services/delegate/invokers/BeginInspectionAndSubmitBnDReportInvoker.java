/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 *
 */
@Component(value="beginInspectionAndSubmitBnDReportInvoker")
public class BeginInspectionAndSubmitBnDReportInvoker extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BeginInspectionAndSubmitBnDReportInvoker.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BEGIN_INSPECTION_AND_SUBMIT_B_D_REPORT_INVOKER: START " + execution.getId());

		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT FUNCTION_CODE
		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

		// TODO Set Function Code of the Next Workflow to be executed
		String functionCode = MotorRepairConstants.ARC_BEGIN_INSPECTION;

		Map<String, Object> nextProcessVars = new HashMap<String, Object>();
		
		// TODO Set only required process variables from the workflow
		setNextProcessVariables(execution, nextProcessVars);

		String procInstanceId=invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; Process Instance Id "+procInstanceId);
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; BEGIN_INSPECTION_AND_SUBMIT_B_D_REPORT_INVOKER: END " + execution.getId());
	}

}
