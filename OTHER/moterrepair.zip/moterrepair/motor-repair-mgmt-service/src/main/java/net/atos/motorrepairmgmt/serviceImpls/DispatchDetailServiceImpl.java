package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.DispatchDetailDTO;
import net.atos.motorrepairmgmt.entity.DispatchDetail;
import net.atos.motorrepairmgmt.repository.DispatchDetailRepository;
import net.atos.motorrepairmgmt.services.DispatchDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610039
 * 
 */
@Service
@Transactional
public class DispatchDetailServiceImpl implements DispatchDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The CustomerDetail Repository */
	@Autowired
	private DispatchDetailRepository dispatchDetailRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(DispatchDetailServiceImpl.class);

	/**
	 * The method creates/updates a CustomerDetail record. The method performs an update operation when CustomerId is
	 * passed and an existing record with matching Customer Id is fetched for updation
	 * 
	 * @param budgetedBOMDTO
	 *            The Budgeted BOM
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateDispatchDetail(DispatchDetailDTO dispatchDetailDTO) {
		LOGGER.info("DispatchDetailServiceImpl : createUpdateDispatchDetail : Start");
		DispatchDetail dispatchDetail = null;
		Long returnId = -1l;
		try {
			if (null != dispatchDetailDTO) {
				if (null != dispatchDetailDTO.getDispatchId()) {
					dispatchDetail = dispatchDetailRepository.findOne(dispatchDetailDTO.getDispatchId());
				}
				if (null == dispatchDetail) {
					dispatchDetail = new DispatchDetail();
				}
				BeanUtils.copyProperties(dispatchDetailDTO, dispatchDetail,
						NullPropertyMapper.getNullPropertyNames(dispatchDetailDTO));
				DispatchDetail savedObject = dispatchDetailRepository.save(dispatchDetail);
				LOGGER.info("DispatchDetailServiceImpl : createUpdateDispatchDetail : Record Saved/Updated");
				if (savedObject != null) {
					returnId = savedObject.getDispatchId();
				}
			} else {
				LOGGER.info("DispatchDetailServiceImpl : createUpdateDispatchDetail : dispatchDetailDTO sent is Null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * The method retrieves all the CustomerDetail
	 * 
	 * @return List of CustomerDetail DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<DispatchDetailDTO> getAllDispatchDetail() {
		LOGGER.info("DispatchDetailServiceImpl : getAllDispatchDetail : Start");
		List<DispatchDetailDTO> dispatchDetailDTOs = null;
		List<DispatchDetail> dispatchDetails = dispatchDetailRepository.findAll();
		if (null != dispatchDetails) {
			dispatchDetailDTOs = new ArrayList<DispatchDetailDTO>();
			DispatchDetailDTO dispatchDetailDTO = null;
			for (DispatchDetail dispatchDetailRecord : dispatchDetails) {
				dispatchDetailDTO = new DispatchDetailDTO();
				dispatchDetailDTO = dozerBeanMapper.map(dispatchDetailRecord, DispatchDetailDTO.class);
				dispatchDetailDTOs.add(dispatchDetailDTO);
			}
		}
		LOGGER.info("DispatchDetailServiceImpl : getAllDispatchDetail : End");
		return dispatchDetailDTOs;
	}

	/**
	 * The method retrieves a CustomerDetail on the basis its customerId.
	 * 
	 * @param customerId
	 *            The Customer Id
	 * @return CustomerDetail DTO
	 * 
	 */

	@Override
	@Transactional
	public DispatchDetailDTO getDispatchDetailByDispatchId(Long dispatchId) {
		LOGGER.info("DispatchDetailServiceImpl : getDispatchDetailByDispatchId : Start");
		DispatchDetailDTO dispatchDetailDTO = null;
		if (null != dispatchId) {
			DispatchDetail dispatchDetail = dispatchDetailRepository.findOne(dispatchId);
			if (null != dispatchDetail) {
				dispatchDetailDTO = dozerBeanMapper.map(dispatchDetail, DispatchDetailDTO.class);
			}
		}
		LOGGER.info("DispatchDetailServiceImpl : getDispatchDetailByDispatchId : End");
		return dispatchDetailDTO;
	}

	/**
	 * The deletes a CustomerDetail on the basis its customerId.
	 * 
	 * @param customerId
	 *            The Customer Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteDispatchDetailByDispatchId(Long dispatchId) {

		LOGGER.info("DispatchDetailServiceImpl : deleteDispatchDetailByDispatchId : Start");
		boolean returnVal = false;
		try {
			if (null != dispatchId) {
				dispatchDetailRepository.delete(dispatchId);
				returnVal = true;
			} else {
				LOGGER.info("DispatchDetailServiceImpl : deleteDispatchDetailByDispatchId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;

	}

}