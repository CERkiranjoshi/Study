package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.EndCustomerDetailsArcDTO;
import net.atos.motorrepairmgmt.dto.MotorDetailsArcDTO;
import net.atos.motorrepairmgmt.dto.TicketDetailsDTO;
import net.atos.motorrepairmgmt.entity.EndCustomerDetailsArc;
import net.atos.motorrepairmgmt.entity.MotorDetailsArc;
import net.atos.motorrepairmgmt.entity.TicketDetailsArc;
import net.atos.motorrepairmgmt.repository.EndCustomerDetailARCRepository;
import net.atos.motorrepairmgmt.repository.MotorDetailsArcRepository;
import net.atos.motorrepairmgmt.repository.TicketDetailsRepository;
import net.atos.motorrepairmgmt.services.TicketDetailsService;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;

@Component
public class TicketDetailsServiceImpl implements TicketDetailsService {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BReportFieldsServiceImpl.class);

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private TicketDetailsRepository ticketDetailsRepository;

	@Autowired
	private EndCustomerDetailARCRepository endCustomerDetailARCRepository;

	@Autowired
	private MotorDetailsArcRepository motorDetailsArcRepository;

	/**
	 * The method retrieves all the TicketDetails
	 * 
	 * @return List of TicketDetailsDTOs
	 * 
	 */
	@Override
	@Transactional
	public List<TicketDetailsDTO> getAllTicketDetails() {
		LOGGER.info("TicketDetailsServiceImpl : getAllTicketDetails : Start");
		List<TicketDetailsDTO> ticketDetailsDTOs = null;
		List<TicketDetailsArc> ticketDetailsArcDetails = ticketDetailsRepository.findAll();
		if (null != ticketDetailsArcDetails) {
			ticketDetailsDTOs = new ArrayList<TicketDetailsDTO>();
			for (TicketDetailsArc ticketDetailsArcRecord : ticketDetailsArcDetails) {
				TicketDetailsDTO ticketDetailsDTO = new TicketDetailsDTO();
				ticketDetailsDTO = dozerBeanMapper.map(ticketDetailsArcRecord, TicketDetailsDTO.class);
				ticketDetailsDTOs.add(ticketDetailsDTO);
			}
		}
		LOGGER.info("TicketDetailsServiceImpl : getAllTicketDetails : End");
		return ticketDetailsDTOs;
	}

	/**
	 * The method creates/updates a ElectricalObservation record. The method performs an update operation when
	 * motorElecObsId is passed and an existing record with matching motorElecObsId is fetched for updation Or it will
	 * create a new record
	 * 
	 * @param TicketDetailsDTO
	 *            The electricalObservation Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateTicketDetails(TicketDetailsDTO ticketDetailsDTO) {
		LOGGER.info("TicketDetailsServiceImpl : createUpdateTicketDetails : Start");
		TicketDetailsArc ticketDetailsArcDetail = null;
		MotorDetailsArcDTO motorDetailsArcDTO = null;
		EndCustomerDetailsArcDTO endCustomerDetailsArcDTO = null;
		MotorDetailsArc motorDetailsArc = null;
		EndCustomerDetailsArc endCustomerDetailsArc = null;
		Long returnId = -1l;
		try {
			if (null != ticketDetailsDTO) {
				if (null != ticketDetailsDTO.getTicketdetailsId()) {
					ticketDetailsArcDetail = ticketDetailsRepository.findOne(ticketDetailsDTO.getTicketdetailsId());
					ticketDetailsArcDetail.setModifiedOn(new Date());
				}
				if (null == ticketDetailsArcDetail) {
					ticketDetailsArcDetail = new TicketDetailsArc();
					ticketDetailsArcDetail.setCreatedOn(new Date());
					ticketDetailsArcDetail.setModifiedOn(new Date());
				}

				if (null != ticketDetailsDTO.getEndCustomerDetailsArc()) {
					endCustomerDetailsArc = new EndCustomerDetailsArc();
					endCustomerDetailsArcDTO = ticketDetailsDTO.getEndCustomerDetailsArc();

					if (null == endCustomerDetailsArcDTO.getCustomerId()) {

						BeanUtils.copyProperties(endCustomerDetailsArcDTO, endCustomerDetailsArc,
								getNullPropertyNames(endCustomerDetailsArcDTO));
						ticketDetailsArcDetail.setEndCustomerDetailsArc(endCustomerDetailsArc);
						ticketDetailsDTO.setEndCustomerDetailsArc(null);
					} else {
						endCustomerDetailsArc = endCustomerDetailARCRepository.findOne(endCustomerDetailsArcDTO
								.getCustomerId());

						BeanUtils.copyProperties(endCustomerDetailsArcDTO, endCustomerDetailsArc,
								NullPropertyMapper.getNullPropertyNames(endCustomerDetailsArcDTO));

						ticketDetailsArcDetail.setEndCustomerDetailsArc(endCustomerDetailsArc);
						ticketDetailsDTO.setEndCustomerDetailsArc(null);
					}
				}

				if (null != ticketDetailsDTO.getMotorDetailsArc()) {
					motorDetailsArc = new MotorDetailsArc();
					motorDetailsArcDTO = ticketDetailsDTO.getMotorDetailsArc();

					if (null == motorDetailsArcDTO.getMotorOrderDetailId()) {
						BeanUtils.copyProperties(motorDetailsArcDTO, motorDetailsArc,
								getNullPropertyNames(motorDetailsArcDTO));
						ticketDetailsArcDetail.setMotorDetailsArc(motorDetailsArc);
						ticketDetailsDTO.setMotorDetailsArc(null);
					} else {
						motorDetailsArc = motorDetailsArcRepository.findOne(motorDetailsArcDTO.getMotorOrderDetailId());

						BeanUtils.copyProperties(motorDetailsArcDTO, motorDetailsArc,
								NullPropertyMapper.getNullPropertyNames(motorDetailsArcDTO));
						ticketDetailsArcDetail.setMotorDetailsArc(motorDetailsArc);
						ticketDetailsDTO.setMotorDetailsArc(null);
					}
				}
				BeanUtils.copyProperties(ticketDetailsDTO, ticketDetailsArcDetail,
						getNullPropertyNames(ticketDetailsDTO));
				TicketDetailsArc savedObj = ticketDetailsRepository.save(ticketDetailsArcDetail);
				if (null != savedObj) {
					LOGGER.info("TicketDetailsServiceImpl : createUpdateTicketDetails : Record Saved/Updated");
					returnId = savedObj.getTicketdetailsId();
				}
			} else {
				LOGGER.info("TicketDetailsServiceImpl : createUpdateTicketDetails : TicketDetailsDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * This method retrieves a TicketDeteail on the basis of its ticketdetailsId.
	 * 
	 * @param ticketdetailsId
	 *            The ticketdetailsId
	 * @return TicketDetails DTO
	 * 
	 */
	@Override
	@Transactional
	public TicketDetailsDTO getTicketDeteailByTicketdetailsId(Long ticketdetailsId) {
		LOGGER.info("TicketDetailsServiceImpl : getTicketDeteailByTicketdetailsId : Start");
		TicketDetailsDTO ticketDetailsDTO = null;
		TicketDetailsArc ticketDetailsArcEntity = null;
		if (null != ticketdetailsId) {
			ticketDetailsArcEntity = ticketDetailsRepository.findOne(ticketdetailsId);
			if (null != ticketDetailsArcEntity) {
				ticketDetailsDTO = new TicketDetailsDTO();
				ticketDetailsDTO = dozerBeanMapper.map(ticketDetailsArcEntity, TicketDetailsDTO.class);
			}
		}
		LOGGER.info("TicketDetailsServiceImpl : getTicketDeteailByTicketdetailsId : End");
		return ticketDetailsDTO;
	}

	/**
	 * This method claim a TicketDeteail.
	 * 
	 * @param ticketDetailDTOList
	 *            The ticketDetailDTOList
	 * @return TicketStatus
	 * 
	 */
	@Override
	@Transactional
	public synchronized Boolean claimTickets(List<TicketDetailsDTO> ticketDetailDTOList) throws MotorRepairException
{
		TicketDetailsArc ticketDetailsArcEntity = null;
		Boolean returnClaimStatus=false;

		if (null != ticketDetailDTOList && ticketDetailDTOList.size() > 0) {
			for (TicketDetailsDTO ticketDetailsDTO : ticketDetailDTOList) {

				if (null != ticketDetailsDTO.getRefId()) {
					// check whether this particular getRefIdticket is claimedd by someone else or not ,if claimRefiD is
					// not null then thorw excpetion
					TicketDetailsArc existingObj = ticketDetailsRepository.findOne(ticketDetailsDTO
							.getTicketdetailsId());
					if (null == existingObj) {
						// thorw exception
						throw new MotorRepairException(MotorRepairException.INPUT_ERR, "Invalid icket detail ID  ",
								"Create New claim");
					} else {
						if (null != existingObj.getClaimRefId()) {
							// thorw exception with message that it is claimed by someone else
							throw new MotorRepairException(MotorRepairException.INPUT_ERR, "This Ticket  "+ticketDetailsDTO.getTicketdetailsId()+ "  has been claimed by"+existingObj.getRefId(),
									"Create New Subprocess Workflow");
						}
					}
					ticketDetailsArcEntity=new TicketDetailsArc();

					ticketDetailsArcEntity = dozerBeanMapper.map(ticketDetailsDTO, TicketDetailsArc.class);
					
					ticketDetailsArcEntity.setClaimRefId(ticketDetailsDTO.getClaimRefId());
					ticketDetailsArcEntity.setTicketStatus(2);

					TicketDetailsArc savedObj = ticketDetailsRepository.save(ticketDetailsArcEntity);
					if (null != savedObj) {
						returnClaimStatus=true;
					}
				}
			}
		}
		return returnClaimStatus;
	}
	
	/**
	 * This method retrieves a TicketDeteail on the basis of its ticketdetailsId.
	 * 
	 * @param ticketdetailsId
	 *            The ticketdetailsId
	 * @return TicketDetails DTO
	 * 
	 */
	@Override
	@Transactional
	public Long getAllTicketDeteailCountByTicketStatus(Integer functionCode,String userId,Long arcRefId) {
		LOGGER.info("TicketDetailsServiceImpl : getAllTicketDeteailCountByTicketStatus : Start");
		Long ticketsCount=0L;
		if(functionCode==1){
			ticketsCount= ticketDetailsRepository.findTicketDeteailCountByTicketStatus(1,2,userId);	
		}
		else{
			ticketsCount= ticketDetailsRepository.findTicketDeteailCountByTicketStatusZero(arcRefId);
		}
		LOGGER.info("TicketDetailsServiceImpl : getAllTicketDeteailCountByTicketStatus : End");
		return ticketsCount;
	}
}
