package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSalesDetailDTO;
import net.atos.motorrepairmgmt.services.MotorSalesDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610039
 * 
 */
@EnableSwagger
@RequestMapping(value = "motorSalesDetailService")
@Controller
public class MotorSalesDetailController {

	@Autowired
	private MotorSalesDetailService motorSalesDetailService;

	@RequestMapping(value = "/createUpdateMotorSalesDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update MotorSalesDetail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMotorSalesDetail(
			@ApiParam(value = "MotorSalesDetail object that needs to be added or update in the motorSalesDetail") @RequestBody MotorSalesDetailDTO motorSalesDetailDTO) {
		return motorSalesDetailService.createUpdateMotorSalesDetail(motorSalesDetailDTO);
	}

	@RequestMapping(value = "/getAllMotorSalesDetailByTenantId/{tenantId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All MotorSales Details by Tenant Id", notes = "Returns All MotorSales Details entity when Tenant Id is passed", response = MotorSalesDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid tenant Id supplied"),
			@ApiResponse(code = 404, message = "MotorSales Details not found") })
	public @ResponseBody List<MotorSalesDetailDTO> getAllMotorSalesDetailByTenantId(
			@ApiParam(value = "TenantId of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId) {
		return motorSalesDetailService.getAllMotorSalesDetailByTenantId(tenantId);
	}

	@RequestMapping(value = "/getMotorSalesDetailByMotorSalesDetailId/{motorSalesDetailId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSales Details By MotorSalesDetail Id", notes = "Returns a MotorSales Details entity when MotorSalesDetail Id is passed", response = MotorSalesDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorSalesDetail Id supplied"),
			@ApiResponse(code = 404, message = " MotorSales Details not found") })
	public @ResponseBody MotorSalesDetailDTO getMotorSalesDetailByMotorSalesDetailId(
			@ApiParam(value = "MotorSalesDetail Id of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("motorSalesDetailId") Long motorSalesDetailId) {
		return motorSalesDetailService.getMotorSalesDetailByMotorSalesDetailId(motorSalesDetailId);
	}

	@RequestMapping(value = "/getMotorSalesDetailByTenantIdAndSolutionCategoryId/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSales Details By Tenant Id and SolutionCategory Id", notes = "Returns a MotorSales Details entity when Tenan tId and SolutionCategory Id is passed", response = MotorSalesDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid TenantId and SolutionCategoryId supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryId(
			@ApiParam(value = "Tenant Id of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId,
			@ApiParam(value = "SolutionCategory Id of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("solutionCategoryId") String solutionCategoryId) {
		return motorSalesDetailService.getMotorSalesDetailByTenantIdAndSolutionCategoryId(tenantId, solutionCategoryId);
	}

	@RequestMapping(value = "/getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType/{tenantId}/{solutionCategoryId}/{salesType}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSales Details By Tenant Id and SolutionCategory Id and Sales Type", notes = "Returns a MotorSales Details entity when Tenan tId and SolutionCategory Id and Sales Type is passed", response = MotorSalesDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid TenantId and SolutionCategoryId and salesType supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(
			@ApiParam(value = "Tenant Id of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId,
			@ApiParam(value = "SolutionCategory Id of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("solutionCategoryId") String solutionCategoryId,
			@ApiParam(value = "Sales Type of the MotorSalesDetails that needs to be fetched", required = true) @PathVariable("salesType") Integer salesType) {
		return motorSalesDetailService.getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(tenantId,
				solutionCategoryId, salesType);
	}

	@RequestMapping(value = "/deleteMotorSalesDetailByMotorSalesDetailId/{motorSalesDetailId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete MotorSalesDetail By MotorSalesDetail Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid  MotorSalesDetail Id value") })
	public @ResponseBody Boolean deleteMotorSalesDetailByMotorSalesDetailId(
			@ApiParam(value = "MotorSalesDetail Id to delete", required = true) @PathVariable("motorSalesDetailId") Long motorSalesDetailId) {
		try {
			return motorSalesDetailService.deleteMotorSalesDetailByMotorSalesDetailId(motorSalesDetailId);
		} catch (Exception e) {
			return false;
		}
	}
}
