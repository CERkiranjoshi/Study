/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;

/**
 * @author a593775
 *
 */
public interface TemplateInfoService {

	 public List<TemplateInfoDTO> findTemplateInfoByFunCodeNEmailCode(String functionCode,String emailCode);
	 
	 public List<TemplateInfoDTO> findTemplateInfoByFunCodeNNotificationType(String functionCode,Integer notificationType);
}
