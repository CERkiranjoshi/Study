package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;
import net.atos.motorrepairmgmt.services.ParallelProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603975
 * 
 */

@Controller
@EnableSwagger
@RequestMapping(value = "parallelProcessService")
public class ParallelProcessController {

	@Autowired
	private ParallelProcessService parallelProcessService;

	@RequestMapping(value = "/createUpdateParallelProcess", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates  ParallelProcess with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateParallelProcess(
			@ApiParam(value = "  ParallelProcess Data object that needs to be added or update in the ParallelProcess") @RequestBody ParallelProcessDTO parallelProcessDTO) {
		return parallelProcessService.createUpdateParallelProcess(parallelProcessDTO);
	}

	@RequestMapping(value = "/getAllParallelProcess", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find  ParallelProcess ", notes = "Returns a  ParallelProcess entity", response = ParallelProcessDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<ParallelProcessDTO> getAllParallelProcess() {
		return parallelProcessService.getAllParallelProcess();
	}

	@RequestMapping(value = "/deleteParallelProcessByParallelProcessId/{parallelProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete ParallelProcess By ParallelProcess Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid WorkflowState Id value") })
	public @ResponseBody Boolean deleteParallelProcessByParallelProcessId(
			@ApiParam(value = "parallelProcess Id to delete", required = true) @PathVariable("parallelProcessId") final Long parallelProcessId) {
		return parallelProcessService.deleteParallelProcessByParallelProcessId(parallelProcessId);
	}

	@RequestMapping(value = "/getParallelProcessListByParallelProcessState/{parallelProcessState}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ParallelProcess By parallelProcessState", notes = "Returns a list of ParallelProcess entity when parallelProcessState is passed", response = ParallelProcessDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid parallelProcessState supplied"),
			@ApiResponse(code = 404, message = "ParallelProcess not found") })
	public @ResponseBody List<ParallelProcessDTO> getParallelProcessListByParallelProcessState(
			@ApiParam(value = "WorkflowState  based on  parallelProcessState  needs to be fetched", required = true) @PathVariable("parallelProcessState") final String parallelProcessState) {
		return parallelProcessService.getParallelProcessListByParallelProcessState(parallelProcessState);
	}

	@RequestMapping(value = "/getParallelProcessByParallelProcessId/{parallelProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ParallelProcess By parallelProcessId", notes = "Returns a ParallelProcess entity when parallelProcessId is passed", response = ParallelProcessDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid parallelProcessId supplied"),
			@ApiResponse(code = 404, message = "ParallelProcess not found") })
	public @ResponseBody List<ParallelProcessDTO> getParallelProcessByParallelProcessId(
			@ApiParam(value = "ParallelProcess  based on  parallelProcessId  needs to be fetched", required = true) @PathVariable("parallelProcessId") final String parallelProcessId) {
		return parallelProcessService.getParallelProcessByParallelProcessId(parallelProcessId);
	}

	@RequestMapping(value = "/getParallelProcessByParallelProcessIdandTenantIdandSolCatId/{parallelProcessId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find ParallelProcess Fields By parallelProcessId ,TenantId and solutionCategoryId", notes = "Returns a ParallelProcess Fields entity when MasterWorkflowId,TenantId and SolutionCategoryId is passed", response = ParallelProcessDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid parallelProcessId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " ParallelProcess Fields not found") })
	public @ResponseBody ParallelProcessDTO getParallelProcessByParallelProcessIdandTenantIdandSolCatId(
			@ApiParam(value = "parallelProcessId of the ParallelProcess that needs to be fetched", required = true)@PathVariable(value = "parallelProcessId") final Long parallelProcessId,
			@ApiParam(value = "tenantId of the ParallelProcess that needs to be fetched", required = true)@PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "solutionCategoryId of the ParallelProcess that needs to be fetched", required = true)@PathVariable(value = "solutionCategoryId")final String solutionCategoryId) {
		return parallelProcessService.getParallelProcessByParallelProcessIdandTenantIdandSolCatId(parallelProcessId, tenantId,solutionCategoryId);
		
	}
}
