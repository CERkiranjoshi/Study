/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.Date;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.TaskProcessAttributesDTO;
import net.atos.motorrepairmgmt.entity.TaskProcessAttributes;
import net.atos.motorrepairmgmt.repository.TaskProcessAttributesRepository;
import net.atos.motorrepairmgmt.services.TaskProcessAttributesService;

/**
 * @author Sweety Kothari
 *
 */
@Service
public class TaskProcessAttributesServiceImpl implements TaskProcessAttributesService {
	
	//@Autowired
	//add entry in persistence.xml & then autowire
	private TaskProcessAttributesRepository taskAttributesRepository;
	
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/* 
	 * save TaskParameterDetailDTO
	 */
	@Override
	@Transactional
	public Long createUpdateTaskParameterDetails(TaskProcessAttributesDTO taskParameterDetailDTO) {
		TaskProcessAttributesDTO existingTaskAttributeDTO=getTaskParameterDetailsByActivitiTaskId(taskParameterDetailDTO.getActivitiTaskId());
		if(null !=existingTaskAttributeDTO){
			//set id in taskParameterDetailDTO
			taskParameterDetailDTO.setTaskProcessAttributeId(existingTaskAttributeDTO.getTaskProcessAttributeId());
		}
		else{
			taskParameterDetailDTO.setCreatedOn(new Date());
		}
		//convert DTO to entity
		TaskProcessAttributes taskParameterDetails =dozerBeanMapper.map(taskParameterDetailDTO, TaskProcessAttributes.class);
		taskParameterDetails=taskAttributesRepository.save(taskParameterDetails);
		return taskParameterDetails.getTaskProcessAttributeId();
	}

	/* 
	 * getTaskParameterDetailDTO by activiti task id
	 */
	@Override
	@Transactional
	public TaskProcessAttributesDTO getTaskParameterDetailsByActivitiTaskId(String activitiTaskId) {
		// TODO Auto-generated method stub
		TaskProcessAttributes taskParameterDetails=taskAttributesRepository.getTaskParameterDetailsByActivitiTaskId(activitiTaskId);
	    TaskProcessAttributesDTO taskParameterDetailsDTO =dozerBeanMapper.map(taskParameterDetails, TaskProcessAttributesDTO.class);
	    return taskParameterDetailsDTO;
	}

}
