/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component(value = "dispatchReplacedMotorInvoker")
public class DispatchReplacedMotorInvoker extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(DispatchReplacedMotorInvoker.class);

	@Autowired
	private ARCMasterService arcMasterService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; DISPATCH_REPLACED_MOTOR_INVOKER: START " + execution.getId());

		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT FUNCTION_CODE
		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

		// TODO Set Function Code of the Next Workflow to be executed
		String functionCode = MotorRepairConstants.ARC_DISPATCH_MOTOR;

		Map<String, Object> nextProcessVars = new HashMap<String, Object>();

		// TODO Set only required process variables from the workflow
		setNextProcessVariables(execution, nextProcessVars);

		int parasTypeARCId = 0;
		try {
			parasTypeARCId = (null != execution.getVariable(ActivitiConstants.CONFIG_PARAS_ARC_TYPE)) ? Integer
					.parseInt(execution.getVariable(ActivitiConstants.CONFIG_PARAS_ARC_TYPE).toString()) : 0;
		} catch (Exception e) {
			LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; DISPATCH_REPLACED_MOTOR_INVOKER: PARAS TYPE ARC ID not set in workflow?");
		}

		if (0 != parasTypeARCId) {

			// TODO this wud require to be changed as ARC types would be multiple
			List<ARCMasterDTO> arcMasterDTOs = arcMasterService.getARCMasterByArcType(parasTypeARCId);

			if ((null != arcMasterDTOs) && (0 < arcMasterDTOs.size())) {

				ARCMasterDTO arcMasterDTO = arcMasterDTOs.get(0);

				// Setting variables related to PARAS
				nextProcessVars.put(ActivitiConstants.ARC_REF_ID, arcMasterDTO.getArcId().toString());
				nextProcessVars.put(ActivitiConstants.ARC_TYPE, arcMasterDTO.getArcType());
				nextProcessVars.put(ActivitiConstants.ARC_NAME, arcMasterDTO.getArcName().toString());
			} else {
				LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS TYPE ARC not available!!");
			}
		}

		String procInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; DISPATCH_REPLACED_MOTOR_INVOKER: END " + execution.getId() + " New WORKFLOW ID " + procInstanceId);
	}

}
