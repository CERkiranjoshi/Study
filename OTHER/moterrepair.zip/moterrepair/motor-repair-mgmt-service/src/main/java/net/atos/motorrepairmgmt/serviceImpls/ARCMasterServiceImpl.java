package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;
import net.atos.motorrepairmgmt.entity.ARCMaster;
import net.atos.motorrepairmgmt.repository.ARCMasterRepository;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

/**
 * @author a603975
 * 
 */

@Service
public class ARCMasterServiceImpl implements ARCMasterService {
	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private ARCMasterRepository arcMasterRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */

	private static final Logger LOGGER = Logger.getLogger(ARCMasterServiceImpl.class);

	/**
	 * This method creates/updates a ARCMaster record. The method performs an
	 * update operation when arcId is passed or else create new record if arcId
	 * is not found
	 * 
	 * @param arcMasterDTO
	 *            The ARCMaster Details
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Long createUpdateARCMaster(ARCMasterDTO arcMasterDTO) {
		LOGGER.info("ArcMasterServiceImpl : createUpdateARCMaster : Start");
		ARCMaster arcMasterDetails = null;
		Long returnId = -1l;
		try {
			if (null != arcMasterDTO) {
				if (null != arcMasterDTO.getArcId()) {
					arcMasterDetails = arcMasterRepository.findOne(arcMasterDTO.getArcId());
				}
				BeanUtils.copyProperties(arcMasterDTO, arcMasterDetails,
						NullPropertyMapper.getNullPropertyNames(arcMasterDTO));
				// arcMasterDetails = dozerBeanMapper.map(arcMasterDTO,
				// ARCMaster.class);
				ARCMaster savedObj = arcMasterRepository.save(arcMasterDetails);
				LOGGER.info("ArcMasterServiceImpl : createUpdateArcMaster : Record Saved/Updated");
				if (null != savedObj) {
					returnId = savedObj.getArcId();
				}

			} else {
				LOGGER.info("ArcMasterServiceImpl : createUpdateArcMaster : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;

	}

	/**
	 * The method map ARCMaster To DTO
	 * 
	 * @param arcMasterRecord
	 *            The ARCMaster
	 * @return arcMasterDTO
	 * 
	 */

	private ARCMasterDTO mapARCMasterDataToDTO(ARCMaster arcMasterRecord) {
		RegionMasterDTO regionMasterDTO = new RegionMasterDTO();
		ARCMasterDTO arcMasterDTO = new ARCMasterDTO();
		arcMasterDTO.setArcId(arcMasterRecord.getArcId());
		arcMasterDTO.setArcName(arcMasterRecord.getArcName());
		arcMasterDTO.setArcVCode(arcMasterRecord.getArcVCode());
		arcMasterDTO.setArcAddress(arcMasterRecord.getArcAddress());
		arcMasterDTO.setArcCity(arcMasterRecord.getArcCity());
		arcMasterDTO.setArcZipCode(arcMasterRecord.getArcZipCode());
		arcMasterDTO.setArcContactPerson(arcMasterRecord.getArcContactPerson());
		arcMasterDTO.setArcContactEmail(arcMasterRecord.getArcContactEmail());
		arcMasterDTO.setArcEnabled(arcMasterRecord.getArcEnabled());
		arcMasterDTO.setArcContactMobile(arcMasterRecord.getArcContactMobile());
		arcMasterDTO.setArcContactOffice(arcMasterRecord.getArcContactOffice());
		arcMasterDTO.setArcBranchCity(arcMasterRecord.getArcBranchCity());
		arcMasterDTO.setArcType(arcMasterRecord.getArcType());
		arcMasterDTO.setArcCategory(arcMasterRecord.getArcCategory());
		arcMasterDTO.setArcClientCode(arcMasterRecord.getArcClientCode());
		arcMasterDTO.setArcProductType(arcMasterRecord.getArcProductType());
		regionMasterDTO.setRegionId(arcMasterRecord.getRegionMaster().getRegionId());
		regionMasterDTO.setRegionName(arcMasterRecord.getRegionMaster().getRegionName());
		regionMasterDTO.setRegionEnabled(arcMasterRecord.getRegionMaster().getRegionEnabled());
		regionMasterDTO.setTenantId(arcMasterRecord.getRegionMaster().getTenantId());
		regionMasterDTO.setSolutionCategoryId(arcMasterRecord.getRegionMaster().getSolutionCategoryId());
		arcMasterDTO.setRegionMaster(regionMasterDTO);
		return arcMasterDTO;
	}

	/**
	 * The method retrieves all ARCMasterData
	 * 
	 * 
	 * @return ARCMasterDto
	 * 
	 */

	@Override
	@Transactional
	public List<ARCMasterDTO> getAllARCMaster() {
		LOGGER.info("ARCMasterServiceImpl : getAllARCMaster : Start");
		List<ARCMasterDTO> arcMasterDTOs = null;
		List<ARCMaster> arcMasterDetails = arcMasterRepository.findAll();
		if (null != arcMasterDetails && !arcMasterDetails.isEmpty()) {
			arcMasterDTOs = new ArrayList<ARCMasterDTO>();
			ARCMasterDTO arcMasterDTO = null;
			for (ARCMaster arcMasterRecord : arcMasterDetails) {
				arcMasterDTO = new ARCMasterDTO();
				arcMasterDTO = mapARCMasterDataToDTO(arcMasterRecord);
				arcMasterDTOs.add(arcMasterDTO);
			}
		}
		LOGGER.info("ARCMasterServiceImpl : getAllARCMaster : End");
		return arcMasterDTOs;
	}

	/**
	 * The method retrieves a ARCMasterData on the basis of ARC id.
	 * 
	 * @param ArcId
	 *            The ARC Id
	 * @return ARCMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public ARCMasterDTO getARCMasterByArcId(Long arcId) {
		LOGGER.info("ARCMasterServiceImpl : getARCMasterByARCId : Start");
		ARCMasterDTO arcMasterDTO = null;
		if (null != arcId) {
			ARCMaster arcMasterDetails = arcMasterRepository.findArcMasterByARCId(arcId);
			if (null != arcMasterDetails) {
				arcMasterDTO = mapARCMasterDataToDTO(arcMasterDetails);
			}
		}
		LOGGER.info("ARCMasterServiceImpl : getARCMasterByARCId : End");
		return arcMasterDTO;
	}

	/**
	 * The method retrieves a ARCMasterData on the basis of ARC Name.
	 * 
	 * @param ArcName
	 *            The ARC Name
	 * @return ARCMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public List<ARCMasterDTO> getARCMasterListByArcName(String arcName) {
		LOGGER.info("ARCMasterServiceImpl : getARCMAsterListByARCName : Start");
		List<ARCMasterDTO> arcMasterDTOs = null;
		List<ARCMaster> arcMasterDetails = null;
		if (null != arcName) {
			arcMasterDetails = arcMasterRepository.findArcMasterByARCName(arcName);
		}
		if (null != arcMasterDetails && arcMasterDetails.size() > 0) {
			arcMasterDTOs = new ArrayList<ARCMasterDTO>();
			ARCMasterDTO arcMasterDTO = null;
			for (ARCMaster arcMasterRecord : arcMasterDetails) {
				arcMasterDTO = new ARCMasterDTO();
				arcMasterDTO = mapARCMasterDataToDTO(arcMasterRecord);
				arcMasterDTOs.add(arcMasterDTO);
			}

		}
		LOGGER.info("ARCMasterServiceImpl : getARCMAsterListByARCName : End");
		return arcMasterDTOs;
	}

	/**
	 * The method retrieves a ARCMasterData on the basis of Region id.
	 * 
	 * @param RegionId
	 *            The Region Id
	 * @return ARCMasterDTO
	 * 
	 */

	@Override
	@Transactional
	public List<ARCMasterDTO> getARCMasterListByRegionId(Long regionId) {
		LOGGER.info("ARCMasterServiceImpl : getARCMasterListByRegionId : Start");
		List<ARCMasterDTO> arcMasterDTOs = null;
		List<ARCMaster> arcMasterDetails = arcMasterRepository.findArcMasterByRegionId(regionId);
		if (null != arcMasterDetails && !arcMasterDetails.isEmpty()) {
			arcMasterDTOs = new ArrayList<ARCMasterDTO>();
			ARCMasterDTO arcMasterDTO = null;
			for (ARCMaster arcMasterRecord : arcMasterDetails) {
				arcMasterDTO = new ARCMasterDTO();
				arcMasterDTO = mapARCMasterDataToDTO(arcMasterRecord);
				arcMasterDTOs.add(arcMasterDTO);
			}
		}
		LOGGER.info("ARCMasterServiceImpl : getARCMasterListByRegionId : End");
		return arcMasterDTOs;
	}

	/**
	 * The deletes a ARCMaster on the basis its ARC id.
	 * 
	 * @param arcId
	 *            The ArcId
	 * 
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteARCMasterByArcId(Long arcId) {
		LOGGER.info("ARCMasterServiceImpl : deleteARCMasterByArcId : Start");
		boolean returnVal = false;
		try {
			if (null != arcId) {
				arcMasterRepository.delete(arcId);
				returnVal = true;
			} else {
				LOGGER.info("ARCMasterServiceImpl : deleteARCMasterByArcId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	@Transactional
	public List<ARCMasterDTO> getARCMasterByArcType(Integer arcType) {
	LOGGER.info("ARCMasterServiceImpl : getARCMasterByArcType : Start");
	List<ARCMasterDTO> arcMasterDTOs = null;
	List<ARCMaster> arcMasterDetails = null;
	if (null != arcType) {
		arcMasterDetails = arcMasterRepository
				.findArcMasterByArcType(arcType);
	}
	if (null != arcMasterDetails && arcMasterDetails.size() > 0) {
		arcMasterDTOs = new ArrayList<ARCMasterDTO>();
		ARCMasterDTO arcMasterDTO = null;
		for (ARCMaster arcMasterRecord : arcMasterDetails) {
			arcMasterDTO = new ARCMasterDTO();
			arcMasterDTO = mapARCMasterDataToDTO(arcMasterRecord);
			arcMasterDTOs.add(arcMasterDTO);
		}

	}
	LOGGER.info("ARCMasterServiceImpl : getARCMasterByArcType : End");
	return arcMasterDTOs;
}

}
