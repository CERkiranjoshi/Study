package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;

/**
 * @author a603975
 * 
 */

public interface ParallelProcessService {
	Long createUpdateParallelProcess(ParallelProcessDTO parallelProcessDTO);

	List<ParallelProcessDTO> getAllParallelProcess();

	Boolean deleteParallelProcessByParallelProcessId(Long initParallelProcessId);

	List<ParallelProcessDTO> getParallelProcessListByParallelProcessState(String parallelProcessState);

	List<ParallelProcessDTO> getParallelProcessByParallelProcessId(String parallelProcessId);

	ParallelProcessDTO getParallelProcessByParallelProcessThreadId(Long parallelProcessThreadId);

	List<ParallelProcessDTO> getParallelProcessByType(String parallelProcessType);
	
	//method to add parallel process object to subProcess
	public Long addParallelProcessToSubProcess(ParallelProcessDTO parallelProcessDTO,Long subProcessId);

	ParallelProcessDTO getParallelProcessByParallelProcessIdandTenantIdandSolCatId(Long parallelProcessId,String tenantId,String solutionCategoryId);
}
