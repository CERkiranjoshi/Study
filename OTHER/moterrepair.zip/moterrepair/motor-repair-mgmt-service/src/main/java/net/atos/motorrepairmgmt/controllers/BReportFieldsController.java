/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;
import net.atos.motorrepairmgmt.dto.BReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.services.BReportFieldsService;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author a603327
 * 
 */

@Controller
@EnableSwagger
@RequestMapping("bReportFieldsService")
public class BReportFieldsController {

	@Autowired
	private BReportFieldsService bReportFieldsService;

	@RequestMapping(value = "/getAllBReportFields", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find All B Report Fields ", notes = "Returns a B Report Fields Entity", response = BReportFieldsDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found") })
	public @ResponseBody List<BReportFieldsDTO> getAllBReportFields() {
		return bReportFieldsService.getAllBReportFields();
	}

	@RequestMapping(value = "/createUpdateBReportFields", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates B Report Fields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody BReportFieldsDTO createUpdateBReportFields(
			@ApiParam(value = "B Report Fields object that needs to be added or update in the BReportFields") @RequestBody BReportFieldsDTO bReportFieldsDTO) {
		return bReportFieldsService.createUpdateBReportFields(bReportFieldsDTO);
	}

	@RequestMapping(value = "/getBReportFieldsByBReportFieldId/{bReportFieldId}", produces = { "application/json" }, method = { RequestMethod.GET })
	@ApiOperation(value = "Find B Report Fields By BReportField Id", notes = "Returns a B Report Fields entity when BReportField Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid BReportField Id supplied"),
			@ApiResponse(code = 404, message = "B Report Fields not found") })
	public @ResponseBody BReportFieldsDTO getBReportFieldsByBReportFieldId(
			@ApiParam(value = "BReportField Id of the B Report Fields that needs to be fetched", required = true) @PathVariable(value = "bReportFieldId") Long bReportFieldId) {
		return bReportFieldsService.getBReportFieldsByBReportFieldId(bReportFieldId);

	}

	@RequestMapping(value = "/deleteBReportFieldsByBReportFieldId/{bReportFieldId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Delete B Report Fields By BReportField Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid BReportField Id value") })
	public @ResponseBody Boolean deleteBReportFieldsByBReportFieldId(
			@ApiParam(value = "BReportField Id to delete") @PathVariable("bReportFieldId") Long bReportFieldId) {
		try {
			return bReportFieldsService.deleteBReportFieldsByBReportFieldId(bReportFieldId);
		} catch (Exception e) {
			return false;
		}
	}

	@RequestMapping(value = "/getVoltageDetailByBreportId/{bReportFieldId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find Motor Voltage Detail By BReportField Id", notes = "Returns a Motor Voltage Detail entity when BReportField Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid BReportField Id supplied"),
			@ApiResponse(code = 404, message = "Motor Voltage Detail not found") })
	public @ResponseBody MotorVoltageDetailDTO getVoltageDetailByBreportId(
			@ApiParam(value = "BReportField Id of the B Report Fields that needs to be fetched", required = true) @PathVariable("bReportFieldId") Long bReportFieldId) {
		return bReportFieldsService.getVoltageDetailByBreportId(bReportFieldId);
	}

	@RequestMapping(value = "/getSpeedDetailByBReportId/{bReportFieldId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find Motor Speed Detail By BReportField Id", notes = "Returns a Motor Speed Detail entity when BReportField Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid BReportField Id supplied"),
			@ApiResponse(code = 404, message = "Motor Speed Detail not found") })
	public @ResponseBody List<MotorSpeedDetailDTO> getSpeedDetailByBReportId(
			@ApiParam(value = "BReportField Id of the B Report Fields that needs to be fetched", required = true) @PathVariable("bReportFieldId") Long bReportFieldId) {
		return bReportFieldsService.getSpeedDetailByBReportId(bReportFieldId);
	}

	@RequestMapping(value = "/getNamePlateByBreportId/{bReportFieldId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find Motor Name Plate By BReportField Id", notes = "Returns a Motor Name Plate entity when BReportField Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid BReportField Id supplied"),
			@ApiResponse(code = 404, message = "Motor Name Plate not found") })
	public @ResponseBody MotorNamePlateDetailDTO getNamePlateByBreportId(
			@ApiParam(value = "BReportField Id of the B Report Fields that needs to be fetched", required = true) @PathVariable("bReportFieldId") Long bReportFieldId) {
		return bReportFieldsService.getNamePlateByBreportId(bReportFieldId);
	}

	@RequestMapping(value = "/getBReportFieldsBySubProcessId/{wlfwSubProcessId}", method = { RequestMethod.GET }, produces = "application/json")
	@ApiOperation(value = "Find B Report Fields By SubProcessFields Id", notes = "Returns a B Report Fields entity when SubProcessFields Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid SubProcessFields Id supplied"),
			@ApiResponse(code = 404, message = "B Report Fields not found") })
	public @ResponseBody BReportFieldsDTO getBReportFieldsBySubProcessId(
			@ApiParam(value = "SubProcessFields Id of the SubProcess Fields that needs to be fetched", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return bReportFieldsService.getBReportFieldsBySubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/addARCRepairEstimatesToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add ARC Repair Estimates to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addARCRepairEstimatesToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "ARC Repair Estimates to be added in BReportFields", required = true) @RequestBody List<ARCRepairEstimatesDTO> aRCRepairEstimatesDTOList) {
		return bReportFieldsService.addARCRepairEstimatesToBReportFields(bReportFieldId, aRCRepairEstimatesDTOList);
	}

	// OneToMany
	@RequestMapping(value = "/addARCSparesEstimatesToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add ARC Spares Estimates to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addARCSparesEstimatesToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "ARC Spares Estimates to be added in BReportFields", required = true) @RequestBody List<ARCSparesEstimatesDTO> aRCSparesEstimatesDTOList) {
		return bReportFieldsService.addARCSparesEstimatesToBReportFields(bReportFieldId, aRCSparesEstimatesDTOList);
	}

	// OneToMany
	@RequestMapping(value = "/addMotorSpeedDetailToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Motor Speed Detail to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addMotorSpeedDetailToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "Motor Speed Detail to be added in BReportFields", required = true) @RequestBody List<MotorSpeedDetailDTO> motorSpeedDetailDTOList) {
		return bReportFieldsService.addMotorSpeedDetailToBReportFields(bReportFieldId, motorSpeedDetailDTOList);
	}

	// OneToOne
	@RequestMapping(value = "/addMotorVoltageDetailToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Motor Voltage Detail to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addMotorVoltageDetailToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "Motor Voltage Detail to be added in BReportFields", required = true) @RequestBody MotorVoltageDetailDTO motorVoltageDetailDTO) {
		return bReportFieldsService.addMotorVoltageDetailToBReportFields(bReportFieldId, motorVoltageDetailDTO);
	}

	// OneToOne
	@RequestMapping(value = "/addMotorNamePlateDetailToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Motor Name Plate Detail to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addMotorNamePlateDetailToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "Motor Name Plate Detail to be added in BReportFields", required = true) @RequestBody MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		return bReportFieldsService.addMotorNamePlateDetailToBReportFields(bReportFieldId, motorNamePlateDetailDTO);
	}

	// OneToOne
	@RequestMapping(value = "/addElectricalObservationToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Electrical Observation to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addElectricalObservationToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "Electrical Observation to be added in BReportFields", required = true) @RequestBody ElectricalObservationDTO electricalObservationDTO) {
		return bReportFieldsService.addElectricalObservationToBReportFields(bReportFieldId, electricalObservationDTO);
	}

	// OneToOne
	@RequestMapping(value = "/addSubProcessFieldsToBReportFields/{bReportFieldId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Sub Process Fields to B Report Fields when bReportField ID is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "B Report Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long addSubProcessFieldsToBReportFields(
			@ApiParam(value = "Id of BReportFields", required = true) @PathVariable("bReportFieldId") Long bReportFieldId,
			@ApiParam(value = "Sub Process Fields to be added in BReportFields", required = true) @RequestBody SubProcessFieldsDTO subProcessFieldsDTO) {
		return bReportFieldsService.addSubProcessFieldsToBReportFields(bReportFieldId, subProcessFieldsDTO);
	}
}
