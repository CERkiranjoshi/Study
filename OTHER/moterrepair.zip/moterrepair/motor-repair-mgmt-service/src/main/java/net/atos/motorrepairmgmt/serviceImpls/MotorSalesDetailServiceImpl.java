package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSalesDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorSalesDetail;
import net.atos.motorrepairmgmt.repository.MotorSalesDetailRepository;
import net.atos.motorrepairmgmt.services.MotorSalesDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610039
 * 
 */
@Service
@Transactional
public class MotorSalesDetailServiceImpl implements MotorSalesDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The BudgetedBOM Repository */
	@Autowired
	private MotorSalesDetailRepository motorSalesDetailRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorSalesDetailServiceImpl.class);

	/**
	 * The method creates/updates a MotorSalesDetail record. The method performs
	 * an update operation when MotorSalesDetailId is passed and an existing
	 * record with matching MotorSalesDetailId is fetched for updation
	 * 
	 * @param MotorSalesDetailDTO
	 *            The MotorSales Detail
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateMotorSalesDetail(MotorSalesDetailDTO motorSalesDetailDTO) {
		LOGGER.info("MotorSalesDetailServiceImpl : createUpdateMotorSalesDetail : Start");
		MotorSalesDetail motorSalesDetails = null;
		Long id = -1l;
		try {
			if (null != motorSalesDetailDTO) {
				if (null != motorSalesDetailDTO.getMotorSalesDetailId()) {
					motorSalesDetails = motorSalesDetailRepository.findOne(motorSalesDetailDTO.getMotorSalesDetailId());
				}
				BeanUtils.copyProperties(motorSalesDetailDTO, motorSalesDetails,
						NullPropertyMapper.getNullPropertyNames(motorSalesDetailDTO));
				MotorSalesDetail savedObject = motorSalesDetailRepository.save(motorSalesDetails);
				LOGGER.info("MotorSalesDetailServiceImpl : createUpdateMotorSalesDetail : Record Saved/Updated");
				if (null != savedObject) {
					id = savedObject.getMotorSalesDetailId();
				}

			} else {
				LOGGER.info("MotorSalesDetailServiceImpl : createUpdateMotorSalesDetail : MotorSalesDetailDTO sent is Null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	/**
	 * The method retrieves all MotorSalesDetail on the basis its tenantId.
	 * 
	 * @param tenantId
	 *            The tenant Id
	 * @return List of MotorSalesDetail DTO
	 * 
	 */
	@Override
	public List<MotorSalesDetailDTO> getAllMotorSalesDetailByTenantId(String tenantId) {
		LOGGER.info("MotorSalesDetailServiceImpl : getAllMotorSalesDetailByTenantId : Start");
		List<MotorSalesDetailDTO> motorSalesDetailDTOs = null;
		List<MotorSalesDetail> motorSalesDetails = motorSalesDetailRepository
				.findAllMotorSalesDetailByTenantId(tenantId);
		MotorSalesDetailDTO motorSalesDetailDTO = new MotorSalesDetailDTO();
		if (null != motorSalesDetails && motorSalesDetails.size() > 0) {
			motorSalesDetailDTOs = new ArrayList<MotorSalesDetailDTO>();
			for (MotorSalesDetail motorSalesDetailRecord : motorSalesDetails) {
				motorSalesDetailDTO = dozerBeanMapper.map(motorSalesDetailRecord, MotorSalesDetailDTO.class);
				motorSalesDetailDTOs.add(motorSalesDetailDTO);
			}
		}
		LOGGER.info("MotorSalesDetailServiceImpl : getAllMotorSalesDetailByTenantId : End");
		return motorSalesDetailDTOs;
	}

	/**
	 * The method retrieves a MotorSalesDetail on the basis its
	 * motorSalesDetailId.
	 * 
	 * @param motorSalesDetailId
	 *            The MotorSalesDetailId
	 * @return MotorSalesDetail DTO
	 * 
	 */

	@Override
	public MotorSalesDetailDTO getMotorSalesDetailByMotorSalesDetailId(Long motorSalesDetailId) {
		LOGGER.info("MotorSalesDetailServiceImpl : getMotorSalesDetailByMasterWorkflowFieldId : Start");
		MotorSalesDetailDTO motorSalesDetailDTO = null;
		if (null != motorSalesDetailId) {
			MotorSalesDetail motorSalesDetails = motorSalesDetailRepository.findOne(motorSalesDetailId);
			if (null != motorSalesDetails) {
				motorSalesDetailDTO = dozerBeanMapper.map(motorSalesDetails, MotorSalesDetailDTO.class);
			}
		}
		LOGGER.info("MotorSalesDetailServiceImpl : getMotorSalesDetailByMasterWorkflowFieldId : End");
		return motorSalesDetailDTO;
	}

	/**
	 * Retrieves a list of all Active MotorSalesDetail on the basis of tenant id
	 * and solutionCategoryId
	 * 
	 * @param tenantId
	 *            The Tenant Id
	 * @param solutionCategoryId
	 *            The SolutionCategory Id
	 * @return Boolean
	 * 
	 */

	@Override
	public List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryId(String tenantId,
			String solutionCategoryId) {
		LOGGER.info("MotorSalesDetailServiceImpl :  getMotorSalesDetailByTenantIdAndSolutionCategoryId : Start");
		List<MotorSalesDetailDTO> motorSalesDetailDTOs = null;
		List<MotorSalesDetail> motorSalesDetails = null;
		MotorSalesDetailDTO motorSalesDetailDTO = null;
		if (null != tenantId && null != solutionCategoryId) {
			motorSalesDetails = motorSalesDetailRepository.findMotorSalesDetailByTenantIdAndSolutionCategoryId(
					tenantId, solutionCategoryId);
			if (null != motorSalesDetails && motorSalesDetails.size() > 0) {
				motorSalesDetailDTOs = new ArrayList<MotorSalesDetailDTO>();
				for (MotorSalesDetail motorSalesDetailRecord : motorSalesDetails) {
					motorSalesDetailDTO = dozerBeanMapper.map(motorSalesDetailRecord, MotorSalesDetailDTO.class);
					motorSalesDetailDTOs.add(motorSalesDetailDTO);
				}
			}
		}
		LOGGER.info("MotorSalesDetailServiceImpl : getMotorSalesDetailByTenantIdAndSolutionCategoryId : End");
		return motorSalesDetailDTOs;
	}

	/**
	 * Retrieves a list of all Active MotorSalesDetail on the basis of tenant id
	 * and solutionCategoryId and salesType
	 * 
	 * @param tenantId
	 *            The Tenant Id
	 * @param solutionCategoryId
	 *            The solutionCategory Id
	 * @param salesType
	 *            The Sales Type
	 * @return Boolean
	 * 
	 */
	@Override
	public List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(String tenantId,
			String solutionCategoryId, Integer salesType) {
		LOGGER.info("MotorSalesDetailServiceImpl :  getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType : Start");
		List<MotorSalesDetailDTO> motorSalesDetailDTOs = null;
		List<MotorSalesDetail> motorSalesDetails = null;
		MotorSalesDetailDTO motorSalesDetailDTO = null;
		if (null != tenantId && null != solutionCategoryId && null != salesType) {
			motorSalesDetails = motorSalesDetailRepository
					.findMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(tenantId, solutionCategoryId,
							salesType);
			if (null != motorSalesDetails && motorSalesDetails.size() > 0) {
				motorSalesDetailDTOs = new ArrayList<MotorSalesDetailDTO>();
				for (MotorSalesDetail motorSalesDetailRecord : motorSalesDetails) {
					motorSalesDetailDTO = dozerBeanMapper.map(motorSalesDetailRecord, MotorSalesDetailDTO.class);
					motorSalesDetailDTOs.add(motorSalesDetailDTO);
				}
			}
		}
		LOGGER.info("MotorSalesDetailServiceImpl : getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType : End");
		return motorSalesDetailDTOs;
	}

	/**
	 * The deletes a MotorSalesDetail on the basis its motorSalesDetailId.
	 * 
	 * @param motorSalesDetailId
	 *            The MotorSalesDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMotorSalesDetailByMotorSalesDetailId(Long motorSalesDetailId) {

		LOGGER.info("MotorSalesDetailServiceImpl : deleteMotorSalesDetailByMotorSalesDetailId : Start");
		boolean returnVal = false;
		try {
			if (null != motorSalesDetailId) {
				motorSalesDetailRepository.delete(motorSalesDetailId);
				returnVal = true;
			} else {
				LOGGER.info("MotorSalesDetailServiceImpl : deleteMotorSalesDetailByMotorSalesDetailId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

}
