package net.atos.motorrepairmgmt.services;

import java.util.List;
import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.RegionMasterDTO;

/**
 * @author a603975
 * 
 */
public interface RegionMasterService {
	Long createUpdateRegionMaster(RegionMasterDTO regionMasterDTO);

	List<RegionMasterDTO> getAllRegionMaster();

	List<ARCMasterDTO> getARCMasterListByRegionIDAndTenantIdAndSolCatId(Long regionId, String tenantId,
			String solutionCategoryId);

	List<RegionMasterDTO> getRegionMasterListByTenantIdAndSolCatId(String tenantId, String solutionCategoryId);
	
	RegionMasterDTO getRegionMasterByRegionIdAndTenantIdAndSolCatId(Long regionId,String tenantId, String solutionCategoryId);

	List<RegionMasterDTO> getRegionMasterListByTenantId(String tenantId);

	Boolean deleteRegionMasterByRegionId(Long regionId);
}
