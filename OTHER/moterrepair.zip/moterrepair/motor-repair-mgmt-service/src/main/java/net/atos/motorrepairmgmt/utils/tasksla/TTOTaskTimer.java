/**
 * 
 */
package net.atos.motorrepairmgmt.utils.tasksla;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;
import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.NotificationService;
import net.atos.motorrepairmgmt.services.SchedulerDetailsService;
import net.atos.motorrepairmgmt.services.TemplateInfoService;
import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.singetons.TaskSLAManager;
import net.atos.taskmgmt.activiti.engine.TaskManagementService;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.common.dto.TaskStatus;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author a529421
 * 
 */
public class TTOTaskTimer implements RunnableFuture<TTOTaskTimer> {

	private static final Logger LOGGER = Logger.getLogger(TTOTaskTimer.class);
	private final int SCHEDULER_TYPE = MotorRepairConstants.SCHEDULER_TYPES.TTO.getValue();

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private SchedulerDetailsService schedulerDetailsService;

	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;

	@Autowired
	protected WorkflowInvoker workflowInvoker;

	@Autowired
	protected ConfigDetailService configDetailService;

	@Autowired
	protected TemplateInfoService templateInfoService;

	@Autowired
	TaskSLAManager taskSLAManager;

	@Autowired
	TaskManagementService taskManagementService;

	private String name;
	private String taskId;
	private String processInstanceId;
	private String ttoTaskTimerId;
	private String schedulerId;
	private Long subprocessId;
	private long nextRunTimeInMillis;
	private List<String> emailAddresses;
	private int reminderNumber;
	private String functionCode;

	public TTOTaskTimer() {
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId
	 *            the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the processInstanceId
	 */
	public String getProcessInstanceId() {
		return processInstanceId;
	}

	/**
	 * @param processInstanceId
	 *            the processInstanceId to set
	 */
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	/**
	 * @return the ttoTaskTimerId
	 */
	public String getTtoTaskTimerId() {
		return ttoTaskTimerId;
	}

	/**
	 * @param ttoTaskTimerId
	 *            the ttoTaskTimerId to set
	 */
	public void setTtoTaskTimerId(String ttoTaskTimerId) {
		this.ttoTaskTimerId = ttoTaskTimerId;
	}

	/**
	 * @return the schedulerId
	 */
	public String getSchedulerId() {
		return schedulerId;
	}

	/**
	 * @param schedulerId
	 *            the schedulerId to set
	 */
	public void setSchedulerId(String schedulerId) {
		this.schedulerId = schedulerId;
	}

	/**
	 * @return the subprocessId
	 */
	public Long getSubprocessId() {
		return subprocessId;
	}

	/**
	 * @param subprocessId
	 *            the subprocessId to set
	 */
	public void setSubprocessId(Long subprocessId) {
		this.subprocessId = subprocessId;
	}

	/**
	 * @return the nextRunTimeInMillis
	 */
	public long getNextRunTimeInMillis() {
		return nextRunTimeInMillis;
	}

	/**
	 * @param nextRunTimeInMillis
	 *            the nextRunTimeInMillis to set
	 */
	public void setNextRunTimeInMillis(long nextRunTimeInMillis) {
		this.nextRunTimeInMillis = nextRunTimeInMillis;
	}

	/**
	 * @return the emailAddresses
	 */
	public List<String> getEmailAddresses() {
		return emailAddresses;
	}

	/**
	 * @param emailAddresses
	 *            the emailAddresses to set
	 */
	public void setEmailAddresses(List<String> emailAddresses) {
		this.emailAddresses = emailAddresses;
	}

	/**
	 * @return the reminderNumber
	 */
	public int getReminderNumber() {
		return reminderNumber;
	}

	/**
	 * @param reminderNumber
	 *            the reminderNumber to set
	 */
	public void setReminderNumber(int reminderNumber) {
		this.reminderNumber = reminderNumber;
	}

	/**
	 * @return the functionCode
	 */
	public String getFunctionCode() {
		return functionCode;
	}

	/**
	 * @param functionCode
	 *            the functionCode to set
	 */
	public void setFunctionCode(String functionCode) {
		this.functionCode = functionCode;
	}

	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		System.out.println("Called CANCEL for " + this.toString());
		return false;
	}

	@Override
	public boolean isCancelled() {
		System.out.println("Called isCANCEL" + this.toString());
		return false;
	}

	@Override
	public boolean isDone() {
		System.out.println("Called isDONE" + this.toString());
		return false;
	}

	@Override
	public TTOTaskTimer get() throws InterruptedException, ExecutionException {
		System.out.println("Called get()" + this.toString());

		return this;
	}

	@Override
	public TTOTaskTimer get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException,
			TimeoutException {
		System.out.println("Called get(long timeout, TimeUnit unit)" + this.toString());
		return this;
	}

	@Override
	public void run() {
		LOGGER.info("TTO_TASK_TIMER: BEGIN: " + Calendar.getInstance().getTime() + " " + this.toString()
				+ " AM RUNNING!");

		
		
		// ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
		//
		// SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);
		SchedulerDetailsDTO schedulerDetailsDTO = schedulerDetailsService
				.getSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(getSchedulerId(),
						MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
		schedulerDetailsDTO.setLastRunTs(new Date());
		schedulerDetailsDTO.setHasExecuted(1);

		schedulerDetailsService.createUpdateSchedulerDetails(schedulerDetailsDTO);

		//TODO Further execution skipped
		boolean skipExecution = true;
		if(skipExecution)
			return;

		// Test if task has been completed.
		try {
			// TaskManagementService taskManagementService = applicationContext.getBean(TaskManagementService.class);
			TaskDetailsDTO taskDetailsDTO = taskManagementService.getTaskDetails(taskId);

			if (null != taskDetailsDTO) {

				if (!TaskStatus.Completed.toString().equals(taskDetailsDTO.getStatus())) {

					LOGGER.info("TTO_TASK_TIMER: TASK [ID: " + taskId + "] NOT COMPLETED, TO BE RESCHEDULED : "
							+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
							+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId() + "; RUN NUMBER: "
							+ schedulerDetailsDTO.getRunNumber());
					// TemplateInfoService templateInfoService = applicationContext.getBean(TemplateInfoService.class);

					/**
					 * 
					 * TODO check the run number for this TTO Task. If it is: <br>
					 * 1: <t>Send Warning Notification and re-run for escalation.<br>
					 * <t>Update task to be in Warning SLA State.<br>
					 * 2: <t>Send Escalation Notification for Level 1 and re-run for escalation level 2 if any.<br>
					 * <t>Update task to be in Escalated SLA State.<br>
					 * 3: <t>Send Escalation Notification for Level 2 and re-run for escalation level 3 if any.<br>
					 * <t> Task remains in Escalated SLA State.<br>
					 * 4: <t>Send Escalation Notification and re-run for escalation level 4 if any.<br>
					 * <t>Task remains in Escalated SLA State.<br>
					 * 5: <t>Send Escalation Notification and re-run for escalation level 4<br>
					 * <t>Tash remains in Escalated SLA State.<br>
					 */

					List<TemplateInfoDTO> templateInfoDTOs = templateInfoService
							.findTemplateInfoByFunCodeNNotificationType(functionCode,
									MotorRepairConstants.TASK_NOTIFY_TYPE.TASK_WARN.getValue());

					for (TemplateInfoDTO templateInfoDTO : templateInfoDTOs) {
						String templateCode = templateInfoDTO.getTemplateCode();

						LOGGER.info("TTO_TASK_TIMER: [ID: " + taskId + "] TODO SEND NOTIFICATION FOR : "
								+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
								+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId() + "; TEMPLATE_CODE: "
								+ templateCode + "; FUNCTION_CODE: " + functionCode);
						// Send notification for TTO
						// notificationService.triggerWarningNotification(templateCode, templateCode, schedulerDetailsDTO.getSubprocessId(), actorName);

					}

					// schedule another reminder
					// TODO FETCH DATA FROM CONFIG
					if (schedulerDetailsDTO.getRunNumber() < 3) {
						LOGGER.info("TTO_TASK_TIMER: [ID: " + taskId + "] Scheduling next run: " + this.toString()
								+ " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
								+ schedulerDetailsDTO.getSubprocessId());
						// TaskSLAManager taskSLAManager = applicationContext.getBean(TaskSLAManager.class);
						String schedulerId = taskSLAManager.triggerMotorNotReceivedScheduler(schedulerDetailsDTO
								.getBatchProcessId(), schedulerDetailsDTO.getMasterWorkflowId().toString(),
								schedulerDetailsDTO.getProcInstRefId(), schedulerDetailsDTO.getScheduledBy(),
								schedulerDetailsDTO.getSubprocessId().toString(),
								schedulerDetailsDTO.getFunctionCode(), schedulerDetailsDTO.getGspRefNum(), 1,
								schedulerDetailsDTO.getRunNumber().intValue() + 1, schedulerDetailsDTO.getTaskRefId(),
								schedulerDetailsDTO.getTaskPriority());
					} else {
						LOGGER.info("TTO_TASK_TIMER: [ID: " + taskId + "] Triggering Workflow : " + this.toString()
								+ " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
								+ schedulerDetailsDTO.getSubprocessId());
						// invokeMotorNotReceivedWorkflow(taskDetailsDTO);
					}

				} else {
					LOGGER.info("TTO_TASK_TIMER: TASK [ID: " + taskId
							+ "] HAS BEEN COMPLETED >> NO SCHEDULING REQUIRED: " + this.toString() + " for GSP_REF: "
							+ schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
							+ schedulerDetailsDTO.getSubprocessId());

				}
			} else {
				LOGGER.warn("TTO_TASK_TIMER: TASK [ID: " + taskId + "] NOT FOUND!! NO FURTHER SCHEDULING REQUIRED: "
						+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
						+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId());

			}
		} catch (BeansException e) {
			LOGGER.error("TTO_TASK_TIMER: Error while fetching task Details", e);
		} catch (Exception e) {
			LOGGER.error("TTO_TASK_TIMER: Error while fetching task Details", e);
		}

		LOGGER.info("TTO_TASK_TIMER: END: " + this.toString() + " DONE");
	}

	/**
	 * Invoke Notification workflow.
	 * 
	 * @param execution
	 * @param nextProcessVars
	 * @return
	 */
	protected String sendNotification(Map<String, Object> nextProcessVars) {

		String functionCode = MotorRepairConstants.SYS_NOTIFICATION;

		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);
		String workflowName = actorFunctionMasterDTO.getWorkflowName();

		// TODO set nextProcessVars with appropriate values
		nextProcessVars.put(ActivitiConstants.CHECK_EDIT_ENABLED, 0);

		return workflowInvoker.startNewProcess(nextProcessVars, workflowName);

	}

	@Override
	public String toString() {
		return "TTOTaskTimer [" + name + "; " + taskId + "; " + processInstanceId + "]";
	}

}
