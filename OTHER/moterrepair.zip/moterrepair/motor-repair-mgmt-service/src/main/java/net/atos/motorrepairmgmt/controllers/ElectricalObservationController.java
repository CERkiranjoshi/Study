package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.services.ElectricalObservationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610051
 * 
 */
@Controller
@EnableSwagger
@RequestMapping(value = "electricalObservationService")
public class ElectricalObservationController {

	/** The ARCRepairEstimates Service */
	@Autowired
	private ElectricalObservationService electricalObservationService;

	/**
	 * This method is used for creating and updating ElectricalObservation.
	 * 
	 * @param ElectricalObservationDTO
	 *            The electricalObservationDTO
	 * 
	 * @return Boolean
	 */
	@RequestMapping(value = "/createUpdateElectricalObservation", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates ElectricalObservation with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateElectricalObservation(
			@RequestBody ElectricalObservationDTO electricalObservationDTO) {

		return electricalObservationService.createUpdateElectricalObservation(electricalObservationDTO);
	}

	/**
	 * This method is used for deleting ElectricalObservation.
	 * 
	 * @param motorElecObsId
	 *            The MotorElecObs Id
	 * 
	 * @return Boolean
	 */

	@RequestMapping(value = "/deleteElectricalObservationByMotorElecObsId/{motorElecObsId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete ElectricalObservation By MotorElecObs Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid MotorElecObs Id value") })
	public @ResponseBody Boolean deleteElectricalObservationByMotorElecObsId(
			@ApiParam(value = "MotorElecObs Id to delete", required = true) @PathVariable("motorElecObsId") Long motorElecObsId) {
		try {
			return electricalObservationService.deleteElectricalObservationByMotorElecObsId(motorElecObsId);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 
	 * This method is used for retrieving all ElectricalObservation.
	 * 
	 * @return ElectricalObservationDTOs
	 */
	@RequestMapping(value = "/getAllElectricalObservation", method = RequestMethod.GET)
	@ApiOperation(value = "Find All ElectricalObservation", notes = "Returns a ElectricalObservation entity", response = ElectricalObservationDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation") })
	public @ResponseBody List<ElectricalObservationDTO> getAllElectricalObservation() {
		return electricalObservationService.getAllElectricalObservation();
	}

	/**
	 * This method is used for retrieving ElectricalObservation based on
	 * motorElecObsId.
	 * 
	 * @param motorElecObsId
	 *            The MotorElecObs Id
	 * 
	 * @return ElectricalObservationDTO
	 * 
	 */
	@RequestMapping(value = "/getElectricalObservationByMotorElecObsId/{motorElecObsId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ElectricalObservation By motorElecObs Id", notes = "Returns a ElectricalObservation entity when motorElecObs Id is passed", response = ARCRepairEstimatesDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorElecObs Id supplied"),
			@ApiResponse(code = 404, message = "ElectricalObservation not found") })
	public @ResponseBody ElectricalObservationDTO getElectricalObservationByMotorElecObsId(
			@ApiParam(value = "motorElecObs Id of the ElectricalObservation that needs to be fetched", required = true) @PathVariable("motorElecObsId") Long motorElecObsId) {
		return electricalObservationService.getElectricalObservationByMotorElecObsId(motorElecObsId);
	}

}
