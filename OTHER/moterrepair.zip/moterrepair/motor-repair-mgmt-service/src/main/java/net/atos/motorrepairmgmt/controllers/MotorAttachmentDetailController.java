/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.services.MotorAttachmentDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a603327
 * 
 */
@Controller
@EnableSwagger
@RequestMapping("motorAttachmentDetailService")
public class MotorAttachmentDetailController {

	@Autowired
	private MotorAttachmentDetailService motorAttachmentDetailService;

	@RequestMapping(value = "/getAllMotorAttachmentDetail", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Find All Motor Attachment Detail", notes = "Returns a Motor Attachment Detail Entity", response = MotorAttachmentDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 404, message = "Motor Attachment Detail not found") })
	public @ResponseBody
	List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetail() {
		return motorAttachmentDetailService.getAllMotorAttachmentDetail();
	}

	@RequestMapping(value = "/getMotorAttachmentDetailById/{motorAttachmentsId}", produces = { "application/json" }, method = { RequestMethod.GET })
	@ApiOperation(value = "Find Motor Attachment Detail By MotorAttachment Id", notes = "Returns a Motor Attachment Detail entity when MotorAttachment Id is passed", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 400, message = "Invalid MotorAttachment Id supplied"),
			@ApiResponse(code = 404, message = "Motor Attachment Detail not found") })
	public @ResponseBody
	MotorAttachmentDetailDTO getMotorAttachmentDetailById(
			@ApiParam(value = "MotorAttachment Id of the Motor Attachment Detail that needs to be fetched", required = true) @PathVariable(value = "motorAttachmentsId") Long motorAttachmentsId) {
		return motorAttachmentDetailService.getMotorAttachmentDetailById(motorAttachmentsId);

	}

	@RequestMapping(value = "/createUpdateMotorAttachmentDetail", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates Motor Attachment Detail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Operation"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long createUpdateMotorAttachmentDetail(
			@ApiParam(value = "Motor Attachment Detail object that needs to be added or update in the MotorAttachmentDetail") @RequestBody MotorAttachmentDetailDTO motorAttachmentDetailDTO) {
		return motorAttachmentDetailService.createUpdateMotorAttachmentDetail(motorAttachmentDetailDTO);
	}

	@RequestMapping(value = "/deleteMotorAttachmentDetail/{motorAttachmentsId}", method = { RequestMethod.GET }, produces = { "application/json" })
	@ApiOperation(value = "Delete Motor Attachment Detail By MotorAttachment Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorAttachment Id value") })
	public @ResponseBody
	Boolean deleteMotorAttachmentDetail(
			@ApiParam(value = "MotorAttachment Id to delete") @PathVariable("motorAttachmentsId") Long motorAttachmentsId) {
		try {
			return motorAttachmentDetailService.deleteMotorAttachmentDetail(motorAttachmentsId);
		} catch (Exception e) {
			return false;
		}
	}

	@RequestMapping(value = "/getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId/{motorAttachmentsId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MotorAttachmentDetail Fields By motorAttachmentsId ,TenantId and solutionCategoryId", notes = "Returns a MotorAttachmentDetail Fields entity when motorAttachmentsId,TenantId and SolutionCategoryId is passed", response = MotorAttachmentDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorAttachmentsId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " MotorAttachmentDetailDTO Fields not found") })
	public @ResponseBody
	MotorAttachmentDetailDTO getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId(
			@ApiParam(value = "motorAttachmentsId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable(value = "motorAttachmentsId") final Long motorAttachmentsId,
			@ApiParam(value = "TenantId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "SolutionCategoryId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable(value = "solutionCategoryId") final String solutionCategoryId) {
		return motorAttachmentDetailService.getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId(
				motorAttachmentsId, tenantId, solutionCategoryId);
	}

	@RequestMapping(value = "/getMotorAttachmentCount/{subprocessId}/{tenantId}/{solutionCategoryId}/{external}/{uploadedBy}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Fetch MotorAttachmentDetail count By subprocessId ,TenantId, solutionCategoryId and visibility Type", notes = "Returns count of Motor Attachments for a given subprocessId, tenantId, solutionCategoryId and visibilityType", response = Integer.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid subprocessId,Tenantid, SolutionCategoryId and visibility type supplied"),
			@ApiResponse(code = 404, message = " MotorAttachmentDetailDTO Fields not found") })
	public @ResponseBody
	Long getMotorAttachmentCount(
			@ApiParam(value = "subprocessId of the Subprocess for which the count needs to be fetched", required = true) @PathVariable(value = "subprocessId") final Long subprocessId,
			@ApiParam(value = "TenantId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "SolutionCategoryId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable(value = "solutionCategoryId") final String solutionCategoryId,
			@ApiParam(value = "Attachment Visibility", required = true) @PathVariable(value = "external") final boolean external,
			@ApiParam(value = "Uploaded By, required if external flag is true", required = false) @PathVariable(value = "uploadedBy") final String uploadedBy) {
		return motorAttachmentDetailService.getMotorAttachmentCountBySubprocessIdandTenantIdandSolCatId(subprocessId,
				external, solutionCategoryId, tenantId, uploadedBy);
	}
}
