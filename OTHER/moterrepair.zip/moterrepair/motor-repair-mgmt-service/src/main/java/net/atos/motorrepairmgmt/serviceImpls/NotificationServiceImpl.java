/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.NotificationService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.TemplateInfoService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.client.rest.RestClient;
import net.atos.taskmgmt.service.ActorMasterService;

import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * @author Sweety Kothari service to handle all notification to customer ,for assignment & auto trigger
 */
@Service
public class NotificationServiceImpl implements NotificationService {

	/**
	 * LOGGER
	 */
	private static final Logger LOGGER = Logger.getLogger(NotificationServiceImpl.class);

	@Value("${logoPath}")
	private String logoPath;

	@Autowired
	private ConfigDetailService configDetailService;

	private Map<String, String> notificationConfigMap;

	@Autowired
	private VelocityEngine velocityEngine;

	@Autowired
	private SubProcessFieldsService subProcessFieldsService;

	@Autowired
	private TemplateInfoService templateInfoService;

	@Autowired
	private ActorMasterService actorMasterService;

	@Autowired
	private ARCMasterService arcMasterService;

	@Autowired
	private RestClient restClient;

	private Map<String, String> smtpServerDetail;

	private Map<String, String> smsConfigDetailMap;

	private boolean secured;

	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public void setVelocityEngine(VelocityEngine velocityEngine) {
		this.velocityEngine = velocityEngine;
	}

	private void setInitMap() {
		if (null == smtpServerDetail) {
			List<ConfigDetailDTO> configDetailDTOList = configDetailService.findConfigDetailsByConfigType(
					MotorRepairConstants.SMTP_SERVER, MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
			smtpServerDetail = new HashMap<String, String>();
			for (ConfigDetailDTO configDetailDTO : configDetailDTOList) {
				smtpServerDetail.put(configDetailDTO.getConfigSubType(), getValue(configDetailDTO));
				if (MotorRepairConstants.IS_SECURED.equals(configDetailDTO.getConfigSubType())) {
					secured = "1".equals(getValue(configDetailDTO));
				}
			}
		}
	}

	private String getValue(ConfigDetailDTO configDetailDTO) {
		String value = null;
		switch (configDetailDTO.getCofigDataType()) {
		// Config Type - 1: String value; 2: Integer; 3: Float; 4: Date Time; 5:
		// Boolean
			case 1:
				value = configDetailDTO.getConfigStrVal();
				break;
			case 2:
				if (null != configDetailDTO.getConfigIntVal())
					value = configDetailDTO.getConfigIntVal().toString();
				else
					value = "0";
				break;
			case 3:
				if (null != configDetailDTO.getConfigDoubleVal())
					value = configDetailDTO.getConfigDoubleVal().toString();
				else
					value = "0";
				break;
		}
		return value;
	}

	private void setSMSInitMap() {
		if (null == smsConfigDetailMap) {
			List<ConfigDetailDTO> configDetailDTOList = configDetailService.findConfigDetailsByConfigType(
					MotorRepairConstants.SMS_SERVER_DETAIL, MotorRepairConstants.TENANT_ID,
					MotorRepairConstants.PROGRAM_ID);
			smsConfigDetailMap = new HashMap<String, String>();
			for (ConfigDetailDTO configDetailDTO : configDetailDTOList) {
				smsConfigDetailMap.put(configDetailDTO.getConfigSubType(), getValue(configDetailDTO));

			}
		}
	}

	// store all config parameter related to notification
	private synchronized Map<String, String> getNotificationConfigMap() {
		/*
		 * get email notification & SMS notification flag ,if anyone of it enabled then only proceed further else return
		 */
		if (null == notificationConfigMap) {
			List<ConfigDetailDTO> configDetailDTOList = configDetailService
					.findEnabledNVisibleConfigDetailsByType(MotorRepairConstants.NOTIFICATIONS,
							MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
			notificationConfigMap = new HashMap<String, String>();
			if (null != configDetailDTOList) {
				for (ConfigDetailDTO configDetailDTO : configDetailDTOList) {
					notificationConfigMap.put(configDetailDTO.getConfigKey(), getValue(configDetailDTO));
				}
			}
		}
		return notificationConfigMap;

	}

	private MimeMessage getMessageObj(List<String> toEmailAddressList, List<String> ccEmailAddressList,
			List<String> bccEmailAddressList, String content, String subjectLine) {
		MimeMessage message = null;
		try {
			Properties properties = System.getProperties();
			setInitMap();
			if (!secured) {
				// Setup mail server
				properties.setProperty("mail.smtp.host", smtpServerDetail.get(MotorRepairConstants.SMTP_HOST));
				properties.setProperty("mail.smtp.port", smtpServerDetail.get(MotorRepairConstants.SMTP_PORT));
				properties.setProperty("mail.user", smtpServerDetail.get(MotorRepairConstants.SMTP_USER));
				properties.setProperty("mail.password", smtpServerDetail.get(MotorRepairConstants.SMTP_PASSWORD));
			} else {
				properties.setProperty("mail.transport.protocol", "smtps");
				properties.setProperty("mail.smtps.auth", "true");
				properties.setProperty("mail.smtps.host", smtpServerDetail.get(MotorRepairConstants.SMTP_HOST));
				properties.setProperty("mail.smtps.port", smtpServerDetail.get(MotorRepairConstants.SMTP_PORT));
				properties.setProperty("mail.user", smtpServerDetail.get(MotorRepairConstants.SMTP_USER));
				properties.setProperty("mail.password", smtpServerDetail.get(MotorRepairConstants.SMTP_PASSWORD));
			}
			// Get the default Session object.
			Session session = Session.getDefaultInstance(properties, new Authenticator() {

				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(smtpServerDetail.get(MotorRepairConstants.SMTP_USER),
							smtpServerDetail.get(MotorRepairConstants.SMTP_PASSWORD));
				}
			});
			LOGGER.info("SMTP server details:"+smtpServerDetail);
			// Create a default MimeMessage object.
			message = new MimeMessage(session);

			// Set From: header field of the header.
			if (null != smtpServerDetail.get(MotorRepairConstants.REPLY_TO_ADDRESS)) {
				message.setFrom(new InternetAddress(smtpServerDetail.get(MotorRepairConstants.REPLY_TO_ADDRESS)));
			}

			// Set To: header field of the header.
			for (String toAddress : toEmailAddressList) {
				LOGGER.info("Adding toaddress in message recipient ");
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
			}
			// set CC address
			if (null != ccEmailAddressList) {
				for (String ccAddress : ccEmailAddressList) {
				message.addRecipient(Message.RecipientType.CC, new InternetAddress(ccAddress));
				}
			}
			// set bcc address
			if (null != bccEmailAddressList) {
				for (String bccAddress : bccEmailAddressList) {
					message.addRecipient(Message.RecipientType.BCC, new InternetAddress(bccAddress));
				}
			}

			// Set Subject: header field
			message.setSubject(subjectLine);

			LOGGER.debug("Content ===========> " + content);

			// Send the actual HTML message, as big as you like
			message.setContent(content, "text/html");
		} catch (Exception e) {
			LOGGER.error("SMTP Server detail is missing ", e);
		}
		return message;

	}

	// fetch ARC email value by subprocess arc ref id
	private List<String> fetchArcEmailList(Long arcRefId, List<String> toEmailAddressList) {
		// fetch email Id based on arcRefId
		ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(arcRefId);
		if (null != arcMasterDTO) {
			toEmailAddressList.add(arcMasterDTO.getArcContactEmail());
		}
		return toEmailAddressList;
	}

	private List<String> fetchActorGroupEmailList(String actorName, List<String> toEmailAddressList) {
		// fetch group id based on actorName
		List<String> actorNameList = new ArrayList<String>();
		actorNameList.add(actorName);
		Map<String, String> actorGroupEmailMap = actorMasterService.getActorGroupEmailId(actorNameList);
		if (null != actorGroupEmailMap.get(actorName)) {
			toEmailAddressList.add(actorGroupEmailMap.get(actorName));
		}
		return toEmailAddressList;
	}

	/**
	 * Steps: 1. Using SubprocessId, fetch the details of the customer 2. fetch template code for motor not received
	 * function code 3.trigger notification
	 */
	public boolean autoTriggerNotification(String functionCode, String templateCode, Long subProcessId) {
		LOGGER.info("inside auto trigger notification ...");
		try {
			Map<String, String> configMap = getNotificationConfigMap();
			// if any of notification flag is set then only go for below process
			int emailNotificationEnabled = null != configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString())) : 0;
			if (emailNotificationEnabled == 0) {
				return false;
			}

			// Fetch subprocess object using subprocess id.
			SubProcessFieldsDTO subProcessFieldsDTO = subProcessFieldsService
					.getSubProcessFieldsByWlfwSubProcessId(subProcessId);
			if (null == subProcessFieldsDTO) {
				LOGGER.error("subProcess object is null ");
				return false;
			}
			// fiend template & Subject line based on function code & emailCode
			LOGGER.info("Function code " + functionCode + "template code is " + templateCode);
			List<TemplateInfoDTO> templateInfoDTOList = templateInfoService.findTemplateInfoByFunCodeNEmailCode(
					functionCode, templateCode);
			String emailTemplateName = null;
			String subjectLine = null;
			String smsTemplateName = null;
			Map<String, String> userParams = new HashMap<String, String>();
			for (TemplateInfoDTO templateInfoDTO : templateInfoDTOList) {
				if (templateInfoDTO.getTemplateType().equals(MotorRepairConstants.TEMPLATE_TYPE.EMAIL.getValue())) {
					emailTemplateName = templateInfoDTO.getTemplateName();
					subjectLine = templateInfoDTO.getSubjectLine();
				} else {
					smsTemplateName = templateInfoDTO.getTemplateName();
				}
				userParams.put(MotorRepairConstants.STATUS, templateInfoDTO.getStatusText());
			}
			// Replace GSP Ticket reference in Subject line
			String gspRefNo = null;
			String motorSnNo = null;
			if (null != subProcessFieldsDTO.getMasterWorkflowFields()) {
				gspRefNo = subProcessFieldsDTO.getMasterWorkflowFields().getGspRefNo();
				motorSnNo = subProcessFieldsDTO.getMotorSnNum();
			}
			// Replace common values in template body.

			Calendar cl = Calendar.getInstance();

			if (null != subProcessFieldsDTO.getArcRefId()) {
				ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(Long.valueOf(subProcessFieldsDTO
						.getArcRefId()));
				if (null != arcMasterDTO) {
					userParams.put(MotorRepairConstants.ARC_NAME, arcMasterDTO.getArcName());
					userParams.put(MotorRepairConstants.ARC_ADDRESS, arcMasterDTO.getArcAddress());
					userParams.put(MotorRepairConstants.ARC_CITY, arcMasterDTO.getArcCity());
					userParams.put(MotorRepairConstants.ARC_ZIP, arcMasterDTO.getArcZipCode());
				}
			}
			userParams.put(MotorRepairConstants.TICKET_REF_NO, gspRefNo);

			userParams.put(MotorRepairConstants.MOTOR_SN_NO, motorSnNo);
			userParams.put(MotorRepairConstants.DATE_EMAIL, dateFormat.format(cl.getTime()));
			userParams.put(MotorRepairConstants.HELPLINE_NUMBER, configMap.get(MotorRepairConstants.HELPLINE_NUMBER)
					.toString());
			userParams.put(MotorRepairConstants.HELPLINE_EMAIL, configMap.get(MotorRepairConstants.HELPLINE_EMAIL)
					.toString());
			/*
			 * userParams.put(MotorRepairConstants.HELPLINE_URL, configMap.get(MotorRepairConstants.HELPLINE_URL)
			 * .toString());
			 */
			userParams.put(MotorRepairConstants.LOGO_URL, configMap.get(MotorRepairConstants.HOST_URL).toString()
					+ logoPath);
			String statusTracking = configMap.get(MotorRepairConstants.STATUS_TRACKING).toString();
			if (statusTracking != null) {
				statusTracking = statusTracking.replace(MotorRepairConstants.TASK_ID, gspRefNo);
				userParams.put(MotorRepairConstants.TRACKING_URL, statusTracking);
			}

			// get ccaddress from additionContanctDetail
			List<String> ccAddress = new ArrayList<String>();
			if (null != subProcessFieldsDTO.getMasterWorkflowFields().getAdditionalContactDetails()) {
				for (AdditionalContactDetailDTO additionalContactDetailDTO : subProcessFieldsDTO
						.getMasterWorkflowFields().getAdditionalContactDetails()) {
					if (null != additionalContactDetailDTO.getEmailAddress())
						ccAddress.add(additionalContactDetailDTO.getEmailAddress());
				}
			}
			boolean mailSentToAll = false;

			List<String> internalEmailAddressList = new ArrayList<String>();
			// fetch CCC use group email id which will go in CCaddressList
			internalEmailAddressList = fetchActorGroupEmailList(MotorRepairConstants.CCC_USER, internalEmailAddressList);

			ccAddress.addAll(internalEmailAddressList);
			for (CustomerDetailDTO custDetailDTO : subProcessFieldsDTO.getMasterWorkflowFields().getCustomerDetails()) {
				List<String> toEmailAddressList = new ArrayList<String>();
				// replace individual values specific to each customer
				userParams.put(MotorRepairConstants.CUST_NAME, custDetailDTO.getCustomerName());
				toEmailAddressList.add(custDetailDTO.getEmailId());

				// Send notification for email
				boolean response = false;
				if (null != emailTemplateName) {
					response = triggerEmailNotification(userParams, toEmailAddressList, ccAddress, subjectLine,
							emailTemplateName, null);
				}
				// to store flag ,if in failed for any customer
				if (!response && mailSentToAll) {
					mailSentToAll = response;
					LOGGER.info("mail sent to all ...");
				}

			}
			// END LOOP
			return mailSentToAll;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/*public static void main(String[] args) throws AddressException, MessagingException {
		System.out.println("BEGIN Executing Notification Service........");
		NotificationServiceImpl ns = new NotificationServiceImpl();
		List<String> toEmailAddressList = new ArrayList<String>();
		// toEmailAddressList.add("sweety.kothari@atos.net");
		toEmailAddressList.add("anand.ved@atos.net");
		List<String> bccEmailAddressList;
		// ns.smsConfigDetailMap.put(key, value)

		MimeMessage message = null;
		try {
			Properties properties = System.getProperties();
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.smtp.auth", "true"); // If you need to authenticate

			// Use the following if you need SSL
			// properties.put("mail.smtp.socketFactory.port", d_port);
			// properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			// properties.put("mail.smtp.socketFactory.fallback", "false");

			properties.setProperty("mail.transport.protocol", "smtps");
			properties.setProperty("mail.smtps.auth", "true");
			properties.setProperty("mail.smtps.host", "smtp.office365.com");
			properties.setProperty("mail.smtps.port", "587");
			properties.setProperty("mail.user", "");
			properties.setProperty("mail.password", "");
			// Get the default Session object.
			Session session = Session.getDefaultInstance(properties, new Authenticator() {

				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("", "");
				}
			});

			// Create a default MimeMessage object.
			message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress("ics.india@siemens.com"));

			// Set To: header field of the header.
			for (String toAddress : toEmailAddressList) {
				// if email id is not ending with @atos.net ,then do not send
				// mail
				if (null != toAddress && (toAddress.toLowerCase().endsWith("@atos.net"))) {
					message.addRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
				} else {
					LOGGER.info("EMAIL NOT SENT:Email Id is not ending with @atos.net ,so not sending email ...");
				}
			}
			message.setSubject("TEST");

			// Send the actual HTML message, as big as you like
			message.setContent("This is the body", "text/html");
			// Send message
			Transport.send(message);
		} catch (Exception e) {
			LOGGER.error("SMTP Server detail is missing ", e);
		}

		System.out.println("DONE Executing Notification Service........");
	}
*/
	// All email address are list
	private boolean triggerEmailNotification(Map<String, String> userParam, List<String> toEmailAddressList,
			List<String> ccEmailAddressList, String subjectLine, String emailTemplateName,
			List<String> bccEmailAddressList) {
		LOGGER.info("NOTIFICATION:trigger email notification" + emailTemplateName);
		try {
			VelocityContext velocityContext = new VelocityContext(userParam);
			StringWriter writer = new StringWriter();
			if (null != velocityEngine) {
				velocityEngine.mergeTemplate(emailTemplateName, "UTF-8", velocityContext, writer);
				String content = writer.getBuffer().toString();
				LOGGER.trace("Content ===========> " + content);
				MimeMessage message = getMessageObj(toEmailAddressList, ccEmailAddressList, bccEmailAddressList,
						content, subjectLine);
				// Send message
				if (null != message) {
					LOGGER.debug("-----email template ready to send-----");

					Transport.send(message);
					LOGGER.info("Sent message successfully....");
					return true;

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	// trigger SMS notification
	private boolean triggerSMSNotification(String phoneNo, String smsTemplateName) {
		setSMSInitMap();
		ResponseEntity<String> response = null;
		LOGGER.info("NOTIFICATION:trigger sms notification");
		try {
			// String inputString = "";
			String urlString = smsConfigDetailMap
					.get(MotorRepairConstants.SMS_SERVER_CONFIG.SMS_URL.toString())
					.replace("#" + MotorRepairConstants.SMS_SERVER_CONFIG.PHONE_NO.toString() + "#", phoneNo)
					.replace("#" + MotorRepairConstants.SMS_SERVER_CONFIG.DESCRIPTION.toString() + "#", smsTemplateName);
			// replace user name & password
			urlString = urlString
					.replace("#" + MotorRepairConstants.SMS_SERVER_CONFIG.SMS_USER_NAME.toString() + "#",
							smsConfigDetailMap.get(MotorRepairConstants.SMS_SERVER_CONFIG.SMS_USER_NAME.toString()))
					.replace("#" + MotorRepairConstants.SMS_SERVER_CONFIG.SMS_USER_PASSWORD.toString() + "#",
							smsConfigDetailMap.get(MotorRepairConstants.SMS_SERVER_CONFIG.SMS_USER_PASSWORD.toString()))
					.replace("#" + MotorRepairConstants.SMS_SERVER_CONFIG.SMS_FEED_ID.toString() + "#",
							smsConfigDetailMap.get(MotorRepairConstants.SMS_SERVER_CONFIG.SMS_FEED_ID.toString()));

			response = restClient.restExchange(urlString, "", HttpMethod.GET, null, MediaType.APPLICATION_JSON);

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return null != response ? true : false;

	}

	/**
	 * Steps: 1. Using SubprocessId, fetch subProcess entity detail which need to be send in mail 2.fetch group email id
	 * for internal user for assignment 3.check actor name if ARC is actor name ,then get email Id based on arcRefId
	 */
	@Override
	public void triggerAssignmentNotification(String functionCode, String templateCode, Long subProcessId,
			String groupName, String arcRefId) {
		LOGGER.info("inside triggerAssignmentNotification ...");
		try {
			List<TemplateInfoDTO> templateInfoDTOList = templateInfoService

			.findTemplateInfoByFunCodeNEmailCode(functionCode, templateCode);

			for (TemplateInfoDTO templateInfoDTO : templateInfoDTOList) {
				if (MotorRepairConstants.TASK_NOTIFY_TYPE.NEW_TASK.getValue() == templateInfoDTO.getNotificationType()) {
					sendNotification(templateInfoDTO, subProcessId, groupName, arcRefId);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void triggerCustomerNotification(String functionCode, String templateCode, Long subProcessId,
			String groupName, String arcRefId) {
		LOGGER.info("inside triggerCustomerNotification for :"+subProcessId+" - "+functionCode+" - "+templateCode);
		try {
			List<TemplateInfoDTO> templateInfoDTOList = templateInfoService

			.findTemplateInfoByFunCodeNEmailCode(functionCode, templateCode);
			for (TemplateInfoDTO templateInfoDTO : templateInfoDTOList) {
				if (MotorRepairConstants.TASK_NOTIFY_TYPE.NOTIFY.getValue() == templateInfoDTO.getNotificationType()) {
					sendNotificationToCustomer(templateInfoDTO, subProcessId, groupName, arcRefId);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean sendNotification(TemplateInfoDTO templateInfoDTO, Long subProcessId, String groupName,
			String arcRefId) {
		boolean response = false;
		LOGGER.info("NOTIFICATION:sendNotification start");
		try {

			SubProcessFieldsDTO subProcessFieldsDTO = subProcessFieldsService
					.getSubProcessFieldsByWlfwSubProcessId(subProcessId);
			if (null == subProcessFieldsDTO) {
				LOGGER.error("subProcess object is null ");
				return false;
			}

			// fetch email ids based on actor name
			List<String> toEmailAddressList = new ArrayList<String>();

			if (templateInfoDTO.getReceipientType().equals(MotorRepairConstants.RECEIPIENT_TYPE.SIEMENS.getValue())) {

				if (groupName != null) {
					toEmailAddressList = fetchActorGroupEmailList(groupName, toEmailAddressList);
				}

				// toEmailAddressList.add("sweety.kothari@atos.net");
			} else if (templateInfoDTO.getReceipientType().equals(MotorRepairConstants.RECEIPIENT_TYPE.ARC.getValue())) {

				toEmailAddressList = fetchArcEmailList(subProcessFieldsDTO.getArcRefId(), toEmailAddressList);

				// toEmailAddressList.add("sweety.kothari@atos.net");
			} else {
				LOGGER.info("NOTIFICATION:Receipent type doesn't match");
				return false;
			}

			// fetch end customer name list
			String custName = null;
			for (CustomerDetailDTO custDetailDTO : subProcessFieldsDTO.getMasterWorkflowFields().getCustomerDetails()) {
				if (custDetailDTO.getCustType().equals(MotorRepairConstants.CUST_TYPE.END_CUSTOMER.getValue())) {
					custName = custDetailDTO.getCustomerName();
					break;
				}
			}
			String gspRefNo = null;
			String motorSnNo = null;
			if (null != subProcessFieldsDTO.getMasterWorkflowFields()) {
				gspRefNo = subProcessFieldsDTO.getMasterWorkflowFields().getGspRefNo();
				motorSnNo = subProcessFieldsDTO.getMotorSnNum();
			}

			Map<String, String> configMap = getNotificationConfigMap();
			// if any of notification flag is set then only go for below process
			int emailNotificationEnabled = null != configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString())) : 0;
			String emailTemplateName = null;
			String subjectLine = null;
			if (templateInfoDTO.getTemplateType().equals(MotorRepairConstants.TEMPLATE_TYPE.EMAIL.getValue())) {
				emailTemplateName = templateInfoDTO.getTemplateName();
				subjectLine = templateInfoDTO.getSubjectLine();
			}

			Calendar cl = Calendar.getInstance();

			Map<String, String> userParams = new HashMap<String, String>();
			// get arc details and add to map
			Long arcId = null;
			if (null != subProcessFieldsDTO.getArcRefId()) {
				arcId = subProcessFieldsDTO.getArcRefId();
			} else if (null != arcRefId) {
				arcId = Long.valueOf(arcRefId);
			}

			if (null != arcId) {
				ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(arcId);
				if (null != arcMasterDTO) {
					userParams.put(MotorRepairConstants.ARC_NAME, arcMasterDTO.getArcName());
					userParams.put(MotorRepairConstants.ARC_ADDRESS, arcMasterDTO.getArcAddress());
					userParams.put(MotorRepairConstants.ARC_CITY, arcMasterDTO.getArcCity());
					userParams.put(MotorRepairConstants.ARC_ZIP, arcMasterDTO.getArcZipCode());
				}
			}

			userParams.put(MotorRepairConstants.TICKET_REF_NO, gspRefNo);
			userParams.put(MotorRepairConstants.MOTOR_SN_NO, motorSnNo);
			userParams.put(MotorRepairConstants.DATE_EMAIL, dateFormat.format(cl.getTime()));
			userParams.put(MotorRepairConstants.USER_NAME, groupName);
			userParams.put(MotorRepairConstants.CUST_NAME, custName);
			userParams.put(MotorRepairConstants.STATUS, templateInfoDTO.getStatusText());
			// TODO set status text instead of template code and motor dispatch and ship to party address
			userParams.put(MotorRepairConstants.HELPLINE_NUMBER, configMap.get(MotorRepairConstants.HELPLINE_NUMBER)
					.toString());
			userParams.put(MotorRepairConstants.HELPLINE_EMAIL, configMap.get(MotorRepairConstants.HELPLINE_EMAIL)
					.toString());
			/*
			 * userParams.put(MotorRepairConstants.HELPLINE_URL, configMap.get(MotorRepairConstants.HELPLINE_URL)
			 * .toString());
			 */
			userParams.put(MotorRepairConstants.LOGO_URL, configMap.get(MotorRepairConstants.HOST_URL).toString()
					+ logoPath);
			String statusTracking = configMap.get(MotorRepairConstants.STATUS_TRACKING).toString();
			if (statusTracking != null) {
				statusTracking = statusTracking.replace(MotorRepairConstants.TASK_ID, gspRefNo);
				userParams.put(MotorRepairConstants.TRACKING_URL, statusTracking);
			}

			if (toEmailAddressList.size() > 0 && emailNotificationEnabled == 1) {
				subjectLine = subjectLine.replace(MotorRepairConstants.GSP_REFERNCE_TEXT, gspRefNo);
				response = triggerEmailNotification(userParams, toEmailAddressList, null, subjectLine,
						emailTemplateName, null);
				LOGGER.info("NOTIFICATION:sendNotification end");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;

	}

	private boolean sendNotificationToCustomer(TemplateInfoDTO templateInfoDTO, Long subProcessId, String actorName,
			String arcRefId) {
		LOGGER.info("NOTIFICATION:sendNotificationToCustomer start");
		try {
			if (MotorRepairConstants.RECEIPIENT_TYPE.CUSTOMER.getValue() != templateInfoDTO.getReceipientType()) {
				return false;
			}

			SubProcessFieldsDTO subProcessFieldsDTO = subProcessFieldsService
					.getSubProcessFieldsByWlfwSubProcessId(subProcessId);
			if (null == subProcessFieldsDTO) {
				LOGGER.error("subProcess object is null ");
				return false;
			}
			String gspRefNo = null;
			String motorSnNo = null;
			if (null != subProcessFieldsDTO.getMasterWorkflowFields()) {
				gspRefNo = subProcessFieldsDTO.getMasterWorkflowFields().getGspRefNo();
				motorSnNo = subProcessFieldsDTO.getMotorSnNum();
			}

			Map<String, String> configMap = getNotificationConfigMap();
			int emailNotificationEnabled = null != configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
					.toString())) : 0;
			int smsNotificationEnabled = null != configMap.get(MotorRepairConstants.SMS_NOTIFICATIONS_ENABLED
					.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.SMS_NOTIFICATIONS_ENABLED
					.toString())) : 0;

			String emailTemplateName = null;
			String subjectLine = null;
			String smsTemplateName = null;
			if (templateInfoDTO.getTemplateType().equals(MotorRepairConstants.TEMPLATE_TYPE.EMAIL.getValue())) {
				emailTemplateName = templateInfoDTO.getTemplateName();
				subjectLine = templateInfoDTO.getSubjectLine();
			} else {
				smsTemplateName = templateInfoDTO.getSubjectLine();
			}

			// get ccaddress from additionContanctDetail
			List<String> ccAddress = new ArrayList<String>();
			for (AdditionalContactDetailDTO additionalContactDetailDTO : subProcessFieldsDTO.getMasterWorkflowFields()
					.getAdditionalContactDetails()) {
				if (null != additionalContactDetailDTO.getEmailAddress())
					ccAddress.add(additionalContactDetailDTO.getEmailAddress());
			}

			ccAddress = fetchActorGroupEmailList(MotorRepairConstants.CCC_USER, ccAddress);

			// ccAddress.add("sweety.kothari@atos.net");

			Calendar cl = Calendar.getInstance();
			Map<String, String> userParams = new HashMap<String, String>();
			// get arc details and add to map
			Long arcId = null;
			if (null != subProcessFieldsDTO.getArcRefId()) {
				arcId = subProcessFieldsDTO.getArcRefId();
			} else if (null != arcRefId) {
				arcId = Long.valueOf(arcRefId);
			}

			if (null != arcId) {
				ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(arcId);
				if (null != arcMasterDTO) {
					userParams.put(MotorRepairConstants.ARC_NAME, arcMasterDTO.getArcName());
					userParams.put(MotorRepairConstants.ARC_ADDRESS, arcMasterDTO.getArcAddress());
					userParams.put(MotorRepairConstants.ARC_CITY, arcMasterDTO.getArcCity());
					userParams.put(MotorRepairConstants.ARC_ZIP, arcMasterDTO.getArcZipCode());
				}
			}
			for (CustomerDetailDTO custDetailDTO : subProcessFieldsDTO.getMasterWorkflowFields().getCustomerDetails()) {

				List<String> toEmailAddressList = new ArrayList<String>();

				/*
				 * BEGIN LOOP For each customer check for email notification enabled flag ,if it is 1 then only send
				 * mail else don't send mail
				 */
				LOGGER.info("Template: "+emailTemplateName+" Customer Notification:"+custDetailDTO.getNotificationType());
				if ((null != emailTemplateName)
						&& (emailNotificationEnabled == 1)
						&& ((custDetailDTO.getNotificationType() == MotorRepairConstants.NOTIFICATION_TYPE.EMAIL
								.getValue()) || (custDetailDTO.getNotificationType() == MotorRepairConstants.NOTIFICATION_TYPE.EMAILNSMS
								.getValue()))) {

					// replace GSP ref no in subJectLine as well
					subjectLine = subjectLine.replace(MotorRepairConstants.GSP_REFERNCE_TEXT, gspRefNo);
					// replace individual values specific to each customer
					userParams.put(MotorRepairConstants.CUST_NAME, custDetailDTO.getCustomerName());
					userParams.put(MotorRepairConstants.USER_NAME, custDetailDTO.getCustomerName());
					userParams.put(MotorRepairConstants.TICKET_REF_NO, gspRefNo);
					userParams.put(MotorRepairConstants.MOTOR_SN_NO, motorSnNo);
					userParams.put(MotorRepairConstants.DATE_EMAIL, dateFormat.format(cl.getTime()));
					userParams.put(MotorRepairConstants.STATUS, templateInfoDTO.getStatusText());
					userParams.put(MotorRepairConstants.HELPLINE_NUMBER,
							configMap.get(MotorRepairConstants.HELPLINE_NUMBER).toString());
					userParams.put(MotorRepairConstants.HELPLINE_EMAIL,
							configMap.get(MotorRepairConstants.HELPLINE_EMAIL).toString());
					/*
					 * userParams.put(MotorRepairConstants.HELPLINE_URL,
					 * configMap.get(MotorRepairConstants.HELPLINE_URL) .toString());
					 */
					userParams.put(MotorRepairConstants.LOGO_URL, configMap.get(MotorRepairConstants.HOST_URL)
							.toString() + logoPath);
					String statusTracking = configMap.get(MotorRepairConstants.STATUS_TRACKING).toString();
					if (statusTracking != null) {
						statusTracking = statusTracking.replace(MotorRepairConstants.TASK_ID, gspRefNo);
						userParams.put(MotorRepairConstants.TRACKING_URL, statusTracking);
					}

					if (custDetailDTO.getIsShipToParty() != null
							&& custDetailDTO.getIsShipToParty().equals(MotorRepairConstants.TRUE)) {
						userParams.put(MotorRepairConstants.SHIP_TO_PARTY_NAME, custDetailDTO.getCustomerName());
						userParams.put(MotorRepairConstants.SHIP_TO_PARTY_ADDRESS, custDetailDTO.getShipToAddress());
					}
					toEmailAddressList.add(custDetailDTO.getEmailId());

					// Send notification for email
					triggerEmailNotification(userParams, toEmailAddressList, ccAddress, subjectLine, emailTemplateName,
							null);

				}
				if ((null != smsTemplateName)
						&& (smsNotificationEnabled == 1)
						&& (custDetailDTO.getNotificationType().equals(
								MotorRepairConstants.NOTIFICATION_TYPE.SMS.getValue()) || (custDetailDTO
								.getNotificationType().equals(MotorRepairConstants.NOTIFICATION_TYPE.EMAILNSMS
								.getValue())))) {

					smsTemplateName = smsTemplateName.replace(MotorRepairConstants.GSP_REFERNCE_TEXT, gspRefNo);

					triggerSMSNotification(custDetailDTO.getCountyCode() + custDetailDTO.getMobileContactNum(),
							smsTemplateName);

					LOGGER.info("NOTIFICATION:sendNotificationToCustomer end");

				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	@Override
	public void triggerSLANotification(String functionCode, Integer notifType, String slaType, Long subProcessId,
			String RINumber, List<String> toEmailAddress, List<String> ccEmailAddress, boolean isEmailEnabled,
			boolean isSMSEnabled, String arcRefId) {
		LOGGER.info("inside triggerSLANotification ...");
		try {

			SubProcessFieldsDTO subProcessFieldsDTO = subProcessFieldsService
					.getSubProcessFieldsByWlfwSubProcessId(subProcessId);
			if (null != subProcessFieldsDTO) {

				String gspRefNo = null;
				String motorSnNo = null;
				if (null != subProcessFieldsDTO.getMasterWorkflowFields()) {
					gspRefNo = subProcessFieldsDTO.getMasterWorkflowFields().getGspRefNo();
					motorSnNo = subProcessFieldsDTO.getMotorSnNum();
				}

				Map<String, String> configMap = getNotificationConfigMap();
				// if any of notification flag is set then only go for below
				// process
				int emailNotificationEnabled = null != configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
						.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.MAIL_NOTIFICATIONS_ENABLED
						.toString())) : 0;
				int smsNotificationEnabled = null != configMap.get(MotorRepairConstants.SMS_NOTIFICATIONS_ENABLED
						.toString()) ? Integer.parseInt(configMap.get(MotorRepairConstants.SMS_NOTIFICATIONS_ENABLED
						.toString())) : 0;

				List<TemplateInfoDTO> templateInfoDTOList = templateInfoService
						.findTemplateInfoByFunCodeNNotificationType(functionCode, notifType);
				for (TemplateInfoDTO templateInfoDTO : templateInfoDTOList) {

					String emailTemplateName = null;
					String subjectLine = null;
					emailTemplateName = templateInfoDTO.getTemplateName();
					subjectLine = templateInfoDTO.getSubjectLine();

					if (subjectLine != null) {
						subjectLine = subjectLine.replace(MotorRepairConstants.GSP_REFERNCE_TEXT, gspRefNo);
					}

					Calendar cl = Calendar.getInstance();

					Map<String, String> userParams = new HashMap<String, String>();
					// get arc details and add to map
					Long arcId = null;
					if (null != subProcessFieldsDTO.getArcRefId()) {
						arcId = subProcessFieldsDTO.getArcRefId();
					} else if (null != arcRefId) {
						arcId = Long.valueOf(arcRefId);
					}
					if (null != arcId) {
						ARCMasterDTO arcMasterDTO = arcMasterService.getARCMasterByArcId(arcId);
						if (null != arcMasterDTO) {
							userParams.put(MotorRepairConstants.ARC_NAME, arcMasterDTO.getArcName());
							userParams.put(MotorRepairConstants.ARC_ADDRESS, arcMasterDTO.getArcAddress());
							userParams.put(MotorRepairConstants.ARC_CITY, arcMasterDTO.getArcCity());
							userParams.put(MotorRepairConstants.ARC_ZIP, arcMasterDTO.getArcZipCode());
						}
					}
					userParams.put(MotorRepairConstants.TICKET_REF_NO, gspRefNo);
					userParams.put(MotorRepairConstants.MOTOR_SN_NO, motorSnNo);
					userParams.put(MotorRepairConstants.DATE_EMAIL, dateFormat.format(cl.getTime()));
					// userParams.put(MotorRepairConstants.USER_NAME,
					// actorName);
					// userParams.put(MotorRepairConstants.CUST_NAME, custName);
					userParams.put(MotorRepairConstants.STATUS, templateInfoDTO.getStatusText());
					userParams.put(MotorRepairConstants.HELPLINE_NUMBER,
							configMap.get(MotorRepairConstants.HELPLINE_NUMBER).toString());
					userParams.put(MotorRepairConstants.HELPLINE_EMAIL,
							configMap.get(MotorRepairConstants.HELPLINE_EMAIL).toString());
					/*
					 * userParams.put(MotorRepairConstants.HELPLINE_URL,
					 * configMap.get(MotorRepairConstants.HELPLINE_URL) .toString());
					 */
					userParams.put(MotorRepairConstants.LOGO_URL, configMap.get(MotorRepairConstants.HOST_URL)
							.toString() + logoPath);
					String statusTracking = configMap.get(MotorRepairConstants.STATUS_TRACKING).toString();
					if (statusTracking != null) {
						statusTracking = statusTracking.replace(MotorRepairConstants.TASK_ID, gspRefNo);
						userParams.put(MotorRepairConstants.TRACKING_URL, statusTracking);
					}

					if (toEmailAddress.size() > 0 && emailNotificationEnabled == 1 && isEmailEnabled) {

						triggerEmailNotification(userParams, toEmailAddress, ccEmailAddress, subjectLine,
								emailTemplateName, null);
					}

					if (toEmailAddress.size() > 0 && smsNotificationEnabled == 1 && isSMSEnabled) {
						// set phone no for sms
						triggerSMSNotification(toEmailAddress.get(0), subjectLine);
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
