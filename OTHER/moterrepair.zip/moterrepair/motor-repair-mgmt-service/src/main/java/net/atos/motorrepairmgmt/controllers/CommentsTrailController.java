package net.atos.motorrepairmgmt.controllers;

import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.MasterWorkflowFieldsDTO;
import net.atos.taskmgmt.common.dto.BenchmarksDTO;
import net.atos.taskmgmt.common.dto.CommentsDTO;
import net.atos.taskmgmt.service.ActorFunctionMasterService;
import net.atos.taskmgmt.service.CommentsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author Sweety Kothari
 * 
 */

@Controller
@EnableSwagger
@RequestMapping(value = "commentsService")
public class CommentsTrailController {
	@Autowired
	private CommentsService commentsService;
	
	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;


	@RequestMapping(value = "/getCommentsByTenantIdNSolnCatNSubProcessId/{subProcessId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody List<CommentsDTO> getCommentsBySubProcessIdNTenantIdNSolnCatID(
			@PathVariable("subProcessId") final Long subProcessId,
			@PathVariable("tenantId") final String tenantId,
			@PathVariable( "solutionCategoryId") final String solutionCategoryId
			) {
		List<CommentsDTO> commentsDTOList= commentsService.getCommentsByTenantIdNSolnCatNSubProcessId(subProcessId, tenantId, solutionCategoryId,null);
	    return setFunctionNameInComments(commentsDTOList, tenantId, solutionCategoryId);
	 	
	
	}
	
	@RequestMapping(value = "/getCommentsByTenantIdNSolnCatNSubProcessIdNArcID/{subProcessId}/{tenantId}/{solutionCategoryId}/{arcRefId}", produces = "application/json", method = RequestMethod.GET)
	public @ResponseBody List<CommentsDTO> getCommentsBySubProcessIdNTenantIdNSolnCatIDNARCRefId(
			@PathVariable( "subProcessId") final Long subProcessId,
			@PathVariable( "tenantId") final String tenantId,
			@PathVariable( "solutionCategoryId")final String solutionCategoryId,
			@PathVariable( "arcRefId")final String arcRefId) {
		List<CommentsDTO> commentsDTOList= commentsService.getCommentsByTenantIdNSolnCatNSubProcessId(subProcessId, tenantId, solutionCategoryId,arcRefId);
	    return setFunctionNameInComments(commentsDTOList, tenantId, solutionCategoryId);
	}
	
	    private List<CommentsDTO> setFunctionNameInComments(List<CommentsDTO> commentsDTOList,String tenantId,String solutionCategoryId){
		  Map<String,String> functionCodeMap=	actorFunctionMasterService.getActorFunctionMap(tenantId,solutionCategoryId);
		 	for(CommentsDTO commentsDTO:commentsDTOList)
		 	{
		 		commentsDTO.setFunctionName(functionCodeMap.get(commentsDTO.getTaskCode()));
		    }
		 	return commentsDTOList;
	}

	

}
