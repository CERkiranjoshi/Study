package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;

public interface CustomerDetailService {

	public Long createUpdateCustomerDetail(CustomerDetailDTO customerDetailDTO);

	public List<CustomerDetailDTO> getAllCustomerDetail();

	public CustomerDetailDTO getCustomerDetailByCustomerId(Long customerId);

	public Boolean deleteCustomerDetailByCustomerId(Long customerId);

}
