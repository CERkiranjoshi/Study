package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;
import net.atos.motorrepairmgmt.entity.ParallelProcess;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.ParallelProcessRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.ParallelProcessService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603975
 * 
 */

@Service
public class ParallelProcessServiceImpl implements ParallelProcessService {
	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private ParallelProcessRepository parallelProcessRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/**
	 * Logger
	 */

	private static final Logger LOGGER = Logger.getLogger(ParallelProcessServiceImpl.class);

	/**
	 * This method creates/updates a ParallelProcess record. The method performs an update operation when
	 * ParallelProcessId is passed or else create new record if ParallelProcessId is not found
	 * 
	 * @param parallelProcessDTO
	 *            The ParallelProcess Details
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Long createUpdateParallelProcess(ParallelProcessDTO parallelProcessDTO) {
		LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Start");
		ParallelProcess parallelProcessDetails = null;
		Long id = -1l;
		try {
			if (null != parallelProcessDTO) {
				if (null != parallelProcessDTO.getParallelProcessId()) {
					parallelProcessDetails = parallelProcessRepository.findOne(parallelProcessDTO
							.getParallelProcessThreadId());
				} else {
					parallelProcessDTO.setCreatedOn(new Date());
				}
				parallelProcessDetails = dozerBeanMapper.map(parallelProcessDTO, ParallelProcess.class);
				ParallelProcess savedObj = parallelProcessRepository.save(parallelProcessDetails);
				LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Record Saved/Updated");
				if (null != savedObj) {
					id = savedObj.getParallelProcessThreadId();
				}

			} else {
				LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;

	}

	@Override
	@Transactional
	public Long addParallelProcessToSubProcess(ParallelProcessDTO parallelProcessDTO, Long subProcessId) {
		LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Start");
		ParallelProcess parallelProcessDetails = null;
		Long id = -1l;
		// get subprocess object with given id
		SubProcessFields subProcessFields = subProcessFieldsRepository.findOne(subProcessId);
		if (null == subProcessFields) {
			return id;
		}

		try {
			if (null != parallelProcessDTO) {
				parallelProcessDTO.setCreatedOn(new Date());
				parallelProcessDetails = dozerBeanMapper.map(parallelProcessDTO, ParallelProcess.class);
				ParallelProcess savedObj = parallelProcessRepository.save(parallelProcessDetails);
				LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Record Saved/Updated");
				if (null != savedObj) {
					id = savedObj.getParallelProcessThreadId();
				}
				// link to subprocess object
				List<ParallelProcess> parallelProcessList = subProcessFields.getParallelProcess();
				if (null == parallelProcessList) {
					// create new array list
					parallelProcessList = new ArrayList<ParallelProcess>();
				}
				parallelProcessList.add(savedObj);
				subProcessFields = subProcessFieldsRepository.save(subProcessFields);

			} else {
				LOGGER.info("ParallelProcessServiceImpl : createUpdateParallelProcess : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;

	}

	/**
	 * The method retrieves all getAllParallelProcess
	 * 
	 * 
	 * @return ParallelProcessDTO
	 * 
	 */

	@Override
	@Transactional
	public List<ParallelProcessDTO> getAllParallelProcess() {
		LOGGER.info("ParallelProcessServiceImpl : getAllParallelProcess : Start");

		List<ParallelProcessDTO> parallelProcessDTOs = null;

		ParallelProcessDTO parallelProcessDTO = null;

		List<ParallelProcess> parallelProcessDetails = parallelProcessRepository.findAll();

		if (null != parallelProcessDetails) {
			parallelProcessDTOs = new ArrayList<ParallelProcessDTO>();

			for (ParallelProcess parallelProcessRecord : parallelProcessDetails) {
				parallelProcessDTO = new ParallelProcessDTO();

				parallelProcessDTO = dozerBeanMapper.map(parallelProcessRecord, ParallelProcessDTO.class);

				parallelProcessDTOs.add(parallelProcessDTO);
			}
		}
		LOGGER.info("ParallelProcessServiceImpl : getAllParallelProcess : End");
		return parallelProcessDTOs;

	}

	/**
	 * The deletes a ParallelProcess on the basis its parallelProcessId .
	 * 
	 * @param parallelProcessId
	 *            The parallelProcessId
	 * 
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteParallelProcessByParallelProcessId(Long initParallelProcessId) {
		LOGGER.info("ParallelProcessServiceImpl : deleteParallelProcessByParallelProcessId : Start");
		boolean returnVal = false;
		try {
			if (null != initParallelProcessId) {
				parallelProcessRepository.delete(initParallelProcessId);

				returnVal = true;
			} else {
				LOGGER.info("ParallelProcessServiceImpl : deleteParallelProcessByParallelProcessId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;

	}

	/**
	 * The method retrieves a ParallelProcess on the basis of parallelProcessState.
	 * 
	 * @param parallelProcessState
	 *            The parallelProcessState
	 * @return ParallelProcessDTO
	 * 
	 */

	@Override
	@Transactional
	public List<ParallelProcessDTO> getParallelProcessListByParallelProcessState(String parallelProcessState) {
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessListByParallelProcessState : Start");
		List<ParallelProcessDTO> parallelProcessDTOs = null;
		List<ParallelProcess> parallelProcessDetails = null;
		if (null != parallelProcessState) {
			parallelProcessDetails = parallelProcessRepository
					.findParallelProcessByParallelProcessState(parallelProcessState);
		}
		if (null != parallelProcessDetails && parallelProcessDetails.size() > 0) {
			parallelProcessDTOs = new ArrayList<ParallelProcessDTO>();
			ParallelProcessDTO parallelProcessDTO = null;
			for (ParallelProcess parallelProcessRecord : parallelProcessDetails) {
				parallelProcessDTO = new ParallelProcessDTO();
				parallelProcessDTO = dozerBeanMapper.map(parallelProcessRecord, ParallelProcessDTO.class);
				parallelProcessDTOs.add(parallelProcessDTO);
			}

		}
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessListByParallelProcessState : End");
		return parallelProcessDTOs;
	}

	/**
	 * The method retrieves a ParallelProcess on the basis of parallelProcessId.
	 * 
	 * @param parallelProcessId
	 *            The parallelProcessId
	 * @return ParallelProcessDTO
	 * 
	 */
	@Override
	@Transactional
	public List<ParallelProcessDTO> getParallelProcessByParallelProcessId(String parallelProcessId) {
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByParallelProcessId : Start");
		List<ParallelProcessDTO> parallelProcessDTOs = null;
		if (null != parallelProcessId) {
			List<ParallelProcess> parallelProcessDetails = parallelProcessRepository
					.findParallelProcessByParallelProcessId(parallelProcessId);
			if ((null != parallelProcessDetails) && (0 < parallelProcessDetails.size())) {

				parallelProcessDTOs = new ArrayList<ParallelProcessDTO>();
				ParallelProcessDTO parallelProcessDTO = null;
				for (ParallelProcess parallelProcessRecord : parallelProcessDetails) {
					parallelProcessDTO = new ParallelProcessDTO();
					parallelProcessDTO = dozerBeanMapper.map(parallelProcessRecord, ParallelProcessDTO.class);
					parallelProcessDTOs.add(parallelProcessDTO);
				}
			}
		}
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByParallelProcessId : End");
		return parallelProcessDTOs;
	}

	/**
	 * The method retrieves a List of ParallelProcess on the basis of parallelProcessType.
	 * 
	 * @param parallelProcessId
	 *            The parallelProcessId
	 * @return ParallelProcessDTO
	 * 
	 */
	@Override
	@Transactional
	public List<ParallelProcessDTO> getParallelProcessByType(String parallelProcessType) {
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByType : Start " + parallelProcessType);
		List<ParallelProcessDTO> parallelProcessDTOs = null;
		if (null != parallelProcessType) {
			List<ParallelProcess> parallelProcessDetails = parallelProcessRepository
					.findParallelProcessByType(parallelProcessType);
			if ((null != parallelProcessDetails) && (0 < parallelProcessDetails.size())) {

				parallelProcessDTOs = new ArrayList<ParallelProcessDTO>();
				ParallelProcessDTO parallelProcessDTO = null;
				for (ParallelProcess parallelProcessRecord : parallelProcessDetails) {
					parallelProcessDTO = new ParallelProcessDTO();
					parallelProcessDTO = dozerBeanMapper.map(parallelProcessRecord, ParallelProcessDTO.class);
					parallelProcessDTOs.add(parallelProcessDTO);
				}
			}
		}
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByType : End");
		return parallelProcessDTOs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.ParallelProcessService#getParallelProcessByInitParallelProcessId(java.lang.
	 * String)
	 */
	@Override
	@Transactional
	public ParallelProcessDTO getParallelProcessByParallelProcessThreadId(Long parallelProcessThreadId) {
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByParallelProcessId : Start");
		if (null != parallelProcessThreadId) {
			ParallelProcess parallelProcessDetails = parallelProcessRepository
					.findParallelProcessByParallelProcessThreadId(parallelProcessThreadId);
			if (null != parallelProcessDetails) {
				ParallelProcessDTO parallelProcessDTO = new ParallelProcessDTO();
				parallelProcessDTO = dozerBeanMapper.map(parallelProcessDetails, ParallelProcessDTO.class);
				return parallelProcessDTO;
			}
		}
		return null;
	}
	
	/**
	 * The method retrieves a ParallelProcess on the basis of parallelProcessId,tenantId and SolutionCategoryId.
	 * 
	 * @param parallelProcessId
	 *            The parallelProcessId
	 * @param tenantId
	 *            The tenantId
	 * @param solutionCategoryId
	 *            The solutionCategoryId
	 * @return ParallelProcessDTO
	 * 
	 */
	@Override
	@Transactional
	public ParallelProcessDTO getParallelProcessByParallelProcessIdandTenantIdandSolCatId(
			Long parallelProcessId, String tenantId, String solutionCategoryId) {
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByParallelProcessIdandTenantIdandSolCatId : Start");
		 
		ParallelProcessDTO parallelProcessDTO=null;
		ParallelProcess parallelProcessDetails=null;
		if (null != parallelProcessId && null != tenantId && null != solutionCategoryId) {
			parallelProcessDetails = parallelProcessRepository.findParallelProcessByParallelProcessIdAndTenantIdAndSolCatId(parallelProcessId,tenantId,
					solutionCategoryId);
		}
		if (null != parallelProcessDetails ) {
			
			parallelProcessDTO=new ParallelProcessDTO();
			parallelProcessDTO=dozerBeanMapper.map(parallelProcessDetails, ParallelProcessDTO.class);
		}
		LOGGER.info("ParallelProcessServiceImpl : getParallelProcessByParallelProcessIdandTenantIdandSolCatId : End");
		return parallelProcessDTO;
	}

}
