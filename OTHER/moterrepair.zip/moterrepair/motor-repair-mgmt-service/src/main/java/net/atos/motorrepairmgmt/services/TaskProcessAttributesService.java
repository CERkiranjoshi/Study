/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import net.atos.motorrepairmgmt.dto.TaskProcessAttributesDTO;

/**
 * @author a593775
 *
 */
public interface TaskProcessAttributesService {
	public Long createUpdateTaskParameterDetails(TaskProcessAttributesDTO taskParameterDetailDTO);
	public TaskProcessAttributesDTO getTaskParameterDetailsByActivitiTaskId(String tasKId);

}
