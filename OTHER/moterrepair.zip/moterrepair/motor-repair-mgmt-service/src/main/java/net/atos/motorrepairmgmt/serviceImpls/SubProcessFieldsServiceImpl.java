package net.atos.motorrepairmgmt.serviceImpls;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.DispatchDetailDTO;
import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.dto.MasterWorkflowFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorDetailsDTO;
import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;
import net.atos.motorrepairmgmt.dto.RMTAuditDTO;
import net.atos.motorrepairmgmt.dto.RMTCommentDTO;
import net.atos.motorrepairmgmt.dto.RMTTaskLogDTO;
import net.atos.motorrepairmgmt.dto.SearchByParameterDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.dto.SubProcessGroupDetailDTO;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;
import net.atos.motorrepairmgmt.entity.AdditionalContactDetail;
import net.atos.motorrepairmgmt.entity.CustomerDetail;
import net.atos.motorrepairmgmt.entity.DispatchDetail;
import net.atos.motorrepairmgmt.entity.FSEVisitDetail;
import net.atos.motorrepairmgmt.entity.MasterWorkflowFields;
import net.atos.motorrepairmgmt.entity.MotorAttachmentDetail;
import net.atos.motorrepairmgmt.entity.MotorOrderDetail;
import net.atos.motorrepairmgmt.entity.MotorSparesDetail;
import net.atos.motorrepairmgmt.entity.ParallelProcess;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.entity.SubProcessGroupDetail;
import net.atos.motorrepairmgmt.entity.WorkflowState;
import net.atos.motorrepairmgmt.repository.AuditLogRepository;
import net.atos.motorrepairmgmt.repository.CustomerDetailRepository;
import net.atos.motorrepairmgmt.repository.FSEVisitDetailRepository;
import net.atos.motorrepairmgmt.repository.MasterWorkflowFieldsRepository;
import net.atos.motorrepairmgmt.repository.MotorAttachmentDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorOrderDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorSparesDetailRepository;
import net.atos.motorrepairmgmt.repository.ParallelProcessRepository;
import net.atos.motorrepairmgmt.repository.SearchFieldRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.repository.SubProcessGroupDetailRepository;
import net.atos.motorrepairmgmt.repository.WorkflowStateRepository;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.taskmgmt.common.dto.BenchmarksDTO;
import net.atos.taskmgmt.common.dto.CommentsDTO;
import net.atos.taskmgmt.service.BenchmarksService;
import net.atos.taskmgmt.service.CommentsService;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610039
 * 
 */
@Service
public class SubProcessFieldsServiceImpl implements SubProcessFieldsService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The ParallelProcess Repository */
	@Autowired
	private ParallelProcessRepository parallelProcessRepository;

	/** The MotorAttachmentDetail Repository */
	@Autowired
	private MotorAttachmentDetailRepository motorAttachmentDetailRepository;

	/** The MotorSparesDetail Repository */
	@Autowired
	private MotorSparesDetailRepository motorSparesDetailRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/** The MotorOrderDetail Repository */
	@Autowired
	private MotorOrderDetailRepository motorOrderDetailRepository;

	/** The MasterWorkflowFields Repository */
	@Autowired
	private MasterWorkflowFieldsRepository masterWorkflowFieldsRepository;

	/** The FSEVisitDetail Repository */
	@Autowired
	private FSEVisitDetailRepository fSEVisitDetailRepository;

	/** The WorkflowState Repository */
	@Autowired
	private WorkflowStateRepository workflowStateRepository;

	/** The CustomerDetail Repository */
	@Autowired
	private CustomerDetailRepository customerDetailRepository;

	@Autowired
	private SearchFieldRepository searchFieldRepository;

	@Autowired
	private AuditLogRepository auditLogRepository;

	@Autowired
	private CommentsService commentsService;

	@Autowired
	private BenchmarksService benchmarksService;

	@Autowired
	private SubProcessGroupDetailRepository groupDetailRepository;
	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger
			.getLogger(SubProcessFieldsServiceImpl.class);

	/**
	 * The method creates/updates a SubProcessFields record. The method performs
	 * an update operation when WlfwSubProcessId is passed and an existing
	 * record with matching wlfwSubProcessId is fetched for updation
	 * 
	 * @param subProcessFieldsDTO
	 *            The SubProcess Fields
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateSubProcessFields(
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {

		LOGGER.info("SubProcessFieldsServiceImpl : createUpdateSubProcessFields : Start");
		Long id = -1l;
		boolean value = false;
		// check if subProcessFieldsDTO pass is null
		if (null == subProcessFieldsDTO) {
			throw new MotorRepairException(MotorRepairException.INPUT_ERR,
					"SubprocessFieldsDTO is null",
					"Create New Subprocess Workflow");
		}
		// check if MasterWorkflowFields is null
		// check for ARC job ref no in case of without GSP ref no
		if ((subProcessFieldsDTO.getArcJobRefNo() == null)
				&& (subProcessFieldsDTO.getWlfwSubProcessId() == null)
				&& ((null == subProcessFieldsDTO.getMasterWorkflowFields()) || ((null == subProcessFieldsDTO
						.getMasterWorkflowFields().getGspRefNo()) && (null == subProcessFieldsDTO
						.getMasterWorkflowFields().getMasterWorkflowFieldId())))) {
			// throw exception if MasterWorkflowFields is null
			throw new MotorRepairException(MotorRepairException.INPUT_ERR,
					"MasterWorkflow Info is null",
					"Create New Subprocess Workflow");
		}

		SubProcessFields subProcessFields = null;
		MasterWorkflowFields masterWorkflowFields = null;
		// check if WlfwSubProcessId of subProcessFields is null
		if (null == subProcessFieldsDTO.getWlfwSubProcessId()) {
			// CREATE HERE
			LOGGER.info("Creating new SubProcess: begin");

			// Check state of Motor Sr No is in execution
			if (null != subProcessFieldsDTO.getMotorSnNum()
					&& null != subProcessFieldsDTO.getWlfwSubProcessId()) {
				value = checkStateForMotorSrNo(
						subProcessFieldsDTO.getMotorSnNum(),
						subProcessFieldsDTO.getWlfwSubProcessId().longValue(),
						MotorRepairConstants.TENANT_ID,
						MotorRepairConstants.PROGRAM_ID);
			}

			if (value == true) {
				LOGGER.info("Motor serial number already in IN-EXEC state");
				throw new MotorRepairException(
						MotorRepairException.PROCESS_ERR,
						"Motor serial number already in IN-EXEC state",
						"Create New Motor Serial Number");
			}

			// MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = null;

			if (null != subProcessFieldsDTO.getMasterWorkflowFields()
					.getMasterWorkflowFieldId()) {

				masterWorkflowFields = masterWorkflowFieldsRepository
						.findOne(subProcessFieldsDTO.getMasterWorkflowFields()
								.getMasterWorkflowFieldId());

			} else if (null != subProcessFieldsDTO.getMasterWorkflowFields()
					.getGspRefNo()) {

				// check whether record exist with GSP ref
				masterWorkflowFields = masterWorkflowFieldsRepository
						.findMasterWorkflowFieldsByGspRefNo(subProcessFieldsDTO
								.getMasterWorkflowFields().getGspRefNo());
			}

			subProcessFieldsDTO.setTenantId(MotorRepairConstants.TENANT_ID);
			subProcessFieldsDTO
					.setSolutionCategoryId(MotorRepairConstants.PROGRAM_ID);

			String masterBatchProcessId = uniqueIdGenerator.generateUniqueId();
			// Master workflow object is now available
			if (null == masterWorkflowFields) {
				MasterWorkflowFieldsDTO masterWorkflowFieldsDTO = subProcessFieldsDTO
						.getMasterWorkflowFields();
				MasterWorkflowFields masterWorkflowFieldsEntity = new MasterWorkflowFields();
				subProcessFields = new SubProcessFields();
				// Set Master Workflow properties
				masterWorkflowFieldsDTO.setCreatedOn(new Date());
				masterWorkflowFieldsDTO.setQuantity(1);

				masterWorkflowFieldsDTO.setBatchProcessId(masterBatchProcessId);

				masterWorkflowFieldsDTO
						.setTenantId(MotorRepairConstants.TENANT_ID);
				masterWorkflowFieldsDTO
						.setSolutionCategoryId(MotorRepairConstants.PROGRAM_ID);

				WorkflowState workflowState = workflowStateRepository
						.findWorkflowStateByStateName(MotorRepairConstants.IN_EXEC);
				WorkflowStateDTO workflowStateDTO = new WorkflowStateDTO();
				BeanUtils.copyProperties(workflowState, workflowStateDTO);
				masterWorkflowFieldsDTO.setWorkflowState(null);
				dozerBeanMapper.map(masterWorkflowFieldsDTO,
						masterWorkflowFieldsEntity);
				masterWorkflowFieldsDTO.setAdditionalContactDetails(null);
				masterWorkflowFieldsDTO.setCustomerDetails(null);
				BeanUtils.copyProperties(masterWorkflowFieldsDTO,
						masterWorkflowFieldsEntity, NullPropertyMapper
								.getNullPropertyNames(masterWorkflowFieldsDTO));
				masterWorkflowFieldsEntity
						.setModifiedByRefId(subProcessFieldsDTO
								.getModifiedByRefId());
				masterWorkflowFieldsEntity.setModifiedOn(new Date());
				// set audit field
				masterWorkflowFieldsEntity.setFunctionCode(subProcessFieldsDTO
						.getFunctionCode());
				masterWorkflowFieldsEntity.setWorkflowState(workflowState);
				subProcessFields
						.setMasterWorkflowFields(masterWorkflowFieldsEntity);
			} else {
				// qty shall not exceed 10
				if (masterWorkflowFields.getQuantity() >= MotorRepairConstants.MAX_QTY) {
					// throw exception
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"Can not add more motors to it ,as its exceeding the limit 10",
							"Create New Subprocess Workflow");
				}
				masterWorkflowFields.setQuantity(masterWorkflowFields
						.getQuantity() + 1);
				masterWorkflowFields.setModifiedByRefId(subProcessFieldsDTO
						.getModifiedByRefId());
				masterWorkflowFields.setModifiedOn(new Date());
				// set audit field
				masterWorkflowFields.setFunctionCode(subProcessFieldsDTO
						.getFunctionCode());
				subProcessFields = new SubProcessFields();
				if (null != subProcessFieldsDTO.getMasterWorkflowFields()
						&& null != subProcessFieldsDTO
								.getMasterWorkflowFields().getCustomerDetails()) {
					masterWorkflowFields = setCustomerDetails(
							masterWorkflowFields,
							subProcessFieldsDTO.getMasterWorkflowFields());
					masterWorkflowFields = setAdditionalContactDetails(
							masterWorkflowFields,
							subProcessFieldsDTO.getMasterWorkflowFields());
				}
				subProcessFields.setMasterWorkflowFields(masterWorkflowFields);
				subProcessFieldsDTO.setMasterWorkflowFields(null);
			}
			if (null == subProcessFieldsDTO.getBatchProcId()) {
				subProcessFields.setBatchProcId(uniqueIdGenerator
						.generateUniqueId());
			}
			// Set SubProcess Workflow fields
			subProcessFieldsDTO.setCreatedOn(new Date());
			// Workflow is set to be IN_EXEC state
			subProcessFieldsDTO
					.setSubProcState(MotorRepairConstants.SUBPROC_STATE.SUBPROC_STATE_INITIAL
							.getValue());
			subProcessFieldsDTO
					.setWorkflowClosureType(MotorRepairConstants.WORKFLOW_CLOSURE_TYPE.IN_EXEC
							.getValue());
			subProcessFieldsDTO.setMasterWorkflowFields(null);

		}// end if WlfwSubProcessId of subProcessFields is null
		else {
			// UPDATE HERE

			LOGGER.info("Updating existing subProcess: begin with ID :"
					+ subProcessFieldsDTO.getWlfwSubProcessId());
			// Check state of Motor Sr No is in execution
			if (null != subProcessFieldsDTO.getMotorSnNum()
					&& null != subProcessFieldsDTO.getWlfwSubProcessId()) {
				value = checkStateForMotorSrNo(
						subProcessFieldsDTO.getMotorSnNum(),
						subProcessFieldsDTO.getWlfwSubProcessId().longValue(),
						MotorRepairConstants.TENANT_ID,
						MotorRepairConstants.PROGRAM_ID);
			}

			if (value == true) {
				LOGGER.info("Motor serial number already in IN-EXEC state");
				throw new MotorRepairException(
						MotorRepairException.PROCESS_ERR,
						"Motor serial number already in IN-EXEC state",
						"Create New Motor Serial Number");
			}

			subProcessFields = subProcessFieldsRepository
					.findOne(subProcessFieldsDTO.getWlfwSubProcessId());
			if (null != subProcessFieldsDTO.getMasterWorkflowFields()
					&& null != subProcessFieldsDTO.getMasterWorkflowFields()
							.getCustomerDetails()) {
				masterWorkflowFields = subProcessFields
						.getMasterWorkflowFields();
				masterWorkflowFields.setModifiedByRefId(subProcessFieldsDTO
						.getModifiedByRefId());
				masterWorkflowFields.setModifiedOn(new Date());
				// set audit field
				masterWorkflowFields.setFunctionCode(subProcessFieldsDTO
						.getFunctionCode());
				masterWorkflowFields = setCustomerDetails(masterWorkflowFields,
						subProcessFieldsDTO.getMasterWorkflowFields());
				masterWorkflowFields = setAdditionalContactDetails(
						masterWorkflowFields,
						subProcessFieldsDTO.getMasterWorkflowFields());
				subProcessFields.setMasterWorkflowFields(masterWorkflowFields);
			}
			subProcessFieldsDTO.setMasterWorkflowFields(null);
		}

		if (subProcessFields != null) {
			// setSparesList Process
			if (null != subProcessFieldsDTO.getMotorSparesDetails()) {
				subProcessFields = setSparesList(subProcessFields,
						subProcessFieldsDTO);
			}
			// setParallelProcessList Process
			// commenting as parallel process entry should not be insert from UI
			// if (null != subProcessFieldsDTO.getParallelProcess()) {
			// subProcessFields = setParallelProcessList(subProcessFields,
			// subProcessFieldsDTO);
			// }
			// setMotorAttachmentList Process

			// setFSEVisitDetailList Process

			if (null != subProcessFieldsDTO.getfSEVisitDetails()) {
				subProcessFields = setFSEVisitDetailList(subProcessFields,
						subProcessFieldsDTO);
			}

			// setOrderDetail Process

			if (null != subProcessFieldsDTO.getMotorOrderDetails()) {
				subProcessFields = setOrderDetail(subProcessFields,
						subProcessFieldsDTO);
			}
			// setDispatchDetail Process
			if (null != subProcessFieldsDTO.getDispatchDetail()) {
				subProcessFields = setDispatchDetail(subProcessFields,
						subProcessFieldsDTO);
			}

			// setting all child entity to null to avoid exception while
			// BeanUtils.map

			subProcessFieldsDTO.setMotorSparesDetails(null);
			subProcessFieldsDTO.setParallelProcess(null);
			subProcessFieldsDTO.setMotorAttachmentDetails(null);
			subProcessFieldsDTO.setfSEVisitDetails(null);
			subProcessFieldsDTO.setMotorOrderDetails(null);
			subProcessFieldsDTO.setDispatchDetail(null);

			BeanUtils.copyProperties(subProcessFieldsDTO, subProcessFields,
					NullPropertyMapper
							.getNullPropertyNames(subProcessFieldsDTO));
			// set modified on
			subProcessFields.setModifiedOn(new Date());
			// set audit field
			subProcessFields.setFunctionCode(subProcessFieldsDTO
					.getFunctionCode());

			// saving final subProcessFields to DB
			SubProcessFields savedObject = subProcessFieldsRepository
					.save(subProcessFields);
			id = savedObject.getWlfwSubProcessId();
		}
		LOGGER.info("New Subprocess created: end");
		return id;
	}

	// create multiple subprocessDTO from single SubProcessDTO based on
	// motorDetail List

	public Long saveMultipleSubProcessFields(
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {
		List<SubProcessFieldsDTO> subProcessFieldDTOList = new ArrayList<SubProcessFieldsDTO>();
		Long id = null;
		// check for master workflow Id ,if it is null
		if (null == subProcessFieldsDTO.getMasterWorkflowFields()
				.getMasterWorkflowFieldId()) {
			LOGGER.info("SAVE_MULTIPLE_PROCESSES: Masterworkflow ID is null ");
			// check for GSP Reference ,if it it already present in DB
			MasterWorkflowFields masterworkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByGspRefNo(subProcessFieldsDTO
							.getMasterWorkflowFields().getGspRefNo());
			if (null != masterworkflowFields) {
				LOGGER.info("SAVE_MULTIPLE_PROCESSES: Masterworkflow with ID:  "
						+ masterworkflowFields.getMasterWorkflowFieldId()
						+ "; found for GSP: "
						+ subProcessFieldsDTO.getMasterWorkflowFields()
								.getGspRefNo() + "; HENCE DUPLICATE!!");
				// throw exception saying that it is duplicate entry
				throw new MotorRepairException(MotorRepairException.INPUT_ERR,
						"Duplicate GSP Reference No",
						"Create New Subprocess Workflow");
			}
		} else {
			// if master workflow is present then go & check for existing GSP
			// reference no masterworkflow Id
			MasterWorkflowFields masterworkflowFields = masterWorkflowFieldsRepository
					.findMasterWorkflowFieldsByGspRefNo(subProcessFieldsDTO
							.getMasterWorkflowFields().getGspRefNo());
			if (null != masterworkflowFields) {
				// then id shall match
				if (!(masterworkflowFields.getMasterWorkflowFieldId()
						.longValue() == subProcessFieldsDTO
						.getMasterWorkflowFields().getMasterWorkflowFieldId()
						.longValue())) {
					LOGGER.info("SAVE_MULTIPLE_PROCESSES: Different Masterworkflow with ID:  "
							+ masterworkflowFields.getMasterWorkflowFieldId()
							+ "; found for GSP: "
							+ subProcessFieldsDTO.getMasterWorkflowFields()
									.getGspRefNo()
							+ "; with current workflowId: "
							+ subProcessFieldsDTO.getMasterWorkflowFields()
									.getMasterWorkflowFieldId()
							+ "; HENCE DUPLICATE!!");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"Duplicate GSP Reference No",
							"Create New Subprocess Workflow");
				}
			}
		}

		// Check for motorSrNum if its in EXECUTION
		if (null != subProcessFieldsDTO.getMotorDetailsDTOList()
				&& subProcessFieldsDTO.getMotorDetailsDTOList().size() > 0) {
			List<SubProcessFields> subProcessFieldsDetails = null;
			for (MotorDetailsDTO motorDetailsDTO : subProcessFieldsDTO
					.getMotorDetailsDTOList()) {
				if (null != motorDetailsDTO) {
					// Check for MotorSrNum if its already exists
					subProcessFieldsDetails = subProcessFieldsRepository
							.findSubProcessFieldsByMotorSnNumAndTenantIdAndSolCatId(
									motorDetailsDTO.getMotorSnNum(),
									MotorRepairConstants.TENANT_ID,
									MotorRepairConstants.PROGRAM_ID);
				}

				if (null != subProcessFieldsDetails) {

					for (SubProcessFields subProcessFieldsRecord : subProcessFieldsDetails) {
						if ((subProcessFieldsRecord.getMotorSnNum()
								.equals(motorDetailsDTO.getMotorSnNum()))
								&& ((subProcessFieldsRecord
										.getWorkflowClosureType() == 0)
										|| (subProcessFieldsRecord
												.getWorkflowClosureType() == 1) || (subProcessFieldsRecord
										.getWorkflowClosureType() == 2))
								&& (motorDetailsDTO.getSubProcessId() == null)) {
							// Throw exception if the motorSrNumis already in
							// execution
							LOGGER.info("Motor serial number already in IN-EXEC state");
							throw new MotorRepairException(
									MotorRepairException.PROCESS_ERR,
									"Motor serial number :"
											+ subProcessFieldsRecord
													.getMotorSnNum()
											+ " already in IN-EXEC state",
									"Create New Motor Serial Number");
						}

						else {
							if ((subProcessFieldsRecord.getMotorSnNum()
									.equals(motorDetailsDTO.getMotorSnNum()))
									&& ((subProcessFieldsRecord
											.getWorkflowClosureType() == 0)
											|| (subProcessFieldsRecord
													.getWorkflowClosureType() == 1) || (subProcessFieldsRecord
											.getWorkflowClosureType() == 2))
									&& (!(subProcessFieldsRecord
											.getWlfwSubProcessId().longValue() == motorDetailsDTO
											.getSubProcessId().longValue()))) {
								// Throw exception if the motorSrNumis already
								// in execution
								LOGGER.info("Motor serial number already in IN-EXEC state");
								throw new MotorRepairException(
										MotorRepairException.PROCESS_ERR,
										"Motor serial number :"
												+ subProcessFieldsRecord
														.getMotorSnNum()
												+ " already in IN-EXEC state",
										"Create New Motor Serial Number");
							}

						}
					}
				}
			}
		}

		if (null != subProcessFieldsDTO.getMotorDetailsDTOList()
				&& subProcessFieldsDTO.getMotorDetailsDTOList().size() > 0) {
			for (MotorDetailsDTO motorDetailsDTO : subProcessFieldsDTO
					.getMotorDetailsDTOList()) {
				SubProcessFieldsDTO newSubProcessFieldDTO = dozerBeanMapper
						.map(subProcessFieldsDTO, SubProcessFieldsDTO.class);
				newSubProcessFieldDTO.setWlfwSubProcessId(motorDetailsDTO
						.getSubProcessId());
				newSubProcessFieldDTO.setMotorDetailsDTOList(null);
				newSubProcessFieldDTO.setFaultDesc(motorDetailsDTO
						.getFaultDesc());
				newSubProcessFieldDTO.setFrameSize(motorDetailsDTO
						.getFrameSize());
				newSubProcessFieldDTO.setInitialWarrantyClaim(motorDetailsDTO
						.getInitialWarrantyClaim());
				newSubProcessFieldDTO
						.setInitialWarrantyClaimSetByRefId(motorDetailsDTO
								.getInitialWarrantyClaimSetByRefId());
				newSubProcessFieldDTO.setMlfbSpiridon(motorDetailsDTO
						.getMlfbSpiridon());
				newSubProcessFieldDTO.setMotorIBaseNum(motorDetailsDTO
						.getMotorIBaseNum());
				newSubProcessFieldDTO.setMotorMaterialSpec(motorDetailsDTO
						.getMotorMaterialSpec());
				newSubProcessFieldDTO.setMotorSnNum(motorDetailsDTO
						.getMotorSnNum());
				newSubProcessFieldDTO
						.setMotorSpiridonMaterialCode(motorDetailsDTO
								.getMotorSpiridonMaterialCode());
				newSubProcessFieldDTO.setProductGrp(motorDetailsDTO
						.getProductGrp());
				newSubProcessFieldDTO
						.setRegionId(motorDetailsDTO.getRegionId());
				newSubProcessFieldDTO.setSalesDivRefId(motorDetailsDTO
						.getSalesDivRefId());
				newSubProcessFieldDTO.setSalesOfficeRefId(motorDetailsDTO
						.getSalesOfficeRefId());
				newSubProcessFieldDTO.setSalesOrgRefId(motorDetailsDTO
						.getSalesOrgRefId());
				newSubProcessFieldDTO.setSalesGrpRefId(motorDetailsDTO
						.getSalesGrpRefId());
				SubProcessGroupDetailDTO groupDTO = new SubProcessGroupDetailDTO();
				groupDTO.setGroupName(motorDetailsDTO.getGroupName());
				newSubProcessFieldDTO.setSubProcessGroupDetailDTO(groupDTO);
				subProcessFieldDTOList.add(newSubProcessFieldDTO);
			}

			id = createUpdateMultipleSubProcessFields(subProcessFieldDTOList);

		}
		return id;
	}

	public Long createUpdateMultipleSubProcessFields(
			List<SubProcessFieldsDTO> subProcessFieldsDTOList) {
		String gspRefNo = null;

		// find different group name & insert in map with unique batch process
		// Id
		Map<String, String> newGroupMap = new HashMap<String, String>();
		Map<String, SubProcessGroupDetail> existingGroupMap = new HashMap<String, SubProcessGroupDetail>();
		Long masterWorkFlowId = null;
		for (SubProcessFieldsDTO subProcessFieldsDTO : subProcessFieldsDTOList) {
			masterWorkFlowId = subProcessFieldsDTO.getMasterWorkflowFields()
					.getMasterWorkflowFieldId();
			if (null != subProcessFieldsDTO.getSubProcessGroupDetailDTO()
					.getGroupName()) {
				// check if present
				if (!newGroupMap.containsKey(subProcessFieldsDTO
						.getSubProcessGroupDetailDTO().getGroupName())) {
					newGroupMap.put(subProcessFieldsDTO
							.getSubProcessGroupDetailDTO().getGroupName(),
							uniqueIdGenerator.generateUniqueId());
				}
			}
			if (null != masterWorkFlowId) {

				List<SubProcessGroupDetail> groups = groupDetailRepository
						.findAllGroupByMasterWorkFlowId(masterWorkFlowId);
				for (SubProcessGroupDetail group : groups) {
					if (!existingGroupMap.containsKey(group.getGroupName())) {
						existingGroupMap.put(group.getGroupName(), group);
					}
				}

			}
		}

		for (SubProcessFieldsDTO subProcessFieldsDTO : subProcessFieldsDTOList) {
			if (null != subProcessFieldsDTO.getMasterWorkflowFields()) {
				gspRefNo = subProcessFieldsDTO.getMasterWorkflowFields()
						.getGspRefNo();
				Long id = createUpdateSubProcessFields(subProcessFieldsDTO);
				subProcessFieldsDTO.setWlfwSubProcessId(id);
			}
		}
		Long masterworkflowId = null;
		MasterWorkflowFields masterField = masterWorkflowFieldsRepository
				.findMasterWorkflowFieldsByGspRefNo(gspRefNo);
		if (null != masterField) {
			masterworkflowId = masterField.getMasterWorkflowFieldId();
		}

		for (SubProcessFieldsDTO subProcessFieldsDTO : subProcessFieldsDTOList) {

			if (subProcessFieldsDTO.getSubProcessGroupDetailDTO()
					.getGroupName() != null) {
				SubProcessGroupDetail group = existingGroupMap
						.get(subProcessFieldsDTO.getSubProcessGroupDetailDTO()
								.getGroupName());

				if (null == group) {

					group = new SubProcessGroupDetail();
					group.setBatchProcessId(newGroupMap.get(subProcessFieldsDTO
							.getSubProcessGroupDetailDTO().getGroupName()));
					group.setGroupName(subProcessFieldsDTO
							.getSubProcessGroupDetailDTO().getGroupName());
					group.setMasterWorkflowFieldId(masterworkflowId);
					group = groupDetailRepository.save(group);

					existingGroupMap.put(subProcessFieldsDTO
							.getSubProcessGroupDetailDTO().getGroupName(),
							group);

				}
				SubProcessFields subProcessFields = subProcessFieldsRepository
						.findOne(subProcessFieldsDTO.getWlfwSubProcessId());
				subProcessFields.setSubProcessGroupDetail(group);
				subProcessFields = subProcessFieldsRepository
						.save(subProcessFields);
			}

		}

		// return masterworkflowId
		return masterworkflowId;
	}

	// set Spares list

	private SubProcessFields setSparesList(SubProcessFields subProcessFields,
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {
		// spare detail create update begins here
		List<MotorSparesDetail> motorSparesDetailEntityList = new ArrayList<MotorSparesDetail>();
		// this is a container to remove old MotorSpares detail which are not
		// obtain from service call

		// Anand Ved: Unprocessed items must copy the list from the entity and
		// not point directly to it.
		/*
		 * List<MotorSparesDetail> unProcessedMotorSparesDetailList = new
		 * ArrayList<MotorSparesDetail>();
		 * unProcessedMotorSparesDetailList.addAll
		 * (subProcessFields.getMotorSparesDetails());
		 */

		List<MotorSparesDetail> existMotorSparesDetailList = subProcessFields
				.getMotorSparesDetails();
		List<MotorSparesDetail> existingMotorSparesListFromInput = new ArrayList<MotorSparesDetail>();
		List<MotorSparesDetail> newSparesList = null;
		List<MotorSparesDetail> finalSparesList = new ArrayList<MotorSparesDetail>();

		// converting MotorSparesDTO to Entity
		for (MotorSparesDetailDTO motorSparesDetailDTORecord : subProcessFieldsDTO
				.getMotorSparesDetails()) {
			motorSparesDetailEntityList.add(dozerBeanMapper.map(
					motorSparesDetailDTORecord, MotorSparesDetail.class));
		}
		// spares list from json DTO
		for (MotorSparesDetail motorSparesDetailEntityRecord : motorSparesDetailEntityList) {
			// if material Id is coming ,then it should be existing one else
			// throws an exception
			if (null != motorSparesDetailEntityRecord.getMaterialId()) {
				boolean isExist = false;
				// existing MotorSparesDetail list in subprocess entity
				if (null != existMotorSparesDetailList) {
					for (MotorSparesDetail existingMotorSparesDetailRecord : existMotorSparesDetailList) {
						// if record already exists in DB
						if (motorSparesDetailEntityRecord.getMaterialId()
								.equals(existingMotorSparesDetailRecord
										.getMaterialId())) {
							// setting existing MaterialRatePerUnit float
							// Commented by Anand Ved as the value should be
							// picked up from the UI from where the data is
							// entered.
							// motorSparesDetailEntityRecord.setMaterialRatePerUnit(existingMotorSparesDetailRecord
							// .getMaterialRatePerUnit());
							// setting existing ExternalCost float
							// Commented by Anand Ved as the value should be
							// picked up from the UI from where the data is
							// entered.
							// motorSparesDetailEntityRecord
							// .setExternalCost(existingMotorSparesDetailRecord.getExternalCost());
							// add new Motorspares according to its qty (if
							// qty=4 then insert 4 records)
							int qty = existingMotorSparesDetailRecord.getQty();
							MotorSparesDetail motorSpareNewRecord = null;
							if (qty > 1) {
								for (int q = 0; q < qty; q++) {
									motorSpareNewRecord = new MotorSparesDetail();
									// add mapper
									BeanUtils
											.copyProperties(
													existingMotorSparesDetailRecord,
													motorSpareNewRecord,
													NullPropertyMapper
															.getNullPropertyNames(existingMotorSparesDetailRecord));
									motorSpareNewRecord.setQty(1);
									motorSpareNewRecord
											.setCreatedOn(new Date());
									// set audit field
									motorSpareNewRecord
											.setFunctionCode(subProcessFieldsDTO
													.getFunctionCode());
									motorSpareNewRecord
											.setWlfwSubProcessId(subProcessFieldsDTO
													.getWlfwSubProcessId());
									motorSpareNewRecord
											.setModifiedByRefId(subProcessFieldsDTO
													.getModifiedByRefId());
									// set id to null as it i is new record
									motorSpareNewRecord.setMaterialId(null);
									existingMotorSparesListFromInput
											.add(motorSpareNewRecord);
								}
							}

							BeanUtils
									.copyProperties(
											motorSparesDetailEntityRecord,
											existingMotorSparesDetailRecord,
											NullPropertyMapper
													.getNullPropertyNames(motorSparesDetailEntityRecord));
							LOGGER.info("Saved object with MaterialId: "
									+ existingMotorSparesDetailRecord
											.getMaterialId());
							existingMotorSparesDetailRecord
									.setModifiedOn(new Date());
							// set audit field
							existingMotorSparesDetailRecord
									.setFunctionCode(subProcessFieldsDTO
											.getFunctionCode());
							existingMotorSparesDetailRecord
									.setWlfwSubProcessId(subProcessFieldsDTO
											.getWlfwSubProcessId());
							existingMotorSparesDetailRecord
									.setModifiedByRefId(subProcessFieldsDTO
											.getModifiedByRefId());
							existingMotorSparesListFromInput
									.add(existingMotorSparesDetailRecord);
							// unProcessedMotorSparesDetailList.remove(existingMotorSparesDetailRecord);
							isExist = true;
							break;
						}
					}
				}
				if (!isExist) {
					LOGGER.info("Spares Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"Spares Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if material id is null ,that indicates it is new entry
			else {
				/*
				 * if (newSparesList == null) { newSparesList = new
				 * ArrayList<MotorSparesDetail>(); }
				 * 
				 * //set new date motorSparesDetailEntityRecord.setCreatedOn(new
				 * Date()); // add new Motor spares
				 * newSparesList.add(motorSparesDetailEntityRecord);
				 */
				if (newSparesList == null) {
					newSparesList = new ArrayList<MotorSparesDetail>();
				}
				// add new Motorspares according to its qty (if qty=4 then
				// insert 4 records)
				int qty = motorSparesDetailEntityRecord.getQty();
				MotorSparesDetail motorSpareNewRecord = null;
				for (int q = 0; q < qty; q++) {
					motorSpareNewRecord = new MotorSparesDetail();
					// add mapper
					BeanUtils
							.copyProperties(
									motorSparesDetailEntityRecord,
									motorSpareNewRecord,
									NullPropertyMapper
											.getNullPropertyNames(motorSparesDetailEntityRecord));
					motorSpareNewRecord.setQty(1);
					motorSpareNewRecord.setCreatedOn(new Date());
					// set audit field
					motorSpareNewRecord.setFunctionCode(subProcessFieldsDTO
							.getFunctionCode());
					motorSpareNewRecord.setWlfwSubProcessId(subProcessFieldsDTO
							.getWlfwSubProcessId());
					newSparesList.add(motorSpareNewRecord);
				}
			}
		}

		if (existingMotorSparesListFromInput != null
				&& existingMotorSparesListFromInput.size() > 0) {
			finalSparesList.addAll(existingMotorSparesListFromInput);
		}
		if (newSparesList != null && newSparesList.size() > 0) {
			finalSparesList.addAll(newSparesList);
		}

		// to delete old motor spares entries from database which is not
		// coming from DTO
		// if ((null != unProcessedMotorSparesDetailList) && (0 <
		// unProcessedMotorSparesDetailList.size())) {
		// for (MotorSparesDetail existingmotorSparesDetailRecord :
		// unProcessedMotorSparesDetailList) {
		// LOGGER.info("removing object with MaterialId: " +
		// existingmotorSparesDetailRecord.getMaterialId());
		// //motorSparesDetailRepository.delete(existingmotorSparesDetailRecord.getMaterialId());
		// boolean deleted =
		// subProcessFields.getMotorSparesDetails().remove(existingmotorSparesDetailRecord);
		// LOGGER.info("Removing for: " +
		// existingmotorSparesDetailRecord.getMaterialId() + " ==> " + deleted);
		// }
		// }
		// setting finalMotorSpares
		if (null != subProcessFields.getMotorSparesDetails()) {
			subProcessFields.getMotorSparesDetails().clear();
		}

		if (finalSparesList != null && finalSparesList.size() > 0) {
			subProcessFields.getMotorSparesDetails().addAll(finalSparesList);
		}

		return subProcessFields;
	}

	// set customer list

	private MasterWorkflowFields setCustomerDetails(
			MasterWorkflowFields masterWorkflowFields,
			MasterWorkflowFieldsDTO masterWorkflowFieldsDTO)
			throws MotorRepairException {
		// spare detail create update begins here
		List<CustomerDetail> customeDetailList = new ArrayList<CustomerDetail>();
		// this is a container to remove old customer detail which are not
		// obtain from service call
		// List<CustomerDetail> unProcessedCustomerDetailList =
		// masterWorkflowFields.getCustomerDetails();
		List<CustomerDetail> existCustList = masterWorkflowFields
				.getCustomerDetails();
		List<CustomerDetail> existingCustListFromInput = new ArrayList<CustomerDetail>();

		List<CustomerDetail> newCustList = null;
		List<CustomerDetail> finalCustList = new ArrayList<CustomerDetail>();

		// converting customerDetailDTO to Entity
		if (null != masterWorkflowFieldsDTO.getCustomerDetails()) {
			for (CustomerDetailDTO custDetailDTO : masterWorkflowFieldsDTO
					.getCustomerDetails()) {
				customeDetailList.add(dozerBeanMapper.map(custDetailDTO,
						CustomerDetail.class));
			}
		}
		// spares list from json DTO
		for (CustomerDetail custDetail : customeDetailList) {
			// if customer Id is coming ,then it should be existing one else
			// throws an exception
			// set audit field
			custDetail.setFunctionCode(masterWorkflowFields.getFunctionCode());
			custDetail.setMasterWorkflowFieldId(masterWorkflowFields
					.getMasterWorkflowFieldId());
			custDetail.setModifiedByRefId(masterWorkflowFields
					.getModifiedByRefId());
			if (null != custDetail.getCustomerId()) {
				boolean isExist = false;
				// existing customerDetail list in subprocess entity
				for (CustomerDetail exitCustRecord : existCustList) {
					// if record already exists in DB
					if (exitCustRecord.getCustomerId().equals(
							custDetail.getCustomerId())) {
						BeanUtils.copyProperties(custDetail, exitCustRecord,
								NullPropertyMapper
										.getNullPropertyNames(custDetail));
						existingCustListFromInput.add(exitCustRecord);
						// unProcessedCustomerDetailList.remove(exitCustRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("customer Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"customer Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if customer id is null ,that indicates it is new entry
			else {
				if (newCustList == null) {
					newCustList = new ArrayList<CustomerDetail>();
				}
				// add new customer detail
				newCustList.add(custDetail);
			}
		}

		if (existingCustListFromInput != null
				&& existingCustListFromInput.size() > 0) {
			finalCustList.addAll(existingCustListFromInput);
		}
		if (newCustList != null && newCustList.size() > 0) {
			finalCustList.clear();
			finalCustList.addAll(newCustList);
		}

		/*
		 * // to delete old customer entries from database which is not //
		 * coming from DTO if ((null != unProcessedCustomerDetailList) && (0 <
		 * unProcessedCustomerDetailList.size())) { for (CustomerDetail
		 * custDetail : unProcessedCustomerDetailList) {
		 * customerDetailRepository.delete(custDetail.getCustomerId()); } }
		 */
		// setting customer detail
		/*
		 * masterWorkflowFields.getCustomerDetails().clear();
		 * masterWorkflowFields.setCustomerDetails(finalCustList); return
		 * masterWorkflowFields;
		 */
		masterWorkflowFields.getCustomerDetails().clear();
		masterWorkflowFields.getCustomerDetails().addAll(finalCustList);
		return masterWorkflowFields;
	}

	private MasterWorkflowFields setAdditionalContactDetails(
			MasterWorkflowFields masterWorkflowFields,
			MasterWorkflowFieldsDTO masterWorkflowFieldsDTO)
			throws MotorRepairException {
		// spare detail create update begins here
		List<AdditionalContactDetail> additionalContactDetailList = new ArrayList<AdditionalContactDetail>();
		// this is a container to remove old customer detail which are not
		// obtain from service call
		// List<CustomerDetail> unProcessedCustomerDetailList =
		// masterWorkflowFields.getCustomerDetails();
		List<AdditionalContactDetail> existadditionalContactDetai = masterWorkflowFields
				.getAdditionalContactDetails();
		List<AdditionalContactDetail> existingadditionalContactDetaiFromInput = new ArrayList<AdditionalContactDetail>();

		List<AdditionalContactDetail> newadditionalContactDetail = null;
		List<AdditionalContactDetail> finaladditionalContactDetail = new ArrayList<AdditionalContactDetail>();

		// converting customerDetailDTO to Entity
		if (null != masterWorkflowFieldsDTO.getAdditionalContactDetails()) {
			for (AdditionalContactDetailDTO custDetailDTO : masterWorkflowFieldsDTO
					.getAdditionalContactDetails()) {
				additionalContactDetailList.add(dozerBeanMapper.map(
						custDetailDTO, AdditionalContactDetail.class));
			}
		}
		// spares list from json DTO
		for (AdditionalContactDetail custDetail : additionalContactDetailList) {
			// if customer Id is coming ,then it should be existing one else
			// throws an exception
			// set audit field
			custDetail.setFunctionCode(masterWorkflowFields.getFunctionCode());
			custDetail.setMasterWorkflowFieldId(masterWorkflowFields
					.getMasterWorkflowFieldId());
			custDetail.setModifiedByRefId(masterWorkflowFields
					.getModifiedByRefId());
			if (null != custDetail.getAdditionalContactDetailId()) {
				boolean isExist = false;
				// existing customerDetail list in subprocess entity
				for (AdditionalContactDetail exitCustRecord : existadditionalContactDetai) {
					// if record already exists in DB
					if (exitCustRecord.getAdditionalContactDetailId().equals(
							custDetail.getAdditionalContactDetailId())) {
						BeanUtils.copyProperties(custDetail, exitCustRecord,
								NullPropertyMapper
										.getNullPropertyNames(custDetail));
						existingadditionalContactDetaiFromInput
								.add(exitCustRecord);
						// unProcessedAdditionalContactDetailList.remove(exitCustRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("customer Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"customer Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if customer id is null ,that indicates it is new entry
			else {
				if (newadditionalContactDetail == null) {
					newadditionalContactDetail = new ArrayList<AdditionalContactDetail>();
				}
				// add new customer detail
				newadditionalContactDetail.add(custDetail);
			}
		}

		if (existingadditionalContactDetaiFromInput != null
				&& existingadditionalContactDetaiFromInput.size() > 0) {
			finaladditionalContactDetail
					.addAll(existingadditionalContactDetaiFromInput);
		}
		if (newadditionalContactDetail != null
				&& newadditionalContactDetail.size() > 0) {
			finaladditionalContactDetail.clear();
			finaladditionalContactDetail.addAll(newadditionalContactDetail);
		}

		/*
		 * // to delete old customer entries from database which is not //
		 * coming from DTO if ((null != unProcessedAdditionalContactDetailList)
		 * && (0 < unProcessedAdditionalContactDetailList.size())) { for
		 * (AdditionalContactDetail custDetail :
		 * unProcessedAdditionalContactDetailList) {
		 * AdditionalContactDetailRepository.delete(custDetail.getCustomerId());
		 * } }
		 */
		// setting customer detail
		/*
		 * masterWorkflowFields.getAdditionalContactDetails().clear();
		 * masterWorkflowFields
		 * .setAdditionalContactDetails(finaladditionalContactDetai); return
		 * masterWorkflowFields;
		 */
		masterWorkflowFields.getAdditionalContactDetails().clear();

		masterWorkflowFields.getAdditionalContactDetails().addAll(
				finaladditionalContactDetail);
		return masterWorkflowFields;
	}

	// set Parallel Process list

	private SubProcessFields setParallelProcessList(
			SubProcessFields subProcessFields,
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {

		List<ParallelProcess> parallelProcessDetailList = new ArrayList<ParallelProcess>();
		// this is a container to remove old ParallelProcess detail which are
		// not
		// obtain from service call
		// List<ParallelProcess> unProcessedParallelProcessList =
		// subProcessFields.getParallelProcess();
		List<ParallelProcess> existingParallelProcessList = subProcessFields
				.getParallelProcess();
		List<ParallelProcess> existingParallelProcessListFromInput = new ArrayList<ParallelProcess>();
		List<ParallelProcess> newParallelProcessList = null;
		List<ParallelProcess> finalParallelProcessList = new ArrayList<ParallelProcess>();

		// converting ParallelProcessDTO to Entity
		for (ParallelProcessDTO parallelProcessDTORecord : subProcessFieldsDTO
				.getParallelProcess()) {
			parallelProcessDetailList.add(dozerBeanMapper.map(
					parallelProcessDTORecord, ParallelProcess.class));
		}
		// ParallelProcessDetail list from json DTO
		for (ParallelProcess parallelProcessEntityRecord : parallelProcessDetailList) {
			// if ParallelProcess Id is coming ,then it should be existing one
			// else
			// throws an exception
			// set audit field
			parallelProcessEntityRecord.setFunctionCode(subProcessFieldsDTO
					.getFunctionCode());
			parallelProcessEntityRecord.setWlfwSubProcessId(subProcessFieldsDTO
					.getWlfwSubProcessId());
			parallelProcessEntityRecord.setModifiedByRefId(subProcessFieldsDTO
					.getModifiedByRefId());
			if (null != parallelProcessEntityRecord.getParallelProcessId()) {
				boolean isExist = false;
				// existing ParallelProcess list in subprocess entity
				for (ParallelProcess existingparallelProcessDetailRecord : existingParallelProcessList) {
					// if record already exists in DB
					if (parallelProcessEntityRecord.getParallelProcessId()
							.equals(existingparallelProcessDetailRecord
									.getParallelProcessId())) {

						BeanUtils
								.copyProperties(
										parallelProcessEntityRecord,
										existingparallelProcessDetailRecord,
										NullPropertyMapper
												.getNullPropertyNames(parallelProcessEntityRecord));

						existingParallelProcessListFromInput
								.add(existingparallelProcessDetailRecord);
						// unProcessedParallelProcessList.remove(existingparallelProcessDetailRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("ParallelProcess Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"ParallelProcess Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if maParallelProcessterial id is null ,that indicates it is new
			// entry
			else {
				if (newParallelProcessList == null) {
					newParallelProcessList = new ArrayList<ParallelProcess>();
				}
				// add new Parallel Process
				newParallelProcessList.add(parallelProcessEntityRecord);
			}
		}
		if (existingParallelProcessListFromInput != null
				&& existingParallelProcessListFromInput.size() > 0) {
			finalParallelProcessList
					.addAll(existingParallelProcessListFromInput);
		}
		if (newParallelProcessList != null && newParallelProcessList.size() > 0) {
			finalParallelProcessList.addAll(newParallelProcessList);
		}
		// to delete old Parallel Process entries from database which is not
		// coming from DTO
		/*
		 * if ((null != unProcessedParallelProcessList) && (0 <
		 * unProcessedParallelProcessList.size())) { for (ParallelProcess
		 * unProcessedParallelProcessRecord : unProcessedParallelProcessList) {
		 * parallelProcessRepository
		 * .delete(unProcessedParallelProcessRecord.getParallelProcessId());
		 * LOGGER.info("removing object with ParallelProcessId: " +
		 * unProcessedParallelProcessRecord.getParallelProcessId()); } }
		 */
		// setting finalParallelProcess
		if (null != subProcessFields.getParallelProcess()) {
			subProcessFields.getParallelProcess().clear();
		}
		if (finalParallelProcessList != null
				&& finalParallelProcessList.size() > 0) {
			subProcessFields.getParallelProcess().addAll(
					finalParallelProcessList);
		}

		return subProcessFields;
	}

	// set Motor attachment list to subProcessFields
	// commenting as we are handling attachment separately
	/*
	 * private SubProcessFields setMotorAttachmentList( SubProcessFields
	 * subProcessFields, SubProcessFieldsDTO subProcessFieldsDTO) throws
	 * MotorRepairException {
	 * 
	 * List<MotorAttachmentDetail> motorAttachmentDetailList = new
	 * ArrayList<MotorAttachmentDetail>(); // this is a container to remove old
	 * MotorAttachmentDetail detail which // are not // obtain from service call
	 * // List<MotorAttachmentDetail> unProcessedMotorAttachmentDetailList = //
	 * subProcessFields.getMotorAttachmentDetails(); List<MotorAttachmentDetail>
	 * existingMotorAttachmentDetailList = subProcessFields
	 * .getMotorAttachmentDetails(); List<MotorAttachmentDetail>
	 * existingMotorAttachmentDetailListFromInput = new
	 * ArrayList<MotorAttachmentDetail>(); List<MotorAttachmentDetail>
	 * newMotorAttachmentDetailList = null; List<MotorAttachmentDetail>
	 * finalMotorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();
	 * 
	 * // converting MotorAttachmentDetailDTO to Entity for
	 * (MotorAttachmentDetailDTO motorAttachmentDTORecord : subProcessFieldsDTO
	 * .getMotorAttachmentDetails()) {
	 * motorAttachmentDetailList.add(dozerBeanMapper.map(
	 * motorAttachmentDTORecord, MotorAttachmentDetail.class)); } // spares list
	 * from json DTO for (MotorAttachmentDetail motorAttachmentEntityRecord :
	 * motorAttachmentDetailList) { // if MotorAttachments Id is coming ,then it
	 * should be existing one // else // throws an exception if (null !=
	 * motorAttachmentEntityRecord.getMotorAttachmentsId()) { boolean isExist =
	 * false; // existing MotorAttachmentDetail list in subprocess entity for
	 * (MotorAttachmentDetail existingMotorAttachmentEntityRecordRecord :
	 * existingMotorAttachmentDetailList) { // if record already exists in DB if
	 * (motorAttachmentEntityRecord.getMotorAttachmentsId()
	 * .equals(existingMotorAttachmentEntityRecordRecord
	 * .getMotorAttachmentsId())) {
	 * 
	 * motorAttachmentEntityRecord
	 * .setFileSize(existingMotorAttachmentEntityRecordRecord .getFileSize());
	 * 
	 * BeanUtils .copyProperties( motorAttachmentEntityRecord,
	 * existingMotorAttachmentEntityRecordRecord, NullPropertyMapper
	 * .getNullPropertyNames(motorAttachmentEntityRecord));
	 * 
	 * existingMotorAttachmentDetailListFromInput
	 * .add(existingMotorAttachmentEntityRecordRecord); //
	 * unProcessedMotorAttachmentDetailList
	 * .remove(existingMotorAttachmentEntityRecordRecord); isExist = true;
	 * break; } } if (!isExist) {
	 * LOGGER.info("MotorAttachments Id is incorrect Create New Subprocess Workflow"
	 * ); throw new MotorRepairException( MotorRepairException.INPUT_ERR,
	 * "MotorAttachments Id is incorrect", "Create New Subprocess Workflow"); }
	 * } // if MotorAttachments id is null ,that indicates it is new entry else
	 * { if (newMotorAttachmentDetailList == null) {
	 * newMotorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>(); }
	 * // add new Motor Attachment Record
	 * newMotorAttachmentDetailList.add(motorAttachmentEntityRecord); } }
	 * 
	 * if (existingMotorAttachmentDetailListFromInput != null &&
	 * existingMotorAttachmentDetailListFromInput.size() > 0) {
	 * finalMotorAttachmentDetailList
	 * .addAll(existingMotorAttachmentDetailListFromInput); } if
	 * (newMotorAttachmentDetailList != null &&
	 * newMotorAttachmentDetailList.size() > 0) {
	 * finalMotorAttachmentDetailList.addAll(newMotorAttachmentDetailList); }
	 * 
	 * // to delete old Motor Attachment entries from database which is not //
	 * coming from DTO
	 * 
	 * if ((null != unProcessedMotorAttachmentDetailList) && (0 <
	 * unProcessedMotorAttachmentDetailList.size())) { for
	 * (MotorAttachmentDetail unrpocessedMotorAttachmentDetailRecord :
	 * unProcessedMotorAttachmentDetailList) { motorAttachmentDetailRepository
	 * .delete(unrpocessedMotorAttachmentDetailRecord .getMotorAttachmentsId());
	 * LOGGER.info("removing object with MotorAttachmentsId: " +
	 * unrpocessedMotorAttachmentDetailRecord.getMotorAttachmentsId()); } }
	 * 
	 * // setting finalMotorAttachmentDetails if (null !=
	 * subProcessFields.getMotorAttachmentDetails()) {
	 * subProcessFields.getMotorAttachmentDetails().clear(); }
	 * subProcessFields.getMotorAttachmentDetails().addAll(
	 * finalMotorAttachmentDetailList);
	 * 
	 * return subProcessFields; }
	 */
	// set FSE detail list to subProcessFields

	private SubProcessFields setFSEVisitDetailList(
			SubProcessFields subProcessFields,
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {
		List<FSEVisitDetail> fseVisitDetailList = new ArrayList<FSEVisitDetail>();
		// this is a container to remove old FSEVisitDetail detail which are not
		// obtain from service call
		// List<FSEVisitDetail> unProcessedFSEVisitDetailList =
		// subProcessFields.getfSEVisitDetails();
		List<FSEVisitDetail> existingFSEVisitDetailList = subProcessFields
				.getfSEVisitDetails();
		List<FSEVisitDetail> existingFSEVisitDetailListFromInput = new ArrayList<FSEVisitDetail>();
		List<FSEVisitDetail> newFSEVisitDetailList = null;
		List<FSEVisitDetail> finalFSEVisitDetailList = new ArrayList<FSEVisitDetail>();

		// converting FSEVisitDetailDTO to Entity
		for (FSEVisitDetailDTO fseVisitDetailDTORecord : subProcessFieldsDTO
				.getfSEVisitDetails()) {
			fseVisitDetailList.add(dozerBeanMapper.map(fseVisitDetailDTORecord,
					FSEVisitDetail.class));
		}
		// FSEVisitDetail list from json DTO
		for (FSEVisitDetail fseVisitDetailEntityRecord : fseVisitDetailList) {
			// if FseVisitDetail Id is coming ,then it should be existing one
			// else
			// throws an exception
			// set audit field
			fseVisitDetailEntityRecord.setFunctionCode(subProcessFieldsDTO
					.getFunctionCode());
			fseVisitDetailEntityRecord.setWlfwSubProcessId(subProcessFieldsDTO
					.getWlfwSubProcessId());
			fseVisitDetailEntityRecord.setModifiedByRefId(subProcessFieldsDTO
					.getModifiedByRefId());
			if (null != fseVisitDetailEntityRecord.getFseVisitDetailId()) {
				boolean isExist = false;
				// existing FSEVisitDetail list in subprocess entity
				for (FSEVisitDetail existingFSEVisitDetailEntityRecordRecord : existingFSEVisitDetailList) {
					// if record already exists in DB
					if (fseVisitDetailEntityRecord.getFseVisitDetailId()
							.equals(existingFSEVisitDetailEntityRecordRecord
									.getFseVisitDetailId())) {

						BeanUtils
								.copyProperties(
										fseVisitDetailEntityRecord,
										existingFSEVisitDetailEntityRecordRecord,
										NullPropertyMapper
												.getNullPropertyNames(fseVisitDetailEntityRecord));

						existingFSEVisitDetailListFromInput
								.add(existingFSEVisitDetailEntityRecordRecord);
						// unProcessedFSEVisitDetailList.remove(existingFSEVisitDetailEntityRecordRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("FseVisitDetail Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"FseVisitDetail Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if FseVisitDetail id is null ,that indicates it is new entry
			else {
				if (newFSEVisitDetailList == null) {
					newFSEVisitDetailList = new ArrayList<FSEVisitDetail>();
				}
				// add new FSEVisit Detail
				newFSEVisitDetailList.add(fseVisitDetailEntityRecord);
			}
		}

		if (existingFSEVisitDetailListFromInput != null
				&& existingFSEVisitDetailListFromInput.size() > 0) {
			finalFSEVisitDetailList.addAll(existingFSEVisitDetailListFromInput);
		}
		if (newFSEVisitDetailList != null && newFSEVisitDetailList.size() > 0) {
			finalFSEVisitDetailList.addAll(newFSEVisitDetailList);
		}

		// to delete old FSEVisit Detail entries from database which is not
		// coming from DTO
		/*
		 * if ((null != unProcessedFSEVisitDetailList) && (0 <
		 * unProcessedFSEVisitDetailList.size())) { for (FSEVisitDetail
		 * unProcessedFSEVisitDetailRecord : unProcessedFSEVisitDetailList) {
		 * fSEVisitDetailRepository
		 * .delete(unProcessedFSEVisitDetailRecord.getFseVisitDetailId());
		 * LOGGER.info("removing object with FseVisitDetailId: "
		 * +unProcessedFSEVisitDetailRecord.getFseVisitDetailId()); } }
		 */
		// setting finalFSEVisitDetails
		if (null != subProcessFields.getfSEVisitDetails()) {
			subProcessFields.getfSEVisitDetails().clear();
		}
		if (finalFSEVisitDetailList != null
				&& finalFSEVisitDetailList.size() > 0) {
			subProcessFields.getfSEVisitDetails().addAll(
					finalFSEVisitDetailList);
		}

		return subProcessFields;
	}

	// set Order detail list to subProcessFields

	private SubProcessFields setOrderDetail(SubProcessFields subProcessFields,
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {

		List<MotorOrderDetail> orderDetailList = new ArrayList<MotorOrderDetail>();
		// this is a container to remove old FSEVisitDetail detail which are not
		// obtain from service call
		// List<MotorOrderDetail> unprocessedMotorOrderDetailList =
		// subProcessFields.getMotorOrderDetails();
		List<MotorOrderDetail> existingMotorOrderDetailList = subProcessFields
				.getMotorOrderDetails();
		List<MotorOrderDetail> existingMotorOrderDetailListFromInput = new ArrayList<MotorOrderDetail>();
		List<MotorOrderDetail> newMotorOrderDetailList = null;
		List<MotorOrderDetail> finalMotorOrderDetailList = new ArrayList<MotorOrderDetail>();

		// converting MotorOrderDetailDTO to Entity
		for (MotorOrderDetailDTO motorOrderDetailDTORecord : subProcessFieldsDTO
				.getMotorOrderDetails()) {
			orderDetailList.add(dozerBeanMapper.map(motorOrderDetailDTORecord,
					MotorOrderDetail.class));
		}
		// OrderDetail list from json DTO
		for (MotorOrderDetail orderDetailListEntityRecord : orderDetailList) {
			// if MotorOrderDetail Id is coming ,then it should be existing one
			// else
			// throws an exception
			// set audit field
			orderDetailListEntityRecord.setFunctionCode(subProcessFieldsDTO
					.getFunctionCode());
			orderDetailListEntityRecord.setWlfwSubProcessId(subProcessFieldsDTO
					.getWlfwSubProcessId());
			orderDetailListEntityRecord.setModifiedByRefId(subProcessFieldsDTO
					.getModifiedByRefId());
			if (null != orderDetailListEntityRecord.getMotorOrderDetailId()) {
				boolean isExist = false;
				// existing MotorOrderDetail list in subprocess entity
				for (MotorOrderDetail existingMotorOrderDetailEntityRecordRecord : existingMotorOrderDetailList) {
					// if record already exists in DB
					if (orderDetailListEntityRecord.getMotorOrderDetailId()
							.equals(existingMotorOrderDetailEntityRecordRecord
									.getMotorOrderDetailId())) {

						BeanUtils
								.copyProperties(
										orderDetailListEntityRecord,
										existingMotorOrderDetailEntityRecordRecord,
										NullPropertyMapper
												.getNullPropertyNames(orderDetailListEntityRecord));
						// set modified date

						existingMotorOrderDetailListFromInput
								.add(existingMotorOrderDetailEntityRecordRecord);
						// unprocessedMotorOrderDetailList.remove(existingMotorOrderDetailEntityRecordRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("MotorOrderDetail Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"MotorOrderDetail Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if MotorOrderDetail id is null ,that indicates it is new entry
			else {
				if (newMotorOrderDetailList == null) {
					newMotorOrderDetailList = new ArrayList<MotorOrderDetail>();
				}
				// add new OrderDetail
				// set created on
				orderDetailListEntityRecord.setCreatedOn(new Date());
				// set order status to open on initial
				// orderDetailListEntityRecord.setOrderStatus(MotorRepairConstants.ORDER_STATUS.OPEN.getValue());
				newMotorOrderDetailList.add(orderDetailListEntityRecord);
			}
		}

		if (existingMotorOrderDetailListFromInput != null
				&& existingMotorOrderDetailListFromInput.size() > 0) {
			finalMotorOrderDetailList
					.addAll(existingMotorOrderDetailListFromInput);
		}
		if (newMotorOrderDetailList != null
				&& newMotorOrderDetailList.size() > 0) {
			finalMotorOrderDetailList.addAll(newMotorOrderDetailList);
		}

		// to delete old Order Detail entries from database which is not
		// coming from DTO
		/*
		 * if ((null != unprocessedMotorOrderDetailList) && (0 <
		 * unprocessedMotorOrderDetailList.size())) { for (MotorOrderDetail
		 * unprocessedMotorOrderDetailRecord : unprocessedMotorOrderDetailList)
		 * {
		 * motorOrderDetailRepository.delete(unprocessedMotorOrderDetailRecord.
		 * getMotorOrderDetailId());
		 * LOGGER.info("removing object with MotorOrderDetailId: "
		 * +unprocessedMotorOrderDetailRecord.getMotorOrderDetailId()); } }
		 */
		// setting finalMotorOrderDetails
		if (null != subProcessFields.getMotorOrderDetails()) {
			subProcessFields.getMotorOrderDetails().clear();
		}
		if (finalMotorOrderDetailList != null
				&& finalMotorOrderDetailList.size() > 0) {
			subProcessFields.getMotorOrderDetails().addAll(
					finalMotorOrderDetailList);
		}

		return subProcessFields;
	}

	// set Dispatch Detail list to subProcessFields
	@Transactional
	private SubProcessFields setDispatchDetail(
			SubProcessFields subProcessFields,
			SubProcessFieldsDTO subProcessFieldsDTO)
			throws MotorRepairException {

		List<DispatchDetail> dispatchDetailList = new ArrayList<DispatchDetail>();
		List<DispatchDetail> existingDispatchDetailList = subProcessFields
				.getDispatchDetail();
		List<DispatchDetail> existingDispatchDetailListFromInput = new ArrayList<DispatchDetail>();
		List<DispatchDetail> newDispatchDetailList = null;
		List<DispatchDetail> finalDispatchDetailList = new ArrayList<DispatchDetail>();
		List<DispatchDetailDTO> dispatchDetailDTOList = subProcessFieldsDTO
				.getDispatchDetail();

		for (DispatchDetailDTO dispatchDetailDTORecord : dispatchDetailDTOList) {
			if (null != existingDispatchDetailList
					&& existingDispatchDetailList.size() > 0) {
				for (DispatchDetail dispatchDetailRecord : existingDispatchDetailList) {
					if (dispatchDetailDTORecord.getDispatchType().equals(
							dispatchDetailRecord.getDispatchType())) {
						dispatchDetailDTORecord
								.setDispatchId(dispatchDetailRecord
										.getDispatchId());
					}
				}
			}

		}
		// converting DispatchDetailDTO to Entity
		for (DispatchDetailDTO dispatchDetailDTORecord : subProcessFieldsDTO
				.getDispatchDetail()) {

			dispatchDetailList.add(dozerBeanMapper.map(dispatchDetailDTORecord,
					DispatchDetail.class));
		}
		// DispatchDetail list from json DTO
		for (DispatchDetail dispatchDetailListEntityRecord : dispatchDetailList) {
			// if DispatchDetail Id is coming ,then it should be existing one
			// else
			// throws an exception
			if (null != dispatchDetailListEntityRecord.getDispatchId()) {
				boolean isExist = false;
				// existing DispatchDetail list in subprocess entity
				for (DispatchDetail existingDispatchDetailEntityRecord : existingDispatchDetailList) {
					// if record already exists in DB
					if (dispatchDetailListEntityRecord.getDispatchId().equals(
							existingDispatchDetailEntityRecord.getDispatchId())) {
						BeanUtils
								.copyProperties(
										dispatchDetailListEntityRecord,
										existingDispatchDetailEntityRecord,
										NullPropertyMapper
												.getNullPropertyNames(dispatchDetailListEntityRecord));
						if (null == dispatchDetailListEntityRecord
								.getTransporterName()) {
							existingDispatchDetailEntityRecord
									.setTransporterName(null);
						}
						if (null == dispatchDetailListEntityRecord
								.getDocketDetail()) {
							existingDispatchDetailEntityRecord
									.setDocketDetail(null);
						}
						if (null == dispatchDetailListEntityRecord
								.getOtherModeDetails()) {
							existingDispatchDetailEntityRecord
									.setOtherModeDetails(null);
						}
						existingDispatchDetailListFromInput
								.add(existingDispatchDetailEntityRecord);
						isExist = true;
						break;
					}
				}
				if (!isExist) {
					LOGGER.info("DispatchDetail Id is incorrect Create New Subprocess Workflow");
					throw new MotorRepairException(
							MotorRepairException.INPUT_ERR,
							"DispatchDetail Id is incorrect",
							"Create New Subprocess Workflow");
				}
			}
			// if DispatchDetail id is null ,that indicates it is new entry
			else {
				if (newDispatchDetailList == null) {
					newDispatchDetailList = new ArrayList<DispatchDetail>();
				}
				// add new DispatchDetail
				// set created on
				dispatchDetailListEntityRecord.setCreatedOn(new Date());
				// set DispatchDetail status to open on initial
				newDispatchDetailList.add(dispatchDetailListEntityRecord);
			}
		}

		if (existingDispatchDetailListFromInput != null
				&& existingDispatchDetailListFromInput.size() > 0) {
			finalDispatchDetailList.addAll(existingDispatchDetailListFromInput);
		}
		if (newDispatchDetailList != null && newDispatchDetailList.size() > 0) {
			finalDispatchDetailList.addAll(newDispatchDetailList);
		}
		if (finalDispatchDetailList != null
				&& finalDispatchDetailList.size() > 0) {
			subProcessFields.getDispatchDetail()
					.addAll(finalDispatchDetailList);
		}

		return subProcessFields;
	}

	/**
	 * The method retrieves all the SubProcessFields on the basis of tenantId
	 * 
	 * @param tenantId
	 *            The tenant ID
	 * @return List of SubProcessFields DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<SubProcessFieldsDTO> getAllSubProcessFieldsByTenantId(
			String tenantId) {
		LOGGER.info("SubProcessFieldsServiceImpl : getAllSubProcessFieldsByTenantId : Start");
		List<SubProcessFieldsDTO> subProcessFieldsDTOs = null;
		List<SubProcessFields> subProcessFields = subProcessFieldsRepository
				.findAllSubProcessFieldsByTenantId(tenantId);
		SubProcessFieldsDTO subProcessFieldsDTO = new SubProcessFieldsDTO();

		if (null != subProcessFields && subProcessFields.size() > 0) {

			subProcessFieldsDTOs = new ArrayList<SubProcessFieldsDTO>();
			for (SubProcessFields subProcessFieldsRecord : subProcessFields) {
				subProcessFieldsDTO = dozerBeanMapper.map(
						subProcessFieldsRecord, SubProcessFieldsDTO.class);
				subProcessFieldsDTOs.add(subProcessFieldsDTO);
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getAllSubProcessFieldsByTenantId : End");
		return subProcessFieldsDTOs;
	}

	/**
	 * The method retrieves a SubProcessFields on the basis its
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return SubProcessFields DTO
	 * 
	 */

	@Override
	@Transactional
	public SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByWlfwSubProcessId : Start");
		SubProcessFieldsDTO subProcessFieldsDTO = null;
		if (null != wlfwSubProcessId) {

			SubProcessFields subProcessFields = subProcessFieldsRepository
					.findOne(wlfwSubProcessId);
			// Hibernate.initialize(subProcessFields.getfSEVisitDetails());
			if (null != subProcessFields) {
				subProcessFieldsDTO = dozerBeanMapper.map(subProcessFields,
						SubProcessFieldsDTO.class);
				subProcessFieldsDTO.setMotorAttachmentDetails(null);
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByWlfwSubProcessId : End");
		return subProcessFieldsDTO;
	}

	/**
	 * The method retrieves a SubProcessFields on the basis its frameSize.
	 * 
	 * @param frameSize
	 *            The frame size
	 * @return List of SubProcessFields DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<SubProcessFieldsDTO> getSubProcessFieldsByFrameSize(
			Integer frameSize) {
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByFrameSize : Start");
		List<SubProcessFieldsDTO> subProcessFieldsDTOs = null;
		List<SubProcessFields> subProcessFields = subProcessFieldsRepository
				.findSubProcessFieldsByFrameSize(frameSize);
		SubProcessFieldsDTO subProcessFieldsDTO = new SubProcessFieldsDTO();
		if (null != subProcessFields && subProcessFields.size() > 0) {
			subProcessFieldsDTOs = new ArrayList<SubProcessFieldsDTO>();
			for (SubProcessFields subProcessFieldsRecord : subProcessFields) {
				subProcessFieldsDTO = dozerBeanMapper.map(
						subProcessFieldsRecord, SubProcessFieldsDTO.class);
				subProcessFieldsDTOs.add(subProcessFieldsDTO);
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByFrameSize : End");
		return subProcessFieldsDTOs;
	}

	/**
	 * The method retrieves all the SubProcessFields on the basis its grnVrreId
	 * 
	 * @param grnVrreId
	 *            The GrnVrreId
	 * @return List of SubProcessFields DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<SubProcessFieldsDTO> getSubProcessFieldsByGrnVrreId(
			String grnVrreId) {
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByGrnVrreId : Start");
		List<SubProcessFieldsDTO> subProcessFieldsDTOs = null;
		List<SubProcessFields> subProcessFields = subProcessFieldsRepository
				.findSubProcessFieldsByGrnVrreId(grnVrreId);
		SubProcessFieldsDTO subProcessFieldsDTO = new SubProcessFieldsDTO();
		if (null != subProcessFields && subProcessFields.size() > 0) {
			subProcessFieldsDTOs = new ArrayList<SubProcessFieldsDTO>();
			for (SubProcessFields subProcessFieldsRecord : subProcessFields) {
				subProcessFieldsDTO = dozerBeanMapper.map(
						subProcessFieldsRecord, SubProcessFieldsDTO.class);
				subProcessFieldsDTOs.add(subProcessFieldsDTO);
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getSubProcessFieldsByGrnVrreId : End");
		return subProcessFieldsDTOs;
	}

	/**
	 * The method retrieves a MotorSparesDetails on the basis of
	 * SubProcessFields wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return List of MotorSparesDetail DTO
	 * 
	 */

	@Override
	@Transactional
	public List<MotorSparesDetailDTO> getMotorSparesDetailsByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl :  getMotorSparesDetailsByWlfwSubProcessId : Start");
		List<MotorSparesDetailDTO> motorSparesDetailDTOs = null;
		List<MotorSparesDetail> motorSparesDetails = null;
		MotorSparesDetailDTO motorSparesDetailDTO = null;
		if (wlfwSubProcessId != null) {
			motorSparesDetails = subProcessFieldsRepository
					.findMotorSparesDetailsByWlfwSubProcessId(wlfwSubProcessId);
			if (null != motorSparesDetails && motorSparesDetails.size() > 0) {
				motorSparesDetailDTOs = new ArrayList<MotorSparesDetailDTO>();
				for (MotorSparesDetail motorSparesDetailRecord : motorSparesDetails) {
					motorSparesDetailDTO = dozerBeanMapper
							.map(motorSparesDetailRecord,
									MotorSparesDetailDTO.class);
					motorSparesDetailDTOs.add(motorSparesDetailDTO);
				}
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getMotorSparesDetailsByWlfwSubProcessId : End");
		return motorSparesDetailDTOs;
	}

	/**
	 * The method retrieves a MotorAttachmentDetail on the basis of
	 * SubProcessFields wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return List of MotorAttachmentDetail DTO
	 * 
	 */

	@Override
	@Transactional
	public List<MotorAttachmentDetailDTO> getMotorAttachmentDetailByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl :  getMotorAttachmentDetailByWlfwSubProcessId : Start");
		List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOs = null;
		List<MotorAttachmentDetail> motorAttachmentDetails = null;
		MotorAttachmentDetailDTO motorAttachmentDetailDTO = null;
		if (null != wlfwSubProcessId) {
			motorAttachmentDetails = subProcessFieldsRepository
					.findMotorAttachmentDetailByWlfwSubProcessId(wlfwSubProcessId);
			if (null != motorAttachmentDetails
					&& motorAttachmentDetails.size() > 0) {
				motorAttachmentDetailDTOs = new ArrayList<MotorAttachmentDetailDTO>();
				for (MotorAttachmentDetail motorAttachmentDetailRecord : motorAttachmentDetails) {
					motorAttachmentDetailDTO = dozerBeanMapper.map(
							motorAttachmentDetailRecord,
							MotorAttachmentDetailDTO.class);
					motorAttachmentDetailDTOs.add(motorAttachmentDetailDTO);
				}
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getMotorAttachmentDetailByWlfwSubProcessId : End");
		return motorAttachmentDetailDTOs;
	}

	/**
	 * The method retrieves a FSEVisitDetails on the basis of SubProcessFields
	 * wlfwSubProcessId.
	 * 
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return List of FSEVisitDetail DTO
	 * 
	 */

	@Override
	@Transactional
	public List<FSEVisitDetailDTO> getFSEVisitDetailByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl :  getFSEVisitDetailByWlfwSubProcessId : Start");
		List<FSEVisitDetailDTO> fSEVisitDetailDTOs = null;
		List<FSEVisitDetail> fSEVisitDetails = null;
		FSEVisitDetailDTO fSEVisitDetailDTO = null;
		if (null != wlfwSubProcessId) {
			fSEVisitDetails = subProcessFieldsRepository
					.findFSEVisitDetailByWlfwSubProcessId(wlfwSubProcessId);

			if (fSEVisitDetails != null && fSEVisitDetails.size() > 0) {

				if (null != fSEVisitDetails && fSEVisitDetails.size() > 0) {

					fSEVisitDetailDTOs = new ArrayList<FSEVisitDetailDTO>();
					for (FSEVisitDetail fSEVisitDetailRecord : fSEVisitDetails) {
						fSEVisitDetailDTO = dozerBeanMapper.map(
								fSEVisitDetailRecord, FSEVisitDetailDTO.class);
						fSEVisitDetailDTOs.add(fSEVisitDetailDTO);
					}
				}
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getFSEVisitDetailByWlfwSubProcessId : End");
		return fSEVisitDetailDTOs;
	}

	/**
	 * The method retrieves a MotorOrderDetail on the basis of SubProcessFields
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return List of MotorOrderDetail DTO
	 * 
	 */

	@Override
	@Transactional
	public List<MotorOrderDetailDTO> getMotorOrderDetailByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl :  getMotorOrderDetailByWlfwSubProcessId : Start");
		List<MotorOrderDetailDTO> motorOrderDetailDTOs = null;
		List<MotorOrderDetail> motorOrderDetails = null;
		MotorOrderDetailDTO motorOrderDetailDTO = null;
		if (null != wlfwSubProcessId) {
			motorOrderDetails = subProcessFieldsRepository
					.findMotorOrderDetailByWlfwSubProcessId(wlfwSubProcessId);
			if (null != motorOrderDetails && motorOrderDetails.size() > 0) {
				motorOrderDetailDTOs = new ArrayList<MotorOrderDetailDTO>();
				for (MotorOrderDetail motorOrderDetailRecord : motorOrderDetails) {
					motorOrderDetailDTO = dozerBeanMapper.map(
							motorOrderDetailRecord, MotorOrderDetailDTO.class);
					motorOrderDetailDTOs.add(motorOrderDetailDTO);
				}
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getMotorOrderDetailByWlfwSubProcessId : End");
		return motorOrderDetailDTOs;
	}

	/**
	 * The method retrieves a ParallelProcess on the basis of SubProcessFields
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcess Id
	 * @return List of ParallelProcess DTO
	 * 
	 */

	@Override
	@Transactional
	public List<ParallelProcessDTO> getParallelProcessByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl :  getParallelProcessByWlfwSubProcessId : Start");
		List<ParallelProcessDTO> parallelProcessDTOs = null;
		List<ParallelProcess> parallelProcesss = null;
		ParallelProcessDTO parallelProcessDTO = null;
		if (null != wlfwSubProcessId) {
			parallelProcesss = subProcessFieldsRepository
					.findParallelProcessByWlfwSubProcessId(wlfwSubProcessId);
			if (null != parallelProcesss && parallelProcesss.size() > 0) {
				parallelProcessDTOs = new ArrayList<ParallelProcessDTO>();
				for (ParallelProcess parallelProcessRecord : parallelProcesss) {
					parallelProcessDTO = dozerBeanMapper.map(
							parallelProcessRecord, ParallelProcessDTO.class);
					parallelProcessDTOs.add(parallelProcessDTO);
				}
			}
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getParallelProcessByWlfwSubProcessId : End");
		return parallelProcessDTOs;
	}

	/**
	 * The deletes a SubProcessFields on the basis its wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The WlfwSubProcess Id
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteSubProcessFieldsByWlfwSubProcessId(
			Long wlfwSubProcessId) {
		LOGGER.info("SubProcessFieldsServiceImpl : deleteSubProcessFieldsByWlfwSubProcessId : Start");
		boolean returnVal = false;
		try {
			if (null != wlfwSubProcessId) {
				subProcessFieldsRepository.delete(wlfwSubProcessId);
				returnVal = true;
			} else {
				LOGGER.info("SubProcessFieldsServiceImpl : deleteSubProcessFieldsByWlfwSubProcessId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	@Transactional
	public Long addMotorAttachmentDetailToSubProcessFields(
			Long wlfwSubProcessId,
			List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOList) {
		LOGGER.info("SubProcessFieldsServiceImpl : addMotorAttachmentDetailToSubProcessFields : Start");
		Long id = -1l;
		SubProcessFields subProcessFields;
		SubProcessFields savedObject = null;

		MotorAttachmentDetail motorAttachmentDetail = null;
		List<MotorAttachmentDetail> motorAttachmentDetailList = new ArrayList<MotorAttachmentDetail>();
		try {
			if (null != wlfwSubProcessId
					&& null != motorAttachmentDetailDTOList) {
				subProcessFields = subProcessFieldsRepository
						.findOne(wlfwSubProcessId);
				if (null != subProcessFields) {
					for (MotorAttachmentDetailDTO motorAttachmentDetailDTO : motorAttachmentDetailDTOList) {
						if (null != motorAttachmentDetailDTO
								.getMotorAttachmentsId()) {
							motorAttachmentDetail = motorAttachmentDetailRepository
									.findOne(motorAttachmentDetailDTO
											.getMotorAttachmentsId());
							motorAttachmentDetail
									.setUploadedOn(motorAttachmentDetail
											.getUploadedOn());
						} else {
							motorAttachmentDetailDTO.setUploadedOn(new Date());
						}
						motorAttachmentDetail = dozerBeanMapper.map(
								motorAttachmentDetailDTO,
								MotorAttachmentDetail.class);
						// set audit field
						motorAttachmentDetail.setFunctionCode(subProcessFields
								.getFunctionCode());
						motorAttachmentDetail
								.setWlfwSubProcessId(subProcessFields
										.getWlfwSubProcessId());
						motorAttachmentDetailList.add(motorAttachmentDetail);
					}
					List<MotorAttachmentDetail> existMotorAttachmentDetailList = subProcessFields
							.getMotorAttachmentDetails();
					if (null != existMotorAttachmentDetailList
							&& motorAttachmentDetailList.size() > 0) {
						motorAttachmentDetailList
								.addAll(existMotorAttachmentDetailList);
					}
					subProcessFields
							.setMotorAttachmentDetails(motorAttachmentDetailList);
					savedObject = subProcessFieldsRepository
							.save(subProcessFields);
				}
				LOGGER.info("BReportFieldsServiceImpl : addMotorAttachmentDetailToSubProcessFields : Record Saved");
				if (savedObject != null) {
					id = savedObject.getWlfwSubProcessId();
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : addMotorAttachmentDetailToSubProcessFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	@Override
	@Transactional
	public Long addMotorSparesDetailToSubProcessFields(Long wlfwSubProcessId,
			List<MotorSparesDetailDTO> motorSparesDetailDTOList) {
		LOGGER.info("SubProcessFieldsServiceImpl : addMotorSparesDetailToSubProcessFields : Start");
		Long id = -1l;
		SubProcessFields subProcessFields;
		SubProcessFields savedObject = null;

		MotorSparesDetail motorSparesDetail = null;
		List<MotorSparesDetail> motorSparesDetailList = new ArrayList<MotorSparesDetail>();
		try {
			if (null != wlfwSubProcessId && null != motorSparesDetailDTOList) {
				subProcessFields = subProcessFieldsRepository
						.findOne(wlfwSubProcessId);
				if (null != subProcessFields) {
					for (MotorSparesDetailDTO motorSparesDetailDTO : motorSparesDetailDTOList) {
						if (null != motorSparesDetailDTO.getMaterialId()) {
							motorSparesDetail = motorSparesDetailRepository
									.findOne(motorSparesDetailDTO
											.getMaterialId());
						}
						motorSparesDetail = dozerBeanMapper.map(
								motorSparesDetailDTO, MotorSparesDetail.class);
						// set audit field
						motorSparesDetail.setFunctionCode(subProcessFields
								.getFunctionCode());
						motorSparesDetail.setWlfwSubProcessId(subProcessFields
								.getWlfwSubProcessId());
						motorSparesDetailList.add(motorSparesDetail);
					}
					List<MotorSparesDetail> existMotorSparesDetailList = subProcessFields
							.getMotorSparesDetails();
					if (null != existMotorSparesDetailList
							&& motorSparesDetailList.size() > 0) {
						motorSparesDetailList
								.addAll(existMotorSparesDetailList);
					}
					subProcessFields
							.setMotorSparesDetails(motorSparesDetailList);
					savedObject = subProcessFieldsRepository
							.save(subProcessFields);
				}
				LOGGER.info("BReportFieldsServiceImpl : addMotorAttachmentDetailToSubProcessFields : Record Saved");
				if (savedObject != null) {
					id = savedObject.getWlfwSubProcessId();
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : addMotorAttachmentDetailToSubProcessFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;

	}

	/**
	 * The method add MotorOrderDetails to SubProcessDetail on the basis of its
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcessId
	 * @param motorOrderDetailDTOList
	 *            The MotorOrderDetailDTO
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long addUpdateMotorOrderDetailsToSubProcessDetail(
			Long wlfwSubProcessId,
			List<MotorOrderDetailDTO> motorOrderDetailDTOList) {
		LOGGER.info("SubProcessFieldsServiceImpl : addUpdateMotorOrderDetailsToSubProcessDetail : Start");
		Long id = -1l;
		SubProcessFields subProcessFields;
		SubProcessFields savedObject = null;

		MotorOrderDetail motorOrderDetail = null;
		List<MotorOrderDetail> motorOrderDetailList = new ArrayList<MotorOrderDetail>();
		try {
			if (null != wlfwSubProcessId && null != motorOrderDetailDTOList) {
				subProcessFields = subProcessFieldsRepository
						.findOne(wlfwSubProcessId);

				if (null != subProcessFields) {
					for (MotorOrderDetailDTO motorOrderDetailDTO : motorOrderDetailDTOList) {
						if (null != motorOrderDetailDTO.getMotorOrderDetailId()) {
							motorOrderDetail = motorOrderDetailRepository
									.findOne(motorOrderDetailDTO
											.getMotorOrderDetailId());
							if (null != motorOrderDetail) {
								motorOrderDetailDTO
										.setCreatedOn(motorOrderDetail
												.getCreatedOn());
							}
						} else {
							motorOrderDetailDTO.setCreatedOn(new Date());
						}
						motorOrderDetail = dozerBeanMapper.map(
								motorOrderDetailDTO, MotorOrderDetail.class);
						// set audit field
						motorOrderDetail.setFunctionCode(subProcessFields
								.getFunctionCode());
						motorOrderDetail.setWlfwSubProcessId(subProcessFields
								.getWlfwSubProcessId());
						motorOrderDetailList.add(motorOrderDetail);
					}
					List<MotorOrderDetail> existMotorOrderDetailList = subProcessFields
							.getMotorOrderDetails();
					if (null != existMotorOrderDetailList
							&& motorOrderDetailList.size() > 0) {
						motorOrderDetailList.addAll(existMotorOrderDetailList);
					}

					subProcessFields.setMotorOrderDetails(motorOrderDetailList);

					savedObject = subProcessFieldsRepository
							.save(subProcessFields);
				}
				LOGGER.info("SubProcessFieldsServiceImpl : addUpdateMotorOrderDetailsToSubProcessDetail : Record Saved");
				if (savedObject != null) {
					id = savedObject.getWlfwSubProcessId();
				}
			} else {
				LOGGER.info("SubProcessFieldsServiceImpl : addUpdateMotorOrderDetailsToSubProcessDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	/**
	 * The method adds FSEVisitDetail to SubProcessDetail on the basis of its
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcessId
	 * @param fSEVisitDetailDTOList
	 *            The fSEVisitDetailDTO
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long addUpdateFSEVisitDetailsToSubProcessDetail(
			Long wlfwSubProcessId, List<FSEVisitDetailDTO> fSEVisitDetailDTOList) {
		LOGGER.info("SubProcessFieldsServiceImpl : addUpdateFSEVisitDetailsToSubProcessDetail : Start");
		Long id = -1l;
		SubProcessFields subProcessFields;
		SubProcessFields savedObject = null;

		FSEVisitDetail fSEVisitDetail = null;
		List<FSEVisitDetail> fSEVisitDetailList = new ArrayList<FSEVisitDetail>();
		try {
			if (null != wlfwSubProcessId && null != fSEVisitDetailDTOList) {
				subProcessFields = subProcessFieldsRepository
						.findOne(wlfwSubProcessId);

				if (null != subProcessFields) {
					for (FSEVisitDetailDTO fSEVisitDetailDTO : fSEVisitDetailDTOList) {
						if (null != fSEVisitDetailDTO.getFseVisitDetailId()) {
							fSEVisitDetail = fSEVisitDetailRepository
									.findOne(fSEVisitDetailDTO
											.getFseVisitDetailId());
							if (null != fSEVisitDetail) {
								fSEVisitDetailDTO
										.setFseVisitPlannedDate(fSEVisitDetail
												.getFseVisitPlannedDate());
								fSEVisitDetailDTO
										.setFseVisitActualDate(new Date());
							}
						} else {

							fSEVisitDetailDTO
									.setFseVisitPlannedDate(new Date());
							fSEVisitDetailDTO.setFseVisitActualDate(new Date());
						}

						fSEVisitDetail = dozerBeanMapper.map(fSEVisitDetailDTO,
								FSEVisitDetail.class);
						// set audit field
						fSEVisitDetail.setFunctionCode(subProcessFields
								.getFunctionCode());
						fSEVisitDetail.setWlfwSubProcessId(subProcessFields
								.getWlfwSubProcessId());
						fSEVisitDetailList.add(fSEVisitDetail);
					}
					List<FSEVisitDetail> existFSEVisitDetailList = subProcessFields
							.getfSEVisitDetails();

					if (null != existFSEVisitDetailList
							&& fSEVisitDetailList.size() > 0) {
						fSEVisitDetailList.addAll(existFSEVisitDetailList);
					}

					subProcessFields.setfSEVisitDetails(fSEVisitDetailList);

					savedObject = subProcessFieldsRepository
							.save(subProcessFields);
				}
				LOGGER.info("SubProcessFieldsServiceImpl : addUpdateFSEVisitDetailsToSubProcessDetail : Record Saved");
				if (savedObject != null) {
					id = savedObject.getWlfwSubProcessId();
				}
			} else {
				LOGGER.info("SubProcessFieldsServiceImpl : addUpdateFSEVisitDetailsToSubProcessDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	/**
	 * The method adds ParallelProcess to SubProcessDetail on the basis of its
	 * wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcessId
	 * @param parallelProcessDetailDTOList
	 *            The ParallelProcessDTO
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long addParallelProcessToSubProcessField(Long wlfwSubProcessId,
			List<ParallelProcessDTO> parallelProcessDetailDTOList) {
		LOGGER.info("SubProcessFieldsServiceImpl : addParallelProcessToSubProcessDetail : Start");
		Long id = -1l;
		SubProcessFields subProcessFields;
		SubProcessFields savedObject = null;

		ParallelProcess parallelProcess = null;

		List<ParallelProcess> parallelProcessDetailList = new ArrayList<ParallelProcess>();
		try {
			if (null != wlfwSubProcessId
					&& null != parallelProcessDetailDTOList) {
				subProcessFields = subProcessFieldsRepository
						.findOne(wlfwSubProcessId);

				if (null != subProcessFields) {
					for (ParallelProcessDTO parallelProcessDetailDTO : parallelProcessDetailDTOList) {
						if (null != parallelProcessDetailDTO
								.getParallelProcessId()) {
							parallelProcess = parallelProcessRepository
									.findOne(parallelProcessDetailDTO
											.getParallelProcessThreadId());

						} else {

							parallelProcessDetailDTO.setCreatedOn(new Date());
						}
						parallelProcess = dozerBeanMapper
								.map(parallelProcessDetailDTO,
										ParallelProcess.class);
						// set audit field
						parallelProcess.setFunctionCode(subProcessFields
								.getFunctionCode());
						parallelProcess.setWlfwSubProcessId(subProcessFields
								.getWlfwSubProcessId());
						parallelProcessDetailList.add(parallelProcess);
					}

					List<ParallelProcess> existparallelProcessList = subProcessFields
							.getParallelProcess();
					if (null != existparallelProcessList
							&& parallelProcessDetailList.size() > 0) {
						parallelProcessDetailList
								.addAll(existparallelProcessList);
					}

					subProcessFields
							.setParallelProcess(parallelProcessDetailList);
					savedObject = subProcessFieldsRepository
							.save(subProcessFields);
				}
				LOGGER.info("SubProcessFieldsServiceImpl : addParallelProcessToSubProcessDetail : Record Saved");
				if (null != savedObject) {
					id = savedObject.getWlfwSubProcessId();
				}
			} else {
				LOGGER.info("SubProcessFieldsServiceImpl : addParallelProcessToSubProcessDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return id;
	}

	// get ARC ref Id by SubProcessId
	@Override
	public Long getARCRefIdBySubProcessId(Long subProcessId) {
		return subProcessFieldsRepository
				.findARCRefIdBySubProcessId(subProcessId);
	}

	@Override
	@Transactional
	public SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessIdandTenantIdandSolCatId(
			Long wlfwSubProcessId, String tenantId, String solutionCategoryId) {
		LOGGER.info("SubProcessFieldsServiceImpl : getActorFunctionMasterByFunctionIdandTenantIdandSolCatId : Start");

		SubProcessFieldsDTO subProcessFieldsDTO = null;
		SubProcessFields subProcessFieldsDetail = null;
		if (null != wlfwSubProcessId && null != tenantId
				&& null != solutionCategoryId) {
			subProcessFieldsDetail = subProcessFieldsRepository
					.findSubProcessFieldsByWlfwSubProcessIdAndTenantIdAndSolCatId(
							wlfwSubProcessId, tenantId, solutionCategoryId);
		}
		if (null != subProcessFieldsDetail) {

			subProcessFieldsDTO = new SubProcessFieldsDTO();
			subProcessFieldsDTO = dozerBeanMapper.map(subProcessFieldsDetail,
					SubProcessFieldsDTO.class);
		}
		LOGGER.info("SubProcessFieldsServiceImpl : getActorFunctionMasterByFunctionIdandTenantIdandSolCatId : End");
		return subProcessFieldsDTO;
	}

	// To check motor serial no. not in execution state or not
	private Boolean checkStateForMotorSrNo(String motorSnNum,
			Long wlfwSubProcessId, String tenantId, String solutionCategoryId) {
		boolean value = false;
		List<SubProcessFields> subProcessFieldsDetails = null;
		// SubProcessFields subProcessFieldsDetail=null;
		if (null != motorSnNum && null != tenantId
				&& null != solutionCategoryId) {
			subProcessFieldsDetails = subProcessFieldsRepository
					.findSubProcessFieldsByMotorSnNumAndTenantIdAndSolCatId(
							motorSnNum, tenantId, solutionCategoryId);
		}

		if (null != subProcessFieldsDetails) {
			for (SubProcessFields subProcessFieldsRecord : subProcessFieldsDetails) {
				if ((subProcessFieldsRecord.getMotorSnNum().equals(motorSnNum))
						&& ((subProcessFieldsRecord.getWorkflowClosureType() == 0)
								|| (subProcessFieldsRecord
										.getWorkflowClosureType() == 1) || (subProcessFieldsRecord
								.getWorkflowClosureType() == 2))
						&& (!(subProcessFieldsRecord.getWlfwSubProcessId()
								.longValue() == wlfwSubProcessId))) {
					value = true;
				}
			}
		}
		return value;
	}

	@Override
	public List<SearchByParameterDTO> searchByParameter(
			SearchByParameterDTO searchByParameterDTO) {

		List<SearchByParameterDTO> subProcessFieldList = searchFieldRepository
				.searchByParameter(searchByParameterDTO);

		return subProcessFieldList;
	}

	public SubProcessFieldsDTO getSubprocessFieldWithMotorDetailsByMasterworkflowId(
			Long processVariableId) {
		// get SubProcess list belonging to master workflow id
		List<SubProcessFields> subProcessFieldList = subProcessFieldsRepository
				.findSubProcessFieldsByMasterWorkflowId(processVariableId);
		// set MotorDetailDTO list
		SubProcessFieldsDTO subProcessFieldsDTO = null;
		List<MotorDetailsDTO> motorDetailDTOList = new ArrayList<MotorDetailsDTO>();
		for (SubProcessFields subProcessFields : subProcessFieldList) {
			subProcessFieldsDTO = dozerBeanMapper.map(subProcessFields,
					SubProcessFieldsDTO.class);
			MotorDetailsDTO motorDetailDTO = new MotorDetailsDTO();
			motorDetailDTO.setSubProcessId(subProcessFields
					.getWlfwSubProcessId());
			// motorDetailDTO.setMotorDetailsDTOList(null);
			motorDetailDTO.setFaultDesc(subProcessFieldsDTO.getFaultDesc());
			motorDetailDTO.setFrameSize(subProcessFieldsDTO.getFrameSize());
			motorDetailDTO.setInitialWarrantyClaim(subProcessFieldsDTO
					.getInitialWarrantyClaim());
			motorDetailDTO
					.setInitialWarrantyClaimSetByRefId(subProcessFieldsDTO
							.getInitialWarrantyClaimSetByRefId());
			motorDetailDTO.setMlfbSpiridon(subProcessFieldsDTO
					.getMlfbSpiridon());
			motorDetailDTO.setMotorIBaseNum(subProcessFieldsDTO
					.getMotorIBaseNum());
			motorDetailDTO.setMotorMaterialSpec(subProcessFieldsDTO
					.getMotorMaterialSpec());
			motorDetailDTO.setMotorSnNum(subProcessFieldsDTO.getMotorSnNum());
			motorDetailDTO.setMotorSpiridonMaterialCode(subProcessFieldsDTO
					.getMotorSpiridonMaterialCode());
			motorDetailDTO.setProductGrp(subProcessFieldsDTO.getProductGrp());
			motorDetailDTO.setRegionId(subProcessFieldsDTO.getRegionId());
			motorDetailDTO.setSalesDivRefId(subProcessFieldsDTO
					.getSalesDivRefId());
			motorDetailDTO.setSalesOfficeRefId(subProcessFieldsDTO
					.getSalesOfficeRefId());
			motorDetailDTO.setSalesOrgRefId(subProcessFieldsDTO
					.getSalesOrgRefId());
			// set sales group ref ID
			motorDetailDTO.setSalesGrpRefId(subProcessFieldsDTO
					.getSalesGrpRefId());
			// set group name
			if (null != subProcessFields.getSubProcessGroupDetail())
				motorDetailDTO.setGroupName(subProcessFields
						.getSubProcessGroupDetail().getGroupName());

			motorDetailDTOList.add(motorDetailDTO);
		}
		if (null != motorDetailDTOList && motorDetailDTOList.size() > 0) {
			subProcessFieldsDTO.setMotorDetailsDTOList(motorDetailDTOList);
		}
		return subProcessFieldsDTO;
	}

	@Override
	public List<RMTTaskLogDTO> getWorkLogBySubProcessFieldsBy(
			Long wlfwSubProcessId) throws SQLException {
		List<RMTTaskLogDTO> RMTTaskLogs = new ArrayList<RMTTaskLogDTO>();

		SimpleDateFormat out = new SimpleDateFormat("dd MMM yyyy, hh:mma");

		Map<String, List<RMTAuditDTO>> taskLogs = auditLogRepository
				.fetchAuditLogsBySubprocessId(wlfwSubProcessId);

		List<CommentsDTO> comments = commentsService
				.getCommentsByTenantIdNSolnCatNSubProcessId(wlfwSubProcessId,
						MotorRepairConstants.TENANT_ID,
						MotorRepairConstants.PROGRAM_ID, null);

		List<BenchmarksDTO> benchMarks = benchmarksService
				.getBenchmarksBySubprocessId(wlfwSubProcessId.toString());

		Map<String, List<RMTCommentDTO>> commentMap = new HashMap<String, List<RMTCommentDTO>>();
		for (CommentsDTO comment : comments) {
			String key = comment.getTaskCode() + "-" + comment.getTaskRefId();

			RMTCommentDTO rmt_comment = new RMTCommentDTO();
			rmt_comment.setDescription(comment.getComment_text());
			rmt_comment.setCommentedOn(out.format(comment
					.getComment_timestamp()));
			rmt_comment.setType(MotorRepairConstants.COMMENT_TYPE.of(
					comment.getCommentType()).toString());
			List<RMTCommentDTO> list = null;
			if (commentMap.containsKey(key)) {
				list = commentMap.get(key);
				list.add(rmt_comment);
			} else {
				list = new ArrayList<RMTCommentDTO>();
				list.add(rmt_comment);

			}
			commentMap.put(key, list);

		}
		Map<String, RMTTaskLogDTO> benchMarksMap = new LinkedHashMap<String, RMTTaskLogDTO>();

		if (null != benchMarks) {
			RMTTaskLogDTO task = null;
			// String taskCode = null;

			for (BenchmarksDTO benchmark : benchMarks) {

				if ((benchmark.getTaskId()).matches("^\\d+$")
						|| benchmark.getTaskId().equals("initialProcessing")
						|| benchmark.getTaskId().equals(
								"invokeConsolidationWorkflow")) {

					String userName = null;
					String uniqueTaskKey = null;
					if (benchmark.getTaskCode().equals(
							MotorRepairConstants.CCC_CLOSURE_VERIFY_CUST)
							|| benchmark.getTaskCode().equals(
									MotorRepairConstants.SYS_MULTIPLE_WORKFLOW)) {
						uniqueTaskKey = benchmark.getTaskCode();

					} else {
						uniqueTaskKey = benchmark.getTaskCode() + "-"
								+ benchmark.getTaskId();
					}

					if (benchMarksMap.containsKey(uniqueTaskKey)) {
						task = benchMarksMap.get(uniqueTaskKey);
						RMTTaskLogs.remove(task);
					} else {
						task = new RMTTaskLogDTO();
					}
					if ((benchmark.getBenchmarkState()
							.equals(MotorRepairConstants.BENCHMARK_STATE.ASSIGNED
									.getValue()))
							&& benchmark.getBenchmarkTimestamp() != null) {
						task.setAssignedOn(out.format(benchmark
								.getBenchmarkTimestamp()));
						task.setAssignedPriority(benchmark.getTaskPriority());
						if (benchmark.getActionByRefId().equalsIgnoreCase(
								MotorRepairConstants.ARC)) {
							task.setOwnedOn(out.format(benchmark
									.getBenchmarkTimestamp()));
							task.setOwnedPriority(benchmark.getTaskPriority());
						}
					}

					if ((benchmark.getBenchmarkState()
							.equals(MotorRepairConstants.BENCHMARK_STATE.OWNED
									.getValue()))
							&& benchmark.getBenchmarkTimestamp() != null) {
						task.setOwnedOn(out.format(benchmark
								.getBenchmarkTimestamp()));
						task.setOwnedPriority(benchmark.getTaskPriority());
					}
					if ((benchmark.getBenchmarkState()
							.equals(MotorRepairConstants.BENCHMARK_STATE.COMPLETED
									.getValue()))
							&& benchmark.getBenchmarkTimestamp() != null) {

						task.setClosedOn(out.format(benchmark
								.getBenchmarkTimestamp()));
						task.setClosedPriority(benchmark.getTaskPriority());

						if (benchmark.getTaskCode().equals(
								MotorRepairConstants.SYS_MULTIPLE_WORKFLOW)
								|| benchmark
										.getTaskCode()
										.equals(MotorRepairConstants.CCC_NEW_SERVICE_REC_MOTOR)) {
							task.setAssignedOn(out.format(benchmark
									.getBenchmarkTimestamp()));
							task.setAssignedPriority(benchmark
									.getTaskPriority());
							task.setOwnedOn(out.format(benchmark
									.getBenchmarkTimestamp()));
							task.setOwnedPriority(benchmark.getTaskPriority());
						}

					}

					if (null != benchmark.getMilestones()) {
						task.setMilestone(benchmark.getMilestones()
								.getMilestoneName());
					}
					if (benchmark
							.getBenchmarkState()
							.equals(MotorRepairConstants.BENCHMARK_STATE.CUSTOMER_NOTIFICATION
									.getValue())) {
						task.setIsCustomerNotified(true);
					}

					task.setEscalationLevel(benchmark.getSlaState());
					task.setAuditLogs(taskLogs.get(benchmark.getTaskCode()));
					task.setTaskName(benchmark.getBenchmarkName());
					task.setComments(commentMap.get(uniqueTaskKey));
					task.setTaskCode(benchmark.getTaskCode());
					task.setParallelProcessId(benchmark.getParallelProcessId());
					task.setGroup(benchmark.getActionByRefId());
					if (null != task.getAuditLogs()
							&& task.getAuditLogs().size() > 0) {
						for (RMTAuditDTO audit : task.getAuditLogs()) {
							if (null != audit.getUserName()) {
								userName = audit.getUserName();
								break;
							}
						}
					}
					task.setUserName(userName != null ? userName : "");
					task.setTaskId(benchmark.getTaskId());

					RMTTaskLogs.add(task);
					benchMarksMap.put(uniqueTaskKey, task);

				}
			}
		}

		return RMTTaskLogs;

	}

	/**
	 * The deletes a MultipleSubProcessFields on the basis its wlfwSubProcessId.
	 * 
	 * @param wlfwSubProcessId
	 *            The WlfwSubProcess Id
	 * @return Boolean
	 * 
	 */

	@Override
	@Transactional
	public Boolean deleteMultipleSubProcessFieldsForGroup(
			List<Long> subprocessIdList) {
		LOGGER.info("SubProcessFieldsServiceImpl : deleteMultipleSubProcessFieldsForGroup : Start");
		boolean returnVal = false;
		Long groupId = -1l;
		try {
			if (null != subprocessIdList && subprocessIdList.size() > 0) {
				groupId = subProcessFieldsRepository
						.findSubProcessFieldsGroupIdBywlfwSubProcessId(subprocessIdList
								.get(0));
				for (Long wlfwSubProcessId : subprocessIdList) {
					subProcessFieldsRepository.delete(wlfwSubProcessId);

					returnVal = true;
				}
				groupDetailRepository.delete(groupId);
			} else {
				LOGGER.info("SubProcessFieldsServiceImpl : deleteMultipleSubProcessFieldsForGroup : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}