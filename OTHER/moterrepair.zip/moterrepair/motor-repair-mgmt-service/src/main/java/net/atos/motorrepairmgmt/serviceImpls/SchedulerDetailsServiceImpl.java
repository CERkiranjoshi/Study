package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;
import net.atos.motorrepairmgmt.entity.SchedulerDetails;
import net.atos.motorrepairmgmt.repository.SchedulerDetailsRepository;
import net.atos.motorrepairmgmt.services.SchedulerDetailsService;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603975
 * 
 */

@Service
public class SchedulerDetailsServiceImpl implements SchedulerDetailsService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	@Autowired
	private SchedulerDetailsRepository schedulerDetailsRepository;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(SchedulerDetailsServiceImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.SchedulerDetailsService#createUpdateSchedulerDetails(net.atos.motorrepairmgmt
	 * .dto.SchedulerDetailsDTO)
	 */
	@Override
	@Transactional
	public String createUpdateSchedulerDetails(SchedulerDetailsDTO schedulerDetailsDTO) {
		String id = null;
		// create operation
		if (null == schedulerDetailsDTO.getSchedulerId()) {
			// set id
			schedulerDetailsDTO.setSchedulerId(uniqueIdGenerator.generateUniqueId());
		}
		// convert dto to entity
		SchedulerDetails schedulerDetail = dozerBeanMapper.map(schedulerDetailsDTO, SchedulerDetails.class);
		schedulerDetail = schedulerDetailsRepository.save(schedulerDetail);
		id = schedulerDetail.getSchedulerId();
		return id;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.atos.motorrepairmgmt.services.SchedulerDetailsService#getAllSchedulerDetails()
	 */
	@Override
	@Transactional
	public List<SchedulerDetailsDTO> getAllSchedulerDetails() {
		// get all scheduler details
		List<SchedulerDetails> schedulerDetailList = schedulerDetailsRepository.findAll();
		List<SchedulerDetailsDTO> schedulerDetailDTOList = new ArrayList<SchedulerDetailsDTO>();
		for (SchedulerDetails schedulerDetails : schedulerDetailList) {
			schedulerDetailDTOList.add(dozerBeanMapper.map(schedulerDetails, SchedulerDetailsDTO.class));
		}
		return schedulerDetailDTOList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.atos.motorrepairmgmt.services.SchedulerDetailsService#
	 * getSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	@Transactional
	public SchedulerDetailsDTO getSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(String schedulerDetailsId,
			String tenantId, String solutionCategoryId) {
		SchedulerDetails schedulerDetail = schedulerDetailsRepository
				.findSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(schedulerDetailsId, tenantId,
						solutionCategoryId);
		return dozerBeanMapper.map(schedulerDetail, SchedulerDetailsDTO.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.SchedulerDetailsService#getSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId
	 * (java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<SchedulerDetailsDTO> getSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId(Long subprocessId,
			String tenantId, String solutionCategoryId) {
		List<SchedulerDetails> schedulerDetailList = schedulerDetailsRepository
				.findSchedulerDetailsBySubprocessIdAndTenantIdAndSolCatId(subprocessId, tenantId, solutionCategoryId);
		List<SchedulerDetailsDTO> schedulerDetailDTOList = new ArrayList<SchedulerDetailsDTO>();
		for (SchedulerDetails schedulerDetails : schedulerDetailList) {
			schedulerDetailDTOList.add(dozerBeanMapper.map(schedulerDetails, SchedulerDetailsDTO.class));
		}
		return schedulerDetailDTOList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.SchedulerDetailsService#getAllSchedulerDetailsByTenantIdAndSolCatId(java.lang
	 * .String, java.lang.String)
	 */
	@Override
	public List<SchedulerDetailsDTO> getAllSchedulerDetailsByTenantIdAndSolCatId(String tenantId,
			String solutionCategoryId) {
		List<SchedulerDetails> schedulerDetailList = schedulerDetailsRepository
				.findSchedulerDetailsByTenantIdAndSolCatId(tenantId, solutionCategoryId);
		List<SchedulerDetailsDTO> schedulerDetailDTOList = new ArrayList<SchedulerDetailsDTO>();
		for (SchedulerDetails schedulerDetails : schedulerDetailList) {
			schedulerDetailDTOList.add(dozerBeanMapper.map(schedulerDetails, SchedulerDetailsDTO.class));
		}
		return schedulerDetailDTOList;
	}

	
	
	/* (non-Javadoc)
	 * @see net.atos.motorrepairmgmt.services.SchedulerDetailsService#getAllPendingSchedulerDetailsByTenantIdAndSolCatId(java.lang.String, java.lang.String)
	 */
	@Override
	public List<SchedulerDetailsDTO> getAllPendingSchedulerDetailsByTenantIdAndSolCatId(String tenantId,
			String solutionCategoryId) {
		List<SchedulerDetails> schedulerDetailList = schedulerDetailsRepository
				.findPendingSchedulerDetailsByTenantIdAndSolCatId(tenantId, solutionCategoryId);
		List<SchedulerDetailsDTO> schedulerDetailDTOList = new ArrayList<SchedulerDetailsDTO>();
		for (SchedulerDetails schedulerDetails : schedulerDetailList) {
			schedulerDetailDTOList.add(dozerBeanMapper.map(schedulerDetails, SchedulerDetailsDTO.class));
		}
		return schedulerDetailDTOList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.motorrepairmgmt.services.SchedulerDetailsService#deleteSchedulerDetailsBySchedulerDetailsId(java.lang
	 * .Long)
	 */
	@Override
	public Boolean deleteSchedulerDetailsBySchedulerDetailsId(String schedulerDetailsId) {
		Boolean response = false;
		try {
			schedulerDetailsRepository.delete(schedulerDetailsId);
			response = true;
		} catch (IllegalArgumentException ex) {
			LOGGER.error("Error while deleting Scheduler Details", ex);

		}
		return response;
	}

}
