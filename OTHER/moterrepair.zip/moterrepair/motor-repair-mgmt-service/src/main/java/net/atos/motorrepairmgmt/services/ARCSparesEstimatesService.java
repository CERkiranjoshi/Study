package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;

/**
 * @author a610051
 * 
 */
public interface ARCSparesEstimatesService {

	Long createUpdateARCSparesEstimates(ARCSparesEstimatesDTO arcSparesEstimatesDTO);

	Boolean deleteARCSparesEstimatesByARCSparesEstimateId(Long arcSparesEstimateId);

	ARCSparesEstimatesDTO getARCSparesEstimatesByARCSparesEstimateId(Long arcSparesEstimateId);

	List<ARCSparesEstimatesDTO> getAllARCSparesEstimates();
}
