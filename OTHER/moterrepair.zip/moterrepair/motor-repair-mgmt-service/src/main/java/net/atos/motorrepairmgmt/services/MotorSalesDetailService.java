package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSalesDetailDTO;

public interface MotorSalesDetailService {

	public Long createUpdateMotorSalesDetail(MotorSalesDetailDTO motorSalesDetailDTO);

	public List<MotorSalesDetailDTO> getAllMotorSalesDetailByTenantId(String tenantId);

	public MotorSalesDetailDTO getMotorSalesDetailByMotorSalesDetailId(Long motorSalesDetailId);

	public List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryId(String tenantId,
			String solutionCategoryId);

	public List<MotorSalesDetailDTO> getMotorSalesDetailByTenantIdAndSolutionCategoryIdAndSalesType(String tenantId,
			String solutionCategoryId, Integer salesType);

	public Boolean deleteMotorSalesDetailByMotorSalesDetailId(Long motorSalesDetailId);
}
