package net.atos.motorrepairmgmt.services;


import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;

import org.springframework.web.multipart.MultipartFile;

public interface UploadAttachmentsService {

	
	List<MotorAttachmentDetailDTO> uploadDocument(MultipartFile file,Long wlfwSubProcessId,String description,String uploadedBy,Integer attachmentType,String tenantId,String solCatId,Integer isInternal,Integer methodCallValue);
	
	List<MotorAttachmentDetailDTO> uploadDocumentForMultipleSubprocess(MultipartFile file,String description,String uploadedBy,Integer attachmentType,String tenantId,String solCatId,Integer isInternal,Long masterWorkflowFieldId,Integer methodCallValue);
	
	boolean deleteFile(Long motorAttachmentsId, String deletedBy);
	
	void downloadDocument(HttpSession session,HttpServletResponse response,Long motorAttachmentsId);
	
	public List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetailBySubprocesssId(Long wlfwSubProcessId,Boolean external, String uploadedBy);
	
	boolean deleteDocumentForMultipleSubprocess(Long motorAttachmentsId, String deletedBy);
}
