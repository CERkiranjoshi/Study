/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.listeners;

import java.util.Date;
import net.atos.motorrepairmgmt.services.NotificationService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants.BENCHMARK_STATE;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants.FUNCTION_ENABLED_FLAG;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.singetons.TaskSLAManager;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.context.SpringApplicationContext;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.BenchmarksDTO;
import net.atos.taskmgmt.service.ActorFunctionMasterService;
import net.atos.taskmgmt.service.BenchmarksService;
import net.atos.taskmgmt.service.MatricesMasterService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.impl.el.FixedValue;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;

/**
 * @author Sweety Kothari
 * 
 */
public class NotificationHandlerListener implements ExecutionListener {

	/**
	 * Logger for logging
	 */
	private static final Logger LOGGER = Logger.getLogger(NotificationHandlerListener.class);

	/**
	 * 
	 */
	private static final long serialVersionUID = 1123536L;

	private Expression templateCode;

	private Expression notifyType;

	private FixedValue benchmarkType;

	private FixedValue benchmarkName;
	/**
	 * Benchmark Service to insert into benchmark table
	 */
	private BenchmarksService benchmarkService;

	/**
	 * Milestone service to insert into milestone
	 */
	private MatricesMasterService matricesMasterService;

	/**
	 * Actor Function Master service to fetch details of the function from
	 */
	private ActorFunctionMasterService actorFunctionMasterService;

	/**
	 * Task SLA Manager
	 */
	private TaskSLAManager taskSLAManager;

	/**
	 * Unique Id Generator
	 */
	private UniqueIdGenerator uniqueIdGenerator;

	@Override
	public void notify(DelegateExecution execution) throws Exception {

		// check for notify flag if checked then only send mail else dont
		if (null != execution.getVariable(ActivitiConstants.NOTIFY)
				&& Integer.parseInt((execution.getVariable(ActivitiConstants.NOTIFY).toString())) == 1) {
			ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();

			// Fetch function details
			NotificationService notificationService = applicationContext.getBean(NotificationService.class);

			LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
					+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
					+ "; NOTIFICATION_HANDLER_LISTENER: START " + execution.getId());

			if (templateCode != null) {
				execution.setVariableLocal(MotorRepairConstants.TEMPLATE_CODE, templateCode.getExpressionText());
			}
			if ((null != notifyType) && null != notifyType.getExpressionText())
				execution.setVariableLocal(MotorRepairConstants.NOTIFY_TYPE,
						Integer.parseInt(notifyType.getExpressionText()));

			Long subProcessId = (Long) execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID);
			if (null != execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)) {
				subProcessId = Long.valueOf(execution.getVariable(ActivitiConstants.SUB_PROCESS_ID).toString());
			}
			String functionCode = null;
			String arcRefId = null;
			String assignedToStr = null;
			String batchProcessId = null;
			String masterProcessId = null;
			String subReferenceId = null;
			String taskPriority = null;
			Object assigned = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO);
			if (null == assigned) {
				assignedToStr = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP).toString();
			} else {
				assignedToStr = assigned.toString();
			}
			String tenantId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString();
			String programId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROGRAM_ID).toString();
			// TODO remove when testing is done
			if ((null != execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID))
					&& (null != execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID))
					&& (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID))) {
				batchProcessId = execution.getVariable(ActivitiConstants.BATCH_PROCESS_ID).toString();
				masterProcessId = execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID).toString();
				subReferenceId = execution.getVariable(ActivitiConstants.GSP_REF_NO).toString();
				taskPriority = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_PRIORITY).toString();
			}
			// TODO SET taskStatus
			String taskStatus = null;
			Long parallelProcessThreadId = null;
			String taskId = null;
			if (null != execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TASK_ID)) {
				taskId = execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TASK_ID).toString();
			}
			if (null == taskId) {
				taskId = execution.getCurrentActivityId();
			}
			if (null != execution.getVariable(ActivitiConstants.PARALLEL_PROCESS_THREAD_ID)) {
				parallelProcessThreadId = Long.parseLong(execution.getVariable(
						ActivitiConstants.PARALLEL_PROCESS_THREAD_ID).toString());
			}
			if (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) {
				functionCode = execution.getVariable(ActivitiConstants.FUNCTION_CODE).toString();
			} else {
				LOGGER.warn("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; Function Code is null");
			}
			if (null != execution.getVariableLocal(MotorRepairConstants.TEMPLATE_CODE)
					&& null != execution.getVariable(MotorRepairConstants.ASSIGNED_TO_GROUP)) {
				String templateCodeStr = execution.getVariableLocal(MotorRepairConstants.TEMPLATE_CODE).toString();
				String groupName = execution.getVariable(MotorRepairConstants.ASSIGNED_TO_GROUP).toString();
				if (execution.getVariable(MotorRepairConstants.ARC_REF_ID) != null) {
					arcRefId = execution.getVariable(MotorRepairConstants.ARC_REF_ID).toString();
				}
				LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
						+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
						+ "; Function Code:" + functionCode + "- Template Code:" + templateCodeStr);
				notificationService.triggerCustomerNotification(functionCode, templateCodeStr, subProcessId, groupName,
						arcRefId);
				// LOG BENCHMARK
				logBenchmark(functionCode, execution.getProcessInstanceId(), assignedToStr, taskId, tenantId,
						execution.getId(), batchProcessId, masterProcessId, subProcessId.toString(), subReferenceId,
						taskPriority, taskStatus, false, programId, parallelProcessThreadId);
			}

			LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
					+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)
					+ "; NOTIFICATION_HANDLER_LISTENER: END " + execution.getId());
		} else {
			LOGGER.info("subprocessId: " + execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)
					+ "; masterWorkflowId: " + execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID) + ";"
					+ " NOTIFICATION_HANDLER_LISTENER: END " + execution.getId()
					+ " Send Communication flag  NOTIFY is " + execution.getVariable(ActivitiConstants.NOTIFY));
		}
	}

	/**
	 * @return the notifyType
	 */
	public Expression getNotifyType() {
		return notifyType;
	}

	/**
	 * @param notifyType
	 *            the notifyType to set
	 */
	public void setNotifyType(Expression notifyType) {
		this.notifyType = notifyType;
	}

	/**
	 * @return the templateCode
	 */
	public Expression getTemplateCode() {
		return templateCode;
	}

	/**
	 * @param templateCode
	 *            the templateCode to set
	 */
	public void setTemplateCode(FixedValue templateCode) {
		this.templateCode = templateCode;
	}

	private String logBenchmark(String functionCode, String processInstanceId, String assigned, String taskId,
			String tenantId, String executionId, String batchProcessId, String masterProcessId, String subProcessId,
			String refId, String taskPriority, String taskStaus, boolean checkForMilestone, String programId,
			Long parallelProcessThreadId) {

		// Insert into DB
		BenchmarksDTO benchmarksDTO = new BenchmarksDTO();

		ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();

		// Fetch function details
		actorFunctionMasterService = applicationContext.getBean(ActorFunctionMasterService.class);

		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);

		if (null != actorFunctionMasterDTO) {

			if (FUNCTION_ENABLED_FLAG.TRUE.getValue() == actorFunctionMasterDTO.getFunctionEnabled()) {

				benchmarksDTO.setBenchmarkName(actorFunctionMasterDTO.getFunctionName());

				benchmarksDTO.setBenchmarkState(MotorRepairConstants.BENCHMARK_STATE.CUSTOMER_NOTIFICATION.getValue());

				benchmarksDTO.setProcessInstanceId(processInstanceId);

				// Set other params
				benchmarksDTO.setBatchProcessId(batchProcessId);
				benchmarksDTO.setActionByRefId(assigned);
				benchmarksDTO.setBenchmarkTimestamp(new Date());
				benchmarksDTO.setMastProcessId(masterProcessId);

				// TODO set proper SLA based on process variable
				benchmarksDTO.setSlaState(MotorRepairConstants.FUNCTION_SLA_STATE.IN_SLA.getValue());

				benchmarksDTO.setSubProcessId(subProcessId);
				benchmarksDTO.setSubReferenceId(refId);

				// set task_status, task_code, task_priority
				benchmarksDTO.setTaskCode(actorFunctionMasterDTO.getFunctionCode());
				benchmarksDTO.setTaskId(taskId);
				benchmarksDTO.setTaskPriority(taskPriority);
				benchmarksDTO.setTaskStaus(taskStaus);
				benchmarksDTO.setTenantId(tenantId);
				benchmarksDTO.setSolutionCategoryId(programId);
				// set parallel process Id
				benchmarksDTO.setParallelProcessId(parallelProcessThreadId);

				taskSLAManager = applicationContext.getBean(TaskSLAManager.class);
				uniqueIdGenerator = applicationContext.getBean(UniqueIdGenerator.class);

				// Initialize benchmark service
				benchmarkService = applicationContext.getBean(BenchmarksService.class);
				// Insert into benchmark table
				String benchmarkId = benchmarkService.createUpdateBenchmarks(benchmarksDTO);
				if (null == benchmarkId) {
					LOGGER.warn("NotificationHandlerListener: Some error in setting benchmark for executionId: "
							+ executionId);
				}

				return benchmarkId;

			} else {
				LOGGER.warn("NotificationHandlerListener: Function for functionCode: " + functionCode
						+ " is disabled!! No benchmarks would be inserted");
			}
		} else {
			LOGGER.warn("NotificationHandlerListener: No Functions found for functionCode: " + functionCode);
		}
		return null;

	}

	/**
	 * @return the benchmarkType
	 */
	public FixedValue getBenchmarkType() {
		return benchmarkType;
	}

	/**
	 * @param benchmarkType
	 *            the benchmarkType to set
	 */
	public void setBenchmarkType(FixedValue benchmarkType) {
		this.benchmarkType = benchmarkType;
	}

	/**
	 * @return the benchmarkName
	 */
	public FixedValue getBenchmarkName() {
		return benchmarkName;
	}

	/**
	 * @param benchmarkName
	 *            the benchmarkName to set
	 */
	public void setBenchmarkName(FixedValue benchmarkName) {
		this.benchmarkName = benchmarkName;
	}

}
