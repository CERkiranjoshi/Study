/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;
import net.atos.motorrepairmgmt.dto.BReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.entity.ARCRepairEstimates;
import net.atos.motorrepairmgmt.entity.ARCSparesEstimates;
import net.atos.motorrepairmgmt.entity.BReportFields;
import net.atos.motorrepairmgmt.entity.ElectricalObservation;
import net.atos.motorrepairmgmt.entity.MotorNamePlateDetail;
import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import net.atos.motorrepairmgmt.entity.MotorVoltageDetail;
import net.atos.motorrepairmgmt.entity.SubProcessFields;
import net.atos.motorrepairmgmt.repository.ARCRepairEstimatesRepository;
import net.atos.motorrepairmgmt.repository.ARCSparesEstimatesRepository;
import net.atos.motorrepairmgmt.repository.BReportFieldsRepository;
import net.atos.motorrepairmgmt.repository.ElectricalObservationRepository;
import net.atos.motorrepairmgmt.repository.MotorNamePlateDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorSpeedDetailRepository;
import net.atos.motorrepairmgmt.repository.MotorVoltageDetailRepository;
import net.atos.motorrepairmgmt.repository.SubProcessFieldsRepository;
import net.atos.motorrepairmgmt.services.BReportFieldsService;
import net.atos.motorrepairmgmt.utils.MotorRepairException;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603327
 * 
 */

@Component
public class BReportFieldsServiceImpl implements BReportFieldsService {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(BReportFieldsServiceImpl.class);

	/**
	 * The Dozer Bean Mapper
	 */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The BReportFields Repository */
	@Autowired
	private BReportFieldsRepository bReportFieldsRepository;

	/** The SubProcessFields Repository */
	@Autowired
	private SubProcessFieldsRepository subProcessFieldsRepository;

	/** The MotorVoltageDetail Repository */
	@Autowired
	private MotorVoltageDetailRepository motorVoltageDetailRepository;

	/** The MotorNamePlateDetail Repository */
	@Autowired
	private MotorNamePlateDetailRepository motorNamePlateDetailRepository;

	/** The ElectricalObservation Repository */
	@Autowired
	private ElectricalObservationRepository electricalObservationRepository;

	/** The ARCRepairEstimates Repository */
	@Autowired
	private ARCRepairEstimatesRepository aRCRepairEstimatesRepository;

	/** The ARCSparesEstimates Repository */
	@Autowired
	private ARCSparesEstimatesRepository aRCSparesEstimatesRepository;

	/** The MotorSpeedDetail Repository */
	@Autowired
	private MotorSpeedDetailRepository motorSpeedDetailRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	public String value;

	/**
	 * The method retrieves all the BReportFields
	 * 
	 * @return List of BReportFields DTOs
	 * 
	 */
	@Override
	@Transactional
	public List<BReportFieldsDTO> getAllBReportFields() {
		value = "harshad";
		LOGGER.info("BReportFieldsServiceImpl : getAllBReportFields : Start");
		List<BReportFieldsDTO> bReportFieldsDTOs = null;
		List<BReportFields> bReportFieldsDetails = bReportFieldsRepository.findAll();
		if (null != bReportFieldsDetails) {
			bReportFieldsDTOs = new ArrayList<BReportFieldsDTO>();
			for (BReportFields bReportFieldsRecord : bReportFieldsDetails) {
				BReportFieldsDTO bReportFieldsDTO = new BReportFieldsDTO();
				bReportFieldsDTO = dozerBeanMapper.map(bReportFieldsRecord, BReportFieldsDTO.class);
				bReportFieldsDTOs.add(bReportFieldsDTO);
			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getAllBReportFields : End");
		return bReportFieldsDTOs;
	}

	/**
	 * The method retrieves a BReportFields on the basis of bReportField Id.
	 * 
	 * @param bReportField
	 *            id The BReportFields bReportFieldId
	 * @return BReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public BReportFieldsDTO getBReportFieldsByBReportFieldId(Long bReportFieldId) {
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsByBReportFieldId : Start");
		BReportFieldsDTO bReportFieldsDTO = null;
		if (null != bReportFieldId) {
			BReportFields bReportFieldsDetails = bReportFieldsRepository.findOne(bReportFieldId);
			if (null != bReportFieldsDetails) {
				bReportFieldsDTO = dozerBeanMapper.map(bReportFieldsDetails, BReportFieldsDTO.class);
			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsByBReportFieldId : End");
		return bReportFieldsDTO;
	}

	/**
	 * The deletes a BReportFields on the basis its bReportField Id.
	 * 
	 * @param bReportFieldId
	 *            The BReportFields bReportFieldId
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteBReportFieldsByBReportFieldId(Long bReportFieldId) {
		LOGGER.info("BReportFieldsServiceImpl : deleteBReportFieldsByBReportFieldId : Start");
		Boolean returnVal = false;
		if (null != bReportFieldId) {
			try {
				bReportFieldsRepository.delete(bReportFieldId);
				returnVal = true;

			} catch (Exception e) {
				LOGGER.error("Exception ", e);
			}
		} else {
			LOGGER.info("BReportFieldsServiceImpl : deleteBReportFieldsByBReportFieldId : Not Deleted");
		}
		LOGGER.info("BReportFieldsServiceImpl : deleteBReportFieldsByBReportFieldId : Deleted");
		return returnVal;
	}

	/**
	 * The method retrieves a MotorVoltageDetail on the basis of bReportField Id.
	 * 
	 * @param bReportField
	 *            id The MotorVoltageDetail bReportFieldId
	 * @return MotorVoltageDetailDTO
	 * 
	 */
	@Override
	public MotorVoltageDetailDTO getVoltageDetailByBreportId(Long bReportFieldId) {
		LOGGER.info("BReportFieldsServiceImpl : getVoltageDetailByBreportId() : Start");
		List<MotorVoltageDetail> motorVoltageDetailDetails = new ArrayList<MotorVoltageDetail>();
		MotorVoltageDetailDTO motorVoltageDetailDTO = null;
		if (null != bReportFieldId) {
			motorVoltageDetailDetails = bReportFieldsRepository
					.findMotorVoltageDetailListByBReportField(bReportFieldId);
			if (null != motorVoltageDetailDetails) {
				for (MotorVoltageDetail motorVoltageDetailRecord : motorVoltageDetailDetails) {
					motorVoltageDetailDTO = dozerBeanMapper.map(motorVoltageDetailRecord, MotorVoltageDetailDTO.class);
				}

			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getVoltageDetailByBreportId() : End");
		return motorVoltageDetailDTO;
	}

	/**
	 * The method retrieves a MotorSpeedDetail on the basis of bReportField Id.
	 * 
	 * @param bReportField
	 *            id The MotorSpeedDetail bReportFieldId
	 * @return MotorSpeedDetailDTO
	 * 
	 */
	@Override
	public List<MotorSpeedDetailDTO> getSpeedDetailByBReportId(Long bReportFieldId) {
		LOGGER.info("BReportFieldsServiceImpl : getSpeedDetailByBReportId() : Start");
		List<MotorSpeedDetailDTO> motorSpeedDetailDTOs = new ArrayList<MotorSpeedDetailDTO>();
		List<MotorSpeedDetail> motorSpeedDetailDetails = new ArrayList<MotorSpeedDetail>();
		MotorSpeedDetailDTO motorSpeedDetailDTO = null;
		if (null != bReportFieldId) {
			motorSpeedDetailDetails = bReportFieldsRepository.findMotorSpeedDetailListByBReportField(bReportFieldId);
			for (MotorSpeedDetail motorSpeedDetailRecord : motorSpeedDetailDetails) {
				motorSpeedDetailDTO = new MotorSpeedDetailDTO();
				motorSpeedDetailDTO = dozerBeanMapper.map(motorSpeedDetailRecord, MotorSpeedDetailDTO.class);
				motorSpeedDetailDTOs.add(motorSpeedDetailDTO);

			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getSpeedDetailByBReportId() : End");
		return motorSpeedDetailDTOs;
	}

	/**
	 * The method retrieves a MotorNamePlateDetail on the basis of bReportField Id.
	 * 
	 * @param bReportField
	 *            id The MotorNamePlateDetail bReportFieldId
	 * @return MotorNamePlateDetailDTO
	 * 
	 */
	@Override
	public MotorNamePlateDetailDTO getNamePlateByBreportId(Long bReportFieldId) {
		LOGGER.info("BReportFieldsServiceImpl : getNamePlateByBreportId() : Start");
		List<MotorNamePlateDetail> motorNamePlateDetailDetails = new ArrayList<MotorNamePlateDetail>();
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		if (null != bReportFieldId) {
			motorNamePlateDetailDetails = bReportFieldsRepository
					.findMotorNamePlateDetailListByBReportField(bReportFieldId);
			if (null != motorNamePlateDetailDetails) {
				for (MotorNamePlateDetail motorNamePlateDetailRecord : motorNamePlateDetailDetails) {
					motorNamePlateDetailDTO = dozerBeanMapper.map(motorNamePlateDetailRecord,
							MotorNamePlateDetailDTO.class);
				}

			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getNamePlateByBreportId() : End");
		return motorNamePlateDetailDTO;
	}

	/**
	 * The method retrieves a BReportFields on the basis of SubProcess Id.
	 * 
	 * @param wlfwSubProcessId
	 *            The wlfwSubProcessId
	 * @return BReportFieldsDTO
	 * 
	 */
	@Override
	@Transactional
	public BReportFieldsDTO getBReportFieldsBySubProcessId(Long wlfwSubProcessId) {
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsBySubProcessId : Start");

		BReportFieldsDTO bReportFieldsDTO = null;
		if (null != wlfwSubProcessId) {
			BReportFields bReportFieldsDetail = bReportFieldsRepository
					.findBReportFieldsBySubProcessId(wlfwSubProcessId);
			if (null != bReportFieldsDetail) {
				bReportFieldsDTO = new BReportFieldsDTO();
				bReportFieldsDTO = dozerBeanMapper.map(bReportFieldsDetail, BReportFieldsDTO.class);
				bReportFieldsDTO.setFunctionCode(bReportFieldsDetail.getFunctionCode());
			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsBySubProcessId : End");
		return bReportFieldsDTO;
	}

	/**
	 * The method creates/updates a bReportFields record. The method performs an update operation when bReportField Id
	 * is passed and an existing record with matching bReportField Id is fetched for updation.
	 * 
	 * @param bReportFieldsDTO
	 *            The BReportFields Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public BReportFieldsDTO createUpdateBReportFields(BReportFieldsDTO bReportFieldsDTO) throws MotorRepairException{
		LOGGER.info("BReportFieldsServiceImpl : createUpdateBReportFields : Start");
		BReportFields bReportFieldsDetails = new BReportFields();
		MotorVoltageDetailDTO motorVoltageDetailDTO = null;
		MotorNamePlateDetailDTO motorNamePlateDetailDTO = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		ElectricalObservationDTO electricalObservationDTO = null;
		ElectricalObservation electricalObservationDetail = null;
		MotorVoltageDetail motorVoltageDetail = null;
		//Long returnId = -1l;
		try {
			
			if (null != bReportFieldsDTO) {
				if (null != bReportFieldsDTO.getbReportFieldId()) {
					bReportFieldsDetails = bReportFieldsRepository.findOne(bReportFieldsDTO.getbReportFieldId());
					if (null != bReportFieldsDetails) {
						bReportFieldsDTO.setModifiedOn(new Date());
						//bReportFieldsDTO.setFunctionCode(bReportFieldsDetails.getFunctionCode());
						// bReportFieldsDTO.setCreatedOn(bReportFieldsDetails.getCreatedOn());
					}
				} 
				
				if(null==bReportFieldsDetails)
				  {
						bReportFieldsDetails = new BReportFields();
					}

				if (null != bReportFieldsDTO.getSubProcessFields()) {
					SubProcessFieldsDTO subProcessFieldsDTO = bReportFieldsDTO.getSubProcessFields();
					SubProcessFields subProcessFieldsDetails = subProcessFieldsRepository.findOne(bReportFieldsDTO
							.getSubProcessFields().getWlfwSubProcessId());
					BeanUtils.copyProperties(subProcessFieldsDTO, subProcessFieldsDetails,
							NullPropertyMapper.getNullPropertyNames(subProcessFieldsDTO));
					bReportFieldsDetails.setSubProcessFields(subProcessFieldsDetails);
					
					bReportFieldsDTO.setFunctionCode(subProcessFieldsDetails.getFunctionCode());
				}
				
				if (null != bReportFieldsDTO.getMotorSpeedDetailList()) {
					ArrayList<MotorSpeedDetailDTO> motorSpeedDetailDTOs = new ArrayList<MotorSpeedDetailDTO>();
					List<MotorSpeedDetail> motorSpeedDetails = new ArrayList<MotorSpeedDetail>();
					for (MotorSpeedDetailDTO motorSpeedDetailDTORecord : bReportFieldsDTO.getMotorSpeedDetailList()) {

						motorSpeedDetailDTOs.add(motorSpeedDetailDTORecord);
					}
					if (null != bReportFieldsDetails && null != bReportFieldsDetails.getMotorSpeedDetailList()) {
						MotorSpeedDetailDTO motorSpeedDetailDTO = null;
						List<MotorSpeedDetailDTO> motorSpeedDetailDTOList = new ArrayList<MotorSpeedDetailDTO>();
						List<MotorSpeedDetail> existMotorSpeedDetailList = bReportFieldsDetails
								.getMotorSpeedDetailList();
						if (null != existMotorSpeedDetailList && existMotorSpeedDetailList.size() > 0) {
							for (MotorSpeedDetail motorSpeedDetail : existMotorSpeedDetailList) {
								for (MotorSpeedDetailDTO motorSpeedDetailDTORecord : bReportFieldsDTO
										.getMotorSpeedDetailList()) {
									if (null != motorSpeedDetailDTORecord.getMotorSpeedDetailId()) {
										if (!motorSpeedDetailRepository.exists(motorSpeedDetailDTORecord
												.getMotorSpeedDetailId())) {

											motorSpeedDetailDTO = new MotorSpeedDetailDTO();
											motorSpeedDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
											motorSpeedDetail.setModifiedOn(new Date());
											BeanUtils.copyProperties(motorSpeedDetail, motorSpeedDetailDTO,
													NullPropertyMapper.getNullPropertyNames(motorSpeedDetail));
											
											motorSpeedDetailDTOList.add(motorSpeedDetailDTO);
										}
									}
								}
							}
							motorSpeedDetailDTOs.addAll(motorSpeedDetailDTOList);
						}
					}
					for (MotorSpeedDetailDTO motorSpeedDetailDTO : motorSpeedDetailDTOs) {
						MotorSpeedDetail motorSpeedDetail = motorSpeedDetailRepository.findOne(motorSpeedDetailDTO
								.getMotorSpeedDetailId());
						if (null == motorSpeedDetail) {
							motorSpeedDetail = new MotorSpeedDetail();
						}
						BeanUtils.copyProperties(motorSpeedDetailDTO, motorSpeedDetail,
								NullPropertyMapper.getNullPropertyNames(motorSpeedDetailDTO));
						motorSpeedDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						motorSpeedDetail.setModifiedOn(new Date());
						//set audit
						motorSpeedDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						motorSpeedDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						motorSpeedDetails.add(motorSpeedDetail);
					}
					bReportFieldsDetails.setMotorSpeedDetailList(motorSpeedDetails);
					bReportFieldsDTO.setMotorSpeedDetailList(null);
				}

				if (null != bReportFieldsDTO.getArcRepairEstimateList()
						&& bReportFieldsDTO.getArcRepairEstimateList().size() > 0) {
					// spare detail create update begins here
					List<ARCRepairEstimates> aRCRepairEstimatesEntityList = new ArrayList<ARCRepairEstimates>();
					// this is a container to remove old MotorSpares detail
					// which are not
					// obtain from service call
					// List<ARCRepairEstimates>
					// unProcessedaRCRepairEstimatesList =
					// bReportFieldsDetails.getArcRepairEstimateList();

					List<ARCRepairEstimates> existaRCRepairEstimatesList = bReportFieldsDetails
							.getArcRepairEstimateList();
					List<ARCRepairEstimates> existingaRCRepairEstimatesFromInput = new ArrayList<ARCRepairEstimates>();
					List<ARCRepairEstimates> newArcRepairList = null;
					List<ARCRepairEstimates> finalArcRepairList = new ArrayList<ARCRepairEstimates>();

					for (ARCRepairEstimatesDTO arcRepairEstimatesDTORecord : bReportFieldsDTO
							.getArcRepairEstimateList()) {
						aRCRepairEstimatesEntityList.add(dozerBeanMapper.map(arcRepairEstimatesDTORecord,
								ARCRepairEstimates.class));
					}
					// spares list from json DTO
					for (ARCRepairEstimates aRCRepairEstimatesEntityRecord : aRCRepairEstimatesEntityList) {
						// if material Id is coming ,then it should be existing
						// one else
						// throws an exception
						//set audit
						aRCRepairEstimatesEntityRecord.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						aRCRepairEstimatesEntityRecord.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						if (null != aRCRepairEstimatesEntityRecord.getArcRepairEstimateId()) {
							boolean isExist = false;
							// existing MotorSparesDetail list in subprocess
							// entity
							for (ARCRepairEstimates existingaRCRepairEstimatesRecord : existaRCRepairEstimatesList) {
								// if record already exists in DB
								if (aRCRepairEstimatesEntityRecord.getArcRepairEstimateId().equals(
										existingaRCRepairEstimatesRecord.getArcRepairEstimateId())) {

									BeanUtils.copyProperties(aRCRepairEstimatesEntityRecord,
											existingaRCRepairEstimatesRecord,
											NullPropertyMapper.getNullPropertyNames(aRCRepairEstimatesEntityRecord));
									LOGGER.info("Saved object with ArcRepairEstimateId: "
											+ existingaRCRepairEstimatesRecord.getArcRepairEstimateId());
									existingaRCRepairEstimatesRecord.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
									existingaRCRepairEstimatesRecord.setModifiedOn(new Date());
									existingaRCRepairEstimatesFromInput.add(existingaRCRepairEstimatesRecord);
									// unProcessedaRCRepairEstimatesList.remove(existingaRCRepairEstimatesRecord);
									isExist = true;
									break;
								}
							}
							if (!isExist) {
								LOGGER.info("Spares Id is incorrect Create New Subprocess Workflow");
								throw new MotorRepairException(MotorRepairException.INPUT_ERR,
										"Spares Id is incorrect", "Create New Subprocess Workflow");
							}
						}
						// if material id is null ,that indicates it is new
						// entry
						else {
							if (newArcRepairList == null) {
								newArcRepairList = new ArrayList<ARCRepairEstimates>();
							}
							// add new Motor spares
							aRCRepairEstimatesEntityRecord.setCreatedDate(new Date());
							newArcRepairList.add(aRCRepairEstimatesEntityRecord);
						}
					}

					if (existingaRCRepairEstimatesFromInput != null && existingaRCRepairEstimatesFromInput.size() > 0) {
						finalArcRepairList.addAll(existingaRCRepairEstimatesFromInput);
					}
					if (newArcRepairList != null && newArcRepairList.size() > 0) {
						finalArcRepairList.addAll(newArcRepairList);
					}

					if (null != bReportFieldsDetails.getArcRepairEstimateList()) {
						bReportFieldsDetails.getArcRepairEstimateList().clear();
					} else {
						bReportFieldsDetails.setArcRepairEstimateList(new ArrayList<ARCRepairEstimates>());
					}

					bReportFieldsDetails.getArcRepairEstimateList().addAll(finalArcRepairList);

				} else {
					if (null != bReportFieldsDTO.getArcRepairEstimateList()) {
						bReportFieldsDetails.getArcRepairEstimateList().clear();
					}
				}
				bReportFieldsDTO.setArcRepairEstimateList(null);

				// ARC Spares

				if (null != bReportFieldsDTO.getArcSpareEstimateList()
						&& bReportFieldsDTO.getArcSpareEstimateList().size() > 0) {
					// spare detail create update begins here
					List<ARCSparesEstimates> aRCSparesEstimatesEntityList = new ArrayList<ARCSparesEstimates>();
					List<ARCSparesEstimates> existARCSparesEstimatesList = bReportFieldsDetails
							.getArcSpareEstimateList();
					List<ARCSparesEstimates> existingARCSparesEstimatesFromInput = new ArrayList<ARCSparesEstimates>();
					List<ARCSparesEstimates> newArcSparesList = null;
					List<ARCSparesEstimates> finalSparesList = new ArrayList<ARCSparesEstimates>();

					for (ARCSparesEstimatesDTO aRCSparesEstimatesDTORecord : bReportFieldsDTO.getArcSpareEstimateList()) {
						aRCSparesEstimatesEntityList.add(dozerBeanMapper.map(aRCSparesEstimatesDTORecord,
								ARCSparesEstimates.class));
					}
					// spares list from json DTO
					for (ARCSparesEstimates aRCSparesEstimatesEntityRecord : aRCSparesEstimatesEntityList) {
						// if material Id is coming ,then it should be existing
						// one else
						// throws an exception
						//set audit
						aRCSparesEstimatesEntityRecord.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						aRCSparesEstimatesEntityRecord.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						if (null != aRCSparesEstimatesEntityRecord.getArcSparesEstimateId()) {
							boolean isExist = false;
							// existing MotorSparesDetail list in subprocess
							// entity
							for (ARCSparesEstimates existingARCSparesEstimatesRecord : existARCSparesEstimatesList) {
								// if record already exists in DB
								if (aRCSparesEstimatesEntityRecord.getArcSparesEstimateId().equals(
										existingARCSparesEstimatesRecord.getArcSparesEstimateId())) {

									BeanUtils.copyProperties(aRCSparesEstimatesEntityRecord,
											existingARCSparesEstimatesRecord,
											NullPropertyMapper.getNullPropertyNames(aRCSparesEstimatesEntityRecord));
									LOGGER.info("Saved object with ArcRepairEstimateId: "
											+ existingARCSparesEstimatesRecord.getArcSparesEstimateId());
									existingARCSparesEstimatesRecord.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
									existingARCSparesEstimatesRecord.setModifiedOn(new Date());
									existingARCSparesEstimatesFromInput.add(existingARCSparesEstimatesRecord);
									isExist = true;
									break;
								}
							}
							if (!isExist) {
								LOGGER.info("Spares Id is incorrect Create New Subprocess Workflow");
								throw new MotorRepairException(MotorRepairException.INPUT_ERR,
										"Spares Id is incorrect", "Create New Subprocess Workflow");
							}
						}
						// if material id is null ,that indicates it is new
						// entry
						else {
							if (newArcSparesList == null) {
								newArcSparesList = new ArrayList<ARCSparesEstimates>();
							}
							// add new Motor spares

							newArcSparesList.add(aRCSparesEstimatesEntityRecord);
						}
					}

					if (existingARCSparesEstimatesFromInput != null && existingARCSparesEstimatesFromInput.size() > 0) {
						finalSparesList.addAll(existingARCSparesEstimatesFromInput);
					}
					if (newArcSparesList != null && newArcSparesList.size() > 0) {
						finalSparesList.addAll(newArcSparesList);
					}
					if (null != bReportFieldsDetails.getArcSpareEstimateList()) {
						bReportFieldsDetails.getArcSpareEstimateList().clear();
					} else {
						bReportFieldsDetails.setArcSpareEstimateList(new ArrayList<ARCSparesEstimates>());
					}
					bReportFieldsDetails.getArcSpareEstimateList().addAll(finalSparesList);
				} else {
					if (null != bReportFieldsDTO.getArcSpareEstimateList()) {
						bReportFieldsDetails.getArcSpareEstimateList().clear();
					}
				}
				bReportFieldsDTO.setArcSpareEstimateList(null);

				if (null != bReportFieldsDTO.getMotorVoltageDetail()) {
					
					motorVoltageDetailDTO = bReportFieldsDTO.getMotorVoltageDetail();
					
					
					if (null == bReportFieldsDTO.getMotorVoltageDetail().getMotorVoltageDetailId()) {
						motorVoltageDetail = new MotorVoltageDetail();

						bReportFieldsDTO.setMotorVoltageDetail(motorVoltageDetailDTO);
						BeanUtils.copyProperties(motorVoltageDetailDTO, motorVoltageDetail,
								NullPropertyMapper.getNullPropertyNames(motorVoltageDetailDTO));
						motorVoltageDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						motorVoltageDetail.setModifiedOn(new Date());
						//set audit
						motorVoltageDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						motorVoltageDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						bReportFieldsDetails.setMotorVoltageDetail(motorVoltageDetail);
						bReportFieldsDTO.setMotorVoltageDetail(null);
					} else {
						motorVoltageDetail = motorVoltageDetailRepository.findOne(motorVoltageDetailDTO
								.getMotorVoltageDetailId());
						BeanUtils.copyProperties(motorVoltageDetailDTO, motorVoltageDetail,
								NullPropertyMapper.getNullPropertyNames(motorVoltageDetailDTO));
						motorVoltageDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						motorVoltageDetail.setModifiedOn(new Date());
						//set audit
						motorVoltageDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						motorVoltageDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						bReportFieldsDetails.setMotorVoltageDetail(motorVoltageDetail);
						bReportFieldsDTO.setMotorVoltageDetail(null);
					}
					

				}
				if (null != bReportFieldsDTO.getMotorNamePlateDetail()) {
					motorNamePlateDetailDTO = bReportFieldsDTO.getMotorNamePlateDetail();
					if (null == bReportFieldsDTO.getMotorNamePlateDetail().getMotorNamePlateFieldsId()) {
						motorNamePlateDetailDTO.setCreatedOn(new Date());
						motorNamePlateDetail = new MotorNamePlateDetail();

						bReportFieldsDTO.setMotorNamePlateDetail(motorNamePlateDetailDTO);
						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								NullPropertyMapper.getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						//set audit
						motorNamePlateDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						bReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						bReportFieldsDTO.setMotorNamePlateDetail(null);
					} else {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
						if (null != motorNamePlateDetail) {
							motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
						} else {
							motorNamePlateDetailDTO.setCreatedOn(new Date());
						}

						BeanUtils.copyProperties(motorNamePlateDetailDTO, motorNamePlateDetail,
								NullPropertyMapper.getNullPropertyNames(motorNamePlateDetailDTO));
						motorNamePlateDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						motorNamePlateDetail.setModifiedOn(new Date());
						//set audit
						motorNamePlateDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						motorNamePlateDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						bReportFieldsDetails.setMotorNamePlateDetail(motorNamePlateDetail);
						bReportFieldsDTO.setMotorNamePlateDetail(null);
					}
				}

				if (null != bReportFieldsDTO.getElectricalObservation()) {
					electricalObservationDTO = bReportFieldsDTO.getElectricalObservation();
					if (null == bReportFieldsDTO.getElectricalObservation().getMotorElecObsId()) {
						electricalObservationDetail = new ElectricalObservation();

						bReportFieldsDTO.setElectricalObservation(electricalObservationDTO);
						BeanUtils.copyProperties(electricalObservationDTO, electricalObservationDetail,
								NullPropertyMapper.getNullPropertyNames(electricalObservationDTO));
						electricalObservationDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						electricalObservationDetail.setModifiedOn(new Date());
						//set audit
						electricalObservationDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						electricalObservationDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						bReportFieldsDetails.setElectricalObservation(electricalObservationDetail);
						bReportFieldsDTO.setElectricalObservation(null);
					} else {
						electricalObservationDetail = electricalObservationRepository.findOne(electricalObservationDTO
								.getMotorElecObsId());
						BeanUtils.copyProperties(electricalObservationDTO, electricalObservationDetail,
								NullPropertyMapper.getNullPropertyNames(electricalObservationDTO));
						electricalObservationDetail.setModifiedByRefId(bReportFieldsDTO.getModifiedByRefId());
						electricalObservationDetail.setModifiedOn(new Date());
						//set audit
						electricalObservationDetail.setFunctionCode(bReportFieldsDTO.getFunctionCode());
						electricalObservationDetail.setWlfwSubProcessId(bReportFieldsDTO.getSubProcessFields().getWlfwSubProcessId());
						System.out.println(electricalObservationDetail.getWlfwSubProcessId());
						bReportFieldsDetails.setElectricalObservation(electricalObservationDetail);
						bReportFieldsDTO.setElectricalObservation(null);
					}
				}
				bReportFieldsDTO.setSubProcessFields(null);
				
				BeanUtils.copyProperties(bReportFieldsDTO, bReportFieldsDetails,
						NullPropertyMapper.getNullPropertyNames(bReportFieldsDTO));
				//set audit
				bReportFieldsDetails.setFunctionCode(bReportFieldsDTO.getFunctionCode());
				//System.out.println("subprocess id "+bReportFieldsDetails.getMotorNamePlateDetail().getWlfwSubProcessId());
				BReportFields savedObj = bReportFieldsRepository.save(bReportFieldsDetails);
				if (null != savedObj) {
					LOGGER.info("BReportFieldsServiceImpl : createUpdateBReportFields : Record Saved/Updated");
					if (null != savedObj) {
						bReportFieldsDTO = new BReportFieldsDTO();
						bReportFieldsDTO = dozerBeanMapper.map(savedObj, BReportFieldsDTO.class);
					}
					//returnId = savedObj.getBReportFieldId();
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : createUpdateBReportFields : bReportFieldsDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
			throw new MotorRepairException(MotorRepairException.INPUT_ERR,
					"Breport Excpeption","Excption:"+e);
		}
		return bReportFieldsDTO;
	}

	@Override
	@Transactional
	public Boolean addARCRepairEstimatesToBReportFields(Long bReportFieldId,
			List<ARCRepairEstimatesDTO> aRCRepairEstimatesDTOList) {
		LOGGER.info("BReportFieldsServiceImpl : addARCRepairEstimatesToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields;
		BReportFields savedObject = null;

		ARCRepairEstimates aRCRepairEstimatesDetail = null;
		List<ARCRepairEstimates> aRCRepairEstimatesList = new ArrayList<ARCRepairEstimates>();
		try {
			if (null != bReportFieldId && null != aRCRepairEstimatesDTOList) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);

				if (null != bReportFields) {
					for (ARCRepairEstimatesDTO aRCRepairEstimatesDTO : aRCRepairEstimatesDTOList) {
						if (null != aRCRepairEstimatesDTO.getArcRepairEstimateId()) {
							aRCRepairEstimatesDetail = aRCRepairEstimatesRepository.findOne(aRCRepairEstimatesDTO
									.getArcRepairEstimateId());
							aRCRepairEstimatesDTO.setCreatedDate(aRCRepairEstimatesDetail.getCreatedDate());
							aRCRepairEstimatesDTO.setModifiedDate(new Date());

						} else {

							aRCRepairEstimatesDTO.setCreatedDate(new Date());

						}
						aRCRepairEstimatesDetail = dozerBeanMapper.map(aRCRepairEstimatesDTO, ARCRepairEstimates.class);
						aRCRepairEstimatesList.add(aRCRepairEstimatesDetail);
					}
					List<ARCRepairEstimates> existARCRepairEstimatesList = bReportFields.getArcRepairEstimateList();
					if (null != existARCRepairEstimatesList && aRCRepairEstimatesList.size() > 0) {
						aRCRepairEstimatesList.addAll(existARCRepairEstimatesList);
					}

					bReportFields.setArcRepairEstimateList(aRCRepairEstimatesList);

					savedObject = bReportFieldsRepository.save(bReportFields);
				}
				LOGGER.info("BReportFieldsServiceImpl : addARCRepairEstimatesToBReportFields : Record Saved");
				if (savedObject != null) {
					returnVal = true;
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : addARCRepairEstimatesToBReportFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	@Transactional
	public Boolean addARCSparesEstimatesToBReportFields(Long bReportFieldId,
			List<ARCSparesEstimatesDTO> aRCSparesEstimatesDTOList) {
		LOGGER.info("BReportFieldsServiceImpl : addARCSparesEstimatesToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields;
		BReportFields savedObject = null;

		ARCSparesEstimates aRCSparesEstimatesDetail = null;
		List<ARCSparesEstimates> aRCSparesEstimatesList = new ArrayList<ARCSparesEstimates>();
		try {
			if (null != bReportFieldId && null != aRCSparesEstimatesDTOList) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);

				if (null != bReportFields) {
					for (ARCSparesEstimatesDTO aRCSparesEstimatesDTO : aRCSparesEstimatesDTOList) {
						if (null != aRCSparesEstimatesDTO.getArcSparesEstimateId()) {
							aRCSparesEstimatesDetail = aRCSparesEstimatesRepository.findOne(aRCSparesEstimatesDTO
									.getArcSparesEstimateId());
						}
						aRCSparesEstimatesDetail = dozerBeanMapper.map(aRCSparesEstimatesDTO, ARCSparesEstimates.class);
						aRCSparesEstimatesList.add(aRCSparesEstimatesDetail);
					}
					List<ARCSparesEstimates> existARCSparesEstimatesList = bReportFields.getArcSpareEstimateList();
					if (null != existARCSparesEstimatesList && existARCSparesEstimatesList.size() > 0) {
						aRCSparesEstimatesList.addAll(existARCSparesEstimatesList);
					}

					bReportFields.setArcSpareEstimateList(aRCSparesEstimatesList);

					savedObject = bReportFieldsRepository.save(bReportFields);
				}
				LOGGER.info("BReportFieldsServiceImpl : addARCSparesEstimatesToBReportFields : Record Saved");
				if (savedObject != null) {
					returnVal = true;
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : addARCSparesEstimatesToBReportFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;

	}

	@Override
	@Transactional
	public Boolean addMotorSpeedDetailToBReportFields(Long bReportFieldId,
			List<MotorSpeedDetailDTO> motorSpeedDetailDTOList) {
		LOGGER.info("BReportFieldsServiceImpl : addMotorSpeedDetailToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields;
		BReportFields savedObject = null;

		MotorSpeedDetail motorSpeedDetail = null;
		List<MotorSpeedDetail> motorSpeedDetailList = new ArrayList<MotorSpeedDetail>();
		try {
			if (null != bReportFieldId && null != motorSpeedDetailDTOList) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);

				if (null != bReportFields) {
					for (MotorSpeedDetailDTO motorSpeedDetailDTO : motorSpeedDetailDTOList) {
						if (null != motorSpeedDetailDTO.getMotorSpeedDetailId()) {
							motorSpeedDetail = motorSpeedDetailRepository.findOne(motorSpeedDetailDTO
									.getMotorSpeedDetailId());
						}

						motorSpeedDetail = dozerBeanMapper.map(motorSpeedDetailDTO, MotorSpeedDetail.class);
						motorSpeedDetailList.add(motorSpeedDetail);
					}
					List<MotorSpeedDetail> existMotorSpeedDetailList = bReportFields.getMotorSpeedDetailList();
					if (null != existMotorSpeedDetailList && motorSpeedDetailList.size() > 0) {
						motorSpeedDetailList.addAll(existMotorSpeedDetailList);
					}

					bReportFields.setMotorSpeedDetailList(motorSpeedDetailList);

					savedObject = bReportFieldsRepository.save(bReportFields);
				}
				LOGGER.info("BReportFieldsServiceImpl : addMotorSpeedDetailToBReportFields : Record Saved");
				if (savedObject != null) {
					returnVal = true;
				}
			} else {
				LOGGER.info("BReportFieldsServiceImpl : addMotorSpeedDetailToBReportFields : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public Boolean addMotorVoltageDetailToBReportFields(Long bReportFieldId, MotorVoltageDetailDTO motorVoltageDetailDTO) {
		LOGGER.info("BReportFieldsServiceImpl : addMotorVoltageDetailToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields = null;
		BReportFields savedObj = null;
		MotorVoltageDetail motorVoltageDetail = null;
		try {
			if (null != bReportFieldId && null != motorVoltageDetailDTO) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);
				if (null != bReportFields) {
					if (null != motorVoltageDetailDTO.getMotorVoltageDetailId()) {
						motorVoltageDetail = motorVoltageDetailRepository.findOne(motorVoltageDetailDTO
								.getMotorVoltageDetailId());
					}

					motorVoltageDetail = dozerBeanMapper.map(motorVoltageDetailDTO, MotorVoltageDetail.class);
					bReportFields.setMotorVoltageDetail(motorVoltageDetail);
					savedObj = bReportFieldsRepository.save(bReportFields);
					if (null != savedObj) {
						LOGGER.info("BReportFieldsServiceImpl : addMotorVoltageDetailToBReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("BReportFieldsServiceImpl : addMotorVoltageDetailToBReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public Boolean addMotorNamePlateDetailToBReportFields(Long bReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		LOGGER.info("BReportFieldsServiceImpl : addMotorNamePlateDetailToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields = null;
		BReportFields savedObj = null;
		MotorNamePlateDetail motorNamePlateDetail = null;
		try {
			if (null != bReportFieldId && null != motorNamePlateDetailDTO) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);
				if (null != bReportFields) {
					if (null != motorNamePlateDetailDTO.getMotorNamePlateFieldsId()) {
						motorNamePlateDetail = motorNamePlateDetailRepository.findOne(motorNamePlateDetailDTO
								.getMotorNamePlateFieldsId());
					} else {

						motorNamePlateDetailDTO.setCreatedOn(new Date());
					}

					if (null == motorNamePlateDetailDTO.getCreatedOn()) {
						motorNamePlateDetailDTO.setCreatedOn(motorNamePlateDetail.getCreatedOn());
					}
					motorNamePlateDetail = dozerBeanMapper.map(motorNamePlateDetailDTO, MotorNamePlateDetail.class);
					bReportFields.setMotorNamePlateDetail(motorNamePlateDetail);
					savedObj = bReportFieldsRepository.save(bReportFields);
					if (null != savedObj) {
						LOGGER.info("BReportFieldsServiceImpl : addMotorNamePlateDetailToBReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("BReportFieldsServiceImpl : addMotorNamePlateDetailToBReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public Boolean addElectricalObservationToBReportFields(Long bReportFieldId,
			ElectricalObservationDTO electricalObservationDTO) {
		LOGGER.info("BReportFieldsServiceImpl : addElectricalObservationToBReportFields : Start");
		boolean returnVal = false;
		BReportFields bReportFields = null;
		BReportFields savedObj = null;
		ElectricalObservation electricalObservationDetail = null;
		try {
			if (null != bReportFieldId && null != electricalObservationDTO) {
				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);
				if (null != bReportFields) {
					if (null != electricalObservationDTO.getMotorElecObsId()) {
						electricalObservationDetail = electricalObservationRepository.findOne(electricalObservationDTO
								.getMotorElecObsId());
					}
					electricalObservationDetail = dozerBeanMapper.map(electricalObservationDTO,
							ElectricalObservation.class);
					bReportFields.setElectricalObservation(electricalObservationDetail);
					savedObj = bReportFieldsRepository.save(bReportFields);
					if (null != savedObj) {
						LOGGER.info("BReportFieldsServiceImpl : addElectricalObservationToBReportFields : Record Saved/Updated");
						returnVal = true;
					} else {
						LOGGER.info("BReportFieldsServiceImpl : addElectricalObservationToBReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public Long addSubProcessFieldsToBReportFields(Long bReportFieldId, SubProcessFieldsDTO subProcessFieldsDTO) {
		LOGGER.info("BReportFieldsServiceImpl : addSubProcessFieldsToBReportFields : Start");
		Long returnVal = -1l;
		BReportFields bReportFields = null;
		BReportFields savedObj = null;
		SubProcessFields subProcessFieldsDetail = null;
		try {
			if (null != bReportFieldId && null != subProcessFieldsDTO) {

				bReportFields = bReportFieldsRepository.findOne(bReportFieldId);
				if (null != bReportFields) {
					if (null != subProcessFieldsDTO.getWlfwSubProcessId()) {
						subProcessFieldsDetail = subProcessFieldsRepository.findOne(subProcessFieldsDTO
								.getWlfwSubProcessId());
					} else {
						subProcessFieldsDTO.setCreatedOn(new Date());
					}

					if (null == subProcessFieldsDTO.getCreatedOn()) {
						subProcessFieldsDTO.setCreatedOn(subProcessFieldsDetail.getCreatedOn());
					}
					subProcessFieldsDetail = dozerBeanMapper.map(subProcessFieldsDTO, SubProcessFields.class);
					bReportFields.setSubProcessFields(subProcessFieldsDetail);
					savedObj = bReportFieldsRepository.save(bReportFields);
					if (null != savedObj) {
						LOGGER.info("BReportFieldsServiceImpl : addSubProcessFieldsToBReportFields : Record Saved/Updated");
						returnVal = savedObj.getBReportFieldId();
					} else {
						LOGGER.info("BReportFieldsServiceImpl : addSubProcessFieldsToBReportFields : Not saved");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}

	@Override
	public BReportFieldsDTO getBReportFieldsApprovedStatusBySubprocessFieldId(Long wlfwSubProcessId) {
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsApprovedStatusBySubprocessFieldId : Start");

		BReportFieldsDTO bReportFieldsDTO = null;
		if (null != wlfwSubProcessId) {
			Object[] objectArr = bReportFieldsRepository.findBReportFieldsApprovedStatusSubProcessID(wlfwSubProcessId);
			if (null != objectArr) {

				bReportFieldsDTO = new BReportFieldsDTO();
				if (null != objectArr[0]) {
					bReportFieldsDTO.setbReportFieldId(Long.parseLong(objectArr[0].toString()));
				}
				if (null != objectArr[1]) {
					bReportFieldsDTO.setApprovalStatus(Integer.parseInt(objectArr[1].toString()));
				}
				if (null != objectArr[2]) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
					try {
						if(null != objectArr[2])
							bReportFieldsDTO.setStatusUpdatedOn(sdf.parse(objectArr[2].toString()));
					} catch (ParseException e) {
						LOGGER.warn("Error while parsing date in the pattern: yyyy-MM-dd HH:mm:ss.SSS for value: " + objectArr[2].toString());
					}
				}
				if (null != objectArr[3]) {
					bReportFieldsDTO.setStatusUpdatedByRefId(objectArr[3].toString());
				}

			}
		}
		LOGGER.info("BReportFieldsServiceImpl : getBReportFieldsApprovedStatusBySubprocessFieldId : End");
		return bReportFieldsDTO;
	}

}
