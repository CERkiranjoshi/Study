/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component(value = "initializeApproverData")
public class InitializeApproverData extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(InitializeApproverData.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; INITIALIZE_APPROVER_DATA: START " + execution.getId());
		
		// SET FLAG TO INDICATE IT IS SENT FOR APPROVAL
		
		execution.setVariable(MotorRepairConstants.SEND_FOR_APPROVAL_FLAG, 1);

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; INITIALIZE_APPROVER_DATA: END " + execution.getId());
	}

}
