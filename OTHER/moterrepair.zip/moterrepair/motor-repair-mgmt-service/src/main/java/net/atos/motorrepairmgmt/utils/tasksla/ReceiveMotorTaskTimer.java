/**
 * 
 */
package net.atos.motorrepairmgmt.utils.tasksla;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;
import net.atos.motorrepairmgmt.dto.TemplateInfoDTO;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.NotificationService;
import net.atos.motorrepairmgmt.services.SchedulerDetailsService;
import net.atos.motorrepairmgmt.services.TemplateInfoService;
import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.singetons.TaskSLAManager;
import net.atos.taskmgmt.activiti.engine.TaskManagementService;
import net.atos.taskmgmt.activiti.mapper.ProcessVariableMapper;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.ActorFunctionMasterDTO;
import net.atos.taskmgmt.common.dto.TaskDetailsDTO;
import net.atos.taskmgmt.common.dto.TaskStatus;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component
public class ReceiveMotorTaskTimer implements RunnableFuture<ReceiveMotorTaskTimer> {

	private static final Logger LOGGER = Logger.getLogger(ReceiveMotorTaskTimer.class);
	private final int SCHEDULER_TYPE = MotorRepairConstants.SCHEDULER_TYPES.RECEIVE_MOTOR.getValue();

	private String name;
	private String taskId;
	private String processInstanceId;
	private String schedulerId;
	private Long subprocessId;

	private List<String> emailAddresses;
	private int reminderNumber;
	private long nextRunTimeInMillis;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private SchedulerDetailsService schedulerDetailsService;

	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;

	@Autowired
	protected WorkflowInvoker workflowInvoker;

	@Autowired
	protected ConfigDetailService configDetailService;

	@Autowired
	protected TemplateInfoService templateInfoService;

	@Autowired
	TaskSLAManager taskSLAManager;

	@Autowired
	TaskManagementService taskManagementService;

	public ReceiveMotorTaskTimer() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	/**
	 * @return the subprocessId
	 */
	public Long getSubprocessId() {
		return subprocessId;
	}

	/**
	 * @param subprocessId
	 *            the subprocessId to set
	 */
	public void setSubprocessId(Long subprocessId) {
		this.subprocessId = subprocessId;
	}

	/**
	 * @return the emailAddresses
	 */
	public List<String> getEmailAddresses() {
		return emailAddresses;
	}

	/**
	 * @param emailAddresses
	 *            the emailAddresses to set
	 */
	public void setEmailAddresses(List<String> emailAddresses) {
		this.emailAddresses = emailAddresses;
	}

	/**
	 * @return the reminderNumber
	 */
	public int getReminderNumber() {
		return reminderNumber;
	}

	/**
	 * @param reminderNumber
	 *            the reminderNumber to set
	 */
	public void setReminderNumber(int reminderNumber) {
		this.reminderNumber = reminderNumber;
	}

	/**
	 * @return the schedulerId
	 */
	public String getSchedulerId() {
		return schedulerId;
	}

	/**
	 * @param schedulerId
	 *            the schedulerId to set
	 */
	public void setSchedulerId(String schedulerId) {
		this.schedulerId = schedulerId;
	}

	/**
	 * @return the nextRunTimeInMillis
	 */
	public long getNextRunTimeInMillis() {
		return nextRunTimeInMillis;
	}

	/**
	 * @param nextRunTimeInMillis
	 *            the nextRunTimeInMillis to set
	 */
	public void setNextRunTimeInMillis(long nextRunTimeInMillis) {
		this.nextRunTimeInMillis = nextRunTimeInMillis;
	}

	@Override
	public boolean cancel(boolean mayInterruptIfRunning) {
		LOGGER.info("Called CANCEL for " + this.toString());
		return false;
	}

	@Override
	public boolean isCancelled() {
		LOGGER.info("Called isCANCEL" + this.toString());
		return false;
	}

	@Override
	public boolean isDone() {
		LOGGER.info("Called isDONE" + this.toString());
		return false;
	}

	@Override
	public ReceiveMotorTaskTimer get() throws InterruptedException, ExecutionException {
		LOGGER.info("Called get()" + this.toString());

		return this;
	}

	@Override
	public ReceiveMotorTaskTimer get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException,
			TimeoutException {
		LOGGER.info("Called get(long timeout, TimeUnit unit)" + this.toString());
		return this;
	}

	@Override
	public void run() {
		LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: BEGIN: " + Calendar.getInstance().getTime() + " " + this.toString()
				+ " AM RUNNING!");

		String functionCode = MotorRepairConstants.CCC_MOTOR_NOT_RECEIVED_MUL_NOTIFY;

		// ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();

		// SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);
		SchedulerDetailsDTO schedulerDetailsDTO = schedulerDetailsService
				.getSchedulerDetailsByschedulerDetailsIdAndTenantIdAndSolCatId(getSchedulerId(),
						MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
		schedulerDetailsDTO.setLastRunTs(new Date());
		schedulerDetailsDTO.setHasExecuted(1);

		schedulerDetailsService.createUpdateSchedulerDetails(schedulerDetailsDTO);

		// Test if task has been completed.
		try {
			// TaskManagementService taskManagementService = applicationContext.getBean(TaskManagementService.class);
			TaskDetailsDTO taskDetailsDTO = taskManagementService.getTaskDetails(taskId);

			if (null != taskDetailsDTO) {

				if (!TaskStatus.Completed.toString().equals(taskDetailsDTO.getStatus())) {

					LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: TASK [ID: " + taskId
							+ "] NOT COMPLETED, TO BE RESCHEDULED : " + this.toString() + " for GSP_REF: "
							+ schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
							+ schedulerDetailsDTO.getSubprocessId() + "; RUN NUMBER: "
							+ schedulerDetailsDTO.getRunNumber());
					// TemplateInfoService templateInfoService = applicationContext.getBean(TemplateInfoService.class);

					List<TemplateInfoDTO> templateInfoDTOs = templateInfoService
							.findTemplateInfoByFunCodeNNotificationType(functionCode,
									MotorRepairConstants.TASK_NOTIFY_TYPE.MOTOR_NOT_RECEIVED.getValue());

					for (TemplateInfoDTO templateInfoDTO : templateInfoDTOs) {
						String templateCode = templateInfoDTO.getTemplateCode();

						LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: [ID: " + taskId + "] TODO SEND NOTIFICATION FOR : "
								+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
								+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId() + "; TEMPLATE_CODE: "
								+ templateCode + "; FUNCTION_CODE: " + functionCode);
						// Send notification for motor not received
						// notificationService.autoTriggerNotification(functionCode, templateCode, getSubprocessId());

					}

					// schedule another reminder
					// TODO FETCH DATA FROM CONFIG
					if (schedulerDetailsDTO.getRunNumber() < 3) {
						LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: [ID: " + taskId + "] Scheduling next run: "
								+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
								+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId());
						// TaskSLAManager taskSLAManager = applicationContext.getBean(TaskSLAManager.class);
						String schedulerId = taskSLAManager.triggerMotorNotReceivedScheduler(schedulerDetailsDTO
								.getBatchProcessId(), schedulerDetailsDTO.getMasterWorkflowId().toString(),
								schedulerDetailsDTO.getProcInstRefId(), schedulerDetailsDTO.getScheduledBy(),
								schedulerDetailsDTO.getSubprocessId().toString(),
								schedulerDetailsDTO.getFunctionCode(), schedulerDetailsDTO.getGspRefNum(), 1,
								schedulerDetailsDTO.getRunNumber().intValue() + 1, schedulerDetailsDTO.getTaskRefId(),
								schedulerDetailsDTO.getTaskPriority());
						LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: [ID: " + taskId + "] Scheduled next run: "
								+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
								+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId() + "; with SchedulerId: "
								+ schedulerId);
					} else {
						LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: [ID: " + taskId + "] Triggering Workflow : "
								+ this.toString() + " for GSP_REF: " + schedulerDetailsDTO.getGspRefNum()
								+ "; SUB_PROCESS_ID: " + schedulerDetailsDTO.getSubprocessId());
						invokeMotorNotReceivedWorkflow(taskDetailsDTO);
					}

				} else {
					LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: TASK [ID: " + taskId
							+ "] HAS BEEN COMPLETED >> NO SCHEDULING REQUIRED: " + this.toString() + " for GSP_REF: "
							+ schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
							+ schedulerDetailsDTO.getSubprocessId());

				}
			} else {
				LOGGER.warn("RECEIVE_MOTOR_TASK_TIMER: TASK [ID: " + taskId
						+ "] NOT FOUND!! NO FURTHER SCHEDULING REQUIRED: " + this.toString() + " for GSP_REF: "
						+ schedulerDetailsDTO.getGspRefNum() + "; SUB_PROCESS_ID: "
						+ schedulerDetailsDTO.getSubprocessId());

			}
		} catch (BeansException e) {
			LOGGER.error("RECEIVE_MOTOR_TASK_TIMER: Error while fetching task Details", e);
		} catch (Exception e) {
			LOGGER.error("RECEIVE_MOTOR_TASK_TIMER: Error while fetching task Details", e);
		}

		LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: END: " + this.toString() + " DONE");
	}

	private String invokeMotorNotReceivedWorkflow(TaskDetailsDTO taskDetailsDTO) throws Exception {
		Map<String, Object> processVariables = ProcessVariableMapper.createTaskManagerVariables(taskDetailsDTO);
		String functionCode = MotorRepairConstants.CCC_MOTOR_NOT_RECEIVED_MUL_NOTIFY;
		String previousFunctionCode = processVariables.get(ActivitiConstants.FUNCTION_CODE).toString();

		processVariables.put(ActivitiConstants.FUNCTION_CODE, functionCode);
		processVariables.put(ActivitiConstants.PREV_FUNCTION_CODE, previousFunctionCode);

		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);
		String workflowName = actorFunctionMasterDTO.getWorkflowName();

		// Set GROUP NAME FROM FUNCTION MAP
		if (actorFunctionMasterDTO.getActorMasterDTOList() != null
				&& actorFunctionMasterDTO.getActorMasterDTOList().size() > 0) {
			processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO_GROUP, actorFunctionMasterDTO
					.getActorMasterDTOList().get(0).getActorName());
			if (functionCode.startsWith("ARC")) {
				// get SubProcessId from process variable map
				// Long subProcessId = Long.parseLong(processVariables.get(
				// ActivitiConstants.ACTIVITI_PROC_VAR_PROCESS_VARIABLES_ID).toString());
				// find ARCrefId from subProcessId
				// Long arcRefId = subProcessFieldsService.getARCRefIdBySubProcessId(subProcessId);
				// set assign to parameter based on ARC refId
				processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO,
						processVariables.get(ActivitiConstants.ARC_REF_ID));
			} else {
				// reset assignedto
				processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ASSIGNED_TO, null);

			}
		}
		processVariables.put(ActivitiConstants.FUNCTION_NAME, actorFunctionMasterDTO.getFunctionName());
		// if function code starts with ARC task

		processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_BY, MotorRepairConstants.SYSTEM_USER);
		processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_CREATED_DATE, new Date());
		processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_ACTUAL_START_DATE, new Date());

		// TODO set the region for this task
		// processVariables.put(ActivitiConstants.ACTIVITI_PROC_VAR_REGION, value);

		// Invoke Task Assignment Notifications
		LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: Invoke ASSIGNMENT NOTIFICATION : BEGIN");
		List<ConfigDetailDTO> configDetails = configDetailService.findConfigDetailsByConfigTypeNSubType(
				MotorRepairConstants.ASSIGNMENT_EMAIL_CONFIG_TYPE,
				MotorRepairConstants.ASSIGNMENT_EMAIL_CONFIG_SUBTYPE, MotorRepairConstants.TENANT_ID,
				MotorRepairConstants.PROGRAM_ID);

		if ((null != configDetails) && (1 == configDetails.size())) {
			ConfigDetailDTO configDetailDTO = configDetails.get(0);
			if (configDetailDTO.getConfigIntVal().intValue() == 1) {

				LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: ASSIGNMENT NOTIFICATION ENABLED");
				// Fetch the template details from templateInfoService

				List<TemplateInfoDTO> templateInfos = templateInfoService.findTemplateInfoByFunCodeNNotificationType(
						processVariables.get(ActivitiConstants.FUNCTION_CODE).toString(),
						MotorRepairConstants.TASK_NOTIFY_TYPE.NEW_TASK.getValue());

				for (TemplateInfoDTO templateInfoDTO : templateInfos) {
					LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: ASSIGNMENT NOTIFICATION TEMPLATE: "
							+ templateInfoDTO.getFunctionCode() + "; " + templateInfoDTO.getTemplateCode());

					processVariables.put(ActivitiConstants.NOTIFY, 1);
					processVariables.put(MotorRepairConstants.TEMPLATE_CODE, templateInfoDTO.getTemplateCode());
					processVariables.put(MotorRepairConstants.NOTIFY_TYPE,
							MotorRepairConstants.TASK_NOTIFY_TYPE.NEW_TASK.getValue());

					LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: INVOKE NOTIFICATION HANDLER: ");
					sendNotification(processVariables);
				}
			}
		}
		LOGGER.info("RECEIVE_MOTOR_TASK_TIMER: Invoke ASSIGNMENT NOTIFICATION : END");

		// call ARC assignment .bpmn
		return workflowInvoker.startNewProcess(processVariables, workflowName);

	}

	/**
	 * Invoke Notification workflow.
	 * 
	 * @param execution
	 * @param nextProcessVars
	 * @return
	 */
	protected String sendNotification(Map<String, Object> nextProcessVars) {

		String functionCode = MotorRepairConstants.SYS_NOTIFICATION;

		ActorFunctionMasterDTO actorFunctionMasterDTO = actorFunctionMasterService
				.getActorFunctionMasterByFunctionCode(functionCode);
		String workflowName = actorFunctionMasterDTO.getWorkflowName();

		// TODO set nextProcessVars with appropriate values
		nextProcessVars.put(ActivitiConstants.CHECK_EDIT_ENABLED, 0);

		return workflowInvoker.startNewProcess(nextProcessVars, workflowName);

	}

	@Override
	public String toString() {
		return "ReceiveMotorTaskTimer [" + name + "; " + taskId + "; " + processInstanceId + "]";
	}

}
