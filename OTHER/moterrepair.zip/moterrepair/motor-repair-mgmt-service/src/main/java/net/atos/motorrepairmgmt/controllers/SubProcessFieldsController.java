package net.atos.motorrepairmgmt.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.List;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletResponse;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSparesDetailDTO;
import net.atos.motorrepairmgmt.dto.ParallelProcessDTO;
import net.atos.motorrepairmgmt.dto.RMTTaskLogDTO;
import net.atos.motorrepairmgmt.dto.SearchByParameterDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.dto.TrackCallStatusDTO;
import net.atos.motorrepairmgmt.entity.ConfigDetail;
import net.atos.motorrepairmgmt.repository.ConfigDetailRepository;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.services.SubProcessFieldsService;
import net.atos.motorrepairmgmt.services.TrackcallStatusService;
import net.atos.motorrepairmgmt.services.WorkflowService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.dto.CommentsDTO;
import net.atos.taskmgmt.service.CommentsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610039
 * 
 */
@EnableSwagger
@RequestMapping(value = "subProcessFieldsService")
@Controller
public class SubProcessFieldsController {

	@Autowired
	private SubProcessFieldsService subProcessFieldsService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private TrackcallStatusService trackcallStatusService;

	@Autowired
	private ConfigDetailRepository configDetailRepo;
	
	@RequestMapping(value = "/createUpdateSubProcessFields", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update SubProcess Fields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long createUpdateSubProcessFields(
			@ApiParam(value = "SubProcessFields object that needs to be added or update in the subProcessFields") @RequestBody SubProcessFieldsDTO subProcessFieldsDTO) {
		return subProcessFieldsService
				.createUpdateSubProcessFields(subProcessFieldsDTO);
	}

	@RequestMapping(value = "/getSubProcessFieldsByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find SubProcess Fields By WlfwSubProcess Id", notes = "Returns a SubProcess Fields entity when WlfwSubProcess Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid WlfwSubProcess Id supplied"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessId(
			@ApiParam(value = "WlfwSubProcess Id of the SubProcessFields that needs to be fetched", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return subProcessFieldsService
				.getSubProcessFieldsByWlfwSubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/getAllSubProcessFieldsByTenantId/{tenantId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields by Tenant Id", notes = "Returns All SubProcess Fields entity when Tenant Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid tenant Id supplied"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	List<SubProcessFieldsDTO> getAllSubProcessFieldsByTenantId(
			@ApiParam(value = "TenantId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId) {
		return subProcessFieldsService
				.getAllSubProcessFieldsByTenantId(tenantId);
	}

	@RequestMapping(value = "/getSubProcessFieldsByFrameSize/{frameSize}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields by Frame Size", notes = "Returns All SubProcess Fields entity when Frame Size is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid Frame Size supplied"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	List<SubProcessFieldsDTO> getSubProcessFieldsByFrameSize(
			@ApiParam(value = "FrameSize of the SubProcessFields that needs to be fetched", required = true) @PathVariable("frameSize") Integer frameSize) {
		return subProcessFieldsService
				.getSubProcessFieldsByFrameSize(frameSize);
	}

	@RequestMapping(value = "/getSubProcessFieldsByGrnVrreId/{grnVrreId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields by Grn Vrre Id", notes = "Returns All SubProcess Fields entity when Grn Vrre Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid Vrre Id supplied"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	List<SubProcessFieldsDTO> getSubProcessFieldsByGrnVrreId(
			@ApiParam(value = "GrnVrre Id of the SubProcessFields that needs to be fetched", required = true) @PathVariable("grnVrreId") String grnVrreId) {
		return subProcessFieldsService
				.getSubProcessFieldsByGrnVrreId(grnVrreId);
	}

	@RequestMapping(value = "/getMotorSparesDetailsByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSparesDetail By Wlfw SubProcessId", notes = "Returns a MotorSparesDetail entity when wlfw SubProcessId of the SubProcessFields is passed", response = MotorSparesDetailDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Wlfw SubProcessId supplied"),
			@ApiResponse(code = 404, message = " MotorSparesDetail not found") })
	public @ResponseBody
	List<MotorSparesDetailDTO> getMotorSparesDetailsByWlfwSubProcessId(
			@ApiParam(value = "Wlfw SubProcessId of the SubProcessFields that needs to be fetch MotorSparesDetails", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return subProcessFieldsService
				.getMotorSparesDetailsByWlfwSubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/getMotorAttachmentDetailByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorAttachmentDetail By Wlfw SubProcessId", notes = "Returns a MotorAttachmentDetail entity when wlfw SubProcessId of the SubProcessFields is passed", response = MotorAttachmentDetailDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Wlfw SubProcessId supplied"),
			@ApiResponse(code = 404, message = " MotorAttachmentDetail not found") })
	public @ResponseBody
	List<MotorAttachmentDetailDTO> getMotorAttachmentDetailByWlfwSubProcessId(
			@ApiParam(value = "Wlfw SubProcessId of the SubProcessFields that needs to be fetch MotorAttachmentDetails", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return subProcessFieldsService
				.getMotorAttachmentDetailByWlfwSubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/getParallelProcessByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find ParallelProcess By Wlfw SubProcessId", notes = "Returns a ParallelProcess entity when wlfw SubProcessId of the SubProcessFields is passed", response = ParallelProcessDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Wlfw SubProcessId supplied"),
			@ApiResponse(code = 404, message = " ParallelProcess not found") })
	public @ResponseBody
	List<ParallelProcessDTO> getParallelProcessByWlfwSubProcessId(
			@ApiParam(value = "Wlfw SubProcessId of the SubProcessFields that needs to be fetch ParallelProcess", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return subProcessFieldsService
				.getParallelProcessByWlfwSubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/getMotorOrderDetailByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find Motor OrderDetail By Wlfw SubProcessId", notes = "Returns a Motor OrderDetail entity when wlfw SubProcessId of the SubProcessFields is passed", response = MotorOrderDetailDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Wlfw SubProcessId supplied"),
			@ApiResponse(code = 404, message = " OrderDetail not found") })
	public @ResponseBody
	List<MotorOrderDetailDTO> getMotorOrderDetailByWlfwSubProcessId(
			@ApiParam(value = "Wlfw SubProcessId of the SubProcessFields that needs to be fetch Motor OrderDetails", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return subProcessFieldsService
				.getMotorOrderDetailByWlfwSubProcessId(wlfwSubProcessId);
	}

	@RequestMapping(value = "/addUpdateMotorOrderDetailsToSubProcessDetail/{wlfwSubProcessId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add wlfwSubProcessId to Order Detail when wlfwSubProcessId is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long addUpdateMotorOrderDetailsToSubProcessDetail(
			@ApiParam(value = "wlfwSubProcessId of SubProcessFields that adds MotorOrderDetail to SubProcess", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "SubProcessFields to be added in MotorOrderDetail", required = true) @RequestBody List<MotorOrderDetailDTO> motorOrderDetailDTOs) {

		return subProcessFieldsService
				.addUpdateMotorOrderDetailsToSubProcessDetail(wlfwSubProcessId,
						motorOrderDetailDTOs);
	}

	@RequestMapping(value = "/addUpdateFSEVisitDetailsToSubProcessDetail/{wlfwSubProcessId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add wlfwSubProcessId to FSEVisitDetail when wlfwSubProcessId is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long addUpdateFSEVisitDetailsToSubProcessDetail(
			@ApiParam(value = "wlfwSubProcessId of SubProcessFields that adds FSEVisitDetail to SubProcess", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "SubProcessFields to be added in FSEVisitDetail", required = true) @RequestBody List<FSEVisitDetailDTO> FSEVisitDetailDTOs) {

		return subProcessFieldsService
				.addUpdateFSEVisitDetailsToSubProcessDetail(wlfwSubProcessId,
						FSEVisitDetailDTOs);
	}

	@RequestMapping(value = "/deleteSubProcessFieldsByWlfwSubProcessId/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete Budgeted BOM By wlfwSub ProcessId", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid  wlfwSubProcess Id value") })
	public @ResponseBody
	Boolean deleteSubProcessFieldsByWlfwSubProcessId(
			@ApiParam(value = "WlfwSubProcess Id to delete", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		try {
			return subProcessFieldsService
					.deleteSubProcessFieldsByWlfwSubProcessId(wlfwSubProcessId);
		} catch (Exception e) {
			return false;
		}
	}

	@RequestMapping(value = "/addMotorAttachmentDetailToSubProcessFields/{wlfwSubProcessId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Motor Attachment Detail to Sub Process Fields when SubProcess Id is passed", notes = "", response = Void.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "Sub Process Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long addMotorAttachmentDetailToSubProcessFields(
			@ApiParam(value = "Id of SubProcessFields", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "Motor Attachment Detail to be added in SubProcessFields", required = true) @RequestBody List<MotorAttachmentDetailDTO> motorAttachmentDetailDTOList) {
		return subProcessFieldsService
				.addMotorAttachmentDetailToSubProcessFields(wlfwSubProcessId,
						motorAttachmentDetailDTOList);
	}

	@RequestMapping(value = "/addMotorSparesDetailToSubProcessFields/{wlfwSubProcessId}", method = { RequestMethod.POST }, produces = { "application/json" })
	@ApiOperation(value = "Add Motor Spares Detail to Sub Process Fields when SubProcess Id is passed", notes = "", response = Void.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "Sub Process Fields not found"),
			@ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long addMotorSparesDetailToSubProcessFields(
			@ApiParam(value = "Id of SubProcessFields", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "Motor Spares Detail to be added in SubProcessFields", required = true) @RequestBody List<MotorSparesDetailDTO> motorSparesDetailDTOList) {
		return subProcessFieldsService.addMotorSparesDetailToSubProcessFields(
				wlfwSubProcessId, motorSparesDetailDTOList);
	}

	@RequestMapping(value = "/addParallelProcessToSubProcessField/{wlfwSubProcessId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update ParallelProcess in SubProcessField when wlfwSubProcessId "
			+ "is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Long addParallelProcessToSubProcessField(
			@ApiParam(value = "Parallel Process Detail of ParallelProcess  adds or updates  to SubProcessField", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId,
			@ApiParam(value = "Parallel Process to be added in SubProcessField", required = true) @RequestBody List<ParallelProcessDTO> parallelProcessDetailDTOList) {
		return subProcessFieldsService.addParallelProcessToSubProcessField(
				wlfwSubProcessId, parallelProcessDetailDTOList);
	}

	@RequestMapping(value = "/getSubProcessFieldsByWlfwSubProcessIdandTenantIdandSolCatId/{wlfwSubProcessId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find SubProcessFields Fields By wlfwSubProcessId ,TenantId and solutionCategoryId", notes = "Returns a SubProcessFields  entity when MasterWorkflowId,TenantId and SolutionCategoryId is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid wlfwSubProcessId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " SubProcessFields Fields not found") })
	public @ResponseBody
	SubProcessFieldsDTO getSubProcessFieldsByWlfwSubProcessIdandTenantIdandSolCatId(
			@ApiParam(value = "wlfwSubProcessId of the SubProcessFields that needs to be fetched", required = true) @PathVariable(value = "wlfwSubProcessId") final Long wlfwSubProcessId,
			@ApiParam(value = "tenantId of the SubProcessFields that needs to be fetched", required = true) @PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "solutionCategoryId of the SubProcessFields that needs to be fetched", required = true) @PathVariable(value = "solutionCategoryId") final String solutionCategoryId) {
		SubProcessFieldsDTO subProcessFieldsDTO = subProcessFieldsService
				.getSubProcessFieldsByWlfwSubProcessIdandTenantIdandSolCatId(
						wlfwSubProcessId, tenantId, solutionCategoryId);
		return subProcessFieldsDTO;
	}

	@RequestMapping(value = "/searchByParameter", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Search SubProcessFields By mlfbSpiridon,motorSnNum,gspRefNo and customerName", notes = "", response = SubProcessFieldsDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	List<SearchByParameterDTO> searchByParameter(
			@ApiParam(value = "SubProcessFields object will fetched based on mlfbSpiridon,motorSnNum,gspRefNo and customerName ") @RequestBody SearchByParameterDTO searchByParameterDTO) {
		return subProcessFieldsService.searchByParameter(searchByParameterDTO);
	}

	/* TO GENERATE CSV */
	@RequestMapping(value = "/getAllMasterWorkflowFieldsWorkflow", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields ", notes = "Returns a SubProcess Fields entity when WlfwSubProcess Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	void getAllMasterWorkflowFieldsWorkflow(HttpServletResponse response) {
		String fileName = workflowService.generateCSVForAllWorkflowData(null,
				null);
		downloadCSVFile(response, fileName);
	}

	@RequestMapping(value = "/getTrackcallStatusList/{gspRefNo}/{actorId}", method = RequestMethod.GET)
	@ApiOperation(value = "Find SubProcessFields Fields By wlfwSubProcessId ,TenantId and solutionCategoryId", notes = "Returns a SubProcessFields  entity when MasterWorkflowId,TenantId and SolutionCategoryId is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid wlfwSubProcessId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " SubProcessFields Fields not found") })
	public @ResponseBody
	List<TrackCallStatusDTO> getTrackcallStatusList(
			@ApiParam(value = "wlfwSubProcessId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo,
			@ApiParam(value = "tenantId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("actorId") String actorId)

	{
		return trackcallStatusService.getTrackcallStatusList(gspRefNo, actorId);

	}
	
	@RequestMapping(value = "/getAllMasterWorkflowFieldsWorkflow/{gspRefNo} ", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields ", notes = "Returns a SubProcess Fields entity when WlfwSubProcess Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	void getAllMasterWorkflowFieldsWorkflow(
			HttpServletResponse response,
			@ApiParam(value = "wlfwSubProcessId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo) {
		String fileName = workflowService.generateCSVForAllWorkflowData(
				gspRefNo, null);
		downloadCSVFile(response, fileName);
	}
	
	@RequestMapping(value = "/getAllMasterWorkflowFieldsWorkflow/{gspRefNo}/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All SubProcess Fields ", notes = "Returns a SubProcess Fields entity when WlfwSubProcess Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 404, message = "SubProcessFields not found") })
	public @ResponseBody
	void getAllMasterWorkflowFieldsWorkflow(
			HttpServletResponse response,
			@ApiParam(value = "wlfwSubProcessId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo,
			@ApiParam(value = "wlfwSubProcessId of the SubProcessFields that needs to be fetched", required = true) @PathVariable("wlfwSubProcessId") String wlfwSubProcessId) {

		String fileName = workflowService.generateCSVForAllWorkflowData(
				gspRefNo, wlfwSubProcessId);

		downloadCSVFile(response, fileName);
	}

	private void downloadCSVFile(HttpServletResponse response, String fileName) {

		List<ConfigDetail> configList = configDetailRepo
				.findAllConfigDetailsByConfigTypeNSubtype(
						MotorRepairConstants.CSV_DOWNLOAD,
						MotorRepairConstants.BASE_LOCATION,
						MotorRepairConstants.TENANT_ID,
						MotorRepairConstants.PROGRAM_ID);
		if (configList != null && configList.size() > 0) {
			ConfigDetail confDet = configList.get(0);
			String baseLocation=confDet.getConfigStrVal();
			InputStream is = null;
			try {
				File file = new File(baseLocation + fileName);
				response.setContentType(new MimetypesFileTypeMap()
						.getContentType(file));
				response.setContentLength((int) file.length());
				response.setHeader(
						"content-disposition",
						"attachment; filename="
								+ URLEncoder.encode(fileName, "UTF-8"));
				is = new FileInputStream(file);
				FileCopyUtils.copy(is, response.getOutputStream());

			} catch (IOException e) {

			} finally {
				try {
					if (is != null) {
						is.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
	}
	
	@RequestMapping(value = "/getWorkLogBySubProcessFieldsBy/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Get Work Log for  SubProcess Fields By WlfwSubProcess Id", notes = "Returns a list of rmt audit task entity when WlfwSubProcess Id is passed", response = SubProcessFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid WlfwSubProcess Id supplied"),
			@ApiResponse(code = 404, message = "No Log found") })
	public @ResponseBody
	List<RMTTaskLogDTO> getWorkLogBySubProcessFieldsBy(
			@ApiParam(value = "WlfwSubProcess Id of the SubProcessFields that needs to be fetched", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) throws SQLException {
		
		return subProcessFieldsService.getWorkLogBySubProcessFieldsBy(wlfwSubProcessId);
				
	}
	
	@RequestMapping(value = "/deleteMultipleSubProcessFieldsForGroup", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update SubProcess Fields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody
	Boolean deleteMultipleSubProcessFieldsForGroup(
			@ApiParam(value = "SubProcessFields object that needs to be added or update in the subProcessFields") @RequestBody List<Long> subprocessIdList) {
		return subProcessFieldsService
				.deleteMultipleSubProcessFieldsForGroup(subprocessIdList);
	}

}
