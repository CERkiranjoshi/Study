package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorSpeedDetail;
import net.atos.motorrepairmgmt.repository.MotorSpeedDetailRepository;
import net.atos.motorrepairmgmt.services.MotorSpeedDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class MotorSpeedDetailServiceImpl implements MotorSpeedDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The MotorSpeedDetail Repository */
	@Autowired
	private MotorSpeedDetailRepository motorSpeedDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorNamePlateDetailServicesImpl.class);

	/**
	 * The method creates/updates a MotorSpeedDetail record. The method performs
	 * an update operation when motorSpeedDetailId is passed and an existing
	 * record with matching motorSpeedDetailId is fetched for updation.
	 * 
	 * @param motorSpeedDetailDTO
	 *            The MotorSpeedDetail Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateMotorSpeedDetail(MotorSpeedDetailDTO motorSpeedDetailDTO) {
		LOGGER.info("MotorSpeedDetailServiceImpl : createUpdateMotorSpeedDetail : Start");
		Long id = -1l;
		MotorSpeedDetail motorSpeedDetails = new MotorSpeedDetail();
		try {
			if (null != motorSpeedDetailDTO) {
				if (null != motorSpeedDetailDTO.getMotorSpeedDetailId()) {
					motorSpeedDetails = motorSpeedDetailRepository.findOne(motorSpeedDetailDTO.getMotorSpeedDetailId());
				}
				BeanUtils.copyProperties(motorSpeedDetailDTO, motorSpeedDetails,
						NullPropertyMapper.getNullPropertyNames(motorSpeedDetailDTO));

				MotorSpeedDetail savedObj = motorSpeedDetailRepository.save(motorSpeedDetails);
				LOGGER.info("MotorSpeedDetailServiceImpl : createUpdateMotorSpeedDetail : Record Saved/Updated");
				if (savedObj != null) {
					id = savedObj.getMotorSpeedDetailId();
				}
			} else {
				LOGGER.info("MotorSpeedDetailServiceImpl : createUpdateMotorSpeedDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return id;
	}

	/**
	 * The method retrieves all the MotorSpeedDetail
	 * 
	 * @return List of MotorSpeedDetail DTOs
	 * 
	 */
	@Override
	public List<MotorSpeedDetailDTO> getAllMotorSpeedDetail() {
		LOGGER.info("MotorSpeedDetailServiceImpl : getAllMotorSpeedDetail : Start");

		List<MotorSpeedDetailDTO> motorSpeedDetailDTOs = null;

		List<MotorSpeedDetail> motorSpeedDetails = motorSpeedDetailRepository.findAll();

		if (null != motorSpeedDetails) {
			motorSpeedDetailDTOs = new ArrayList<MotorSpeedDetailDTO>();

			MotorSpeedDetailDTO motorSpeedDetailDTO = null;

			for (MotorSpeedDetail motorSpeedDetailRecord : motorSpeedDetails) {
				motorSpeedDetailDTO = new MotorSpeedDetailDTO();

				motorSpeedDetailDTO = dozerBeanMapper.map(motorSpeedDetailRecord, MotorSpeedDetailDTO.class);

				motorSpeedDetailDTOs.add(motorSpeedDetailDTO);
			}
		}
		LOGGER.info("MotorSpeedDetailServiceImpl : getAllMotorSpeedDetail : End");
		return motorSpeedDetailDTOs;
	}

	/**
	 * The method retrieves a MotorSpeedDetail on the basis of motorSpeedDetail
	 * id.
	 * 
	 * @param motorSpeedDetailId
	 *            The MotorSpeedDetail Id
	 * @return MotorSpeedDetail DTO
	 * 
	 */
	@Override
	public MotorSpeedDetailDTO getSpeedDetailByspeedDetailId(Long motorSpeedDetailId) {
		LOGGER.info("MotorSpeedDetailServiceImpl : getSpeedDetailByspeedDetailID : Start");
		MotorSpeedDetailDTO motorSpeedDetailDTO = null;
		if (null != motorSpeedDetailId) {
			MotorSpeedDetail motorSpeedDetails = motorSpeedDetailRepository.findOne(motorSpeedDetailId);

			if (null != motorSpeedDetails) {
				motorSpeedDetailDTO = dozerBeanMapper.map(motorSpeedDetails, MotorSpeedDetailDTO.class);
			}
		}
		LOGGER.info("MotorSpeedDetailServiceImpl : getSpeedDetailByspeedDetailID : End");
		return motorSpeedDetailDTO;
	}

	/**
	 * The deletes a MotorSpeedDetail on the basis its MotorSpeedDetail id.
	 * 
	 * @param motorSpeedDetailId
	 *            The MotorSpeedDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMotorSpeedDetailBySpeedDetailId(Long motorSpeedDetailId) {
		LOGGER.info("MotorSpeedDetailServiceImpl : deleteMotorSpeedDetailBySpeedDetailID : Start");
		boolean returnVal = false;
		try {
			if (null != motorSpeedDetailId) {
				motorSpeedDetailRepository.delete(motorSpeedDetailId);
				returnVal = true;
			} else {
				LOGGER.info("MotorSpeedDetailServiceImpl : deleteMotorSpeedDetailBySpeedDetailID : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}
