package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.FSEVisitDetailDTO;
import net.atos.motorrepairmgmt.entity.FSEVisitDetail;
import net.atos.motorrepairmgmt.repository.FSEVisitDetailRepository;
import net.atos.motorrepairmgmt.services.FSEVisitDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class FSEVisitDetailServiceImpl implements FSEVisitDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The FSEVisitDetail Repository */
	@Autowired
	private FSEVisitDetailRepository fSEVisitDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(FSEVisitDetailServiceImpl.class);

	/**
	 * The method creates/updates a FSEVisitDetail record. The method performs
	 * an update operation when FSEVisitDetailId is passed and an existing
	 * record with matching FSEVisitDetailId is fetched for updation.
	 * 
	 * @param fSEVisitDetailDTO
	 *            The FSEVisit Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateFSEVisitDetail(FSEVisitDetailDTO fSEVisitDetailDTO) {
		LOGGER.info("FSEVisitDetailServiceImpl : createUpdateFSEVisitDetail : Start");
		Long returnId = -1l;
		FSEVisitDetail fSEVisitDetails = new FSEVisitDetail();
		try {
			if (null != fSEVisitDetailDTO) {
				if (null != fSEVisitDetailDTO.getFseVisitDetailId()) {
					fSEVisitDetails = fSEVisitDetailRepository.findOne(fSEVisitDetailDTO.getFseVisitDetailId());

				}
				/**
				 * fSEVisitDetails = dozerBeanMapper.map(fSEVisitDetailDTO,
				 * FSEVisitDetail.class);
				 */

				BeanUtils.copyProperties(fSEVisitDetailDTO, fSEVisitDetails,
						NullPropertyMapper.getNullPropertyNames(fSEVisitDetailDTO));

				FSEVisitDetail savedObj = fSEVisitDetailRepository.save(fSEVisitDetails);
				LOGGER.info("FSEVisitDetailServiceImpl : createUpdateFSEVisitDetail : Record Saved/Updated");
				if (null != savedObj) {
					returnId = savedObj.getFseVisitDetailId();
				}
			} else {
				LOGGER.info("FSEVisitDetailServiceImpl : createUpdateFSEVisitDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return returnId;
	}

	/**
	 * The method retrieves all the FSEVisitDetail
	 * 
	 * @return List of FSEVisitDetail DTOs
	 * 
	 */
	@Override
	public List<FSEVisitDetailDTO> getAllFSEVisitDetail() {
		LOGGER.info("FSEVisitDetailServiceImpl : getAllFSEVisitDetail : Start");

		List<FSEVisitDetailDTO> fSEVisitDetailDTOs = null;

		List<FSEVisitDetail> fSEVisitDetails = fSEVisitDetailRepository.findAll();

		if (null != fSEVisitDetails) {
			fSEVisitDetailDTOs = new ArrayList<FSEVisitDetailDTO>();

			FSEVisitDetailDTO fSEVisitDetailDTO = null;

			for (FSEVisitDetail fSEVisitDetailRecord : fSEVisitDetails) {
				fSEVisitDetailDTO = new FSEVisitDetailDTO();

				fSEVisitDetailDTO = dozerBeanMapper.map(fSEVisitDetailRecord, FSEVisitDetailDTO.class);

				fSEVisitDetailDTOs.add(fSEVisitDetailDTO);
			}
		}
		LOGGER.info("FSEVisitDetailServiceImpl : getAllFSEVisitDetail : End");
		return fSEVisitDetailDTOs;
	}

	/**
	 * The method retrieves a FSEVisitDetail on the basis of fseVisitDetail Id.
	 * 
	 * @param fseVisitDetailId
	 *            The fseVisitDetail Id
	 * @return FSEVisitDetail DTO
	 * 
	 */
	@Override
	public FSEVisitDetailDTO getFSEVisitDetailById(Long fseVisitDetailId) {
		LOGGER.info("FSEVisitDetailServiceImpl : getFSEVisitDetailById : Start");
		FSEVisitDetailDTO fSEVisitDetailDTO = null;
		if (null != fseVisitDetailId) {
			FSEVisitDetail fSEVisitDetails = fSEVisitDetailRepository.findOne(fseVisitDetailId);

			if (null != fSEVisitDetails) {
				fSEVisitDetailDTO = dozerBeanMapper.map(fSEVisitDetails, FSEVisitDetailDTO.class);
			}
		}
		LOGGER.info("FSEVisitDetailServiceImpl : getFSEVisitDetailById : End");
		return fSEVisitDetailDTO;
	}

	/**
	 * The method retrieves a FSEVisitDetail on the basis of fseVisitDetail id.
	 * 
	 * @param fseName
	 *            The FSEName
	 * @return list of FSEVisitDetail DTOs
	 * 
	 */
	@Override
	public List<FSEVisitDetailDTO> getFSEVisitByName(String fseName) {
		LOGGER.info("FSEVisitDetailServiceImpl : getFSEVisitDetailById : Start");
		List<FSEVisitDetailDTO> fSEVisitDetailDTOs = null;
		List<FSEVisitDetail> fSEVisitDetails = null;
		if (null != fseName) {
			fSEVisitDetails = fSEVisitDetailRepository.findFSEVisitByName(fseName);
			if (null != fSEVisitDetails) {
				fSEVisitDetailDTOs = new ArrayList<FSEVisitDetailDTO>();
				FSEVisitDetailDTO fSEVisitDetailDTO = null;
				for (FSEVisitDetail FSEVisitDetailRecord : fSEVisitDetails) {
					fSEVisitDetailDTO = new FSEVisitDetailDTO();
					fSEVisitDetailDTO = dozerBeanMapper.map(FSEVisitDetailRecord, FSEVisitDetailDTO.class);
					fSEVisitDetailDTOs.add(fSEVisitDetailDTO);
				}
			}
		}
		LOGGER.info("FSEVisitDetailServiceImpl : getFSEVisitDetailById : End");
		return fSEVisitDetailDTOs;
	}

	/**
	 * The deletes a FSEVisitDetail on the basis its FSEVisitDetail Id.
	 * 
	 * @param fseVisitDetailId
	 *            The fseVisitDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteFSEVisitDetailByFSEVisitDetailId(Long fseVisitDetailId) {
		LOGGER.info("FSEVisitDetailServiceImpl : deleteFSEVisitDetailByFSEVisitDetailId : Start");
		boolean returnVal = false;
		try {
			if (null != fseVisitDetailId) {
				fSEVisitDetailRepository.delete(fseVisitDetailId);
				returnVal = true;
			} else {
				LOGGER.info("FSEVisitDetailServiceImpl : deleteFSEVisitDetailByFSEVisitDetailId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}
