/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component(value = "flowTypeInitializer")
public class FlowTypeInitializer extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(FlowTypeInitializer.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; FlowTypeInitializer: START " + execution.getId());
	    /*
	     * Set flow type based on current function code
	     */
		String functionCode=execution.getVariable(ActivitiConstants.FUNCTION_CODE).toString();
		if(functionCode.equals(MotorRepairConstants.ARC_ASSIGNMENT_CODE)){
			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; set flow type as repairs " + execution.getId());
			execution.setVariable(MotorRepairConstants.CHECK_FLOW_TYPE, MotorRepairConstants.FLOW_TYPE.REPAIRS.toString());
		}
		else if(functionCode.equals(MotorRepairConstants.FS_ASSIGNMENT)){
			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; set flow type as FS" + execution.getId());
			execution.setVariable(MotorRepairConstants.CHECK_FLOW_TYPE, MotorRepairConstants.FLOW_TYPE.FS.toString());
		}
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; FlowTypeInitializer: END " + execution.getId());
	}

}
