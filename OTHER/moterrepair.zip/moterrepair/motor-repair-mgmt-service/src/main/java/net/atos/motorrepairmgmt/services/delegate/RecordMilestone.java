/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import java.util.Date;

import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.common.dto.MilestonesDTO;
import net.atos.taskmgmt.service.MilestonesService;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Sweety Kothari
 *
 */
@Service
public class RecordMilestone implements JavaDelegate {

	@Autowired
	private MilestonesService milestoneService;
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine
	 * .delegate.DelegateExecution)
	 */

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(RecordMilestone.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; inside record milestone ....");
		MilestonesDTO milestonesDTO= new MilestonesDTO();
		milestonesDTO.setMilestoneName(execution.getCurrentActivityName());
		milestonesDTO.setMilestoneTimeStamp(new Date());
		milestonesDTO.setTenantId(execution.getVariable(ActivitiConstants.ACTIVITI_PROC_VAR_TENANT_ID).toString());
		//save entry in milestone table
		milestoneService.createUpdateMilestones(milestonesDTO);
		
	}

}
