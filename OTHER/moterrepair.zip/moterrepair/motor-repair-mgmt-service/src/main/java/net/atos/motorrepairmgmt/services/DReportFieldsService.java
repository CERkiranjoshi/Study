package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.DReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;

/**
 * @author a610051
 * 
 */
public interface DReportFieldsService {

	DReportFieldsDTO createUpdateDReportFields(DReportFieldsDTO dReportFieldsDTO);

	Boolean deleteDReportFieldsByMotorDReportFieldId(Long motorDReportFieldId);

	List<DReportFieldsDTO> getAllDReportFields();

	DReportFieldsDTO getDReportFieldsBySubProcessID(Long wlfwSubProcessId);

	MotorNamePlateDetailDTO getNamePlateByDReportId(Long motorDReportFieldId);

	Boolean addUpdateMotorNamePlateDetailToDReportFields(Long motorDReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO);

	Long addUpdateSubProcessFieldsToDReportFields(Long motorDReportFieldId, SubProcessFieldsDTO subProcessFieldsDTO);

	DReportFieldsDTO getDReportFieldsByMotorDReportFieldId(Long motorDReportFieldId);
	
	DReportFieldsDTO getDReportFieldsApprovedStatusBySubProcessID(Long wlfwSubProcessId);

}
