package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.TrackCallStatusDTO;

public interface TrackcallStatusService 
{
	List<TrackCallStatusDTO> getTrackcallStatusList(String gspRefNo,String actorId);

}
