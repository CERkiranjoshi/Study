/**
 * 
 */
package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.entity.ConfigDetail;
import net.atos.motorrepairmgmt.repository.ConfigDetailRepository;
import net.atos.motorrepairmgmt.services.ConfigDetailService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Sweety Kothari
 * 
 */
@Service
public class ConfigDetailServiceImpl implements ConfigDetailService {

	@Autowired
	private ConfigDetailRepository configDetailRepo;

	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	private static Map<String, Map<String, List<ConfigDetail>>>  configDetailMap = new HashMap<String, Map<String, List<ConfigDetail>>>();

	private static final Logger LOGGER = Logger.getLogger(ConfigDetailServiceImpl.class);

	private static boolean initialized = false;
	
	private void setDataInMap(String tenantId,String solCatId){
		LOGGER.info("START: config detail map set method");
		List<ConfigDetail> configDetailList = configDetailRepo.findAllConfigDetailsByTenantNSolnCatId(tenantId,
				solCatId);

		for (ConfigDetail configDetail : configDetailList) {
           //fetch config typ
			String configType = configDetail.getConfigType();
			Map<String, List<ConfigDetail>> configSubTypeMap = configDetailMap.get(configType);
			//if record already present ,then check for subtype map
			if (null != configSubTypeMap) {
				// Obtain and add to this
				List<ConfigDetail> configSubTypeList = configSubTypeMap.get(configDetail.getConfigSubType());
				//if subtype record already present ,then add to existing subtype list
				if (null != configSubTypeList) {
					// add
					configSubTypeList.add(configDetail);
				} else {
					// create and add
					configSubTypeList = new ArrayList<ConfigDetail>();
					configSubTypeList.add(configDetail);
					configSubTypeMap.put(configDetail.getConfigSubType(), configSubTypeList);
				}

			} else {
				// Create new Map and add
				configSubTypeMap = new HashMap<String, List<ConfigDetail>>();
				List<ConfigDetail> configSubTypeList = new ArrayList<ConfigDetail>();
				configSubTypeList.add(configDetail);
				configSubTypeMap.put(configDetail.getConfigSubType(), configSubTypeList);
				configDetailMap.put(configDetail.getConfigType(), configSubTypeMap);

			}

		}
	}
	
	private synchronized boolean setConfigDetailMapData(String tenantId, String solCatId) {
		if(!initialized) {
	   setDataInMap(tenantId,solCatId);
		initialized = true;
		}
		LOGGER.info("END: config detail map set method");
		return configDetailMap.size() > 0 ? true : false;
	}

	@Override
	public List<ConfigDetailDTO> findConfigDetailsByConfigTypeNSubType(String configType, String subType,
			String tenantId, String solnCatId) {
		if (configDetailMap.isEmpty()) {
			LOGGER.info("configDetailMap is empty");
			setConfigDetailMapData(tenantId, solnCatId);
		}
		List<ConfigDetail> filterConfigList = new ArrayList<ConfigDetail>();

		// fetch record from map & compare subType
		Map<String, List<ConfigDetail>> subConfigMap = configDetailMap.get(configType);
		if (null != subConfigMap) {
			filterConfigList=subConfigMap.get(subType);
			}
        // convert it into DTO
		return mapConfigEnityListToDTO(filterConfigList);
	}

	@Override
	public List<ConfigDetailDTO> findConfigDetailsByConfigType(String configType, String tenantId, String solnCatId) {
		if (configDetailMap.isEmpty()) {
			LOGGER.info("configDetailMap is empty");
			setConfigDetailMapData(tenantId, solnCatId);
		}
		List<ConfigDetail> filterConfigList = new ArrayList<ConfigDetail>();
		// fetch record from map
		Map<String, List<ConfigDetail>> subConfigMap = configDetailMap.get(configType);
		if (null != subConfigMap) {
			for (String key : subConfigMap.keySet()) {
				filterConfigList.addAll(subConfigMap.get(key));
			}
		}
		// convert it into DTO
		return mapConfigEnityListToDTO(filterConfigList);
	}

	private List<ConfigDetailDTO> mapConfigEnityListToDTO(List<ConfigDetail> configDetailList) {
		List<ConfigDetailDTO> configDetailDTOList = null;
		ConfigDetailDTO configDetailDTO = null;
		if (null != configDetailList && configDetailList.size() > 0) {
			configDetailDTOList = new ArrayList<ConfigDetailDTO>();
			for (ConfigDetail configDetail : configDetailList) {
				configDetailDTO = dozerBeanMapper.map(configDetail, ConfigDetailDTO.class);
				configDetailDTOList.add(configDetailDTO);
			}
		}
		return configDetailDTOList;
	}

	@Override
	public List<ConfigDetailDTO> findEnabledNVisibleConfigDetailsByTypeNSubType(String configType, String subType,
			String tenantId, String solnCatId) {
		if (configDetailMap.isEmpty()) {
			setConfigDetailMapData(tenantId, solnCatId);
		}
		List<ConfigDetail> filterdconfigDetaiList = new ArrayList<ConfigDetail>();
		if (null != subType && !subType.isEmpty()) {
			// fetch record from map & compare subType
			Map<String, List<ConfigDetail>> subConfigMap = configDetailMap.get(configType);
			if (null != subConfigMap) {
				
				        List<ConfigDetail> configDetailList = subConfigMap.get(subType);
						if(null !=configDetailList){
						for (ConfigDetail configDetail : configDetailList) {
							if (configDetail.getConfigVisiblity() == MotorRepairConstants.VISIBLE
									&& configDetail.getConfigEnabled() == MotorRepairConstants.ENABLE) {
								filterdconfigDetaiList.add(configDetail);
							}
						
					}
						
				}
			}

		}
		// convert it into DTO
		return mapConfigEnityListToDTO(filterdconfigDetaiList);
	}

	@Override
	public List<ConfigDetailDTO> findEnabledNVisibleConfigDetailsByType(String configType, String tenantId,
			String solnCatId) {
		// fetch record from map
		if (configDetailMap.isEmpty()) {
			LOGGER.info("configDetailMap is empty");
			setConfigDetailMapData(tenantId, solnCatId);
		}
		List<ConfigDetail> filterdconfigDetaiList = new ArrayList<ConfigDetail>();
		Map<String, List<ConfigDetail>> subConfigMap = configDetailMap.get(configType);
		if (null != subConfigMap) {
			for (String key : subConfigMap.keySet()) {
				List<ConfigDetail> configDetailList = subConfigMap.get(key);
				for (ConfigDetail configDetail : configDetailList) {
					if (configDetail.getConfigVisiblity() == MotorRepairConstants.VISIBLE
							&& configDetail.getConfigEnabled() == MotorRepairConstants.ENABLE) {
						filterdconfigDetaiList.add(configDetail);
					}
				}
			}
		}
		return mapConfigEnityListToDTO(filterdconfigDetaiList);
	}

	@Override
	public boolean refreshCacheData(String tenantId, String solcatId) {
		// reset map
		boolean flag = false;
		configDetailMap.clear();;
		setDataInMap(tenantId, solcatId);
		return true;

	}
	
	@Override
	public List<ConfigDetailDTO> findConfigDetailByTenantIdNSolnCatId(String tenantId, String solnCatId) {
		List<ConfigDetail> configDetailList=new ArrayList<ConfigDetail>();
		
		if(null != tenantId && null != solnCatId){
			boolean value= refreshCacheData(tenantId,solnCatId);
			if(value){
				configDetailList = configDetailRepo.findAllConfigDetailsByTenantNSolnCatIdData(tenantId,solnCatId);
			}
		}
		return mapConfigEnityListToDTO(configDetailList);
	}
	
	@Override
	@Transactional
	public Long createUpdateConfigDetail(ConfigDetailDTO configDetailDTO) {
		LOGGER.info("ConfigDetailServiceImpl : createUpdateConfigDetail : Start");
		ConfigDetail configDetail = null;
		Long returnId = -1l;
		try {
			if (null != configDetailDTO) {
				if (null != configDetailDTO.getConfigId()) {
					configDetail = configDetailRepo.findOne(configDetailDTO.getConfigId());
					configDetail.setModifiedOn(new Date());
				}
				if (null == configDetail) {
					configDetail = new ConfigDetail();
					configDetail.setCreatedOn(new Date());
					configDetail.setModifiedOn(new Date());
				}
				BeanUtils.copyProperties(configDetailDTO, configDetail,
						NullPropertyMapper.getNullPropertyNames(configDetailDTO));
				ConfigDetail savedObject = configDetailRepo.save(configDetail);
				LOGGER.info("ConfigDetailServiceImpl : createUpdateConfigDetail : Record Saved/Updated");
				if (savedObject != null) {
					
					returnId = savedObject.getConfigId();
				}
			} else {
				LOGGER.info("ConfigDetailServiceImpl : createUpdateConfigDetail : configDetailDTO sent is Null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}
}
