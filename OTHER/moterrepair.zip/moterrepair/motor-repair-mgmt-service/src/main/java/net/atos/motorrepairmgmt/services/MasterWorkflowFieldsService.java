package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.MasterWorkflowFieldsDTO;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;

public interface MasterWorkflowFieldsService {

	public Long createUpdateMasterWorkflowFields(MasterWorkflowFieldsDTO masterWorkflowFieldsDTO);

	public List<MasterWorkflowFieldsDTO> getAllMasterWorkflowFieldsByTenantId(String tenantId);

	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByMasterWorkflowFieldId(Long masterWorkflowFieldId);

	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryId(String tenantId,
			String solutionCategoryId);

	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(
			String tenantId, String solutionCategoryId, String gspRefNo);

	public List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(
			String tenantId, String solutionCategoryId, String stateName);

	public List<CustomerDetailDTO> getCustomerDetailListByMasterWorkflowFieldId(Long masterWorkflowFieldId);

	public List<AdditionalContactDetailDTO> getAdditionalContactDetailByMasterWorkflowFieldId(Long masterWorkflowFieldId);

	public Boolean addUpdateCustomerDetailsToMasterWorkflowFields(Long masterWorkflowFieldId,
			List<CustomerDetailDTO> customerDetailDTOList);

	public Boolean deleteMasterWorkflowFieldsByMasterWorkflowFieldId(Long masterWorkflowFieldId);

	public Boolean addUpdateAdditionalContactDetailsToMasterWorkflowFields(Long masterWorkflowFieldId,
			List<AdditionalContactDetailDTO> additionalContactDetailDTOs);

	public WorkflowStateDTO getWorkflowStateByMasterWorkflowFieldId(Long masterWorkflowFieldId);

	public Boolean addUpdateWorkflowStateToMasterWorkflowFields(Long masterWorkflowFieldId,
			WorkflowStateDTO workflowStateDTO);

	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNo(String gspRefNo);
	
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState(String gspRefNo,String tenantId,String solutionCategoryId);
	
	public MasterWorkflowFieldsDTO getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId(Long masterWorkflowFieldId,String tenantId,
			String solutionCategoryId);
}
