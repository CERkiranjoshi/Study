package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;

/**
 * @author a610051
 * 
 */
public interface ElectricalObservationService {

	Long createUpdateElectricalObservation(ElectricalObservationDTO electricalObservationDTO);

	Boolean deleteElectricalObservationByMotorElecObsId(Long motorElecObsId);

	List<ElectricalObservationDTO> getAllElectricalObservation();

	ElectricalObservationDTO getElectricalObservationByMotorElecObsId(Long motorElecObsId);
}
