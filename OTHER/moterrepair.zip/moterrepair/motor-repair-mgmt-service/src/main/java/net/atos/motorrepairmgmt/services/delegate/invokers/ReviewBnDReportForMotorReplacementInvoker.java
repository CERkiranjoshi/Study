/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.atos.motorrepairmgmt.dto.ARCMasterDTO;
import net.atos.motorrepairmgmt.dto.ConfigDetailDTO;
import net.atos.motorrepairmgmt.services.ARCMasterService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */
@Component(value = "reviewBnDReportForMotorReplacementInvoker")
public class ReviewBnDReportForMotorReplacementInvoker extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ReviewBnDReportForMotorReplacementInvoker.class);

	@Autowired
	private ARCMasterService arcMasterService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; REVIEW_B_D_REPORT_FOR_MOTOR_REPLACEMENT_INVOKER: START " + execution.getId());

		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT FUNCTION_CODE
		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.FUNCTION_CODE).toString() : null;

		// TODO Set Function Code of the Next Workflow to be executed
		String functionCode = MotorRepairConstants.ARC_VIEW_MOTOR_DETAIL_N_PROCESS_REPLACEMENT;

		Map<String, Object> nextProcessVars = new HashMap<String, Object>();

		// set paras related variable

		// TODO Set only required process variables from the workflow
		setNextProcessVariables(execution, nextProcessVars);
		setParasVariables(execution, nextProcessVars);
		String newProcInstanceId = invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; REVIEW_B_D_REPORT_FOR_MOTOR_REPLACEMENT_INVOKER: END " + execution.getId() + " NEW WORKFLOW ID : "
				+ newProcInstanceId);
	}

	private void setParasVariables(DelegateExecution execution, Map<String, Object> nextProcessVars) {
		int parasTypeARCId = 0;
		List<ConfigDetailDTO> configDetailDTOList = configDetailService.findEnabledNVisibleConfigDetailsByTypeNSubType(
				MotorRepairConstants.SYSTEM_CONFIG, MotorRepairConstants.PARAS_ARC_TYPE,
				MotorRepairConstants.TENANT_ID, MotorRepairConstants.PROGRAM_ID);
		if (null != configDetailDTOList && configDetailDTOList.size() > 0) {
			parasTypeARCId = configDetailDTOList.get(0).getConfigIntVal();

		}
		if (0 != parasTypeARCId) {

			// TODO this wud require to be changed as ARC types would be multiple
			List<ARCMasterDTO> arcMasterDTOs = arcMasterService.getARCMasterByArcType(parasTypeARCId);

			if ((null != arcMasterDTOs) && (0 < arcMasterDTOs.size())) {

				ARCMasterDTO arcMasterDTO = arcMasterDTOs.get(0);

				// Setting variables related to PARAS
				nextProcessVars.put(ActivitiConstants.ARC_REF_ID, arcMasterDTO.getArcId().toString());
				nextProcessVars.put(ActivitiConstants.ARC_TYPE, arcMasterDTO.getArcType());
				nextProcessVars.put(ActivitiConstants.ARC_NAME, arcMasterDTO.getArcName().toString());
				LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; REVIEW_B_D_REPORT_FOR_MOTOR_REPLACEMENT_INVOKER: " + execution.getId() + " PARAS ARC TYPE DETAILS SET");
			} else {
				LOGGER.error("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS TYPE ARC not available! PARAS TYPE not available in Process variables or in Config!");
			}
		} else {
			LOGGER.error("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; PARAS TYPE ARC not available! PARAS TYPE not available in Process variables or in Config!");
		}
	}

}
