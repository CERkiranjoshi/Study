package net.atos.motorrepairmgmt.serviceImpls;

import static net.atos.motorrepairmgmt.utils.NullPropertyMapper.getNullPropertyNames;

import java.util.ArrayList;
import java.util.List;

import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.entity.ElectricalObservation;
import net.atos.motorrepairmgmt.repository.ElectricalObservationRepository;
import net.atos.motorrepairmgmt.services.ElectricalObservationService;

import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a610051
 * 
 */
@Service
public class ElectricalObservationServiceImpl implements ElectricalObservationService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The ElectricalObservation Repository */
	@Autowired
	private ElectricalObservationRepository electricalObservationRepository;

	/** The UniqueIdGenerator */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ElectricalObservationServiceImpl.class);

	/**
	 * The method creates/updates a ElectricalObservation record. The method
	 * performs an update operation when motorElecObsId is passed and an
	 * existing record with matching motorElecObsId is fetched for updation Or
	 * it will create a new record
	 * 
	 * @param ElectricalObservationDTO
	 *            The electricalObservation Details
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Long createUpdateElectricalObservation(ElectricalObservationDTO electricalObservationDTO) {
		LOGGER.info("ElectricalObservationServiceImpl : createUpdateElectricalObservation : Start");
		ElectricalObservation electricalObservationDetails = null;
		Long returnId = -1l;
		try {
			if (null != electricalObservationDTO) {
				if (null != electricalObservationDTO.getMotorElecObsId()) {
					electricalObservationDetails = electricalObservationRepository.findOne(electricalObservationDTO
							.getMotorElecObsId());
				}
				if (null == electricalObservationDetails) {
					electricalObservationDetails = new ElectricalObservation();
				}
				BeanUtils.copyProperties(electricalObservationDTO, electricalObservationDetails,
						getNullPropertyNames(electricalObservationDTO));
				ElectricalObservation savedObj = electricalObservationRepository.save(electricalObservationDetails);
				if (null != savedObj) {
					LOGGER.info("ElectricalObservationServiceImpl : createUpdateElectricalObservation : Record Saved/Updated");
					returnId = savedObj.getMotorElecObsId();
				}
			} else {
				LOGGER.info("ElectricalObservationServiceImpl : createUpdateElectricalObservation : electricalObservationDTO sent is null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * The deletes a ElectricalObservation on the basis of its motorElecObsId.
	 * 
	 * @param motorElecObsId
	 *            The MotorElecObs Id
	 * @return Boolean
	 * 
	 */
	@Override
	@Transactional
	public Boolean deleteElectricalObservationByMotorElecObsId(Long motorElecObsId) {
		LOGGER.info("ElectricalObservationServiceImpl : deleteElectricalObservationByMotorElecObsId : Start");
		boolean returnVal = false;
		try {
			if (null != motorElecObsId) {
				electricalObservationRepository.delete(motorElecObsId);
				returnVal = true;
			} else {
				LOGGER.info("ElectricalObservationServiceImpl : deleteElectricalObservationByMotorElecObsId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("ElectricalObservationServiceImpl : deleteElectricalObservationByMotorElecObsId : Not Deleted. Record Not Present");
		}
		return returnVal;
	}

	/**
	 * The method retrieves all the ElectricalObservation
	 * 
	 * @return List of ElectricalObservationDTOs
	 * 
	 */
	@Override
	@Transactional
	public List<ElectricalObservationDTO> getAllElectricalObservation() {
		LOGGER.info("ElectricalObservationServiceImpl : getAllElectricalObservation : Start");
		List<ElectricalObservationDTO> electricalObservationDTOs = null;
		ElectricalObservationDTO electricalObservationDTO = null;
		List<ElectricalObservation> electricalObservationDetails = electricalObservationRepository.findAll();
		if (null != electricalObservationDetails) {
			electricalObservationDTOs = new ArrayList<ElectricalObservationDTO>();
			for (ElectricalObservation electricalObservationRecord : electricalObservationDetails) {
				electricalObservationDTO = new ElectricalObservationDTO();
				electricalObservationDTO = dozerBeanMapper.map(electricalObservationRecord,
						ElectricalObservationDTO.class);
				electricalObservationDTOs.add(electricalObservationDTO);
			}
		}
		LOGGER.info("ElectricalObservationServiceImpl : getAllElectricalObservation : End");
		return electricalObservationDTOs;
	}

	/**
	 * This method retrieves a ARCRepairEstimates on the basis of its
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * @return ARCRepairEstimates DTO
	 * 
	 */
	@Override
	@Transactional
	public ElectricalObservationDTO getElectricalObservationByMotorElecObsId(Long motorElecObsId) {
		LOGGER.info("ElectricalObservationServiceImpl : getElectricalObservationByMotorElecObsId : Start");
		ElectricalObservationDTO electricalObservationDTO = null;
		ElectricalObservation electricalObservationDetails = null;
		if (null != motorElecObsId) {
			electricalObservationDetails = electricalObservationRepository.findOne(motorElecObsId);
			if (null != electricalObservationDetails) {
				electricalObservationDTO = new ElectricalObservationDTO();
				electricalObservationDTO = dozerBeanMapper.map(electricalObservationDetails,
						ElectricalObservationDTO.class);
			}
		}
		LOGGER.info("ElectricalObservationServiceImpl : getElectricalObservationByMotorElecObsId : End");
		return electricalObservationDTO;
	}
}
