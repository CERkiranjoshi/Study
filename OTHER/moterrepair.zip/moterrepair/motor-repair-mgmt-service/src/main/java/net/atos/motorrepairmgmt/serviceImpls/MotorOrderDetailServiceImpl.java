package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorOrderDetailDTO;
import net.atos.motorrepairmgmt.entity.MotorOrderDetail;
import net.atos.motorrepairmgmt.repository.MotorOrderDetailRepository;
import net.atos.motorrepairmgmt.services.MotorOrderDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author a603981
 *
 */
@Service
@Transactional
public class MotorOrderDetailServiceImpl implements MotorOrderDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The MotorOrderDetail Repository */
	@Autowired
	private MotorOrderDetailRepository motorOrderDetailRepository;

	/** The UniqueIdGenerator Class */
	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorOrderDetailServiceImpl.class);

	/**
	 * The method creates/updates a MotorOrderDetail record. The method performs
	 * an update operation when motorOrderDetailId is passed and an existing
	 * record with matching motorOrderDetailId is fetched for updation.
	 * 
	 * @param MotorOrderDetailDTO
	 *            The order Details
	 * @return Boolean
	 */
	@Override
	public Long createUpdateMotorOrderDetail(MotorOrderDetailDTO motorOrderDetailDTO) {
		LOGGER.info("MotorOrderDetailServiceImpl : createUpdateOrderDetail : Start");
		Long id = -1l;
		MotorOrderDetail motorOrderDetails = new MotorOrderDetail();
		try {
			if (null != motorOrderDetailDTO) {
				if (null != motorOrderDetailDTO.getMotorOrderDetailId()) {
					motorOrderDetails = motorOrderDetailRepository.findOne(motorOrderDetailDTO.getMotorOrderDetailId());
					if (null != motorOrderDetails) {
						motorOrderDetailDTO.setCreatedOn(motorOrderDetails.getCreatedOn());
					}
				} else {
					motorOrderDetailDTO.setCreatedOn(new Date());

				}

				BeanUtils.copyProperties(motorOrderDetailDTO, motorOrderDetails,
						NullPropertyMapper.getNullPropertyNames(motorOrderDetailDTO));

				MotorOrderDetail savedObj = motorOrderDetailRepository.save(motorOrderDetails);
				LOGGER.info("MotorOrderDetailServiceImpl : createUpdateOrderDetail : Record Saved/Updated");
				if (savedObj != null) {
					id = savedObj.getMotorOrderDetailId();
				}
			} else {
				LOGGER.info("MotorOrderDetailServiceImpl : createUpdateOrderDetail : Not saved");
			}
		} catch (Exception e) {
			LOGGER.error("Exception...", e);
		}
		return id;
	}

	/**
	 * The method retrieves all the MotorOrderDetails
	 * 
	 * @return List of MotorOrderDetail DTOs
	 * 
	 */
	@Override
	public List<MotorOrderDetailDTO> getAllMotorOrderDetail() {
		LOGGER.info("MotorOrderDetailServiceImpl : getAllOrderDetail : Start");

		List<MotorOrderDetailDTO> motorOrderDetailDTOs = null;

		List<MotorOrderDetail> motorOrderDetails = motorOrderDetailRepository.findAll();

		if (null != motorOrderDetails) {
			motorOrderDetailDTOs = new ArrayList<MotorOrderDetailDTO>();

			MotorOrderDetailDTO motorOrderDetailDTO = null;

			for (MotorOrderDetail motorOrderDetailRecord : motorOrderDetails) {
				motorOrderDetailDTO = new MotorOrderDetailDTO();

				motorOrderDetailDTO = dozerBeanMapper.map(motorOrderDetailRecord, MotorOrderDetailDTO.class);

				motorOrderDetailDTOs.add(motorOrderDetailDTO);
			}
		}
		LOGGER.info("MotorOrderDetailServiceImpl : getAllOrderDetail : End");
		return motorOrderDetailDTOs;
	}

	/**
	 * The method retrieves a MotorOrderDetail on the basis of MotorOrderDetail
	 * id.
	 * 
	 * @param motorOrderDetailId
	 *            The motorOrderDetail Id
	 * @return MotorOrderDetail DTO
	 * 
	 */
	@Override
	public MotorOrderDetailDTO getMotorOrderDetailByMotorOrderDetailId(Long motorOrderDetailId) {
		LOGGER.info("MotorOrderDetailServiceImpl : getOrderDetailByOrderDetailID : Start");
		MotorOrderDetailDTO motorOrderDetailDTO = null;
		if (null != motorOrderDetailId) {
			MotorOrderDetail motorOrderDetails = motorOrderDetailRepository.findOne(motorOrderDetailId);

			if (null != motorOrderDetails) {
				motorOrderDetailDTO = dozerBeanMapper.map(motorOrderDetails, MotorOrderDetailDTO.class);
			}
		}
		LOGGER.info("MotorOrderDetailServiceImpl : getOrderDetailByOrderDetailID : End");
		return motorOrderDetailDTO;
	}

	/**
	 * The deletes a MotorOrderDetail on the basis its orderDetail id.
	 * 
	 * @param orderDetailId
	 *            The orderDetail Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteMotorOrderDetailByMotorOrderDetailId(Long motorOrderDetailId) {
		LOGGER.info("MotorOrderDetailServiceImpl : deleteOrderDetailByOrderDetailID : Start");
		boolean returnVal = false;
		try {
			if (null != motorOrderDetailId) {
				motorOrderDetailRepository.delete(motorOrderDetailId);
				returnVal = true;
			} else {
				LOGGER.info("MotorOrderDetailServiceImpl : deleteOrderDetailByOrderDetailID : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;
	}
}
