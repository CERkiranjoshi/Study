package net.atos.motorrepairmgmt.services;
import net.atos.motorrepairmgmt.dto.BuildDetailDTO;

/**
 * @author Sweety Kothari
 * 
 */

public interface BuildDetailService {
	
	BuildDetailDTO getCurrentBuildDetailByTenantIdNSolCategory(String tenantId,String solCategoryID);

}
