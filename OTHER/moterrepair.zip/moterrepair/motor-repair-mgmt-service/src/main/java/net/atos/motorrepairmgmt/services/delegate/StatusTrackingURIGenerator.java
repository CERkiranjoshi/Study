/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.motorrepairmgmt.services.delegate.listeners.BenchmarkEventListener;
import net.atos.motorrepairmgmt.services.utils.CipherUtil;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.impl.el.FixedValue;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Anand Ved
 * 
 */

@Component(value = "statusTrackingURIGenerator")
public class StatusTrackingURIGenerator implements JavaDelegate {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(StatusTrackingURIGenerator.class);

	/**
	 * CipherUtil to encode GSP Reference for Status Tracking URL
	 */
	@Autowired
	private CipherUtil cipherUtil;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; STATUS_TRACKING_URI_GENERATOR: START " + execution.getId());

		// TODO Generate Status Tracking URL here

		String batchProcessId = (null != execution.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID)) ? execution
				.getVariable(ActivitiConstants.MASTER_BATCH_PROCESS_ID).toString() : null;
		String gspRefNumber = (null != execution.getVariable(ActivitiConstants.GSP_REF_NO)) ? execution.getVariable(
				ActivitiConstants.GSP_REF_NO).toString() : null;
		if (null != batchProcessId) {
			String statusTrackingURLString = cipherUtil.encryptString(batchProcessId, gspRefNumber);

			execution.getVariables().put(ActivitiConstants.TRACKING_URL_STRING, statusTrackingURLString);

			LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; STATUS_TRACKING_URI_GENERATOR: [" + execution.getId()
					+ "] Generated Status Tracking URL String " + statusTrackingURLString);
		} else {
			LOGGER.warn("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; STATUS_TRACKING_URI_GENERATOR: [" + execution.getId()
					+ "] BATCH_PROCESS_ID is null, hence ticket encryptor not invoked! ");
		}

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; STATUS_TRACKING_URI_GENERATOR: END " + execution.getId());
	}

}
