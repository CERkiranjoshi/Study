/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.MotorAttachmentDetailDTO;

/**
 * @author a603327
 *
 */
public interface MotorAttachmentDetailService {

	public List<MotorAttachmentDetailDTO> getAllMotorAttachmentDetail();

	public Long createUpdateMotorAttachmentDetail(MotorAttachmentDetailDTO motorAttachmentDetailDTO);

	public Boolean deleteMotorAttachmentDetail(Long motorAttachmentsId);

	public MotorAttachmentDetailDTO getMotorAttachmentDetailById(Long motorAttachmentsId);

	public MotorAttachmentDetailDTO getMotorAttachmentDetailByMotorAttachmentsIdandTenantIdandSolCatId(Long motorAttachmentsId, String tenantId,String solutionCategoryId);

	public Long getMotorAttachmentCountBySubprocessIdandTenantIdandSolCatId(Long subprocessId, boolean externalAttachments, String solnCategoryId, String tenantId, String uploadedBy);
}
