package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.AdditionalContactDetailDTO;
import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.dto.MasterWorkflowFieldsDTO;
import net.atos.motorrepairmgmt.dto.WorkflowStateDTO;
import net.atos.motorrepairmgmt.services.MasterWorkflowFieldsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610039
 * 
 */
@EnableSwagger
@RequestMapping(value = "masterWorkflowFieldsService")
@Controller
public class MasterWorkflowFieldsController {
	@Autowired
	private MasterWorkflowFieldsService masterWorkflowFieldsService;

	@RequestMapping(value = "/createUpdateMasterWorkflowFields", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update MasterWorkflow Fields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateMasterWorkflowFields(
			@ApiParam(value = "MasterWorkflowFields object that needs to be added or update in the budgetedBOM") @RequestBody MasterWorkflowFieldsDTO masterWorkflowFieldsDTO) {
		return masterWorkflowFieldsService.createUpdateMasterWorkflowFields(masterWorkflowFieldsDTO);
	}

	@RequestMapping(value = "/getAllMasterWorkflowFieldsByTenantId/{tenantId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find All MasterWorkflowFields by Tenant Id", notes = "Returns All MasterWorkflow Fields entity when Tenant Id is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid tenant Id supplied"),
			@ApiResponse(code = 404, message = "MasterWorkflow Fields not found") })
	public @ResponseBody List<MasterWorkflowFieldsDTO> getAllMasterWorkflowFieldsByTenantId(
			@ApiParam(value = "TenantId of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId) {
		return masterWorkflowFieldsService.getAllMasterWorkflowFieldsByTenantId(tenantId);
	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByMasterWorkflowFieldId/{masterWorkflowFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By MasterWorkflow Field Id", notes = "Returns a MasterWorkflow Fields entity when MasterWorkflow Field Id is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow Field Id supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody MasterWorkflowFieldsDTO getMasterWorkflowFieldsBymasterWorkflowFieldId(
			@ApiParam(value = "MasterWorkflow Field Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByMasterWorkflowFieldId(masterWorkflowFieldId);
	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByTenantIdAndSolutionCategoryId/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By Tenant Id and SolutionCategory Id", notes = "Returns a MasterWorkflow Fields entity when Tenant Id and SolutionCategory Id is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Tenant Id And SolutionCategory Id supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByMasterWorkflowFieldIdAndSolutionCategoryId(
			@ApiParam(value = "Tenant Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId,
			@ApiParam(value = "Solution Category Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("solutionCategoryId") String solutionCategoryId) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByTenantIdAndSolutionCategoryId(tenantId,
				solutionCategoryId);
	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo/{tenantId}/{solutionCategoryId}/{gspRefNo}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By Tenant Id and SolutionCategory Id and Gsp RefNo", notes = "Returns a MasterWorkflow Fields entity when Tenant Id and SolutionCategory Id and Gsp RefNo date is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Tenant Id And SolutionCategory Id And Gsp RefNo supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(
			@ApiParam(value = "Tenant Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId,
			@ApiParam(value = "SolutionCategory Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("solutionCategoryId") String solutionCategoryId,
			@ApiParam(value = "Gsp RefNo of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndGspRefNo(tenantId,
				solutionCategoryId, gspRefNo);
	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName/{tenantId}/{solutionCategoryId}/{stateName}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By Tenant Id and SolutionCategory Id and State Name", notes = "Returns a MasterWorkflow Fields entity when Tenant Id and SolutionCategory Id and State Name date is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Tenant Id And SolutionCategory Id And Workflow State supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody List<MasterWorkflowFieldsDTO> getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(
			@ApiParam(value = "Tenant Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("tenantId") String tenantId,
			@ApiParam(value = "SolutionCategory Id of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("solutionCategoryId") String solutionCategoryId,
			@ApiParam(value = "State Name of the WorkflowState that needs to be fetched", required = true) @PathVariable("stateName") String stateName) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByTenantIdAndSolutionCategoryIdAndStateName(tenantId,
				solutionCategoryId, stateName);
	}

	@RequestMapping(value = "/getCustomerDetailListByMasterWorkflowFieldId/{masterWorkflowFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CustomerDetails By MasterWorkflow Field Id of MasterWorkflowFields entity", notes = "Returns a CustomerDetail entity when MasterWorkflow Field Id of MasterWorkflowFields entity is passed", response = CustomerDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow Field Id supplied"),
			@ApiResponse(code = 404, message = "CustomerDetails not found") })
	public @ResponseBody List<CustomerDetailDTO> getCustomerDetailListByMasterWorkflowFieldId(
			@ApiParam(value = "MasterWorkflow Field Id of the MasterWorkflowFields that needs to be fetch CustomerDetail ", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId) {
		return masterWorkflowFieldsService.getCustomerDetailListByMasterWorkflowFieldId(masterWorkflowFieldId);
	}

	@RequestMapping(value = "/getAdditionalContactDetailByMasterWorkflowFieldId/{masterWorkflowFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find Additional ContactDetail By MasterWorkflow Field Id of MasterWorkflowFields entity", notes = "Returns a Additional ContactDetail entity when MasterWorkflow Field of MasterWorkflowFields entity Id is passed", response = AdditionalContactDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow Field Id supplied"),
			@ApiResponse(code = 404, message = "Additional ContactDetail not found") })
	public @ResponseBody List<AdditionalContactDetailDTO> getAdditionalContactDetailByMasterWorkflowFieldId(
			@ApiParam(value = "MasterWorkflow Field Id of the MasterWorkflowFields that needs to be fetch AdditionalContactDetail", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId) {
		return masterWorkflowFieldsService.getAdditionalContactDetailByMasterWorkflowFieldId(masterWorkflowFieldId);
	}

	@RequestMapping(value = "/addUpdateCustomerDetailsToMasterWorkflowFields/{masterWorkflowFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update CustomerDetail MasterWorkflow Field when masterWorkflowField Id is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addUpdateCustomerDetailsToMasterWorkflowFields(
			@ApiParam(value = "Customer Detail of ItemMaster that adds or updates SubProcessField to MasterWorkflowField", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId,
			@ApiParam(value = "Customer Detail to be added in MasterWorkflowFields", required = true) @RequestBody List<CustomerDetailDTO> customerDetailDTOList) {
		return masterWorkflowFieldsService.addUpdateCustomerDetailsToMasterWorkflowFields(masterWorkflowFieldId,
				customerDetailDTOList);
	}

	@RequestMapping(value = "/deleteMasterWorkflowFieldsByMasterWorkflowFieldId/{masterWorkflowFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete MasterWorkflow Fields By MasterWorkflow FieldId", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid  masterWorkflowField Id value") })
	public @ResponseBody Boolean deleteMasterWorkflowFieldsByMasterWorkflowFieldId(
			@ApiParam(value = "MasterWorkflow FieldId to delete", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId) {
		try {
			return masterWorkflowFieldsService.deleteMasterWorkflowFieldsByMasterWorkflowFieldId(masterWorkflowFieldId);
		} catch (Exception e) {
			return false;
		}
	}

	@RequestMapping(value = "/addUpdateAdditionalContactDetailsToMasterWorkflowFields/{masterWorkflowFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add masterWorkflowFieldId to AdditionalContact Detail when masterWorkflowFieldId is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addUpdateAdditionalContactDetailsToMasterWorkflowFields(
			@ApiParam(value = "masterWorkflowFieldId of masterWorkflowFields that adds masterWorkflowFieldId to AdditionalContactDetail", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId,
			@ApiParam(value = "SubProcessFields to be added in orderDetail", required = true) @RequestBody List<AdditionalContactDetailDTO> additionalContactDetailDTOs) {

		return masterWorkflowFieldsService.addUpdateAdditionalContactDetailsToMasterWorkflowFields(
				masterWorkflowFieldId, additionalContactDetailDTOs);
	}

	@RequestMapping(value = "/addUpdateWorkflowStateToMasterWorkflowFields/{masterWorkflowFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update workflowState to MasterWorkflow FieldId when masterWorkflowField Id is passed", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Boolean addUpdateWorkflowStateToMasterWorkflowFields(
			@ApiParam(value = "adds or updates workflowState to MasterWorkflowFieldId", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId,
			@ApiParam(value = "workflowState  to be added in MasterWorkflowFields", required = true) @RequestBody WorkflowStateDTO workflowStateDTO) {
		return masterWorkflowFieldsService.addUpdateWorkflowStateToMasterWorkflowFields(masterWorkflowFieldId,
				workflowStateDTO);
	}

	@RequestMapping(value = "/getWorkflowStateByMasterWorkflowFieldId/{masterWorkflowFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find workflowState  By MasterWorkflow Field Id of MasterWorkflowFields entity", notes = "Returns a workflowState  entity when MasterWorkflow Field of MasterWorkflowFields entity Id is passed", response = WorkflowStateDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow Field Id supplied"),
			@ApiResponse(code = 404, message = "Workflow State not found") })
	public @ResponseBody WorkflowStateDTO getWorkflowStateByMasterWorkflowFieldId(
			@ApiParam(value = "MasterWorkflow Field Id of the MasterWorkflowFields that needs to be fetch workflowState", required = true) @PathVariable("masterWorkflowFieldId") Long masterWorkflowFieldId) {
		return masterWorkflowFieldsService.getWorkflowStateByMasterWorkflowFieldId(masterWorkflowFieldId);

	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByGspRefNo/{gspRefNo}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By MasterWorkflow gspRefNo", notes = "Returns a MasterWorkflow Fields entity when MasterWorkflow gspRefNo is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow gspRefNo supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNo(
			@ApiParam(value = "gspRefNo of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByGspRefNo(gspRefNo);
	}
	
	@RequestMapping(value = "/getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId/{masterWorkflowFieldId}/{tenantId}/{solutionCategoryId}", produces = "application/json", method = RequestMethod.GET)
	@ApiOperation(value = "Find MasterWorkflow Fields By MasterWorkflowId ,TenantId and solutionCategoryId", notes = "Returns a MasterWorkflow Fields entity when MasterWorkflowId,TenantId and SolutionCategoryId is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflowId,Tenantid and SolutionCategoryIdsupplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody MasterWorkflowFieldsDTO getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId(
			@ApiParam(value = "masterworkflowId of the MasterWorkflowFields that needs to be fetched", required = true)@PathVariable(value = "masterWorkflowFieldId") final Long masterWorkflowFieldId,
			@ApiParam(value = "TenantId of the MasterWorkflowFields that needs to be fetched", required = true)@PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "SolutionCategoryId of the MasterWorkflowFields that needs to be fetched", required = true)@PathVariable(value = "solutionCategoryId")final String solutionCategoryId) {
		 return masterWorkflowFieldsService.getMasterWorkflowFieldsByMasterWorkflowFieldIdandTenantIdandSolCatId(masterWorkflowFieldId, tenantId,solutionCategoryId);
		   
	}

	@RequestMapping(value = "/getMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState/{gspRefNo}/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MasterWorkflow Fields By MasterWorkflow gspRefNo", notes = "Returns a MasterWorkflow Fields entity when MasterWorkflow gspRefNo,TenantId and SolutionCategoryId is passed", response = MasterWorkflowFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid MasterWorkflow gspRefNo,Tenantid and SolutionCategoryId supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody MasterWorkflowFieldsDTO getMasterWorkflowFieldsByGspRefNoToCheckNoOfMotorsAndState(
			@ApiParam(value = "gspRefNo of the MasterWorkflowFields that needs to be fetched", required = true) @PathVariable("gspRefNo") String gspRefNo,
			@ApiParam(value = "TenantId of the MasterWorkflowFields that needs to be fetched", required = true)@PathVariable(value = "tenantId") final String tenantId,
			@ApiParam(value = "SolutionCategoryId of the MasterWorkflowFields that needs to be fetched", required = true)@PathVariable(value = "solutionCategoryId")final String solutionCategoryId) {
		return masterWorkflowFieldsService.getMasterWorkflowFieldsByGspRefNoAndTenantIdandSolCatIdToCheckNoOfMotorsAndState(gspRefNo, tenantId,solutionCategoryId);
	}
}
