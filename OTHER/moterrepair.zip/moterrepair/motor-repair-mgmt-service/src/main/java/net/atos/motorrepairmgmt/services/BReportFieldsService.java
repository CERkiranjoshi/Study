/**
 * 
 */
package net.atos.motorrepairmgmt.services;

import java.util.List;

import net.atos.motorrepairmgmt.dto.ARCRepairEstimatesDTO;
import net.atos.motorrepairmgmt.dto.ARCSparesEstimatesDTO;
import net.atos.motorrepairmgmt.dto.BReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.ElectricalObservationDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;

/**
 * @author a603327
 * 
 */
public interface BReportFieldsService {

	public List<BReportFieldsDTO> getAllBReportFields();

	public BReportFieldsDTO getBReportFieldsByBReportFieldId(Long bReportFieldId);

	public Boolean deleteBReportFieldsByBReportFieldId(Long bReportFieldId);

	public MotorVoltageDetailDTO getVoltageDetailByBreportId(Long bReportFieldId);

	public List<MotorSpeedDetailDTO> getSpeedDetailByBReportId(Long bReportFieldId);

	public MotorNamePlateDetailDTO getNamePlateByBreportId(Long bReportFieldId);

	public BReportFieldsDTO getBReportFieldsBySubProcessId(Long wlfwSubProcessId);

	public BReportFieldsDTO createUpdateBReportFields(BReportFieldsDTO bReportFieldsDTO);

	public Boolean addARCRepairEstimatesToBReportFields(Long bReportFieldId,
			List<ARCRepairEstimatesDTO> aRCRepairEstimatesDTOList);

	public Boolean addARCSparesEstimatesToBReportFields(Long bReportFieldId,
			List<ARCSparesEstimatesDTO> aRCSparesEstimatesDTOList);

	public Boolean addMotorSpeedDetailToBReportFields(Long bReportFieldId,
			List<MotorSpeedDetailDTO> motorSpeedDetailDTOList);

	public Boolean addMotorVoltageDetailToBReportFields(Long bReportFieldId, MotorVoltageDetailDTO motorVoltageDetailDTO);

	public Boolean addMotorNamePlateDetailToBReportFields(Long bReportFieldId,
			MotorNamePlateDetailDTO motorNamePlateDetailDTO);

	public Boolean addElectricalObservationToBReportFields(Long bReportFieldId,
			ElectricalObservationDTO electricalObservationDTO);

	public Long addSubProcessFieldsToBReportFields(Long bReportFieldId, SubProcessFieldsDTO subProcessFieldsDTO);
	
	BReportFieldsDTO getBReportFieldsApprovedStatusBySubprocessFieldId(Long wlfwSubProcessId);
}
