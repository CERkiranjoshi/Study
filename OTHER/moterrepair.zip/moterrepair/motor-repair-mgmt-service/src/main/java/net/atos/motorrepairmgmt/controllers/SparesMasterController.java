/**
 * 
 */
package net.atos.motorrepairmgmt.controllers;


import java.util.List;

import net.atos.motorrepairmgmt.dto.SparesMasterDTO;
import net.atos.motorrepairmgmt.services.SparesMasterService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;




import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;


/**
 * @author Sweety K
 *
 */
@EnableSwagger
@RequestMapping(value = "sparesMasterService")
@Controller
public class SparesMasterController {
	
	@Autowired
	private SparesMasterService sparesMasterService;
	
	@RequestMapping(value = "/getAllSparesByTenantIdNSolutionCategory/{tenantId}/{solutionCategoryId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Get all spares master by tenantId n Solution category", notes = "", response = SparesMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input")}) 
	public @ResponseBody List<SparesMasterDTO> getSparesMasterByTenantIdNSolutionCategory(@ApiParam(value = "sparesMaster  based on  tenantId and solutionCategoryId   needs to be fetched", required = true)
			@PathVariable("tenantId") final String tenantId,
			@PathVariable("solutionCategoryId") final String solutionCategoryId)
	{
		return sparesMasterService.getAllSparesByTenantIdNSolutionCategory(tenantId, solutionCategoryId);
	}
	
	@RequestMapping(value = "/getSparesMasterBySpareId/{spareId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Get spare master by id", notes = "", response = SparesMasterDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input")}) 
	public @ResponseBody SparesMasterDTO getSpareMasterById(@ApiParam(value = "sparesMaster  based on  tenantId and solutionCategoryId needs to be fetched", required = true)
			@PathVariable("spareId") final Long spareId)
	{
		return sparesMasterService.getSparesMasterById(spareId);
	}


	
}
