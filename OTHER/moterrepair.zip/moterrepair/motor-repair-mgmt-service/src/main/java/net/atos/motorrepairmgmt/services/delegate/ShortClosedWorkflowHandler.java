/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.singetons.ReclaimIdHolder;
import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ReclaimWorkflowHandler handles invoked CCC Reclaim Workflow. It takes care of multiple invocations and ensures only
 * one task is allocated to the actor for processing reclaims.
 * 
 * @author Anand Ved
 *
 */
@Component
public class ShortClosedWorkflowHandler implements JavaDelegate {

	@Autowired
	private WorkflowInvoker workflowInvoker;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ShortClosedWorkflowHandler.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; SHORT_CLOSED_WORKFLOW_HANDLER: Start" + execution.getId()));

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; SHORT_CLOSED_WORKFLOW_HANDLER: End");

	}

}
