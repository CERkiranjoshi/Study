/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate.invokers;

import java.util.HashMap;
import java.util.Map;

import net.atos.motorrepairmgmt.services.WorkflowInvoker;
import net.atos.taskmgmt.common.constant.ActivitiConstants;
import net.atos.taskmgmt.service.ActorFunctionMasterService;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author a593775
 * 
 */
@Component
public class SystemNotificationWorkflowInvoker extends BaseWorkflowInvoker {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(SystemNotificationWorkflowInvoker.class);

	@Autowired
	private WorkflowInvoker workflowInvoker;

	@Autowired
	private ActorFunctionMasterService actorFunctionMasterService;

	/**
	 * Steps:<br>
	 * 1. Find all current tasks being executed for this Subproces Workflow Id.<br>
	 * 2. All these tasks, irrespective of whether they are executed in parallel are closed.<br>
	 * 3. All such tasks would have the benchmark state as 6: RECLAIMED<br>
	 * 4. Respective users, if they own the task are notified of the reclaim. These users would no longer be able to<br>
	 * 5. A task gets assigned to CCC Actor for handling RECLAIM
	 * 
	 * @see org.activiti.engine.delegate.JavaDelegate#execute(org.activiti.engine .delegate.DelegateExecution)
	 */
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; SYSTEM_NOTIFICATION_WORKFLOW_INVOKER: START " + execution.getId());

		// PREVIOUS FUNCTION CODE FOR NEXT WORKFLOW WOULD BE THE CURRENT PREV_FUNCTION_CODE AS THIS IS A SYSTEM WORKFLOW
		// AND CARRIES
		String previousFunctionCode = (null != execution.getVariable(ActivitiConstants.PREV_FUNCTION_CODE)) ? execution
				.getVariable(ActivitiConstants.PREV_FUNCTION_CODE).toString() : null;

		// TODO Set Function Code of the Next Workflow to be executed
		String functionCode = null;

		// Send the entire execution variables to SystemNotificationWorkflow
		Map<String, Object> nextProcessVars = execution.getVariables();

		// NO NEED TO SET NEXT PROCESS VARIABLES FOR THIS. Set only required process variables from the workflow
		// setNextProcessVariables(execution, nextProcessVars);

		// TODO manually invoke workflow as we need to copy the previousFunctionCode and Next Function Code intact.
		String newProcInstanceId=invokeWorkflow(nextProcessVars, previousFunctionCode, functionCode);
		LOGGER.info("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; SYSTEM_NOTIFICATION_WORKFLOW_INVOKER: END " + execution.getId()+" NEW WORKFLOW ID : "+newProcInstanceId);
	}

}
