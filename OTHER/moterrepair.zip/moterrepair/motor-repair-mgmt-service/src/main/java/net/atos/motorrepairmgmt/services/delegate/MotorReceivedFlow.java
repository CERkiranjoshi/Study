/**
 * 
 */
package net.atos.motorrepairmgmt.services.delegate;

import net.atos.taskmgmt.common.constant.ActivitiConstants;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.log4j.Logger;

/**
 * @author a593775
 *
 */
public class MotorReceivedFlow implements JavaDelegate {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MotorReceivedFlow.class);

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.info(("subprocessId: "+execution.getVariable(ActivitiConstants.SUB_PROCESS_ID)+"; masterWorkflowId: "+execution.getVariable(ActivitiConstants.MASTER_PROCESS_ID)+"; inside MotorReceivedFlow ..." + execution.getId()));
	}

}
