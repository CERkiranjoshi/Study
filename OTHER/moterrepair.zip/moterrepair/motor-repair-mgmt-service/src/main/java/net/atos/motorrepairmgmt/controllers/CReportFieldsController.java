package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.CReportFieldsDTO;
import net.atos.motorrepairmgmt.dto.MotorNamePlateDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorSpeedDetailDTO;
import net.atos.motorrepairmgmt.dto.MotorVoltageDetailDTO;
import net.atos.motorrepairmgmt.dto.SubProcessFieldsDTO;
import net.atos.motorrepairmgmt.entity.CReportFields;
import net.atos.motorrepairmgmt.services.CReportFieldsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610051
 * 
 */
@Controller
@EnableSwagger
@RequestMapping(value = "cReportFieldsService")
public class CReportFieldsController {

	/** The CReportFields Service */
	@Autowired
	private CReportFieldsService cReportFieldsService;

	/**
	 * This method is used for creating and updating CReportFields.
	 * 
	 * @param ARCRepairEstimatesDTO
	 *            The arcRepairEstimatesDTO
	 * 
	 * @return Boolean
	 */
	@RequestMapping(value = "/createUpdateCReportFields", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create and Updates CReportFields with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody CReportFieldsDTO createUpdateCReportFields(@RequestBody CReportFieldsDTO cReportFieldsDTO) {

		return cReportFieldsService.createUpdateCReportFields(cReportFieldsDTO);
	}

	/**
	 * This method is used for deleting CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return Boolean
	 */

	@RequestMapping(value = "/deleteCReportFieldsByMotorCReportFieldId/{motorCReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete CReportFields By MotorCReportField Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid MotorCReportField Id value") })
	public @ResponseBody Boolean deleteCReportFieldsByMotorCReportFieldId(
			@PathVariable("motorCReportFieldId") Long motorCReportFieldId) {
		try {
			return cReportFieldsService.deleteCReportFieldsByMotorCReportFieldId(motorCReportFieldId);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 
	 * This method is used for retrieving all CReportFields.
	 * 
	 * @return List of CReportFieldsDTOs
	 */
	@RequestMapping(value = "/getAllCReportFields", method = RequestMethod.GET)
	@ApiOperation(value = "Find All CReportFields", notes = "Returns a CReportFields entity ", response = CReportFieldsDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation") })
	public @ResponseBody List<CReportFieldsDTO> getAllCReportFields() {
		return cReportFieldsService.getAllCReportFields();
	}

	/**
	 * This method is used for retrieving MotorVoltageDetail based on
	 * motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return MotorVoltageDetailDTO
	 * 
	 */
	@RequestMapping(value = "/getVoltageDetailByCReportId/{motorCReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorVoltageDetail By MotorCReportField Id of CReportFields", notes = "Returns a MotorVoltageDetail entity when MotorCReportField Id is passed", response = MotorVoltageDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorCReportField Id supplied"),
			@ApiResponse(code = 404, message = "MotorVoltageDetail not found") })
	public @ResponseBody MotorVoltageDetailDTO getVoltageDetailByCReportId(
			@ApiParam(value = "MotorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId) {
		return cReportFieldsService.getVoltageDetailByCReportId(motorCReportFieldId);
	}

	/**
	 * This method is used for retrieving MotorNamePlateDetail based on
	 * motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return MotorNamePlateDetailDTO
	 * 
	 */
	@RequestMapping(value = "/getNamePlateByCReportId/{motorCReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorNamePlateDetail By MotorCReportField Id of CReportFields", notes = "Returns a MotorNamePlateDetail entity when MotorCReportField Id is passed", response = MotorNamePlateDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorCReportField Id supplied"),
			@ApiResponse(code = 404, message = "MotorNamePlateDetail not found") })
	public @ResponseBody MotorNamePlateDetailDTO getNamePlateByCReportId(
			@ApiParam(value = "MotorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId) {
		return cReportFieldsService.getNamePlateByCReportId(motorCReportFieldId);
	}

	/**
	 * This method is used for retrieving MotorSpeedDetail based on
	 * motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return List of MotorSpeedDetailDTO
	 * 
	 */
	@RequestMapping(value = "/getSpeedDetailByCReportId/{motorCReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find MotorSpeedDetail By MotorCReportField Id of CReportFields", notes = "Returns a MotorSpeedDetail entity when MotorCReportField Id is passed", response = MotorSpeedDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid MotorCReportField Id supplied"),
			@ApiResponse(code = 404, message = "MotorSpeedDetail not found") })
	public @ResponseBody List<MotorSpeedDetailDTO> getSpeedDetailByCReportId(
			@ApiParam(value = "MotorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId) {
		return cReportFieldsService.getSpeedDetailByCReportId(motorCReportFieldId);
	}

	/**
	 * This method is used for retrieving CReportFields based on
	 * WlfwSubProcessId of SubProcessFields.
	 * 
	 * @param WlfwSubProcessId
	 *            The WlfwSubProcess Id
	 * 
	 * @return List of CReportFieldsDTO
	 * 
	 */
	@RequestMapping(value = "/getCReportFieldsBySubProcessID/{wlfwSubProcessId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CReportFields By WlfwSubProcess Id of SubProcessFields", notes = "Returns a CReportFields entity when WlfwSubProcess Id is passed", response = CReportFieldsDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid WlfwSubProcess Id supplied"),
			@ApiResponse(code = 404, message = "CReportFields not found") })
	public @ResponseBody CReportFieldsDTO getCReportFieldsBySubProcessID(
			@ApiParam(value = "WlfwSubProcess Id of the SubProcessFields", required = true) @PathVariable("wlfwSubProcessId") Long wlfwSubProcessId) {
		return cReportFieldsService.getCReportFieldsBySubProcessID(wlfwSubProcessId);
	}

	/**
	 * This method is used to add or Update SpeedDetail To CReportFields based
	 * on motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateSpeedDetailToCReportFields/{motorCReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update SpeedDetail to CReportFields when motorCReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied") })
	public @ResponseBody Boolean addUpdateSpeedDetailToCReportFields(
			@ApiParam(value = "motorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId,
			@ApiParam(value = "MotorSpeedDetailDTO to be added in CReportFields", required = true) @RequestBody List<MotorSpeedDetailDTO> motorSpeedDetailDTOList) {
		return cReportFieldsService.addUpdateSpeedDetailToCReportFields(motorCReportFieldId, motorSpeedDetailDTOList);
	}

	/**
	 * This method is used to add or Update MotorNamePlateDetail To
	 * CReportFields based on motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateMotorNamePlateDetailToCReportFields/{motorCReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update MotorNamePlateDetail to CReportFields when motorCReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied") })
	public @ResponseBody Boolean addUpdateMotorNamePlateDetailToCReportFields(
			@ApiParam(value = "motorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId,
			@ApiParam(value = "MotorNamePlateDetailDTO to be added in CReportFields", required = true) @RequestBody MotorNamePlateDetailDTO motorNamePlateDetailDTO) {
		return cReportFieldsService.addUpdateMotorNamePlateDetailToCReportFields(motorCReportFieldId,
				motorNamePlateDetailDTO);
	}

	/**
	 * This method is used to add or Update MotorVoltageDetail To CReportFields
	 * based on motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateMotorVoltageDetailToCReportFields/{motorCReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update MotorVoltageDetail to CReportFields when motorCReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied") })
	public @ResponseBody Boolean addUpdateMotorVoltageDetailToCReportFields(
			@ApiParam(value = "motorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId,
			@ApiParam(value = "MotorVoltageDetailDTO to be added in CReportFields", required = true) @RequestBody MotorVoltageDetailDTO motorVoltageDetailDTO) {
		return cReportFieldsService.addUpdateMotorVoltageDetailToCReportFields(motorCReportFieldId,
				motorVoltageDetailDTO);
	}

	/**
	 * This method is used to add or Update SubProcessFields To CReportFields
	 * based on motorCReportFieldId of CReportFields.
	 * 
	 * @param motorCReportFieldId
	 *            The MotorCReportField Id
	 * 
	 * @return Boolean
	 * 
	 */
	@RequestMapping(value = "/addUpdateSubProcessFieldsToCReportFields/{motorCReportFieldId}", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Add or update SubProcessFields to CReportFields when motorCReportField Id is passed ", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied") })
	public @ResponseBody Long addUpdateSubProcessFieldsToCReportFields(
			@ApiParam(value = "motorCReportField Id of the CReportFields", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId,
			@ApiParam(value = "SubProcessFieldsDTO to be added in CReportFields", required = true) @RequestBody SubProcessFieldsDTO subProcessFieldsDTO) {
		return cReportFieldsService.addUpdateSubProcessFieldsToCReportFields(motorCReportFieldId, subProcessFieldsDTO);
	}

	/**
	 * This method is used for retrieving ARCRepairEstimates based on
	 * arcRepairEstimateId.
	 * 
	 * @param arcRepairEstimateId
	 *            The arcRepairEstimate Id
	 * 
	 * @return ARCRepairEstimatesDTO
	 * 
	 */
	@RequestMapping(value = "/getCReportFieldsBymotorCReportFieldId/{motorCReportFieldId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CReportFields By motorDReportField Id", notes = "Returns a CReportFields entity when motorDReportField Id is passed", response = CReportFields.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "successful operation"),
			@ApiResponse(code = 400, message = "Invalid motorCReportField Id supplied"),
			@ApiResponse(code = 404, message = "CReportFields not found") })
	public @ResponseBody CReportFieldsDTO getCReportFieldsByMotorCReportFieldId(
			@ApiParam(value = "motorCReportField Id of the CReportFields that needs to be fetched", required = true) @PathVariable("motorCReportFieldId") Long motorCReportFieldId) {
		return cReportFieldsService.getCReportFieldsByMotorCReportFieldId(motorCReportFieldId);
	}
}
