package net.atos.motorrepairmgmt.serviceImpls;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.entity.CustomerDetail;
import net.atos.motorrepairmgmt.repository.CustomerDetailRepository;
import net.atos.motorrepairmgmt.services.CustomerDetailService;
import net.atos.motorrepairmgmt.utils.NullPropertyMapper;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;

/**
 * @author a610039
 * 
 */
@Service
@Transactional
public class CustomerDetailServiceImpl implements CustomerDetailService {

	/** The DozerBeanMapper */
	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	/** The CustomerDetail Repository */
	@Autowired
	private CustomerDetailRepository customerDetailRepository;

	@Autowired
	private UniqueIdGenerator uniqueIdGenerator;

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(CustomerDetailServiceImpl.class);

	/**
	 * The method creates/updates a CustomerDetail record. The method performs
	 * an update operation when CustomerId is passed and an existing record with
	 * matching Customer Id is fetched for updation
	 * 
	 * @param budgetedBOMDTO
	 *            The Budgeted BOM
	 * @return Boolean
	 * 
	 */
	@Override
	public Long createUpdateCustomerDetail(CustomerDetailDTO customerDetailDTO) {
		LOGGER.info("CustomerDetailServiceImpl : createUpdateCustomerDetail : Start");
		CustomerDetail customerDetails = null;
		Long returnId = -1l;
		try {
			if (null != customerDetailDTO) {
				if (null != customerDetailDTO.getCustomerId()) {
					customerDetails = customerDetailRepository.findOne(customerDetailDTO.getCustomerId());
				}

				BeanUtils.copyProperties(customerDetailDTO, customerDetails,
						NullPropertyMapper.getNullPropertyNames(customerDetailDTO));
				CustomerDetail savedObject = customerDetailRepository.save(customerDetails);
				LOGGER.info("CustomerDetailServiceImpl : createUpdateCustomerDetail : Record Saved/Updated");
				if (savedObject != null) {
					returnId = savedObject.getCustomerId();
				}
			} else {
				LOGGER.info("CustomerDetailServiceImpl : createUpdateCustomerDetail : CustomerDetailDTO sent is Null");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnId;
	}

	/**
	 * The method retrieves all the CustomerDetail
	 * 
	 * @return List of CustomerDetail DTOs
	 * 
	 */
	@Override
	public List<CustomerDetailDTO> getAllCustomerDetail() {
		LOGGER.info("CustomerDetailServiceImpl : getAllCustomerDetail : Start");
		List<CustomerDetailDTO> customerDetailDTOs = null;
		List<CustomerDetail> customerDetailDetails = customerDetailRepository.findAll();
		if (null != customerDetailDetails) {
			customerDetailDTOs = new ArrayList<CustomerDetailDTO>();
			CustomerDetailDTO customerDetailDTO = null;
			for (CustomerDetail customerDetailRecord : customerDetailDetails) {
				customerDetailDTO = new CustomerDetailDTO();
				customerDetailDTO = dozerBeanMapper.map(customerDetailRecord, CustomerDetailDTO.class);
				customerDetailDTOs.add(customerDetailDTO);
			}
		}
		LOGGER.info("CustomerDetailServiceImpl : getAllCustomerDetail : End");
		return customerDetailDTOs;
	}

	/**
	 * The method retrieves a CustomerDetail on the basis its customerId.
	 * 
	 * @param customerId
	 *            The Customer Id
	 * @return CustomerDetail DTO
	 * 
	 */

	@Override
	public CustomerDetailDTO getCustomerDetailByCustomerId(Long customerId) {
		LOGGER.info("CustomerDetailServiceImpl : getCustomerDetailByCustomerId : Start");
		CustomerDetailDTO customerDetailDTO = null;
		if (null != customerId) {
			CustomerDetail customerDetails = customerDetailRepository.findOne(customerId);
			if (null != customerDetails) {
				customerDetailDTO = dozerBeanMapper.map(customerDetails, CustomerDetailDTO.class);
			}
		}
		LOGGER.info("CustomerDetailServiceImpl : getCustomerDetailByCustomerId : End");
		return customerDetailDTO;
	}

	/**
	 * The deletes a CustomerDetail on the basis its customerId.
	 * 
	 * @param customerId
	 *            The Customer Id
	 * @return Boolean
	 * 
	 */
	@Override
	public Boolean deleteCustomerDetailByCustomerId(Long customerId) {

		LOGGER.info("CustomerDetailServiceImpl : deleteCustomerDetailByCustomerId : Start");
		boolean returnVal = false;
		try {
			if (null != customerId) {
				customerDetailRepository.delete(customerId);
				returnVal = true;
			} else {
				LOGGER.info("CustomerDetailServiceImpl : deleteCustomerDetailByCustomerId : Not Deleted");
			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return returnVal;

	}
}
