package net.atos.motorrepairmgmt.controllers;

import java.util.List;

import net.atos.motorrepairmgmt.dto.CustomerDetailDTO;
import net.atos.motorrepairmgmt.services.CustomerDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * @author a610039
 * 
 */
@EnableSwagger
@RequestMapping(value = "customerDetailService")
@Controller
public class CustomerDetailController {

	@Autowired
	private CustomerDetailService customerDetailService;

	@RequestMapping(value = "/createUpdateCustomerDetail", method = RequestMethod.POST, produces = { "application/json" })
	@ApiOperation(value = "Create Update Customer Detail with form data", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody Long createUpdateCustomerDetail(
			@ApiParam(value = "CustomerDetail object that needs to be added or update in the customerDetail") @RequestBody CustomerDetailDTO customerDetailDTO) {
		return customerDetailService.createUpdateCustomerDetail(customerDetailDTO);
	}

	@RequestMapping(value = "/getAllCustomerDetail", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CustomerDetail ", notes = "Returns a CustomerDetail entity", response = CustomerDetailDTO.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 405, message = "Invalid input") })
	public @ResponseBody List<CustomerDetailDTO> getAllCustomerDetail() {
		return customerDetailService.getAllCustomerDetail();
	}

	@RequestMapping(value = "/getCustomerDetailByCustomerId/{customerId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Find CustomerDetail By Customer Id", notes = "Returns a CustomerDetail entity when Customer Id is passed", response = CustomerDetailDTO.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful operation"),
			@ApiResponse(code = 400, message = "Invalid Customer Id supplied"),
			@ApiResponse(code = 404, message = " MasterWorkflow Fields not found") })
	public @ResponseBody CustomerDetailDTO getCustomerDetailByCustomerId(
			@ApiParam(value = "Customer Id of the CustomerDetail that needs to be fetched", required = true) @PathVariable("customerId") Long customerId) {
		return customerDetailService.getCustomerDetailByCustomerId(customerId);
	}

	@RequestMapping(value = "/deleteCustomerDetailByCustomerId/{customerId}", method = RequestMethod.GET, produces = { "application/json" })
	@ApiOperation(value = "Delete Customer Detail By Customer Id", notes = "", response = Void.class)
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid  Customer Id value") })
	public @ResponseBody Boolean deleteCustomerDetailByCustomerId(
			@ApiParam(value = "Customer Id to delete", required = true) @PathVariable("customerId") Long customerId) {
		try {
			return customerDetailService.deleteCustomerDetailByCustomerId(customerId);
		} catch (Exception e) {
			return false;
		}
	}
}
