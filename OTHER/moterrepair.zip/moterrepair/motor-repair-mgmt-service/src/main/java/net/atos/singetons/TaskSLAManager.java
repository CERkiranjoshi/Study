package net.atos.singetons;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import net.atos.motorrepairmgmt.dto.SchedulerDetailsDTO;
import net.atos.motorrepairmgmt.services.SchedulerDetailsService;
import net.atos.motorrepairmgmt.utils.MotorRepairConstants;
import net.atos.motorrepairmgmt.utils.UniqueIdGenerator;
import net.atos.motorrepairmgmt.utils.tasksla.ReceiveMotorTaskTimer;
import net.atos.motorrepairmgmt.utils.tasksla.TTOTaskTimer;
import net.atos.taskmgmt.activiti.engine.TaskManagementService;
import net.atos.taskmgmt.common.context.SpringApplicationContext;
import net.atos.taskmgmt.common.dto.TaskDTO;
import net.atos.taskmgmt.common.dto.TaskFilter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

/**
 * 
 * @author Anand Ved
 * 
 */
public class TaskSLAManager {

	private static final int POOL_SIZE = 10;

	private final ScheduledExecutorService slaScheduler = Executors.newScheduledThreadPool(POOL_SIZE);

	private static final Logger LOGGER = Logger.getLogger(TaskSLAManager.class);

	private static final Map<String, ScheduledFuture<?>> schedulerPool = new HashMap<String, ScheduledFuture<?>>();

	private static Boolean reInitialized = false;

	private static final TaskSLAManager taskSLAMgr = new TaskSLAManager();

	@Value("${cluster.nodeId}")
	private String nodeId;

	public TaskSLAManager() {

		LOGGER.info("TASK_SLA_MANAGER: Initialized");
	}

	public static TaskSLAManager getInstance() {
		return taskSLAMgr;
	}

	public synchronized void reInitializeSchedules() {
		if (!reInitialized.booleanValue()) {

			// Fetch all the schedules that are not initialized.
			LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE Fetching all scheduler details for re-initialization");
			ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
			SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);
			TaskManagementService taskManagementService = applicationContext.getBean(TaskManagementService.class);

			List<SchedulerDetailsDTO> schedulerDetailsDTOs = schedulerDetailsService
					.getAllPendingSchedulerDetailsByTenantIdAndSolCatId(MotorRepairConstants.TENANT_ID,
							MotorRepairConstants.PROGRAM_ID);
			TaskFilter taskFilter = null;

			for (SchedulerDetailsDTO schedulerDetailsDTO : schedulerDetailsDTOs) {
				LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
						+ schedulerDetailsDTO.getSchedulerId() + "] START... NODE ID: " + nodeId + "; SchedulerType: "
						+ schedulerDetailsDTO.getSchedulerType() + "; SchedulerNextRunTime: "
						+ schedulerDetailsDTO.getNextRunTimestamp() + "; SchedulerTaskRefId: "
						+ schedulerDetailsDTO.getTaskRefId() + "; SchedulerMasterWorkdlowId: "
						+ schedulerDetailsDTO.getMasterWorkflowId() + "; SchedulerSubprocessId: "
						+ schedulerDetailsDTO.getSubprocessId() + "; NextRunTS: "
						+ schedulerDetailsDTO.getNextRunTimestamp() + "; CurrentTS: " + System.currentTimeMillis()
						+ "; SchedulerBatchProcessId: " + schedulerDetailsDTO.getBatchProcessId() + "; NodeId: "
						+ schedulerDetailsDTO.getNodeId());

				// Check if this scheduler Id already exisits in our Pool
				if (schedulerPool.containsKey(schedulerDetailsDTO.getSchedulerId())) {
					LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
							+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId
							+ "; Already in  Scheduled Pool, hence skipping...");
				} else {
					LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
							+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId
							+ "; Not in  Scheduled Pool, will re-initialize...");

					if (nodeId.equals(schedulerDetailsDTO.getNodeId())) {

						// Check if the Task is still active
						taskFilter = new TaskFilter();
						taskFilter.setTaskId(schedulerDetailsDTO.getTaskRefId());
						List<TaskDTO> taskDTOs = taskManagementService.getAllActiveTasks(taskFilter);
						if ((null != taskDTOs) && (taskDTOs.size() > 0)) {

							// Task is still in ACTIVE state, trigger a scheduler

							switch (MotorRepairConstants.SCHEDULER_TYPES.getSchedulerType(schedulerDetailsDTO
									.getSchedulerType())) {
								case RECEIVE_MOTOR: {

									ReceiveMotorTaskTimer receiveMotorTaskTimer = new ReceiveMotorTaskTimer();
									receiveMotorTaskTimer.setName("RMTT_" + schedulerDetailsDTO.getSubprocessId() + "_"
											+ schedulerDetailsDTO.getSchedulerId());
									receiveMotorTaskTimer.setProcessInstanceId(schedulerDetailsDTO.getProcInstRefId());
									receiveMotorTaskTimer.setTaskId(schedulerDetailsDTO.getTaskRefId());
									receiveMotorTaskTimer.setReminderNumber(schedulerDetailsDTO.getRunNumber());
									receiveMotorTaskTimer.setSchedulerId(schedulerDetailsDTO.getSchedulerId());
									receiveMotorTaskTimer.setSubprocessId(schedulerDetailsDTO.getSubprocessId());

									if (System.currentTimeMillis() >= schedulerDetailsDTO.getNextRunTimestamp()) {
										LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
												+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId
												+ "; Schedule needs to be executed immediately ");
										scheduleMotorToBeReceived(0l, receiveMotorTaskTimer);

									} else {

										LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
												+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId
												+ "; Schedule needs to be executed at a later time ");
										scheduleMotorToBeReceived(
												(schedulerDetailsDTO.getNextRunTimestamp() - System.currentTimeMillis()),
												receiveMotorTaskTimer);

									}
									break;
								}
								case TTO: {

									break;
								}
								case TTH: {
									break;
								}
								case TTR: {
									break;
								}
								default:
									break;
							}
						} else {

							LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
									+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId
									+ "; Task is no longer active / available, hence skipping rescheduling. DONE ");
						}
						LOGGER.info("TASK_SLA_MANAGER: REINITIALIZING SCHEDULE FOR SchedulerDetails: ["
								+ schedulerDetailsDTO.getSchedulerId() + "] NODE ID: " + nodeId + "; DONE ");
					} else {
						LOGGER.info("TASK_SLA_MANAGER: SchedulerDetails: [" + schedulerDetailsDTO.getSchedulerId()
								+ "] has different nodeId: + " + schedulerDetailsDTO.getNodeId() + "; NODE ID: "
								+ nodeId + "; DONE ");

					}
				}
			}
			reInitialized = true;
			LOGGER.info("TASK_SLA_MANAGER: REINITIALIZATION COMPLETED NODE ID: " + nodeId);
		} else {
			LOGGER.info("TASK_SLA_MANAGER: NODE ID: [" + nodeId + "]  ALREADY REINITIALIZED SCHEDULE !!!");
		}
	}

	private ScheduledFuture<?> scheduleTimeToOwnSLA(TTOTaskTimer task, int delayInMinutes) {
		ScheduledFuture<?> sf = slaScheduler.schedule(task, delayInMinutes, TimeUnit.MINUTES);

		schedulerPool.put(task.getSchedulerId(), sf);
		return sf;

	}

	public ScheduledFuture<?> scheduleMotorToBeReceived(ReceiveMotorTaskTimer task, int delayInDays) {
		Long timeToDaysInMillisecs = (delayInDays - 1) * 24 * 60 * 60 * 1000l; // calculate todays difference

		// Long timeToDaysInMillisecs = 5 * 60 * 1000l; // 5 mins

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; timeToDaysInMillisecs: " + timeToDaysInMillisecs);

		Calendar timeAtMidnight = Calendar.getInstance();
		timeAtMidnight.add(Calendar.DATE, 1);
		timeAtMidnight.set(Calendar.MILLISECOND, 0);
		timeAtMidnight.set(Calendar.SECOND, 0);
		timeAtMidnight.set(Calendar.HOUR_OF_DAY, 0);
		timeAtMidnight.set(Calendar.MINUTE, 0);

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Time at midnight ==> " + timeAtMidnight.getTime());

		long timeNow = Calendar.getInstance().getTimeInMillis();

		long timeToMidnight = timeAtMidnight.getTimeInMillis() - timeNow;

		long nextRunTimeDelay = (timeToDaysInMillisecs + timeToMidnight);
		// long nextRunTimeDelay = timeToDaysInMillisecs;
		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Time to Midnight ==> " + timeToMidnight
				+ "; TimeToDays: " + timeToDaysInMillisecs + "; NextRunTimeDelay: " + nextRunTimeDelay);

		Calendar nextRunTime = Calendar.getInstance();
		nextRunTime.add(Calendar.MILLISECOND, (int) nextRunTimeDelay);
		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Next Run Time: " + nextRunTime.getTime());

		task.setNextRunTimeInMillis(nextRunTime.getTimeInMillis());
		return scheduleMotorToBeReceived(nextRunTimeDelay, task);
	}

	private ScheduledFuture<?> scheduleMotorToBeReceived(long nextRunTimeDelay, ReceiveMotorTaskTimer task) {

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Task: " + task);

		ScheduledFuture<?> sf = slaScheduler.schedule(task, nextRunTimeDelay, TimeUnit.MILLISECONDS);
		long mins = sf.getDelay(TimeUnit.MINUTES);
		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Mins to run: " + mins);

		schedulerPool.put(task.getSchedulerId(), sf);

		return sf;

	}

	public boolean cancelTask(String schedulerId) {
		if (null != schedulerId) {

			LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Attempting to CANCEL task with scheduler Id: "
					+ schedulerId);

			ScheduledFuture<?> sf = schedulerPool.get(schedulerId);
			boolean cancelStatus = false;
			if (null != sf && !sf.isDone()) {
				LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Cancelling task with task Id: " + schedulerId);
				cancelStatus = sf.cancel(true);
			} else {
				LOGGER.warn("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Task with task Id: " + schedulerId
						+ " is already DONE? Scheduled Future Not found!!!");
			}
			LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Removing Task with task Id: " + schedulerId
					+ " from pool");
			schedulerPool.remove(schedulerId);
			return cancelStatus;
		}
		return false;
	}

	public String triggerMotorNotReceivedScheduler(String batchProcessId, String masterWorkflowId,
			String procInstRefId, String scheduledBy, String subprocessId, String functionCode, String gspRefNum,
			int delayDays, int reminderNumber, String taskId, String taskPriority) {

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId
				+ "; BEGIN: Scheduling task for MOTOR TO BE RECEIVED FOR BATCH_PROCESS_ID: " + batchProcessId
				+ "; MASTER_WORKFLOW_ID: " + masterWorkflowId + "; SUBPROCESS_ID: " + subprocessId
				+ "; FUNCTION_CODE: " + functionCode + "; DELAY_IN_DAYS: " + delayDays + "; taskPriority: "
				+ taskPriority);

		ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
		SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);
		UniqueIdGenerator uniqueIdGenerator = applicationContext.getBean(UniqueIdGenerator.class);

		String schedulerId = uniqueIdGenerator.generateUniqueId();

		ReceiveMotorTaskTimer receiveMotorTaskTimer = new ReceiveMotorTaskTimer();
		receiveMotorTaskTimer.setName("RMTT_" + subprocessId + "_" + schedulerId + "_" + nodeId);
		receiveMotorTaskTimer.setProcessInstanceId(procInstRefId);
		receiveMotorTaskTimer.setTaskId(taskId);
		receiveMotorTaskTimer.setReminderNumber(reminderNumber);
		receiveMotorTaskTimer.setSchedulerId(schedulerId);
		receiveMotorTaskTimer.setSubprocessId(Long.parseLong(subprocessId));

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Scheduling Motor to be received for subprocessId: "
				+ subprocessId + " with schedulerId: " + schedulerId);
		scheduleMotorToBeReceived(receiveMotorTaskTimer, delayDays);

		SchedulerDetailsDTO schedulerDetailsDTO = new SchedulerDetailsDTO();
		schedulerDetailsDTO.setBatchProcessId(batchProcessId);
		schedulerDetailsDTO.setMasterWorkflowId(Long.parseLong(masterWorkflowId));
		schedulerDetailsDTO.setNextRunTimestamp(receiveMotorTaskTimer.getNextRunTimeInMillis());
		schedulerDetailsDTO.setPostRestartRun(1);
		schedulerDetailsDTO.setProcInstRefId(procInstRefId);
		schedulerDetailsDTO.setRunNumber(reminderNumber);
		schedulerDetailsDTO.setScheduledBy(scheduledBy);
		schedulerDetailsDTO.setSchedulerId(schedulerId);
		schedulerDetailsDTO.setSchedulerType(MotorRepairConstants.SCHEDULER_TYPES.RECEIVE_MOTOR.getValue());
		schedulerDetailsDTO.setSolutionCategoryId(MotorRepairConstants.PROGRAM_ID);
		schedulerDetailsDTO.setSubprocessId(Long.parseLong(subprocessId));
		schedulerDetailsDTO.setTaskRefId(taskId);
		schedulerDetailsDTO.setTaskSLAType(0);
		schedulerDetailsDTO.setTenantId(MotorRepairConstants.TENANT_ID);
		schedulerDetailsDTO.setHasExecuted(0);
		schedulerDetailsDTO.setGspRefNum(gspRefNum);
		schedulerDetailsDTO.setFunctionCode(functionCode);
		schedulerDetailsDTO.setTaskPriority(taskPriority);
		schedulerDetailsDTO.setNodeId(nodeId);

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Persisting SchedulerDetailsDTO for subprocessId: "
				+ subprocessId + " with schedulerId: " + schedulerId);
		// TODO persist scheduler details object
		schedulerDetailsService.createUpdateSchedulerDetails(schedulerDetailsDTO);

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId
				+ "; END: Scheduling task for MOTOR TO BE RECEIVED FOR BATCH_PROCESS_ID: " + batchProcessId
				+ "; MASTER_WORKFLOW_ID: " + masterWorkflowId + "; SUBPROCESS_ID: " + subprocessId
				+ "; FUNCTION_CODE: " + functionCode + "; DELAY_IN_DAYS: " + delayDays);

		return schedulerId;

	}

	public String triggerTTOScheduler(String batchProcessId, String masterWorkflowId, String procInstRefId,
			String scheduledBy, String subprocessId, String functionCode, String gspRefNum, int delayMins,
			int reminderNumber, String taskId, String taskPriority) {

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; BEGIN: Scheduling task for TTO FOR BATCH_PROCESS_ID: "
				+ batchProcessId + "; MASTER_WORKFLOW_ID: " + masterWorkflowId + "; SUBPROCESS_ID: " + subprocessId
				+ "; TASK_ID: " + taskId + "; FUNCTION_CODE: " + functionCode + "; DELAY_IN_MINS: " + delayMins
				+ "; taskPriority: " + taskPriority);

		// DO NOT SCHEDULE
		
		
//		ApplicationContext applicationContext = SpringApplicationContext.getApplicationContext();
//		SchedulerDetailsService schedulerDetailsService = applicationContext.getBean(SchedulerDetailsService.class);
//		UniqueIdGenerator uniqueIdGenerator = applicationContext.getBean(UniqueIdGenerator.class);
//
//		String schedulerId = uniqueIdGenerator.generateUniqueId();
//
//		TTOTaskTimer ttoTaskTimer = new TTOTaskTimer();
//		ttoTaskTimer.setName("TTO_" + subprocessId + "_" + schedulerId + "_" + nodeId);
//		ttoTaskTimer.setProcessInstanceId(procInstRefId);
//		ttoTaskTimer.setTaskId(taskId);
//		ttoTaskTimer.setReminderNumber(reminderNumber);
//		ttoTaskTimer.setSchedulerId(schedulerId);
//		ttoTaskTimer.setSubprocessId(Long.parseLong(subprocessId));
//		ttoTaskTimer.setFunctionCode(functionCode);
//
//		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Scheduling TTO for taskId: " + taskId
//				+ " with schedulerId: " + schedulerId);
//
//		scheduleTimeToOwnSLA(ttoTaskTimer, delayMins);
//
//		SchedulerDetailsDTO schedulerDetailsDTO = new SchedulerDetailsDTO();
//		schedulerDetailsDTO.setBatchProcessId(batchProcessId);
//		schedulerDetailsDTO.setMasterWorkflowId(Long.parseLong(masterWorkflowId));
//		schedulerDetailsDTO.setNextRunTimestamp(ttoTaskTimer.getNextRunTimeInMillis());
//		schedulerDetailsDTO.setPostRestartRun(1);
//		schedulerDetailsDTO.setProcInstRefId(procInstRefId);
//		schedulerDetailsDTO.setRunNumber(reminderNumber);
//		schedulerDetailsDTO.setScheduledBy(scheduledBy);
//		schedulerDetailsDTO.setSchedulerId(schedulerId);
//		schedulerDetailsDTO.setSchedulerType(MotorRepairConstants.SCHEDULER_TYPES.TTO.getValue());
//		schedulerDetailsDTO.setSolutionCategoryId(MotorRepairConstants.PROGRAM_ID);
//		schedulerDetailsDTO.setSubprocessId(Long.parseLong(subprocessId));
//		schedulerDetailsDTO.setTaskRefId(taskId);
//
//		if (reminderNumber == 1)
//			schedulerDetailsDTO.setTaskSLAType(MotorRepairConstants.FUNCTION_SLA_STATE.IN_SLA.getValue());
//		else if (reminderNumber == 2)
//			schedulerDetailsDTO.setTaskSLAType(MotorRepairConstants.FUNCTION_SLA_STATE.WARN_SLA.getValue());
//		else if (reminderNumber >= 3)
//			schedulerDetailsDTO.setTaskSLAType(MotorRepairConstants.FUNCTION_SLA_STATE.ESCALACTED_SLA.getValue());
//
//		schedulerDetailsDTO.setTenantId(MotorRepairConstants.TENANT_ID);
//		schedulerDetailsDTO.setHasExecuted(0);
//		schedulerDetailsDTO.setGspRefNum(gspRefNum);
//		schedulerDetailsDTO.setFunctionCode(functionCode);
//		schedulerDetailsDTO.setTaskPriority(taskPriority);
//		schedulerDetailsDTO.setNodeId(nodeId);
//
//		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; Persisting SchedulerDetailsDTO for taskId: " + taskId
//				+ " with schedulerId: " + schedulerId);
//		// TODO persist scheduler details object
//		schedulerDetailsService.createUpdateSchedulerDetails(schedulerDetailsDTO);

		LOGGER.info("TASK_SLA_MANAGER: NODE ID: " + nodeId + "; END: Scheduled task for TTO FOR BATCH_PROCESS_ID: "
				+ batchProcessId + "; MASTER_WORKFLOW_ID: " + masterWorkflowId + "; SUBPROCESS_ID: " + subprocessId
				+ "; TASK_ID: " + taskId + "; FUNCTION_CODE: " + functionCode + "; DELAY_IN_MINS: " + delayMins);

		return null;
//		return schedulerId;

		
	}

	public static void main(String[] args) {
		System.out.println(Calendar.getInstance().getTime() + " START");
		// TaskSLAManager mgr = TaskSLAManager.getInstance();
		//
		// ReceiveMotorTaskTimer rmt = new ReceiveMotorTaskTimer();
		// rmt.setName("MOTOR_TO_RECEIVE1");
		// rmt.setTaskId("1");
		// rmt.setProcessInstanceId("1");
		//
		// mgr.scheduleMotorToBeReceived(rmt, 1);

		for (int i = 0; i < 4; i++) {
			if (i == 2) {
				continue;
			}
			System.out.println(i);
		}

	}

	public static void main_001(String[] args) {
		System.out.println(Calendar.getInstance().getTime() + " START");

		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();

		TaskSLAManager mgr = new TaskSLAManager();
		TTOTaskTimer t1 = new TTOTaskTimer();
		t1.setName("t1");
		t1.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());
		TTOTaskTimer t2 = new TTOTaskTimer();
		t2.setName("t2");
		t2.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());
		TTOTaskTimer t3 = new TTOTaskTimer();
		t3.setName("t3");
		t3.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());
		TTOTaskTimer t4 = new TTOTaskTimer();
		t4.setName("t4");
		t4.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());
		TTOTaskTimer t5 = new TTOTaskTimer();
		t5.setName("t5");
		t5.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());
		TTOTaskTimer t6 = new TTOTaskTimer();
		t6.setName("t6");
		t6.setTtoTaskTimerId(uniqueIdGenerator.generateUniqueId());

		System.out.println(Calendar.getInstance().getTime() + " SCHEDULING");

		ScheduledFuture sf1 = mgr.scheduleTimeToOwnSLA(t1, 1);
		ScheduledFuture sf2 = mgr.scheduleTimeToOwnSLA(t6, 1);
		ScheduledFuture sf3 = mgr.scheduleTimeToOwnSLA(t3, 10);
		ScheduledFuture sf4 = mgr.scheduleTimeToOwnSLA(t4, 2);
		ScheduledFuture sf5 = mgr.scheduleTimeToOwnSLA(t5, 1);
		ScheduledFuture sf6 = mgr.scheduleTimeToOwnSLA(t6, 1);

		System.out.println(Calendar.getInstance().getTime() + " GETTING");
		try {
			System.out.println(sf1.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		try {
			System.out.println(sf2.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		sf3.cancel(true);

		try {
			System.out.println(sf3.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		try {
			System.out.println(sf4.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		try {
			System.out.println(sf5.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		try {
			System.out.println(sf6.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Throwable th) {
			// TODO Auto-generated catch block
			th.printStackTrace();
		}

		System.out.println(Calendar.getInstance().getTime() + "DONE GETTING");

		sf1.isDone();
		sf2.isDone();
		sf3.isDone();
		sf3.isCancelled();
		sf4.isDone();
		sf4.isCancelled();
		sf5.isDone();
		sf6.isDone();

		mgr.slaScheduler.shutdown();

	}

	/**
	 * Steps: <br>
	 * 1. For every Motor to be received task, create a reminder in the pool<br>
	 * 2. The reminder works every 4th day and sends a notification to customer to send motor to assigned ARC<br>
	 * 3. The reminder copies this email to CCC group for follow up<br>
	 * 4. The reminder then schedules another reminder for 7th day follow up<br>
	 * 5. The 7th day reminder send another reminder to customer to follow up<br>
	 * 6. This reminder also notifies CCC group for follow up.<br>
	 * 7. This reminder also now schedules another reminder for Ticket closure notification for 10th day<br>
	 * 8. On 10th day the ticket closure notification reminder executes and creates a task for CCC for ticket closure<br>
	 * 9. Initially, as soon as the motor reminder is scheduled, it makes an entry in the scheduler table to mark its
	 * next run.<br>
	 * 10. The entries made in scheduler would be:<br>
	 * 10.1 Scheduler Id<br>
	 * 10.2 Next scheduled time<br>
	 * 10.3 Flag if the reminder execution completed.<br>
	 * 10.4 Subprocess Id for which the reminder is scheduled.<br>
	 * 10.5 Benchmark Id for which the scheduler ran 11. Behaviour of the reminder:<br>
	 * 11.1 The
	 */

}
