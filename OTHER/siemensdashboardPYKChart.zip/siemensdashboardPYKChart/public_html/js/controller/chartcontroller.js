var myApp = angular.module('demochart', []).config(['$httpProvider', function ($httpProvider) {
    }]);
myApp.controller('chartcontroller', ['$scope', '$http', function ($scope, $http) {
        $scope.locations = [
            {
                "locid": "1",
                "name": "Mumbai-Worli Office"
            }, {
                "locid": "2",
                "name": "Gurgaon-Jagjit Ind.Ltd"
            }, {
                "locid": "3",
                "name": "Ahmedabad-Prerna Arbor Bd"
            }, {
                "locid": "4",
                "name": "Aurangabad-AW-Gas Insu SGR"
            }, {
                "locid": "5",
                "name": "Thane PTD Transformers"
            }, {
                "locid": "6",
                "name": "Ernakulam-Cochin-OxfordBC"
            }, {
                "locid": "7",
                "name": "Indore"
            }, {
                "locid": "8",
                "name": "Lucknow-Ashok Marg"
            }, {
                "locid": "9",
                "name": "Vadodara-HDX Factory"
            }, {
                "locid": "10",
                "name": "Goa"
            }
        ];
        $scope.divisions = [
            {
                "divid": "1",
                "name": "Mobility Management"
            }, {
                "divid": "2",
                "name": "Mainline Transport"
            }, {
                "divid": "3",
                "name": "Power Transmission"
            }, {
                "divid": "4",
                "name": "Automation"
            }, {
                "divid": "5",
                "name": "Large Drives"
            }, {
                "divid": "6",
                "name": "Customer Sevices"
            }, {
                "divid": "7",
                "name": "Solution & Service"
            }, {
                "divid": "8",
                "name": "Energy Managment"
            }, {
                "divid": "9",
                "name": "Accounting and Controlling"
            }, {
                "divid": "10",
                "name": "Corporate"

            }];
        $scope.departments = [
            {
                "depid": "1",
                "name": "CG"
            }, {
                "depid": "2",
                "name": "EM HP"
            }, {
                "depid": "3",
                "name": "EM"
            }, {
                "depid": "4",
                "name": "HR"
            }, {
                "depid": "5",
                "name": "MO MM"
            }, {
                "depid": "6",
                "name": "MO MLT"
            }, {
                "depid": "7",
                "name": "PD LD"
            }, {
                "depid": "8",
                "name": "BT SSP"
            }, {
                "depid": "9",
                "name": "AD-AW-C"
            }, {
                "depid": "10",
                "name": "DT-MCPM"
            }];
        $scope.employees = [
            {
                "id": "1",
                "name": "kiran"
            },
            {
                "id": "2",
                "name": "haris"
            },
            {
                "id": "3",
                "name": "Vimal"
            },
            {
                "id": "4",
                "name": "Mihir"
            },
            {
                "id": "5",
                "name": "Anil"
            },
            {
                "id": "6",
                "name": "Nikesh"
            }, {
                "id": "7",
                "name": "Ajinkya"
            },
            {
                "id": "8",
                "name": "Kunal"
            }, {
                "id": "9",
                "name": "Rajgopal"
            },
            {
                "id": "10",
                "name": "Vatsal"
            }
        ];
        $scope.months = [
            {
                "monthid": "1",
                "quater": "1",
                "name": "January"
            },
            {
                "monthid": "2",
                "quater": "1",
                "name": "February"
            },
            {
                "monthid": "3",
                "quater": "1",
                "name": "March"
            },
            {
                "monthid": "4",
                "quater": "2",
                "name": "April"
            },
            {
                "monthid": "5",
                "quater": "2",
                "name": "May"
            },
            {
                "monthid": "6",
                "quater": "2",
                "name": "June"
            },
            {
                "monthid": "7",
                "quater": "3",
                "name": "July"
            },
            {
                "monthid": "8",
                "quater": "3",
                "name": "August"
            },
            {
                "monthid": "9",
                "quater": "3",
                "name": "September"
            },
            {
                "monthid": "10",
                "quater": "4",
                "name": "October"
            },
            {
                "monthid": "11",
                "quater": "4",
                "name": "November"
            },
            {
                "monthid": "12",
                "quater": "4",
                "name": "December"
            }
        ];
        $scope.colors = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9", "#4DD9A9"];
        //----------------------------------change Below Part Only-------------------------------------------------------//
        $scope.updategraph = function () {
            $scope.graphData();
            setTimeout(function () {
                $(".PykCharts-credits").remove();
            }, 3000);
        }
        $scope.generateColumnchart = function (selector) {
            $scope.columnchart = $scope.pykcharts.columnchart;
            $scope.columnchart.selector = "#" + selector;
            $http.get("http://localhost:10080/dashboard/rest/columnchart").success(function (data) {
                $scope.columnchart.data = $scope.reformatData("columnchart", data);
                var y = new PykCharts.multiD.column($scope.columnchart);
                y.execute();
                setTimeout(function () {
                    d3.selectAll("#" + selector + " rect.vcolumn")
                            .attr("fill", function (d, i) {
                                return $scope.colors[i];
                            });
                }, 1000);
            });
        }
        $scope.generatePiechart = function (selector) {
            $scope.piechart = $scope.pykcharts.piechart;
            $scope.piechart.selector = "#" + selector;
            $http.get("http://localhost:10080/dashboard/rest/piechart").success(function (data) {
                $scope.piechart.data = data;
                var x = new PykCharts.oneD.pie($scope.piechart);
                x.execute();
                setTimeout(function () {
                    d3.selectAll("#" + selector + "_svg path.pie")
                            .attr("fill", function (d, i) {
                                return $scope.colors[i];
                            });
                }, 1000);
            });
        }
        $scope.generateDonutchart = function (selector) {
            $scope.donutchart = $scope.pykcharts.donutchart;
            $scope.donutchart.selector = "#" + selector;
//            $http.get("http://localhost:10080/dashboard/rest/piechart").success(function (data) {
            //$scope.piechart.data = data;
            var x = new PykCharts.oneD.pie($scope.donutchart);
            x.execute();
            setTimeout(function () {
                d3.selectAll("#" + selector + "_svg path.pie")
                        .attr("fill", function (d, i) {
                            return $scope.colors[i];
                        });
            }, 1000);
//            });
        }
        $scope.generateBarchart = function (selector) {
            $scope.barchart = $scope.pykcharts.barchart;
            $scope.barchart.selector = "#" + selector;
//            $http.get("http://localhost:10080/dashboard/rest/barchart").success(function (data) {
            //$scope.barchart.data = data;
            //$scope.barchart= $scope.reformatData("barchart", $scope.barchart.data);
            var x = new PykCharts.multiD.bar($scope.barchart);
            x.execute();
            setTimeout(function () {
                d3.selectAll("#" + selector + "_svg rect.hbar")
                        .attr("fill", function (d, i) {
                            return $scope.colors[i];
                        });
            }, 1000);
//            });
        }
        $scope.generateMultiSeriesLine = function (selector) {
            $scope.multiSeriesLine = $scope.pykcharts.multiSeriesLine;
            $scope.multiSeriesLine.selector = "#" + selector;
//            $http.get("http://localhost:10080/dashboard/rest/multiSeriesLine").success(function (data) {
            //$scope.multiSeriesLine.data = data;
            var x = new PykCharts.multiD.multiSeriesLine($scope.multiSeriesLine);
            x.execute();
//            });
        }
        $scope.generateElectionDonut = function (selector) {
            $scope.electionDonut = $scope.pykcharts.electionDonut;
            $scope.electionDonut.selector = "#" + selector;
            $scope.electionDonut.title_text = $scope.seldep + " Department";
//            $http.get("http://localhost:10080/dashboard/rest/electionDonut").success(function (data) {
            //$scope.electionDonut.data = data;
            var x = new PykCharts.oneD.electionDonut($scope.electionDonut);
            x.execute();
            setTimeout(function () {
                d3.selectAll("#" + selector + " path.pie")
                        .attr("fill", function (d, i) {
                            return $scope.colors[i];
                        });
                $("#electionDonut_svg").css({"margin-top": "57px", "margin-bottom": "-57px"});
            }, 2000);

//            });
        }
        $scope.generateElectionPie = function (selector) {
            $scope.electionPie = $scope.pykcharts.electionPie;
            $scope.electionPie.selector = "#" + selector;
            $scope.electionPie.title_text = $scope.sellocation + " Location";
//            $http.get("http://localhost:10080/dashboard/rest/electionPie").success(function (data) {
            //$scope.electionPie.data = data;
            var x = new PykCharts.oneD.electionPie($scope.electionPie);
            x.execute();
            setTimeout(function () {
                d3.selectAll("#" + selector + " path.pie")
                        .attr("fill", function (d, i) {
                            return $scope.colors[i];
                        });
                $("#electionPie_svg").css({"margin-top": "57px", "margin-bottom": "-57px"});
            }, 1000);

//            });
        }
        $scope.reformatData = function (type, data) {// Used When Tooltip is missiing & we are adding Custom Heer
            var obj = [];
            if (type == "columnchart") {
                for (var i = 0; i < data.length; i++) {
                    data[i].group = "Progress(%)";
                    data[i].tooltip = "<table class='PykCharts'><tr><th>" + data[i].x + "(Progress %)</th></tr><tr><td>" + data[i].y + "</td></tr></table>";
                    obj.push(data[i]);
                }
            }
            return obj;
        }
        $scope.graphData = function () {
            $scope.generateColumnchart("columnchart");//Top-10 Departments
            $scope.generatePiechart("piechart");//All divisons
            $scope.generateDonutchart("donutchart");//Top-10 Locations
            $scope.generateBarchart("barchart");//Reasons For Exception
            $scope.generateMultiSeriesLine("multiserieschart");//Swips in out
            $scope.generateElectionDonut("electionDonut");//User selected department
            $scope.generateElectionPie("electionPie");//User selected Location
            var pu = new PykCharts.oneD.pie({
                "selector": "#piechartuser",
                "data": [
                    {
                        "name": "Not well",
                        "weight": 200,
                        "color": "#F69191"

                    },
                    {
                        "name": "Earned Leave",
                        "weight": 600,
                        "color": "#F69191"
                    },
                    {
                        "name": "Urgent Personal Work",
                        "weight": 900,
                        "color": "#F69191"
                    },
                    {
                        "name": "Doctor's appointment",
                        "weight": 500,
                        "color": "#F69191"
                    },
                    {
                        "name": "Native Place",
                        "weight": 430,
                        "color": "#F69191"
                    }
                ],
//                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/pie.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
                "shade_color": "#52B3D9",
//                "shade_color": "#239fdc",
                "chart_color": ["#03C9A9,#2BA78D,#BB2412,#E82D2D,#FF5454,#F69191,#3A539B,#4B77BE,#52B3D9,#4DD9A9"],
                "pointer_overflow_enable": "Yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 10,
                "chart_onhover_highlight_enable": "no",
                "pie_radius_percent": 70,
                "tooltip_enable": "yes",
                "title_text": $scope.seldivision + " Division",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            pu.execute();

            var colorspieu = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9", "#4DD9A9"];
            setTimeout(function () {
                d3.selectAll("#piechartuser_svg path.pie")
                        .attr("fill", function (d, i) {
                            return colorspieu[i];
                        });
            }, 1000);
        }
        $scope.generateGraph = function () {
            $scope.currentselected={
                "year":$scope.selyear,
                "quarter":$scope.selquarter,
                "month":$scope.selmonth,
                "department":$scope.seldep,
                "divisions":$scope.seldivision
            }
            window.PykChartsInit = function (e) {
                $scope.graphData();
                setTimeout(function () {
                    $(".PykCharts-credits").remove();
                }, 3000);
            }
        }
        $scope.setTabs = function (tab) {
            $scope.tab = tab;
            $scope.getChartConfig();
//            setTimeout(function () {
            $scope.generateGraph();

//            $scope.getData();
//            }, 500);

        }
        $scope.getChartConfig = function () {
            $http.get("data/pykcharts.json").success(function (data) {
                $scope.pykcharts = data;
            });
        }
       

        $scope.init = function () {
            $scope.selyear = 2015;
            $scope.curselyear = 2015;
            $scope.selquarter = "4";
            $scope.curselquarter = "Q4";
            $scope.selmonth = 10;
            $scope.seldep = "CG";
            $scope.seldivision = "Mobility Management";
            $scope.selemployee = "Select Employee";
            $scope.sellocation = "Mumbai-Worli Office";
             $scope.setTabs(1);

        }
        $scope.init();
        $scope.resetData = function (param) {
            $scope[param] = "";
            if (param == 'curselyear') {
                $scope.selyear = "";
            } else if (param == 'curselquarter') {
                $scope.selquarter = "";
                $scope.selmonth = "";
                $scope.curselmonth = "";
            } else if (param == 'curselmonth') {
                $scope.selmonth = "";
            } else if (param == 'curempname') {
                $scope.selemployee = "";
            } else if (param == 'curmngname') {
                $scope.selmanager = "";
                $scope.curempname = "";
                $scope.selemployee = "";
            }
        }
        $scope.byQuarter = function (month) {
            if (month.quater == $scope.selquarter) {
                return true;
            } else {
                return false;

            }
        }
        $scope.selectQuarter = function () {
            if ($scope.selquarter == "1") {
                $scope.curselquarter = "Q1";
            } else if ($scope.selquarter == "2") {
                $scope.curselquarter = "Q2";
            }
            else if ($scope.selquarter == "3") {
                $scope.curselquarter = "Q3";
            }
            else if ($scope.selquarter == "4") {
                $scope.curselquarter = "Q4";
            } else {
                $scope.curselquarter = "";
            }
//            $scope.selmonth=$scope.months[0];
        }
        $scope.selectMonth = function () {
            for (var i = 0; i <= $scope.months.length; i++) {
                if ($scope.months[i].monthid == $scope.selmonth) {
                    $scope.curselmonth = $scope.months[i].name;
                    break;
                }
            }
        }
    }]);