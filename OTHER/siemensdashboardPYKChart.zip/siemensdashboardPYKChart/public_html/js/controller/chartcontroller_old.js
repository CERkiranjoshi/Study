var myApp = angular.module('demochart', []).config(['$httpProvider', function ($httpProvider) {
    }]);
myApp.controller('chartcontroller', ['$scope', '$http', function ($scope, $http) {
        $scope.sample = 'Sample';
//        $http.get("data/managerdata.json")
//                .success(function (response) {
//                    $scope.manager = response;
//                });
        $scope.manager = [
            {
                "id": "1",
                "depid": "1",
                "name": "Pueshotam Purshvam",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "2",
                "depid": "1",
                "name": "Madhuran D'silva",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "3",
                "depid": "2",
                "name": "sandip gawda",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "4",
                "name": "Xyz",
                "depid": "2",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            }
        ];
//        $http.get("data/employeedata.json")
//                .success(function (response) {
//                    $scope.employees = response;
//                });
        $scope.employees = [
            {
                "id": "1",
                "name": "kiran",
                "mangerid": "1",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "2",
                "name": "haris",
                "mangerid": "1",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "3",
                "name": "ABC",
                "mangerid": "2",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "4",
                "name": "DEF",
                "mangerid": "2",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "5",
                "name": "GHI",
                "mangerid": "3",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "6",
                "name": "JKL",
                "mangerid": "3",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            }
        ];
//        $http.get("data/months.json")
//                .success(function (response) {
//                    $scope.months = response;
//                });
        $scope.months = [
            {
                "monthid": "1",
                "quater": "1",
                "name": "January"
            },
            {
                "monthid": "2",
                "quater": "1",
                "name": "February"
            },
            {
                "monthid": "3",
                "quater": "1",
                "name": "March"
            },
            {
                "monthid": "4",
                "quater": "2",
                "name": "April"
            },
            {
                "monthid": "5",
                "quater": "2",
                "name": "May"
            },
            {
                "monthid": "6",
                "quater": "2",
                "name": "June"
            },
            {
                "monthid": "7",
                "quater": "3",
                "name": "July"
            },
            {
                "monthid": "8",
                "quater": "3",
                "name": "August"
            },
            {
                "monthid": "9",
                "quater": "3",
                "name": "September"
            },
            {
                "monthid": "10",
                "quater": "4",
                "name": "October"
            },
            {
                "monthid": "11",
                "quater": "4",
                "name": "November"
            },
            {
                "monthid": "12",
                "quater": "4",
                "name": "December"
            }
        ];

        //----------------------------------change Below Part Only-------------------------------------------------------//
        $scope.partial =
                {
                    violation: "violation.html",
                    recorder: "recorder.html"
                };
        $scope.updategraph = function () {
            $scope.graphData();
            setTimeout(function () {
                $(".PykCharts-credits").remove();
            }, 3000);
        }
        $scope.graphData = function () {
            var k = new PykCharts.multiD.spiderWeb({
                //Chart Container Id
                "selector": "#spiderweb",
                //Data file path
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/spider.csv",
                //Chart mode
                "mode": "default",
                //Chart Size Parameters
                "chart_width": 400,
                "chart_height": 220,
                //Chart color
                "color_mode": "color",
                "saturation_color": "#255AEE",
                "chart_color": [
                    "#03C9A9", "#2BA78D"
                ],
                //X-Axis parameters
                "axis_x_pointer_size": 12,
                "axis_x_pointer_color": "#1D1D1D",
                //Y-Axis parameters
                "axis_y_pointer_size": 12,
                "axis_y_pointer_color": "#1D1D1D",
                //Realtime data parameters
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                //Chart border parameters
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                //Chart-interactive parameters
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "transition_duration": 0,
                //Other parameters
                "spiderweb_outer_radius_percent": 100,
                "variable_circle_size_enable": "yes",
                //Chart title parameters
                "title_text": "My Divisions",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                //Chart subtitle parameters
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "chart_margin_left": 25,
                "chart_margin_right": 0,
                "chart_margin_top": 0,
                "chart_margin_bottom": 25,
                "click_enable": "yes",
                //Credits parameters
                "credit_my_site_name": "Siemens",
                "credit_my_site_url": "http://www.siemens.com"
            });
            k.execute();

            var y = new PykCharts.multiD.column({
                "selector": "#columnchart",
                "data": [
                    {
                        "x": "January",
                        "y": 48.9,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "Feb",
                        "y": 38.8,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "March",
                        "y": 39.3,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "April",
                        "y": 41.4,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "June",
                        "y": 47,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "July",
                        "y": 48.3,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "August",
                        "y": 59,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "September",
                        "y": 59.6,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "October",
                        "y": 52.4,
                        "group": "Rainfall(mm)"
                    }
                ],
                // "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/column.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
//                "saturation_color": "",
//                "chart_color": [
//                    '#255AEE', '#97BBCD', // blue
//                    '#DCDCDC', // light grey
//                    '#F7464A', // red
//                    '#46BFBD', // green
//                    '#FDB45C', // yellow
//                    '#949FB1', // grey
//                    '#4D5360'
//                ],
                "chart_color": ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9"],
                "axis_onhover_highlight_enable": "no",
                "axis_x_enable": "yes",
                "axis_x_title": "",
                "axis_x_position": "bottom",
                "axis_x_pointer_position": "bottom",
                "axis_x_line_color": "#1D1D1D",
                "axis_x_pointer_size": 12,
                "axis_x_pointer_color": "#1D1D1D",
                "axis_y_enable": "yes",
                "axis_y_title": "",
                "axis_y_position": "left",
                "axis_y_pointer_position": "left",
                "axis_y_line_color": "#1D1D1D",
                "axis_y_pointer_size": 12,
                "axis_y_pointer_color": "#1D1D1D",
                "axis_y_no_of_axis_value": 5,
                "axis_y_pointer_padding": 6,
                "axis_y_pointer_values": [],
                "axis_y_outer_pointer_length": 0,
                "axis_y_time_value_datatype": "",
                "axis_y_time_value_interval": 0,
//                "highlight": "Feb",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "chart_margin_left": 25,
                "chart_margin_right": 0,
                "chart_margin_top": 0,
                "chart_margin_bottom": 25,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "title_text": "Departments",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "Siemens",
                "credit_my_site_url": "http://www.siemens.com",
                "map_code": "world"
            });
            y.execute();

            var colorscl = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9"];
            setTimeout(function () {
                d3.selectAll("#columnchart_svg rect.vcolumn")
                        .attr("fill", function (d, i) {
                            return colorscl[i];
                        });
            }, 1000);

            var z = new PykCharts.oneD.donut({
                "selector": "#donutchart",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/donut.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "shade",
                "shade_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "Property",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 5,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "donut_radius_percent": 70,
                "donut_inner_radius_percent": 40,
                "donut_show_total_at_center": "yes",
                "donut_show_total_at_center_size": 14,
                "donut_show_total_at_center_color": "#1D1D1D",
                "donut_show_total_at_center_weight": "bold",
                "donut_show_total_at_center_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_text": "Locations",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "Siemens",
                "credit_my_site_url": "http://www.siemens.com",
                "map_code": "world"
            });
            z.execute();
            var colors = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454"];
            setTimeout(function () {
                d3.selectAll("#donutchart_svg path.pie")
                        .attr("fill", function (d, i) {
                            return colors[i];
                        });
            }, 1000);


            var a = new PykCharts.oneD.pie({
                "selector": "#piechart",
                "data": [
                    {
                        "name": "ToyotaB",
                        "weight": 7000,
                        "color": "#F69191"

                    },
                    {
                        "name": "Toyota",
                        "weight": 13329,
                        "color": "#F69191"
                    },
                    {
                        "name": "Volkswagen",
                        "weight": 6920,
                        "color": "#F69191"
                    },
                    {
                        "name": "Nissan",
                        "weight": 4050,
                        "color": "#F69191"
                    },
                    {
                        "name": "Mitsubishi",
                        "weight": 430,
                        "color": "#F69191"
                    },
                    {
                        "name": "Ford",
                        "weight": 1000,
                        "color": "#F69191"
                    },
                    {
                        "name": "BMW",
                        "weight": 1895,
                        "color": "#F69191"
                    },
                    {
                        "name": "Suzuki",
                        "weight": 6000,
                        "color": "#F69191"
                    },
                    {
                        "name": "Audi",
                        "weight": 3000,
                        "color": "#F69191"
                    },
                    {
                        "name": "Rolas Roy",
                        "weight": 600,
                        "color": "#F69191"
                    }
                ],
//                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/pie.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
                "shade_color": "#52B3D9",
//                "shade_color": "#239fdc",
                "chart_color": ["#03C9A9,#2BA78D,#BB2412,#E82D2D,#FF5454,#F69191,#3A539B,#4B77BE,#52B3D9,#4DD9A9"],
                "pointer_overflow_enable": "Yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 10,
                "chart_onhover_highlight_enable": "no",
                "pie_radius_percent": 70,
                "tooltip_enable": "yes",
                "title_text": "All Divisions",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            a.execute();

            var colorspie = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9", "#4DD9A9"];
            setTimeout(function () {
                d3.selectAll("#piechart_svg path.pie")
                        .attr("fill", function (d, i) {
                            return colorspie[i];
                        });
            }, 1000);

            var b = new PykCharts.multiD.bar({
                "selector": "#barchart",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/bar.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
                "saturation_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "axis_onhover_highlight_enable": "no",
                "axis_x_enable": "yes",
                "axis_x_title": "",
                "axis_x_position": "bottom",
                "axis_x_pointer_position": "bottom",
                "axis_x_line_color": "#1D1D1D",
                "axis_x_pointer_size": 12,
                "axis_x_pointer_color": "#1D1D1D",
                "axis_x_no_of_axis_value": 5,
                "axis_x_pointer_padding": 6,
                "axis_x_outer_pointer_length": 0,
                "axis_x_pointer_values": [],
                "axis_x_time_value_datatype": "",
                "axis_x_time_value_interval": 0,
                "axis_y_enable": "yes",
                "axis_y_title": "",
                "axis_y_position": "left",
                "axis_y_pointer_position": "left",
                "axis_y_line_color": "#1D1D1D",
                "axis_y_pointer_size": 12,
                "axis_y_pointer_color": "#1D1D1D",
                // "highlight": "United States",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "chart_margin_left": 50,
                "chart_margin_right": 25,
                "chart_margin_top": 35,
                "chart_margin_bottom": 35,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "data_sort_enable": "no",
                "data_sort_type": "alphabetically",
                "data_sort_order": "ascending",
                "title_text": "Reasons For Exception",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            b.execute();

            var colors = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191"];
            setTimeout(function () {
                d3.selectAll("#barchart_svg rect.hbar")
                        .attr("fill", function (d, i) {
                            return colors[i];
                        });
            }, 1000);
            c = new PykCharts.multiD.multiSeriesLine({
                "selector": "#multiserieschart",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/multi-series-line.csv",
                "chart_width": 820,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
                "saturation_color": "#255AEE",
                "chart_color": [
                    "#03C9A9", "#2BA78D", "#BB2412"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "axis_onhover_highlight_enable": "no",
                "axis_x_enable": "yes",
                "axis_x_title": "",
                "axis_x_position": "bottom",
                "axis_x_pointer_position": "bottom",
                "axis_x_line_color": "#1D1D1D",
                "axis_x_pointer_size": 12,
                "axis_x_pointer_color": "#1D1D1D",
                "axis_x_no_of_axis_value": 5,
                "axis_x_pointer_padding": 6,
                "axis_x_outer_pointer_length": 0,
                "axis_x_pointer_values": [],
                "axis_x_time_value_datatype": "",
                "axis_x_time_value_interval": 0,
                "axis_y_enable": "yes",
                "axis_y_title": "",
                "axis_y_position": "left",
                "axis_y_pointer_position": "left",
                "axis_y_line_color": "#1D1D1D",
                "axis_y_pointer_size": 12,
                "axis_y_pointer_color": "#1D1D1D",
                "axis_y_no_of_axis_value": 5,
                "axis_y_pointer_padding": 6,
                "axis_y_pointer_values": [],
                "axis_y_outer_pointer_length": 0,
                "axis_y_time_value_datatype": "",
                "axis_y_time_value_interval": 0,
//                "highlight": "Previously Hired",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "chart_margin_left": 50,
                "chart_margin_right": 25,
                "chart_margin_top": 35,
                "chart_margin_bottom": 35,
                "chart_onhover_highlight_enable": "yes",
                "chart_grid_x_enable": "yes",
                "chart_grid_y_enable": "yes",
                "chart_grid_color": "#ddd",
                "tooltip_enable": "yes",
                "annotation_enable": "no",
                "annotation_background_color": "#C2CBCF",
                "annotation_font_color": "black",
                "annotation_view_mode": "onload",
                "crosshair_enable": "yes",
                "curvy_lines_enable": "no",
                "zoom_enable": "no",
                "title_text": "Swips in Swips Out",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            c.execute();
            var d = new PykCharts.multiD.column({
                "selector": "#columnchart1",
                "data": [
                    {
                        "x": "January",
                        "y": 48.9,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "Feb",
                        "y": 38.8,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "March",
                        "y": 39.3,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "April",
                        "y": 41.4,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "June",
                        "y": 47,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "July",
                        "y": 48.3,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "August",
                        "y": 59,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "September",
                        "y": 59.6,
                        "group": "Rainfall(mm)"
                    },
                    {
                        "x": "October",
                        "y": 52.4,
                        "group": "Rainfall(mm)"
                    }
                ],
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/column.csv",
                        "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "saturation",
                "saturation_color": "#255AEE",
                "chart_color": [
                    "#255AEE", '#97BBCD', // blue
                    '#DCDCDC', // light grey
                    '#F7464A', // red
                    '#46BFBD', // green
                    '#FDB45C', // yellow
                    '#949FB1', // grey
                    '#4D5360'
                ],
                "axis_onhover_highlight_enable": "no",
                "axis_x_enable": "yes",
                "axis_x_title": "",
                "axis_x_position": "bottom",
                "axis_x_pointer_position": "bottom",
                "axis_x_line_color": "#1D1D1D",
                "axis_x_pointer_size": 12,
                "axis_x_pointer_color": "#1D1D1D",
                "axis_y_enable": "yes",
                "axis_y_title": "",
                "axis_y_position": "left",
                "axis_y_pointer_position": "left",
                "axis_y_line_color": "#1D1D1D",
                "axis_y_pointer_size": 12,
                "axis_y_pointer_color": "#1D1D1D",
                "axis_y_no_of_axis_value": 5,
                "axis_y_pointer_padding": 6,
                "axis_y_pointer_values": [],
                "axis_y_outer_pointer_length": 0,
                "axis_y_time_value_datatype": "",
                "axis_y_time_value_interval": 0,
                "highlight": "Feb",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "chart_margin_left": 25,
                "chart_margin_right": 0,
                "chart_margin_top": 0,
                "chart_margin_bottom": 25,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "title_text": "Departments",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "Siemens",
                "credit_my_site_url": "http://www.siemens.com",
                "map_code": "world"
            });

            d.execute();
            var colorscl1 = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9"];
            setTimeout(function () {
                d3.selectAll("#columnchart1_svg rect.vcolumn")
                        .attr("fill", function (d, i) {
                            return colorscl1[i];
                        });
            }, 1000);
            var pe = new PykCharts.oneD.donut({
                "selector": "#donutchart1",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/donut.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "shade",
                "shade_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "Property",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 5,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "donut_radius_percent": 70,
                "donut_inner_radius_percent": 40,
                "donut_show_total_at_center": "yes",
                "donut_show_total_at_center_size": 14,
                "donut_show_total_at_center_color": "#1D1D1D",
                "donut_show_total_at_center_weight": "bold",
                "donut_show_total_at_center_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_text": "Locations",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "Siemens",
                "credit_my_site_url": "http://www.siemens.com",
                "map_code": "world"
            });
            pe.execute();
            var colorsd = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454"];
            setTimeout(function () {
                d3.selectAll("#donutchart1_svg path.pie")
                        .attr("fill", function (d, i) {
                            return colorsd[i];
                        });
            }, 1000);
            var f = new PykCharts.oneD.pie({
                "selector": "#piechart1",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/pie.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "shade",
                "shade_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "Volkswagen",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 5,
                "chart_onhover_highlight_enable": "yes",
                "pie_radius_percent": 70,
                "tooltip_enable": "yes",
                "title_text": "Divisions",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            f.execute();
            var colorspie1 = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9", "#4DD9A9"];
            setTimeout(function () {
                d3.selectAll("#piechart1_svg path.pie")
                        .attr("fill", function (d, i) {
                            return colorspie1[i];
                        });
            }, 1000);
            var g = new PykCharts.oneD.electionDonut({
                "selector": "#electionDonut",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/election-donut.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "shade",
                "shade_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "Production",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 5,
                "chart_onhover_highlight_enable": "yes",
                "tooltip_enable": "yes",
                "donut_radius_percent": 100,
                "donut_inner_radius_percent": 40,
                "donut_show_total_at_center": "yes",
                "donut_show_total_at_center_size": 14,
                "donut_show_total_at_center_color": "#1D1D1D",
                "donut_show_total_at_center_weight": "bold",
                "donut_show_total_at_center_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_text": "My Departments",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });

            g.execute();
            var colorsdoung = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454"];
            setTimeout(function () {
                d3.selectAll("#electionDonut path.pie")
                        .attr("fill", function (d, i) {
                            return colorsdoung[i];
                        });
                console.log($("#electionDonut_svg"));
                $("#electionDonut_svg").css({"margin-top": "57px", "margin-bottom": "-57px"});
            }, 1000);

            var h = new PykCharts.oneD.electionPie({
                "selector": "#electionPie",
                "data": "https://s3-ap-southeast-1.amazonaws.com/chartstore.io-data/election-pie.csv",
                "chart_width": 400,
                "chart_height": 220,
                "background_color": "#FFFFFF",
                "mode": "default",
                "color_mode": "color",
                "shade_color": "#255AEE",
                "chart_color": [
                    "#255AEE"
                ],
                "pointer_overflow_enable": "yes",
                "pointer_thickness": 1,
                "pointer_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "pointer_size": 13,
                "pointer_weight": "normal",
                "highlight": "Wholesalers",
                "label_size": 13,
                "label_weight": "normal",
                "label_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "real_time_charts_last_updated_at_enable": "no",
                "real_time_charts_refresh_frequency": 0,
                "transition_duration": 0,
                "border_between_chart_elements_thickness": 1,
                "border_between_chart_elements_style": "solid",
                "clubdata_enable": "yes",
                "clubdata_text": "Others",
                "clubdata_maximum_nodes": 5,
                "chart_onhover_highlight_enable": "yes",
                "pie_radius_percent": 100,
                "tooltip_enable": "yes",
                "title_text": "My Locations",
                "title_size": 1.3,
                "title_weight": "normal",
                "title_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "title_color": "white",
                "subtitle_text": "",
                "subtitle_size": 1,
                "subtitle_weight": "normal",
                "subtitle_family": "Helvetica Neue,Helvetica,Arial,sans-serif",
                "subtitle_color": "black",
                "credit_my_site_name": "ChartStore.io",
                "credit_my_site_url": "https://chartstore.io",
                "map_code": "world"
            });
            h.execute();
            var colorselectionPie = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454"];
            setTimeout(function () {
                d3.selectAll("#electionPie path.pie")
                        .attr("fill", function (d, i) {
                            return colorselectionPie[i];
                        });
                console.log($("#electionPie_svg"));
                $("#electionPie_svg").css({"margin-top": "57px", "margin-bottom": "-57px"});
            }, 1000);
        }
        $scope.generateGraph = function () {
            window.PykChartsInit = function (e) {
                $scope.graphData();
                setTimeout(function () {
                    $(".PykCharts-credits").remove();
                }, 3000);
            }
        }
        $scope.setTabs = function (tab) {
            $scope.tab = tab;
//            setTimeout(function () {
            $scope.generateGraph();
//            }, 500);

        }
        $scope.setTabs(1);
        $scope.seldep = "";
        $scope.selmanager = "";
        $scope.selemployee = "";
        $scope.curempname = "";
        $scope.curmngname = "";
        $scope.curselyear = "";
        $scope.byManager = function (emp) {
            if (emp.mangerid == $scope.selmanager && $scope.seldep != "") {
                return true;
            } else {
                return false;
            }
        }
        $scope.resetData = function (param) {
            $scope[param] = "";
            if (param == 'curselyear') {
                $scope.selyear = "";
            } else if (param == 'curselquarter') {
                $scope.selquarter = "";
                $scope.selmonth = "";
                $scope.curselmonth = "";
            } else if (param == 'curselmonth') {
                $scope.selmonth = "";
            } else if (param == 'curempname') {
                $scope.selemployee = "";
            } else if (param == 'curmngname') {
                $scope.selmanager = "";
                $scope.curempname = "";
                $scope.selemployee = "";
            }
        }
        $scope.byDepartment = function (manager) {
//            console.log(manager)
            if (manager.depid == $scope.seldep && $scope.seldep != "") {
                return true;
            } else {
                return false;
            }
        }
        $scope.clearManagedata = function () {
            $scope.selemployee = "";
            for (var j = 0; j <= $scope.manager.length; j++) {
                if ($scope.manager[j].id == $scope.selmanager) {
                    $scope.curmngname = $scope.manager[j].name;
                    break;
                }
            }
        }
        $scope.clearDepdata = function () {
            $scope.selmanager = "";
            $scope.selemployee = "";
        }
        $scope.assigndata = function () {
            if ($scope.selemployee != "") {
                for (var i = 0; i <= $scope.employees.length; i++) {
                    if ($scope.employees[i].id == $scope.selemployee) {
                        $scope.curempname = $scope.employees[i].name;
                        break;
                    }
                }
//                for (var j = 0; j <= $scope.manager.length; j++) {
//                    if ($scope.manager[j].id == $scope.selmanager) {
//                        $scope.curmngname = $scope.manager[j].name;
//                        break;
//                    }
//                }
            }
        }
        $scope.byQuarter = function (month) {
            if (month.quater == $scope.selquarter) {
                return true;
            } else {
                return false;

            }
        }
        $scope.selectQuarter = function () {
            if ($scope.selquarter == "1") {
                $scope.curselquarter = "Q1";
            } else if ($scope.selquarter == "2") {
                $scope.curselquarter = "Q2";
            }
            else if ($scope.selquarter == "3") {
                $scope.curselquarter = "Q3";
            }
            else if ($scope.selquarter == "4") {
                $scope.curselquarter = "Q4";
            } else {
                $scope.curselquarter = "";
            }
            
        }
        $scope.selectMonth = function () {
            for (var i = 0; i <= $scope.months.length; i++) {
                if ($scope.months[i].monthid == $scope.selmonth) {
                    $scope.curselmonth = $scope.months[i].name;
                    break;
                }
            }
        }
    }]);

