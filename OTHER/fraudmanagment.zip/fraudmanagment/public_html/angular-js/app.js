'use strict';
var fraudsolution = {};
var App = angular.module('fraudsolution', ['ngRoute', 'fraudsolution.directives', 'fraudsolution.services', 'ngResource']).config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
//        $routeProvider.
//                when('/rca/:viewmode', {templateUrl: '../PixelAdmin-1.3.0/html/rcaListPage.jsp', controller: "RcaController"}).
//                when('/rca/:viewmode/:rcaid', {templateUrl: '../PixelAdmin-1.3.0/html/RcaInnerHtml.jsp', controller: "RcaController"}).
//                otherwise({redirectTo: '/rca/create/0'});
    }]);

// constants

App.constant('URL_LINKS', {
    path: '/fraudmanagment/fraudmanagment'
});
App.run(function ($rootScope, $http) {
    $rootScope.notifier = function (params, callback) {
        $rootScope.error = {}
        $rootScope.error.type = params.type || "message"; //there is also a confirm type which shows Yes and No buttons
        $rootScope.error.title = params.title || "error";
        $rootScope.error.choices = params.choices || [];
        $rootScope.error.notification = params.notification || "Oops! Something went wrong!";
        $("#error-module").modal('show');

        if (params.title == "timeout") {
            $timeout(function () {
                $user.logout();
            }, 2000)
        }

        $rootScope.errorResolution = function (status, value) {
            $("#error-module").modal('hide');
            callback(status, value);
        }
    }

});