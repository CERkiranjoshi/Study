
App.controller('accountManagment', ['$scope', '$http', '$resource', function ($scope, $http, $resource) {

        $scope.simpleStringify = function (object) {
            var simpleObject = {};
            for (var prop in object) {
                if (!object.hasOwnProperty(prop)) {
                    continue;
                }
                if (typeof (object[prop]) == 'object') {
                    continue;
                }
                if (typeof (object[prop]) == 'function') {
                    continue;
                }
                simpleObject[prop] = object[prop];
            }
            var cleanedJson = JSON.stringify(simpleObject);
            return cleanedJson;
        }





        $scope.createAutoClosingAlert = function (selector, delay) {
            $(".alert-success").css("display", "none");
            $(selector).css("display", "block");
            window.setTimeout(function () {
                $(selector).css("display", "none");
            }, delay);
        }
        $scope.addUpdateBlockAccounts = function () {
            if ($scope.addnew == true) {
                $scope.addBlockAccounts();
            } else {
                $scope.updateBlockAccounts();
            }
        }
        $scope.addBlockAccounts = function () {
            $("#myModal").modal('hide');
            $scope.blockaccounts.push($scope.blockaccount);
            $scope.setDefaultDetails();
            console.log($scope.blockaccounts);
            $scope.createAutoClosingAlert("#alertadd", 5000);
            //$scope.saveToPc(angular.toJson($scope.blockaccounts));
            $scope.addToLocalStorage('blockaccounts', $scope.blockaccounts);
            //$scope.adddata();
        }
        $scope.updateBlockAccounts = function () {
            $("#myModal").modal('hide');
            $scope.setDefaultDetails();
            $scope.createAutoClosingAlert("#alertupdate", 5000);
            $scope.addToLocalStorage('blockaccounts', $scope.blockaccounts);
        }
        $scope.addToLocalStorage = function (param, value) {
            localStorage.setItem(param, angular.toJson(value));
//            localStorage.setItem('blockaccounts', angular.toJson($scope.blockaccounts));
        }
        $scope.adddata = function () {
            $http.post("http://156.150.119.56:10080/mwpusdclient/rest/writeJsonDataIntoFile", $scope.blockaccounts).success(function (data) {
                console.log(data);
            });
        }
        $scope.saveToFile = function () {
            var blob = new Blob([angular.toJson($scope.blockaccounts)], {
                type: "application/json;charset=utf-8;"
            });
            console.log(window.URL.createObjectURL(blob));
        }

        $scope.saveToPc = function (data, filename) {

            if (!data) {
                console.error('No data');
                return;
            }

            if (!filename) {
                filename = 'download.json';
            }

            if (typeof data === 'object') {
                data = JSON.stringify(data, undefined, 2);
            }

            var blob = new Blob([data], {type: 'text/json'}),
                    e = document.createEvent('MouseEvents'),
                    a = document.createElement('a');

            a.download = filename;
            a.href = window.URL.createObjectURL(blob);
            a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
            e.initMouseEvent('click', true, false, window,
                    0, 0, 0, 0, 0, false, false, false, false, 0, null);
            a.dispatchEvent(e);
        };
        $scope.addUpdateTransections = function () {
            if ($scope.addnewtran == true) {
                $("#addTransection").modal('hide');
                $scope.transections.push($scope.transection);
                $scope.setDefaultTransection();
                console.log($scope.transections);
                $scope.createAutoClosingAlert("#alertadd", 5000);
                //$scope.saveToPc(angular.toJson($scope.blockaccounts));
                $scope.addToLocalStorage('transections', $scope.transections);
            }
        }
        $scope.deleteTransection = function (tran) {
            $scope.notifier({title: "warning", notification: "Are you sure you want to delete this Transection from this list ?", type: "confirm"}, function (resolve) {
                if (resolve) {
                    $scope.transections.splice($scope.transections.indexOf(tran), 1);
                    $scope.createAutoClosingAlert("#alertdelete", 5000);
                    $scope.addToLocalStorage('transections', $scope.transections);
                }else{
                    
                }
            });

        }
        $scope.editBlockAccount = function (act) {
            $scope.addnew = false;
            $scope.blockaccount = act;
            $("#myModal").modal('show');
        }
        $scope.deleteBlockAccount = function (act) {
            $scope.notifier({title: "warning", notification: "Are you sure you want to delete this Block Account?", type: "confirm"}, function (resolve) {
                if (resolve) {
                    $scope.blockaccounts.splice($scope.blockaccounts.indexOf(act), 1);
                    $scope.createAutoClosingAlert("#alertdelete", 5000);
                    $scope.addToLocalStorage('blockaccounts', $scope.blockaccounts);
                }
            });

        }
        $scope.setDefaultDetails = function () {
            $scope.addnew = true;
            $scope.blockaccount = {
                id: $scope.blockaccounts.length + 1,
                blockby: "Select Block By",
                bank: "Select bank",
                added: $scope.getTodayDate(),
                blockvalue: ""
            };
        }
        $scope.setTabs = function (tab) {
            $scope.tab = tab;
            if ($scope.tab == 1) {
                $scope.blockaccounts = [];
                //  var today = new Date().toJSON().slice(0, 10);
                $scope.setDefaultDetails();
                var blockaccounts = localStorage.getItem('blockaccounts');
                if (blockaccounts != null) {
                    $scope.blockaccounts = JSON.parse(blockaccounts);
                }
            }
            if ($scope.tab == 2) {
                $scope.transections = [];
                $scope.setDefaultTransection();
                var transections = localStorage.getItem('transections');
                if (transections != null) {
                    $scope.transections = JSON.parse(transections);
                }
            }
        }
        $scope.init = function () {
           $scope.setTabs(2);
        };
        $scope.setDefaultTransection = function () {

            $scope.addnewtran = true;
            var today = new Date().toJSON().slice(0, 10);
            $scope.transection = {
                id: $scope.transections.length + 1,
                paymentmode: "Select Payment mode",
                paymenttype: "one Time",
                cardHolderName: "",
                cardNumber: "",
                fromcardNumber: "Primary Account",
                date: today,
                latitude: "",
                longitude: "",
                amount: "",
                remarks: ""
            };
        }
        $scope.validatedata = function () {
            console.log('dfdsfds');
        }
        $scope.tempdata = function () {
            var url = "http://dev.virtualearth.net/REST/v1/Traffic/Incidents/37,-105,45,-94?key=AtowRpizFA-25w_mt6plfgSa9RzAIQJ4-OUOtvMML3hyfN8SDJlMe2DLHhVt49Ou";
//            var url = "http://dev.virtualearth.net/REST/v1/Traffic/Incidents/37,-105,45,-94?key=AtowRpizFA-25w_mt6plfgSa9RzAIQJ4-OUOtvMML3hyfN8SDJlMe2DLHhVt49Ou" + "?callback=JSON_CALLBACK";
            var op = $resource(url, {format: 'json', jsoncallback: 'JSON_CALLBACK'}, {'load': {'method': 'JSONP'}});
            console.log(op);
//            $http.get(url)
//                    .success(function (data) {
//                        console.log(data)
////                        $scope.realTimeData = data;
//                    });
//            $http.get()
//                    .success(function (response) {
//                        console.log(response);
//                    });

//            $http.jsonp("//dev.virtualearth.net/REST/v1/Traffic/Incidents/37,-105,45,-94?key=AtowRpizFA-25w_mt6plfgSa9RzAIQJ4-OUOtvMML3hyfN8SDJlMe2DLHhVt49Ou")
//                    .success(function (data) {
//                        console.log(data);
//                    });
        }
        $scope.getTodayDate = function () {
            var objToday = new Date(),
                    weekday = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
                    dayOfWeek = weekday[objToday.getDay()],
                    domEnder = new Array('th', 'st', 'nd', 'rd', 'th', 'th', 'th', 'th', 'th', 'th'),
                    dayOfMonth = today + (objToday.getDate() < 10) ? '0' + objToday.getDate() + domEnder[objToday.getDate()] : objToday.getDate() + domEnder[parseFloat(("" + objToday.getDate()).substr(("" + objToday.getDate()).length - 1))],
                    months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'),
                    curMonth = months[objToday.getMonth()],
                    curYear = objToday.getFullYear(),
                    curHour = objToday.getHours() > 12 ? objToday.getHours() - 12 : (objToday.getHours() < 10 ? "0" + objToday.getHours() : objToday.getHours()),
                    curMinute = objToday.getMinutes() < 10 ? "0" + objToday.getMinutes() : objToday.getMinutes(),
                    curSeconds = objToday.getSeconds() < 10 ? "0" + objToday.getSeconds() : objToday.getSeconds(),
                    curMeridiem = objToday.getHours() > 12 ? "PM" : "AM";
//            var today = curHour + ":" + curMinute + "." + curSeconds + curMeridiem + " " + dayOfWeek + " " + dayOfMonth + " of " + curMonth + ", " + curYear;
            var today = dayOfWeek + " " + dayOfMonth + " of " + curMonth + ", " + curYear + " at " + curHour + ":" + curMinute + " " + curMeridiem;
            return today;
        }
        $scope.init();
    }]);