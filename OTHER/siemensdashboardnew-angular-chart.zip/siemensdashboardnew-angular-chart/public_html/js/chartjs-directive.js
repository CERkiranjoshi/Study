'use strict';

angular.module('chartjs-directive', []).
        directive('chart', function () {
            var baseWidth = 350;
            var baseHeight = 200;

            return {
                restrict: 'E',
                template: '<canvas chart-options="options"></canvas>',
                scope: {
                    chartObject: "=value"
                },
                link: function (scope, element, attrs) {
                    var canvas = element.find('canvas')[0],
                            context = canvas.getContext('2d'),
                            chart;

                    var options = {
                        type: attrs.type || "Line",
                        width: attrs.width || baseWidth,
                        height: attrs.height || baseHeight,
                        datasetStroke: true,
                        datasetStrokeWidth: 2,
                        datasetFill: true,
                        legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].strokeColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>"
                    };
                    canvas.width = options.width;
                    canvas.height = options.height;
                    chart = new Chart(context);
                    scope.chartObject.options = options;
                    scope.$watch(function () {
                        return element.attr('type');
                    }, function (value) {
                        if (!value)
                            return;
                        options.type = value;
                        var chartType = options.type;
                        chart[chartType](scope.chartObject.data, scope.chartObject.options);
                    });

                    //Update when charts data changes
                    scope.$watch(function () {
                        return scope.chartObject;
                    }, function (value) {
                        if (!value)
                            return;
                        var chartType = options.type;
                        console.log(scope.chartObject)
//                        console.log()
                        chart[chartType](scope.chartObject.data, scope.chartObject.options);
                    });
                }
            }
        });
