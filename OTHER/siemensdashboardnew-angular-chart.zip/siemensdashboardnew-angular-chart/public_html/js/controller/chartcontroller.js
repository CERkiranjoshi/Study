var myApp = angular.module('demochart', ['chartjs-directive']).config(['$httpProvider', function ($httpProvider) {
    }]);
myApp.controller('chartcontroller', ['$scope', '$http', function ($scope, $http) {
        $scope.sample = 'Sample';
//        $http.get("data/managerdata.json")
//                .success(function (response) {
//                    $scope.manager = response;
//                });
        $scope.manager = [
            {
                "id": "1",
                "depid": "1",
                "name": "Pueshotam Purshvam",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "2",
                "depid": "1",
                "name": "Madhuran D'silva",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "3",
                "depid": "2",
                "name": "sandip gawda",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "4",
                "name": "Xyz",
                "depid": "2",
                "department": [
                    {
                        "name": "IT",
                        "depid": "1"
                    },
                    {
                        "name": "Networking",
                        "depid": "2"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            }
        ];
//        $http.get("data/employeedata.json")
//                .success(function (response) {
//                    $scope.employees = response;
//                });
        $scope.employees = [
            {
                "id": "1",
                "name": "kiran",
                "mangerid": "1",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "2",
                "name": "haris",
                "mangerid": "1",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "3",
                "name": "ABC",
                "mangerid": "2",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "4",
                "name": "DEF",
                "mangerid": "2",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "5",
                "name": "GHI",
                "mangerid": "3",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            },
            {
                "id": "6",
                "name": "JKL",
                "mangerid": "3",
                "department": [
                    {
                        "name": "IT"
                    },
                    {
                        "name": "Networking"
                    }
                ],
                "details": {
                    "address": "vikhoroli west",
                    "dob": "13-05-1970"
                }
            }
        ];
//        $http.get("data/months.json")
//                .success(function (response) {
//                    $scope.months = response;
//                });
        $scope.months = [
            {
                "monthid": "1",
                "quater": "1",
                "name": "January"
            },
            {
                "monthid": "2",
                "quater": "1",
                "name": "February"
            },
            {
                "monthid": "3",
                "quater": "1",
                "name": "March"
            },
            {
                "monthid": "4",
                "quater": "2",
                "name": "April"
            },
            {
                "monthid": "5",
                "quater": "2",
                "name": "May"
            },
            {
                "monthid": "6",
                "quater": "2",
                "name": "June"
            },
            {
                "monthid": "7",
                "quater": "3",
                "name": "July"
            },
            {
                "monthid": "8",
                "quater": "3",
                "name": "August"
            },
            {
                "monthid": "9",
                "quater": "3",
                "name": "September"
            },
            {
                "monthid": "10",
                "quater": "4",
                "name": "October"
            },
            {
                "monthid": "11",
                "quater": "4",
                "name": "November"
            },
            {
                "monthid": "12",
                "quater": "4",
                "name": "December"
            }
        ];

        //----------------------------------change Below Part Only-------------------------------------------------------//
        $scope.partial =
                {
                    violation: "violation.html",
                    recorder: "recorder.html"
                };
        $scope.generatePieData = function (id, type) {
            document.getElementById(id).setAttribute('type', type);
            var data = [
                {
                    value: Math.floor((Math.random() * 100) + 1),
                    color: "#F38630",
                    highlight: "#BF792F",
                    label: "Yellow"
                },
                {
                    value: Math.floor((Math.random() * 100) + 1),
                    color: "#E0E4CC",
                    highlight: "#F1F8E0",
                    label: "Cream"
                },
                {
                    value: Math.floor((Math.random() * 100) + 1),
                    color: "#69D2E7",
                    label: "Blue",
                    highlight: "#2EFEF7",
                }
            ]
            $scope[id] = {"data": data, "options": {}};
        };
        $scope.renderdata = function (type) {
            var sevenRandNumbers = function () {
                var numberArray = [];
                for (var i = 0; i < 7; i++) {
                    numberArray.push(Math.floor((Math.random() * 100) + 1));
                }
                return numberArray;
            };
            var data = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {label: 'My First dataset',
                        fillColor: 'rgba(220,220,220,0.2)',
                        strokeColor: 'rgba(220,220,220,1)',
                        pointColor: 'rgba(220,220,220,1)',
                        pointStrokeColor: '#fff',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(220,220,220,1)',
                        data: sevenRandNumbers()
                    },
                    {
                        label: 'My Second dataset',
                        fillColor: 'rgba(151,187,205,0.2)',
                        strokeColor: 'rgba(151,187,205,1)',
                        pointColor: 'rgba(151,187,205,1)',
                        pointStrokeColor: '#fff',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(151,187,205,1)',
                        data: sevenRandNumbers()
                    }
                ]
            };
            $scope[type] = {"data": data, "options": {}};
        }
        $scope.generateGraph = function () {
            $scope.renderdata('myChart');
            document.getElementById('mybar').setAttribute('type', 'Bar');
            $scope.renderdata('mybar');
            document.getElementById('myRadar').setAttribute('type', 'Radar');
            $scope.renderdata('myRadar');
            $scope.generatePieData('myDoughnut', 'Doughnut');
            $scope.generatePieData('myPolarArea', 'PolarArea');
            $scope.generatePieData('myPieChart', 'Pie');
            //            $scope.generatePieData('');
//            $scope.generatePieData('');
        };

        $scope.setTabs = function (tab) {
            $scope.tab = tab;
//            setTimeout(function () {
            $scope.generateGraph();
//            }, 500);

        }
        $scope.setTabs(1);
        $scope.seldep = "";
        $scope.selmanager = "";
        $scope.selemployee = "";
        $scope.curempname = "";
        $scope.curmngname = "";
        $scope.curselyear = "";
        $scope.byManager = function (emp) {
            if (emp.mangerid == $scope.selmanager && $scope.seldep != "") {
                return true;
            } else {
                return false;
            }
        }
        $scope.resetData = function (param) {
            $scope[param] = "";
            if (param == 'curselyear') {
                $scope.selyear = "";
            } else if (param == 'curselquarter') {
                $scope.selquarter = "";
                $scope.selmonth = "";
                $scope.curselmonth = "";
            } else if (param == 'curselmonth') {
                $scope.selmonth = "";
            } else if (param == 'curempname') {
                $scope.selemployee = "";
            } else if (param == 'curmngname') {
                $scope.selmanager = "";
                $scope.curempname = "";
                $scope.selemployee = "";
            }
        }
        $scope.byDepartment = function (manager) {
//            console.log(manager)
            if (manager.depid == $scope.seldep && $scope.seldep != "") {
                return true;
            } else {
                return false;
            }
        }
        $scope.clearManagedata = function () {
            $scope.selemployee = "";
            for (var j = 0; j <= $scope.manager.length; j++) {
                if ($scope.manager[j].id == $scope.selmanager) {
                    $scope.curmngname = $scope.manager[j].name;
                    break;
                }
            }
        }
        $scope.clearDepdata = function () {
            $scope.selmanager = "";
            $scope.selemployee = "";
        }
        $scope.assigndata = function () {
            if ($scope.selemployee != "") {
                for (var i = 0; i <= $scope.employees.length; i++) {
                    if ($scope.employees[i].id == $scope.selemployee) {
                        $scope.curempname = $scope.employees[i].name;
                        break;
                    }
                }
//                for (var j = 0; j <= $scope.manager.length; j++) {
//                    if ($scope.manager[j].id == $scope.selmanager) {
//                        $scope.curmngname = $scope.manager[j].name;
//                        break;
//                    }
//                }
            }
        }
        $scope.byQuarter = function (month) {
            if (month.quater == $scope.selquarter) {
                return true;
            } else {
                return false;

            }
        }
        $scope.selectQuarter = function () {
            if ($scope.selquarter == "1") {
                $scope.curselquarter = "Q1";
            } else if ($scope.selquarter == "2") {
                $scope.curselquarter = "Q2";
            }
            else if ($scope.selquarter == "3") {
                $scope.curselquarter = "Q3";
            }
            else if ($scope.selquarter == "4") {
                $scope.curselquarter = "Q4";
            } else {
                $scope.curselquarter = "";
            }
        }
        $scope.selectMonth = function () {
            for (var i = 0; i <= $scope.months.length; i++) {
                if ($scope.months[i].monthid == $scope.selmonth) {
                    $scope.curselmonth = $scope.months[i].name;
                    break;
                }
            }
        }





    }]);

