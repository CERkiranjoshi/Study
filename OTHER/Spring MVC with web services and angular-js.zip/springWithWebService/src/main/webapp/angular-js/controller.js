App.controller('Booklet', ['$scope', '$http', function ($scope, $http) {
        $scope.init = function () {
            $scope.getData();
        };
        $scope.getData = function () {
            $http.get(contextPath + "/rest/getBookDetails").success(function (data) {
                $scope.bookletListing = data;
            });
        };
        $scope.init();
    }]);
