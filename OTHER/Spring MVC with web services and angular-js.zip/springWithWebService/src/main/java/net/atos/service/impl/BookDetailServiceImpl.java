package net.atos.service.impl;

import java.util.List;

import net.atos.dao.BookDetailDao;
import net.atos.model.BookDetail;
import net.atos.service.BookDetailService;

import org.springframework.stereotype.Service;

@Service
public class BookDetailServiceImpl implements BookDetailService {

	private BookDetailDao bookDetailDao;

	public BookDetailDao getBookDetailDao() {
		return bookDetailDao;
	}

	public void setBookDetailDao(BookDetailDao bookDetailDao) {
		this.bookDetailDao = bookDetailDao;
	}

	public List<BookDetail> showAllBooks() {
		// TODO Auto-generated method stub
		return bookDetailDao.findAll();
	}

}
