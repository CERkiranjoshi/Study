package net.atos.service;

import java.util.List;

import net.atos.model.BookDetail;

public interface BookDetailService {
	public List<BookDetail> showAllBooks();
}
