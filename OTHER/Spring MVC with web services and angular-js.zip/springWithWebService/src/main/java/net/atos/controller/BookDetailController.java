package net.atos.controller;

import java.util.ArrayList;
import java.util.List;

import net.atos.model.BookDetail;
import net.atos.service.BookDetailService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookDetailController {

private BookDetailService bookDetailService;

	

	public BookDetailService getBookDetailService() {
		return bookDetailService;
	}



	public void setBookDetailService(BookDetailService bookDetailService) {
		this.bookDetailService = bookDetailService;
	}
	
	@RequestMapping(value = "/getBookDetails", method = RequestMethod.GET,produces="application/json")
	public @ResponseBody List<BookDetail> getBookDetails()
			{
				List<BookDetail> bookList = null;
						try{
							bookList=bookDetailService.showAllBooks();
						}catch(Exception e)
						{
							e.printStackTrace();
							bookList=new ArrayList<BookDetail>();
						}
						return bookList;
						
			}
	
	@RequestMapping(value = "/showBookListPage", method = RequestMethod.GET)
	public String showBookPage(ModelAndView mv) {
		List<BookDetail> bookList = null;
		
		return "index";

	}
	
	
}
