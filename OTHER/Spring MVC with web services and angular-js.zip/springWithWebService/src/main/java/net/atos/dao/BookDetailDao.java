package net.atos.dao;

import java.util.List;

import net.atos.model.BookDetail;

public interface BookDetailDao {

	List<BookDetail> findAll();
}
