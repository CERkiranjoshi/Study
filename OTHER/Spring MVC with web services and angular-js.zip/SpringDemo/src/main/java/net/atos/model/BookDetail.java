package net.atos.model;

public class BookDetail {

	  private int bookid;
	    private int categoryId;
	    private String title;
	    private String author;
	    private String publisher;
	    private String edition;
	    private double price;
	    private String quantity;
	    private String description;

	    public int getBookid() {
	        return bookid;
	    }

	    public void setBookid(int bookid) {
	        this.bookid = bookid;
	    }

	    public int getCategoryId() {
	        return categoryId;
	    }

	    public void setCategoryId(int categoryId) {
	        this.categoryId = categoryId;
	    }

	    public String getTitle() {
	        return title;
	    }

	    public void setTitle(String title) {
	        this.title = title;
	    }

	    public String getAuthor() {
	        return author;
	    }

	    public void setAuthor(String author) {
	        this.author = author;
	    }

	    public String getPublisher() {
	        return publisher;
	    }

	    public void setPublisher(String publisher) {
	        this.publisher = publisher;
	    }

	    public String getEdition() {
	        return edition;
	    }

	    public void setEdition(String edition) {
	        this.edition = edition;
	    }

	    public double getPrice() {
	        return price;
	    }

	    public void setPrice(double price) {
	        this.price = price;
	    }

	    public String getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(String quantity) {
	        this.quantity = quantity;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	
}
