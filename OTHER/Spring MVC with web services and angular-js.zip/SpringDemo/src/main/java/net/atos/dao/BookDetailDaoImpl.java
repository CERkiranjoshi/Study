package net.atos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import net.atos.model.BookDetail;

public class BookDetailDaoImpl implements BookDetailDao {

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<BookDetail> findAll() {
		String query = "select * from book_details";
		List<BookDetail> bookList = new ArrayList<BookDetail>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = dataSource.getConnection();
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {

				BookDetail book = new BookDetail();
				book.setBookid(rs.getInt("bookId"));
				book.setCategoryId(rs.getInt("categoryId"));
				book.setAuthor(rs.getString("author").trim());
				book.setEdition(rs.getString("edition").trim());
				book.setPrice(rs.getDouble("price"));
				book.setDescription(rs.getString("description").trim());
				book.setPublisher(rs.getString("publisher").trim());
				book.setQuantity(rs.getString("quantity").trim());
				book.setTitle(rs.getString("title").trim());

				bookList.add(book);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bookList;
		
	}

}
