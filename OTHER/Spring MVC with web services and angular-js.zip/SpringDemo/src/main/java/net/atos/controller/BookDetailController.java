package net.atos.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.atos.model.BookDetail;
import net.atos.service.BookDetailService;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class BookDetailController implements Controller {
	private BookDetailService bookDetailService;

	

	public BookDetailService getBookDetailService() {
		return bookDetailService;
	}



	public void setBookDetailService(BookDetailService bookDetailService) {
		this.bookDetailService = bookDetailService;
	}



	public ModelAndView handleRequest(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		ModelAndView modelAndView = new ModelAndView("index");
		List<BookDetail> bookList = bookDetailService.showAllBooks();
		modelAndView.addObject("booklist", bookList);

		return modelAndView;
	}

}
