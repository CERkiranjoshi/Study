package net.atos.service;

import java.util.List;

import net.atos.dao.BookDetailDao;
import net.atos.model.BookDetail;

public class BookDetailServiceImpl implements BookDetailService {

	private BookDetailDao bookDetailDao;

	

	public BookDetailDao getBookDetailDao() {
		return bookDetailDao;
	}



	public void setBookDetailDao(BookDetailDao bookDetailDao) {
		this.bookDetailDao = bookDetailDao;
	}



	public List<BookDetail> showAllBooks() {

		return bookDetailDao.findAll();
	}

}
