'use strict';

/* Controllers */
google.charts.load('current', {packages: ['corechart']});
google.charts.setOnLoadCallback(function () {
    angular.bootstrap(document.body, ['hul']);
});

// declare modules
angular.module('Authentication', []);

var myApp = angular.module('hul', ['am.multiselect', 'ngRoute', 'Authentication', 'ngCookies', 'myApp.directives', 'myApp.filters']).config(['$routeProvider', '$httpProvider', function ($routeProvider, $httpProvider) {
        $routeProvider.
                when('/login', {templateUrl: 'html/login.html'}).
                when('/index/:trendType', {templateUrl: 'html/index.html', controller: "charts"}).
                otherwise({redirectTo: '/login'});
    }]);

myApp.constant('HUL_CONST', {//#FF0000,#FFFF33,#FFC200,#66CC00. Note Don't chnage the Id , it;s unique which used in graph ordering
    path: '/index',
    totalcompcolor: ["Green", '#66CC00'],
    colors: ['Amber', 'Green', 'Red', 'Yellow'],
    colorsarr: ['#FFC200', '#66CC00', '#FF0000', '#FFFF33']
});


myApp.run(['$rootScope', '$location', '$cookieStore', '$http',
    function ($rootScope, $location, $cookieStore, $http) {
        $rootScope.isUserLoggedIn = false;
        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};

        if ($rootScope.globals.currentUser) {
            $rootScope.isUserLoggedIn = true;
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in
            if ($location.path() !== '/login' && !$rootScope.globals.currentUser) {
                $location.path('/login');
            }
        });

        $rootScope.appendToArray = function (obj, arr) {
            if (arr.indexOf(obj) == -1) {
                arr.push(obj);
            }
        }
        $rootScope.prependToArray = function (obj, arr) {
            if (arr.indexOf(obj) == -1) {
                arr.unshift(obj);
            }
        }
        $rootScope.removeFromArray = function (obj, arr) {
            arr.splice(arr.indexOf(obj), 1);
        }
        $rootScope.openModal = function () {
            document.getElementById('modal').style.display = 'block';
            document.getElementById('fade').style.display = 'block';
            $('html, body').css({//html, body
                'overflow': 'hidden',
                'height': '100%'
            });
        }
        $rootScope.closeModal = function () {
            document.getElementById('modal').style.display = 'none';
            document.getElementById('fade').style.display = 'none';
            $('html, body').css({//html, body
                'overflow': 'auto',
                'height': 'auto'
            });
            $('html, body').css({//html, body
                'overflow-x': 'hidden'
            });
        }
        $rootScope.capitalizeFirstLetter = function (string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

        $rootScope.getFormatedDate = function (seldate) {
            if (seldate == undefined) {
                seldate = new Date();
            }
            var dd = seldate.getDate();
            var mm = seldate.getMonth() + 1; //January is 0!

            var yyyy = seldate.getFullYear();
            if (dd < 10) {
                dd = '0' + dd;
            }
            if (mm < 10) {
                mm = '0' + mm;
            }
            var actdate = dd + '-' + mm + '-' + yyyy;
            return actdate;
        };
        $rootScope.getActDate = function (date) {
            var data = date.split("-");
            var dd = data[0];
            var mm = data[1] - 1;
            var yyyy = data[2];
            var actdate = new Date(yyyy, mm, dd, 0, 0, 0);
            return actdate;
        };
    }]);

