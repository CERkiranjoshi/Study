'use strict';

/* Filters */

var AppFilters = angular.module('myApp.filters', []);


AppFilters.filter('ByDeviceColdChain', function () {
    return function (data, coldchain) {
        var filterd = [];
        for (var i = 0; i < data.length; i++) {
            var value = data[i];
            if (value.branchType == coldchain) {
                filterd.push(value);
            }
        }
        return filterd;
    }
});