
myApp.controller('loginCtrl', ['$scope', '$http', 'HUL_CONST', '$timeout', '$rootScope', '$location', 'AuthenticationService', function ($scope, $http, HUL_CONST, $timeout, $rootScope, $location, AuthenticationService) {
        $scope.loginError = '';
        $scope.submitLogin = function () {
            AuthenticationService.ClearCredentials();
            $scope.status = "";
            $scope.selectedValues = {
                "emailId": $scope.hul_emailId,
                "password": $scope.hul_pwd
            };
//			AuthenticationService.Login($scope.selectedValues, function(response) {
            if (true) {
                AuthenticationService.SetCredentials($scope.username, $scope.password);
                $rootScope.isUserLoggedIn = true;
                $location.path('/index/regional');
            } else {
                $scope.error = true;
                $scope.loginError = "EmailId and Password doesnot match";
                $scope.hul_emailId = '';
                $scope.hul_pwd = '';
            }
//            });
        }

        $scope.logout = function () {
//            $http.post(tempContextPath + "/logoutSession").success(function () {
//            });
            AuthenticationService.ClearCredentials();
            $rootScope.isUserLoggedIn = false;
            $location.path('/login');
        };



    }]);
	