SiemensGoogleChart.controller('SiemensGoogleChartDemo', ['$scope', '$http', '$timeout', function ($scope, $http, $timeout) {
        $scope.locations = [
            {
                "locid": "1",
                "name": "Mumbai-Worli Office"
            }, {
                "locid": "2",
                "name": "Gurgaon-Jagjit Ind.Ltd"
            }, {
                "locid": "3",
                "name": "Ahmedabad-Prerna Arbor Bd"
            }, {
                "locid": "4",
                "name": "Aurangabad-AW-Gas Insu SGR"
            }, {
                "locid": "5",
                "name": "Thane PTD Transformers"
            }, {
                "locid": "6",
                "name": "Ernakulam-Cochin-OxfordBC"
            }, {
                "locid": "7",
                "name": "Indore"
            }, {
                "locid": "8",
                "name": "Lucknow-Ashok Marg"
            }, {
                "locid": "9",
                "name": "Vadodara-HDX Factory"
            }, {
                "locid": "10",
                "name": "Goa"
            }
        ];
        $scope.divisions = [
            {
                "divid": "1",
                "name": "Mobility Management"
            }, {
                "divid": "2",
                "name": "Mainline Transport"
            }, {
                "divid": "3",
                "name": "Power Transmission"
            }, {
                "divid": "4",
                "name": "Automation"
            }, {
                "divid": "5",
                "name": "Large Drives"
            }, {
                "divid": "6",
                "name": "Customer Sevices"
            }, {
                "divid": "7",
                "name": "Solution & Service"
            }, {
                "divid": "8",
                "name": "Energy Managment"
            }, {
                "divid": "9",
                "name": "Accounting and Controlling"
            }, {
                "divid": "10",
                "name": "Corporate"

            }];
        $scope.departments = [
            {
                "depid": "1",
                "name": "CG"
            }, {
                "depid": "2",
                "name": "EM HP"
            }, {
                "depid": "3",
                "name": "EM"
            }, {
                "depid": "4",
                "name": "HR"
            }, {
                "depid": "5",
                "name": "MO MM"
            }, {
                "depid": "6",
                "name": "MO MLT"
            }, {
                "depid": "7",
                "name": "PD LD"
            }, {
                "depid": "8",
                "name": "BT SSP"
            }, {
                "depid": "9",
                "name": "AD-AW-C"
            }, {
                "depid": "10",
                "name": "DT-MCPM"
            }];
        $scope.employees = [
            {
                "id": "1",
                "name": "kiran"
            },
            {
                "id": "2",
                "name": "haris"
            },
            {
                "id": "3",
                "name": "Vimal"
            },
            {
                "id": "4",
                "name": "Mihir"
            },
            {
                "id": "5",
                "name": "Anil"
            },
            {
                "id": "6",
                "name": "Nikesh"
            }, {
                "id": "7",
                "name": "Ajinkya"
            },
            {
                "id": "8",
                "name": "Kunal"
            }, {
                "id": "9",
                "name": "Rajgopal"
            },
            {
                "id": "10",
                "name": "Vatsal"
            }
        ];
        $scope.months = [
            {
                "monthid": "1",
                "quater": "1",
                "name": "January"
            },
            {
                "monthid": "2",
                "quater": "1",
                "name": "February"
            },
            {
                "monthid": "3",
                "quater": "1",
                "name": "March"
            },
            {
                "monthid": "4",
                "quater": "2",
                "name": "April"
            },
            {
                "monthid": "5",
                "quater": "2",
                "name": "May"
            },
            {
                "monthid": "6",
                "quater": "2",
                "name": "June"
            },
            {
                "monthid": "7",
                "quater": "3",
                "name": "July"
            },
            {
                "monthid": "8",
                "quater": "3",
                "name": "August"
            },
            {
                "monthid": "9",
                "quater": "3",
                "name": "September"
            },
            {
                "monthid": "10",
                "quater": "4",
                "name": "October"
            },
            {
                "monthid": "11",
                "quater": "4",
                "name": "November"
            },
            {
                "monthid": "12",
                "quater": "4",
                "name": "December"
            }
        ];
        $scope.colors = ["#03C9A9", "#2BA78D", "#BB2412", "#E82D2D", "#FF5454", "#F69191", "#3A539B", "#4B77BE", "#52B3D9", "#4DD9A9"];
        //----------------------------------change Below Part Only-------------------------------------------------------//
        $scope.updategraph = function () {
            $scope.graphData();
        }
        $scope.generatePiechart = function (selector) {
            var data = google.visualization.arrayToDataTable([
                ['Task', 'Mobile App IT Broadcast Per Month'],
                ['Ops & IT Desk', 158],
                ['Org Announcement', 98],
                ['CIO Desk', 85],
                ['My Department Desk', 30],
                ['Other', 39]
            ]);
            var options4 = angular.copy($scope.googlecharts);
            var chart = new google.visualization.PieChart(document.getElementById(selector));
            chart.draw(data, options4);
        };
        $scope.generateBarchart2 = function (selector) {
            var data = google.visualization.arrayToDataTable([
                ["", "Percentage % ", {role: "style"}],
                ["Yes", 27, $scope.colors[0]],
                ["No", 73, $scope.colors[1]]
            ]);

            var view = new google.visualization.DataView(data);
            view.setColumns([0, 1,
                {calc: "stringify",
                    sourceColumn: 1,
                    type: "string",
                    role: "annotation"},
                2]);
            var options5 = {
                title: "Are you aware of IT camp schedule?",
                width: 400,
                height: 256,
//                "isStacked": "percent",
                bar: {groupWidth: "75%"},
                legend: {position: "none"},
                hAxis: {
                    title: 'Answer in Percentage %',
                    "textStyle": {
                        "color": "black",
                        "bold": true
                    }
                }};
            var chart = new google.visualization.BarChart(document.getElementById(selector));
            chart.draw(view, options5);
        }
        $scope.generateBarchart1 = function (selector) {
            var data = google.visualization.arrayToDataTable([
                ["", "Percentage % ", {role: "style"}],
                ["Yes", 75, $scope.colors[0]],
                ["No", 25, $scope.colors[1]]
            ]);

            var view = new google.visualization.DataView(data);
            view.setColumns([0, 1,
                {calc: "stringify",
                    sourceColumn: 1,
                    type: "string",
                    role: "annotation"},
                2]);
            var options5 = {
                title: "Do you like the new look of self service portal?",
                width: 400,
                height: 256,
//                "isStacked": "percent",
                bar: {groupWidth: "75%"},
                legend: {position: "none"},
                hAxis: {
                    title: 'Answer in Percentage %',
                    "textStyle": {
                        "color": "black",
                        "bold": true
                    }
                }};
            var chart = new google.visualization.BarChart(document.getElementById(selector));
            chart.draw(view, options5);
        }
        $scope.generatePiechartOptIn = function (selector) {
            var data = google.visualization.arrayToDataTable([
                ['User : Sandeep', 'Opt In Subscription'],
                ['Ops & IT Desk', 26],
                ['Org Announcement', 57],
                ['CIO Desk', 22],
                ['My Department Desk', 16],
                ['Other', 27]
            ]);
            var options1 = angular.copy($scope.googlecharts);
            options1.title = "BTIC Lead Consultant : Sandeep : Opt In Subscription";
            var chart1 = new google.visualization.PieChart(document.getElementById(selector));
            chart1.draw(data, options1);
        };
        $scope.generateBarchart = function (selector) {//410
            var data = google.visualization.arrayToDataTable([
                ['Region', 'Message Sent', 'Message Delivered', 'Message Read'],
                ['EAST', 130, 112, 109],
                ['WEST', 37, 33, 23],
                ['NORTH', 156, 145, 136],
                ['SOUTH', 87, 56, 51]
            ]);
            var options3 = angular.copy($scope.googlecharts);
//            options3.colors = ["#0000ff", "#FFC200", "#008000"];//  ffff00
//            var options = {
//                chart: {
//                    title: 'Company Performance',
//                    subtitle: 'Sales, Expenses, and Profit: 2014-2017',
//                },
//                bars: 'horizontal', // Required for Material Bar Charts.
//                hAxis: {format: 'decimal'},
//                height: 400,
//                colors: ['#1b9e77', '#d95f02', '#7570b3']
//            };
            var chart = new google.charts.Bar(document.getElementById(selector));
            chart.draw(data, options3);
        }
        $scope.generateLinechart = function (selector) {
            var data = google.visualization.arrayToDataTable([
                ['Month', 'Ops & IT Desk', 'Org Announcement', 'CIO Desk', 'My Department Desk', 'Other'],
                ['September', 43, 30, 15, 12, 7],
                ['October', 37, 25, 11, 10, 8],
                ['November', 47, 23, 18, 11, 9],
                ['December', 40, 20, 17, 18, 5],
                ['January', 47, 26, 12, 18, 6]
            ]);
//            var options = {
//                title: 'Company Performance',
//                curveType: 'function',
//                legend: {position: 'bottom'}
//            };
            $scope.googlecharts.curveType = 'function';
            var options2 = angular.copy($scope.googlecharts);
            var chart = new google.visualization.LineChart(document.getElementById(selector));
            chart.draw(data, options2);
        }
        $scope.graphData = function () {
            $scope.generatePiechart("piechart");
            $scope.generateBarchart("barchart");
            $scope.generateLinechart("linechart");
            $scope.generatePiechartOptIn("piechartopt");
            $scope.generateBarchart1("trendbarchart1");
            $scope.generateBarchart2("trendbarchart2");
        }
        $scope.generateGraph = function () {
            $timeout(function () {
                $scope.graphData();
            }, 3000);
        }
        $scope.setTabs = function (tab) {
            $scope.tab = tab;
            $scope.getChartConfig();
            $scope.generateGraph();
        }
        $scope.getChartConfig = function () {
            $http.get("data/googlecharts.json").success(function (data) {
                $scope.googlecharts = data;
                $scope.googlecharts.colors = $scope.colors;
            });
        }
        $scope.setTabs(1);
        $scope.init = function () {
            $scope.selyear = 2016;
            $scope.curselyear = 2016;
            $scope.selquarter = "1";
            $scope.curselquarter = "Q1";
            $scope.selmonth = 2;
            $scope.seldep = "CG";
            $scope.seldivision = "Mobility Management";
            $scope.selemployee = "Select Employee";
            $scope.sellocation = "Mumbai-Worli Office";
        }
        $scope.init();
        $scope.resetData = function (param) {
            $scope[param] = "";
            if (param == 'curselyear') {
                $scope.selyear = "";
            } else if (param == 'curselquarter') {
                $scope.selquarter = "";
                $scope.selmonth = "";
                $scope.curselmonth = "";
            } else if (param == 'curselmonth') {
                $scope.selmonth = "";
            } else if (param == 'curempname') {
                $scope.selemployee = "";
            } else if (param == 'curmngname') {
                $scope.selmanager = "";
                $scope.curempname = "";
                $scope.selemployee = "";
            }
        }
        $scope.byQuarter = function (month) {
            if (month.quater == $scope.selquarter) {
                return true;
            } else {
                return false;

            }
        }
        $scope.selectQuarter = function () {
            $scope.selquarter = $("#selectQuarter").val();
            if ($scope.selquarter == "1") {
                $scope.curselquarter = "Q1";
            } else if ($scope.selquarter == "2") {
                $scope.curselquarter = "Q2";
            }
            else if ($scope.selquarter == "3") {
                $scope.curselquarter = "Q3";
            }
            else if ($scope.selquarter == "4") {
                $scope.curselquarter = "Q4";
            } else {
                $scope.curselquarter = "";
            }
        }
        $scope.selectMonth = function () {
            for (var i = 0; i <= $scope.months.length; i++) {
                if ($scope.months[i].monthid == $scope.selmonth) {
                    $scope.curselmonth = $scope.months[i].name;
                    break;
                }
            }
        }
    }]);